# Golden Set — Referenzfälle für den Creator-Score-Bewertungskern

## Zweck

Das Golden Set ist das Regressionsnetz des Bewertungskerns. Es besteht aus
Referenzfällen, deren erwartete Ergebnisse **einmal berechnet und dann dauerhaft
fixiert** wurden.

Jede Änderung an Kriterien, Gewichten, Partial-Regeln, Finding-Templates oder
der Score-Berechnung wird automatisch gegen diese Fälle geprüft. Ändert sich ein
Ergebnis, schlägt der Test fehl — **auch wenn die Änderung beabsichtigt war**.

Das ist der Kern des Produktversprechens: *Derselbe Screenshot ergibt denselben
Score.* Ohne diesen Mechanismus ist die Zusage nicht überprüfbar, und stille
Verhaltensänderungen fallen erst durch Nutzerbeschwerden auf.

## Was ein Golden Case enthält

```
id            Eindeutige, stabile Kennung (gc-001-perfect)
description   Was der Fall abdeckt, für Menschen lesbar
platform      tiktok | instagram
input         ObservationPackage — die Eingabe für die Engine
expected      Fixiertes erwartetes Ergebnis
metadata      Versionen, Fixture-Kennung, Herkunftstyp, Notizen
```

Das `expected`-Objekt fixiert:

| Feld | Bedeutung |
|---|---|
| `totalScore` | Normalisierter Gesamtscore 0–100 |
| `displayable` | Ob der Score angezeigt werden darf (Coverage ≥ 60 %) |
| `coverageRatio` | Abdeckungsgrad 0.0–1.0 |
| `categoryScores` | Alle vier Werte je Kategorie (raw, checkedMax, normalized, fullMax) |
| `findingTemplateIds` | Alle Findings **in exakter Sortierreihenfolge** |
| `topFindingTemplateIds` | Die per `selectTopFindings(findings, 3)` ausgewählten |

Die Reihenfolge ist Teil der Erwartung. Eine geänderte Sortierung ist eine
Verhaltensänderung und muss auffallen.

## Synthetische Fälle vs. echte Referenzprofile

Es gibt zwei grundlegend verschiedene Prüfebenen. Das Golden Set deckt nur die
erste ab.

### Synthetische Fälle — im Repository

Sie prüfen: **Rechnet die Engine korrekt?**

Der Input ist ein `ObservationPackage` — eine Liste diskreter
Kriteriumszustände (`fulfilled`, `partial`, `missing`, `unavailable`). Es gibt
keine Bilder, keine Texte, keine Namen. Der Fall ist vollständig konstruiert,
um eine bestimmte Rechenregel oder einen Grenzfall abzudecken.

Diese Fälle liegen versioniert im Repository und laufen in CI bei jedem Commit.

### Echte Referenzprofile — außerhalb des Repositories

Sie prüfen: **Beobachtet die Pipeline korrekt?**

Also: Erkennt OCR die Bio richtig? Segmentiert der Layout-Erkenner das
Beitragsraster korrekt? Beurteilt das Sprachmodell die Zielgruppen-Frage so,
wie ein Mensch es täte?

Das ist eine völlig andere Frage, sie betrifft die Pipeline-Stufen 0–3, und sie
lässt sich nicht mit synthetischen Daten beantworten. Diese Prüfung kommt in
Phase 4 und arbeitet mit annotierten echten Screenshots — die **niemals im
Repository liegen**.

## Warum keine echten Screenshots im Repository

Profil-Screenshots enthalten personenbezogene Daten Dritter: Gesichter in
Feed-Kacheln, Namen, teils Kommentare. Sie sind das sensibelste Material, mit
dem VYRO umgeht.

Für sie gilt im Produktivbetrieb eine harte 24-Stunden-Löschfrist mit
dreifacher Absicherung. Ein Repository ist das genaue Gegenteil davon: Git
speichert jede Version dauerhaft, verteilt sie auf jeden Klon und macht sie
praktisch unlöschbar — ein einmal committetes Bild lässt sich nicht sauber
zurücknehmen.

Ein Screenshot im Git-Verlauf wäre damit ein dauerhafter Datenschutzverstoß,
der auch durch späteres Löschen der Datei nicht behoben wird.

**Deshalb:**

- Golden Cases enthalten ausschließlich `ObservationPackage`-Daten
- Der `fixtureId` verweist auf ein synthetisches Muster, nie auf ein reales Profil
- `sourceType` kennt nur `synthetic` und `synthetic_modeled` — es gibt bewusst
  keinen Wert für echte Profildaten
- Annotierte echte Screenshots (Phase 4) liegen in einer gesicherten
  Entwicklungsumgebung; im Repository liegen nur die abgeleiteten
  Annotationsdateien ohne Bildbezug

## Zielgrößen

| Phase | Anzahl | Zweck |
|---|---|---|
| **Entwicklung** | 10 | Grundlegende Rechenwege und Grenzfälle absichern |
| **Interne Alpha** | 50 | Kategorie-Kombinationen und Finding-Interaktionen abdecken |
| **Vor Launch** | 200 | Breite Abdeckung aller realistischen Zustandsmuster |

Die aktuellen 10 Fälle decken ab: Ober- und Untergrenze, Kategorietrennung in
beide Richtungen, isolierte Schwächen in Branding, Profilbild und Engagement,
beide Seiten der 60-Prozent-Anzeigeschwelle, sowie die Blockierregel bei
gemischten Severities.

## Umgang mit fehlschlagenden Golden Tests

Ein roter Golden Test bedeutet: **Das Verhalten der Engine hat sich geändert.**

1. **Prüfen, ob die Änderung beabsichtigt war.** Meist ist sie es nicht — dann
   liegt ein Fehler in der Engine vor und wird dort behoben.
2. **Falls beabsichtigt:** `SCORING_MODEL_VERSION` erhöhen, die erwarteten
   Werte bewusst neu berechnen und fixieren, `GOLDEN_SET_VERSION` erhöhen.
3. **Niemals** die `expected`-Werte anpassen, nur damit der Test wieder grün
   wird. Das entwertet das gesamte System.

Golden Cases werden nicht automatisch überschrieben. Es gibt bewusst keinen
`--update-snapshots`-Modus.

## Versionierung

```
SCORING_MODEL_VERSION   v1.0.0   Kriterien, Gewichte, Berechnung, Templates
GOLDEN_SET_VERSION      v1.0.0   Bestand und Erwartungswerte der Fälle
```

Beide sind unabhängig. Das Golden Set kann wachsen (neue Fälle), ohne dass sich
das Score-Modell ändert. Ändert sich das Score-Modell, müssen alle
Erwartungswerte neu fixiert werden.

Jeder Golden Case trägt beide Versionen in seinen Metadaten. Die Validierung
prüft, dass sie zur aktuellen Codebasis passen.

## Verwendung

```
validateGoldenSet(GOLDEN_CASES)   Strukturprüfung — ist der Fall wohlgeformt?
runGoldenCase(goldenCase)         Ausführung — stimmt das Ergebnis?
runGoldenSet(GOLDEN_CASES)        Alle Fälle
formatMismatches(result)          Lesbare Ausgabe: Feld, expected, actual
```

Die Strukturvalidierung und der Runner sind reine Funktionen ohne Datenbank,
Netzwerk oder KI — wie der gesamte Bewertungskern.
