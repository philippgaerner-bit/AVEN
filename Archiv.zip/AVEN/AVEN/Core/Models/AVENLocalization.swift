import Foundation

// MARK: - App language

/// AVEN intentionally defaults to English on first launch. The choice is stored
/// independently from the iPhone language so users can switch at any time.
enum AVENAppLanguage: String, CaseIterable, Identifiable {
    case english = "en"
    case german = "de"

    var id: String { rawValue }

    var title: String {
        switch self {
        case .english: return "English"
        case .german: return "Deutsch"
        }
    }

    var subtitle: String {
        switch self {
        case .english: return "English"
        case .german: return "German"
        }
    }

    var localeIdentifier: String { rawValue }
}

enum AVENLocalization {
    static let languageKey = "aven.language"

    static var currentLanguage: AVENAppLanguage {
        guard let raw = UserDefaults.standard.string(forKey: languageKey),
              let language = AVENAppLanguage(rawValue: raw) else {
            return .english
        }
        return language
    }

    static var isGerman: Bool { currentLanguage == .german }

    static func text(_ english: String, _ german: String) -> String {
        isGerman ? german : english
    }

    static var aiLanguageInstruction: String {
        switch currentLanguage {
        case .english:
            return "OUTPUT LANGUAGE: English. Every user-facing sentence, finding, task title, explanation, CTA and copy suggestion must be written in natural English. Keep protocol keys and machine-readable category IDs unchanged."
        case .german:
            return "AUSGABESPRACHE: Deutsch. Jeder nutzerseitige Satz, jedes Finding, jeder Aufgabentitel, jede Erklärung, CTA und Copy-Vorschlag muss in natürlichem Deutsch geschrieben sein. Protokoll-Schlüssel und maschinenlesbare Kategorie-IDs bleiben unverändert."
        }
    }
}

@inline(__always)
func L(_ english: String, _ german: String) -> String {
    AVENLocalization.text(english, german)
}

// MARK: - Transparent AVEN Score rubric

struct AVENScoreCriterionSpec: Identifiable, Hashable {
    let id: String
    let maxScore: Int
    let englishName: String
    let germanName: String

    var localizedName: String {
        L(englishName, germanName)
    }
}

enum AVENScoreRubric {
    static let criteria: [AVENScoreCriterionSpec] = [
        .init(id: "positioning", maxScore: 20,
              englishName: "Positioning & Niche",
              germanName: "Positionierung & Nische"),
        .init(id: "bio", maxScore: 20,
              englishName: "Bio & Value Proposition",
              germanName: "Bio & Nutzenversprechen"),
        .init(id: "branding", maxScore: 15,
              englishName: "Branding & Profile Identity",
              germanName: "Branding & Profilidentität"),
        .init(id: "cta", maxScore: 15,
              englishName: "CTA & Conversion",
              germanName: "CTA & Conversion"),
        .init(id: "content", maxScore: 20,
              englishName: "Content Clarity",
              germanName: "Content-Klarheit"),
        .init(id: "structure", maxScore: 10,
              englishName: "Profile Structure & Completeness",
              germanName: "Profilstruktur & Vollständigkeit")
    ]

    static let totalMaxScore = 100

    static func spec(for key: String?) -> AVENScoreCriterionSpec? {
        guard let key else { return nil }
        let normalized = key.lowercased().trimmingCharacters(in: .whitespacesAndNewlines)
        return criteria.first { $0.id == normalized }
    }

    static func inferredKey(from name: String) -> String? {
        let value = name.lowercased()
        if value.contains("position") || value.contains("nische") || value.contains("niche") { return "positioning" }
        if value.contains("bio") || value.contains("nutzen") || value.contains("value proposition") { return "bio" }
        if value.contains("branding") || value.contains("profilbild") || value.contains("identity") { return "branding" }
        if value.contains("cta") || value.contains("handlungsaufforder") || value.contains("conversion") { return "cta" }
        if value.contains("content") || value.contains("thema") || value.contains("clarity") { return "content" }
        if value.contains("struktur") || value.contains("structure") || value.contains("vollständig") || value.contains("complete") || value.contains("angepinnt") { return "structure" }
        return nil
    }

    static func localizedName(key: String?, fallback: String) -> String {
        if let spec = spec(for: key ?? inferredKey(from: fallback)) {
            return spec.localizedName
        }
        return fallback
    }
}

extension AnalysisDimension {
    var avenCriterionKey: String? {
        key ?? AVENScoreRubric.inferredKey(from: name)
    }

    var avenMaxScore: Int {
        maxScore ?? AVENScoreRubric.spec(for: avenCriterionKey)?.maxScore ?? 100
    }

    var localizedName: String {
        AVENScoreRubric.localizedName(key: avenCriterionKey, fallback: name)
    }

    var normalizedPercent: Int {
        guard score >= 0, avenMaxScore > 0 else { return -1 }
        return min(100, max(0, Int((Double(score) / Double(avenMaxScore) * 100).rounded())))
    }
}
