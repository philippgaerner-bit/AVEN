import Foundation

// ─── AVEN API client protocol ─────────────────────────────────────────────────

protocol AVENAPIClient {
    func getHomeData(period: HomeViewState.Period) async throws -> HomeData
}

// ─── Home data bundle ─────────────────────────────────────────────────────────

struct HomeData {
    let profile:   ProfileData
    let metrics:   MetricsData
    let score:     ScoreData
    let actions:   [ActionData]
}

struct ProfileData {
    let id:          String
    let platform:    String
    let username:    String
    let displayName: String
    let avatarURL:   String?
}

struct MetricsData {
    let followers:       Int;   let followersChange:  Double
    let views:           Int;   let viewsChange:      Double
    let likes:           Int;   let likesChange:      Double
}

struct ScoreData {
    let total:       Int
    let displayable: Bool
    let coverage:    Double
    let findings:    [FindingData]
    /// Per-dimension breakdown derived from analysis signals.
    /// value –1 means "not measurable from available data"
    let dimensions:  [DimensionData]
}

struct DimensionData {
    let name:   String
    let value:  Int     // 0–100 or –1 = unmeasurable
    let detail: String
    let tip:    String
}

struct FindingData {
    let templateId:          String
    let severity:            String
    let impact:              Int
    let priority:            Int
    let blockedByFoundation: Bool
    let title:               String
}

struct ActionData {
    let id:         String
    let title:      String
    let category:   String
    let impact:     Int
    let priority:   Int
    let severity:   String
    let isBlocked:  Bool
}

// ─── Stub client ──────────────────────────────────────────────────────────────
// MARK: - Integration Point: replace StubAVENAPIClient with RealAVENAPIClient
// that calls the AVEN backend with the period param:
//   GET /home?period=1d | 7d | 30d

final class StubAVENAPIClient: AVENAPIClient {

    func getHomeData(period: HomeViewState.Period) async throws -> HomeData {
        try await Task.sleep(nanoseconds: 300_000_000)

        let currentScore = AVENAnalysisStore.currentScore

        // Read real connected TikTok account if available
        struct StoredAccount: Decodable {
            let followers: Int; let following: Int; let likes: Int; let videoCount: Int
        }
        let real: StoredAccount? = {
            guard let data = UserDefaults.standard.data(forKey: "aven.connectedTikTokAccount"),
                  let a = try? JSONDecoder().decode(StoredAccount.self, from: data) else { return nil }
            return a
        }()

        // Period-specific metrics from the connected TikTok account only.
        // Until TikTok has returned verified counters, AVEN uses -1 internally so
        // the UI renders a dash instead of presenting a placeholder 0 as real data.
        let statsVerified = AVENTikTokStatsState.hasVerifiedStats
        let baseFollowers = statsVerified ? (real?.followers ?? 0) : -1
        let baseLikes     = statsVerified ? (real?.likes ?? 0) : -1
        let metrics = MetricsData(
            followers: baseFollowers, followersChange: 0,
            views: -1, viewsChange: 0,
            likes: baseLikes, likesChange: 0
        )

        // Build score dimensions and actions from last real analysis if available
        let record = AVENAnalysisStore.load()

        let dimensions: [DimensionData] = record?.dimensions.map {
            DimensionData(name: $0.name, value: $0.score,
                          detail: ($0.negatives.first ?? $0.positives.first ?? $0.tip),
                          tip: $0.tip)
        } ?? [
            DimensionData(name: "Profil & Bio",    value: -1,
                          detail: "Noch keine Analyse durchgeführt.",
                          tip: "Lade einen Profil-Screenshot hoch um diesen Bereich zu bewerten."),
            DimensionData(name: "Video-Einstieg",   value: -1,
                          detail: "Erfordert Video-Daten.",
                          tip: "Starte Videos mit einer Frage oder Überraschung in den ersten 2 Sek."),
            DimensionData(name: "Interaktionen",      value: -1,
                          detail: "Noch nicht bewertet – TikTok-Account verbinden.",
                          tip: "Stelle am Videoende eine konkrete Frage an deine Zuschauer."),
        ]

        // Actions: use the exact same 2–3 AVEN AI tasks as the Action Plan.
        // No deterministic filler tasks and no task-completion score mutation.
        let actions: [ActionData]
        if let rec = record,
           AVENAnalysisStore.hasCompletedAnalysis,
           let aiTasks = AVENAIActionPlanStore.load(for: rec) {
            actions = aiTasks.prefix(3).enumerated().map { index, task in
                ActionData(
                    id:       task.id,
                    title:    task.title,
                    category: task.category,
                    impact:   task.xp,
                    priority: index + 1,
                    severity: "ai",
                    isBlocked: false
                )
            }
        } else {
            actions = []
        }

        return HomeData(
            profile: ProfileData(
                id: "p1", platform: "tiktok",
                username: "@avencreator", displayName: "AVEN Creator", avatarURL: nil
            ),
            metrics: metrics,
            score: ScoreData(
                total: currentScore, displayable: true, coverage: record != nil ? 0.95 : 0.5,
                findings: [],
                dimensions: dimensions
            ),
            actions: actions
        )
    }
}
