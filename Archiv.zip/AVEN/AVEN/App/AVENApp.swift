import SwiftUI

// ─── AVEN App ─────────────────────────────────────────────────────────────────

@main
struct AVENApp: App {
    @StateObject private var container = AppContainer()
    @Environment(\.scenePhase) private var scenePhase
    @AppStorage("aven.appearance") private var appearanceRaw = AVENAppearance.light.rawValue
    @AppStorage("aven.language") private var languageRaw = AVENAppLanguage.english.rawValue

    private var appearance: AVENAppearance {
        AVENAppearance(rawValue: appearanceRaw) ?? .light
    }

    var body: some Scene {
        WindowGroup {
            AVENSplashWrapper {
                RootView()
                    .environmentObject(container)
                    .environment(\.locale, Locale(identifier: (AVENAppLanguage(rawValue: languageRaw) ?? .english).localeIdentifier))
            }
            .preferredColorScheme(appearance.colorScheme)
        }
        .onChange(of: scenePhase) { _, phase in
            if phase == .active {
                container.syncTikTokStats()
            }
        }
    }
}

// MARK: - AVEN splash
// The splash uses a dedicated 4K AVEN asset so no other in-app branding changes.
// Animation only affects presentation: scale, blur, opacity and glow.

private struct AVENSplashWrapper<Content: View>: View {
    let content: () -> Content
    @State private var showSplash = true
    @State private var splashOpacity: Double = 1

    var body: some View {
        ZStack {
            content()

            if showSplash {
                AVENSplashView()
                    .opacity(splashOpacity)
                    .ignoresSafeArea()
                    .onAppear {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.75) {
                            withAnimation(.easeOut(duration: 0.28)) {
                                splashOpacity = 0
                            }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.29) {
                                showSplash = false
                            }
                        }
                    }
            }
        }
    }
}

private struct AVENSplashView: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var logoVisible = false
    @State private var wordmarkVisible = false
    @State private var glowExpanded = false
    @State private var logoSettled = false

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            Circle()
                .fill(
                    RadialGradient(
                        colors: [
                            AVENColor.accentPurple.opacity(glowExpanded ? 0.20 : 0.04),
                            AVENColor.accentBlue.opacity(glowExpanded ? 0.07 : 0.01),
                            .clear
                        ],
                        center: .center,
                        startRadius: 6,
                        endRadius: 205
                    )
                )
                .frame(width: 420, height: 420)
                .scaleEffect(glowExpanded ? 1.05 : 0.72)
                .opacity(logoVisible ? 1 : 0)

            VStack(spacing: 17) {
                Image("AVENSplashMark")
                    .resizable()
                    .interpolation(.high)
                    .scaledToFit()
                    .frame(width: 154, height: 148)
                    .scaleEffect(logoSettled ? 1.0 : 0.76)
                    .rotationEffect(.degrees(logoSettled ? 0 : -1.8))
                    .offset(y: logoSettled ? 0 : 12)
                    .blur(radius: logoVisible ? 0 : 8)
                    .opacity(logoVisible ? 1 : 0)
                    .shadow(
                        color: AVENColor.accentPurple.opacity(glowExpanded ? 0.50 : 0.18),
                        radius: glowExpanded ? 30 : 12,
                        y: 2
                    )

                Text("AVEN")
                    .font(.system(size: 28, weight: .medium))
                    .tracking(10)
                    .foregroundColor(.white)
                    .offset(x: 5, y: wordmarkVisible ? 0 : 7)
                    .opacity(wordmarkVisible ? 1 : 0)
            }
        }
        .onAppear {
            guard !reduceMotion else {
                logoVisible = true
                logoSettled = true
                wordmarkVisible = true
                glowExpanded = true
                return
            }

            withAnimation(.easeOut(duration: 0.30)) {
                logoVisible = true
            }
            withAnimation(.spring(response: 0.72, dampingFraction: 0.70).delay(0.04)) {
                logoSettled = true
            }
            withAnimation(.easeOut(duration: 0.42).delay(0.34)) {
                wordmarkVisible = true
            }
            withAnimation(.easeInOut(duration: 0.72).delay(0.12)) {
                glowExpanded = true
            }
        }
    }
}
