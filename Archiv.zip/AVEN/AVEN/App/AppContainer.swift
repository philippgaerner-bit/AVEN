import SwiftUI
import Combine

// ─── Shared connected TikTok account ──────────────────────────────────────────

struct ConnectedTikTokAccount: Codable, Equatable {
    let openId:      String
    let username:    String   // with @ prefix
    let displayName: String
    let avatarUrl:   String?
    let followers:   Int
    let following:   Int
    let likes:       Int
    let videoCount:  Int
}

// ─── TikTok stats sync state ──────────────────────────────────────────────────
// A connected account and verified statistic counters are deliberately separate.
// This prevents a missing API field from being presented as a real "0" and keeps
// Challenges from awarding/advancing on placeholder values.

enum AVENTikTokStatsState {
    private static let verifiedKey = "aven.tiktok.statsVerified.v1"
    private static let errorKey = "aven.tiktok.lastStatsError.v1"

    static var hasVerifiedStats: Bool {
        UserDefaults.standard.bool(forKey: verifiedKey)
    }

    static var lastError: String {
        UserDefaults.standard.string(forKey: errorKey) ?? ""
    }

    static func markVerified() {
        UserDefaults.standard.set(true, forKey: verifiedKey)
        UserDefaults.standard.removeObject(forKey: errorKey)
    }

    static func setError(_ message: String) {
        UserDefaults.standard.set(message, forKey: errorKey)
    }

    static func clear() {
        UserDefaults.standard.removeObject(forKey: verifiedKey)
        UserDefaults.standard.removeObject(forKey: errorKey)
        UserDefaults.standard.removeObject(forKey: "aven.tiktok.lastSync")
    }
}

private struct TikTokStatsSnapshot {
    let followers: Int?
    let following: Int?
    let likes: Int?
    let videoCount: Int?
    let displayName: String?
    let username: String?
    let avatarURL: String?

    var hasAnyCounter: Bool {
        followers != nil || following != nil || likes != nil || videoCount != nil
    }
}

private enum TikTokStatsPayloadDecoder {
    private static let counterKeys = Set([
        "follower_count", "followerCount", "followers",
        "following_count", "followingCount", "following",
        "likes_count", "likesCount", "like_count", "likeCount", "likes",
        "video_count", "videoCount", "videos_count", "videosCount"
    ])

    static func decode(_ data: Data) -> TikTokStatsSnapshot? {
        guard let root = try? JSONSerialization.jsonObject(with: data) else { return nil }

        let dictionaries = collectDictionaries(root, depth: 0)
        guard let stats = dictionaries.first(where: { dictionary in
            !counterKeys.isDisjoint(with: dictionary.keys)
        }) else { return nil }

        return TikTokStatsSnapshot(
            followers: int(in: stats, keys: ["follower_count", "followerCount", "followers"]),
            following: int(in: stats, keys: ["following_count", "followingCount", "following"]),
            likes: int(in: stats, keys: ["likes_count", "likesCount", "like_count", "likeCount", "likes"]),
            videoCount: int(in: stats, keys: ["video_count", "videoCount", "videos_count", "videosCount"]),
            displayName: string(in: stats, keys: ["display_name", "displayName"]),
            username: string(in: stats, keys: ["username", "user_name", "unique_id"]),
            avatarURL: string(in: stats, keys: ["avatar_url", "avatarUrl", "avatar_url_100", "avatar_large_url"])
        )
    }

    private static func collectDictionaries(_ value: Any, depth: Int) -> [[String: Any]] {
        guard depth <= 5 else { return [] }
        if let dictionary = value as? [String: Any] {
            var result = [dictionary]
            for child in dictionary.values {
                result.append(contentsOf: collectDictionaries(child, depth: depth + 1))
            }
            return result
        }
        if let array = value as? [Any] {
            return array.flatMap { collectDictionaries($0, depth: depth + 1) }
        }
        return []
    }

    private static func int(in dictionary: [String: Any], keys: [String]) -> Int? {
        for key in keys {
            guard let raw = dictionary[key] else { continue }
            if let value = raw as? Int { return value }
            if let value = raw as? NSNumber { return value.intValue }
            if let value = raw as? String,
               let number = Int(value.trimmingCharacters(in: .whitespacesAndNewlines)) {
                return number
            }
        }
        return nil
    }

    private static func string(in dictionary: [String: Any], keys: [String]) -> String? {
        for key in keys {
            if let value = dictionary[key] as? String,
               !value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                return value
            }
        }
        return nil
    }
}

// ─── AppContainer — dependency injection root ─────────────────────────────────

@MainActor
final class AppContainer: ObservableObject {
    let apiClient: AVENAPIClient
    let videoCredits = VideoCreditsService()
    let authService  = AVENAuthService()
    let subscription = AVENSubscriptionService()

    @Published var selectedTab:       AppTab = .home
    @Published var showNewScan:       Bool   = false
    @Published var showCreationMenu:  Bool   = false
    @Published var showAIVideo:       Bool   = false
    @Published var showTikTokAccount: Bool   = false

    // Single source of truth for the connected TikTok account.
    private let tikTokAccountKey = "aven.connectedTikTokAccount"

    @Published var connectedTikTokAccount: ConnectedTikTokAccount? {
        didSet { persist(connectedTikTokAccount) }
    }

    var isTikTokConnected: Bool { connectedTikTokAccount != nil }

    func setConnectedTikTokAccount(_ account: ConnectedTikTokAccount) {
        connectedTikTokAccount = account

        // If the OAuth exchange already returned counters, treat that payload as
        // real and start Challenges from the NEXT milestone, never retroactively.
        let exchangeContainedStats = account.followers > 0 || account.following > 0 || account.likes > 0 || account.videoCount > 0
        if exchangeContainedStats {
            if !AVENTikTokStatsState.hasVerifiedStats {
                AVENTikTokStatsState.markVerified()
                AVENGrowthChallengeEngine.rebase(account: account)
            } else {
                AVENGrowthChallengeEngine.sync(account: account)
            }
            UserDefaults.standard.set(Date(), forKey: "aven.tiktok.lastSync")
        }

        // Refresh immediately after connection. OAuth itself remains unchanged;
        // only the already-authorized account counters are requested here.
        syncTikTokStats()
    }

    func disconnectTikTok() {
        connectedTikTokAccount = nil
        AVENTikTokStatsState.clear()
        AVENGrowthChallengeEngine.reset()
    }

    private func persist(_ account: ConnectedTikTokAccount?) {
        if let account, let data = try? JSONEncoder().encode(account) {
            UserDefaults.standard.set(data, forKey: tikTokAccountKey)
        } else {
            UserDefaults.standard.removeObject(forKey: tikTokAccountKey)
        }
    }

    // TikTok OAuth/stats intentionally stay on the existing TikTok backend.
    // AI calls use AVENBackend / AIBackendURL separately.
    private var tiktokBackendBase: String {
        if let path = Bundle.main.path(forResource: "AVENConfig", ofType: "plist"),
           let plist = NSDictionary(contentsOfFile: path),
           let raw = plist["BackendURL"] as? String,
           !raw.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            return raw.hasSuffix("/") ? String(raw.dropLast()) : raw
        }
        return "https://muddy-fire-2876.philipp-gaerner.workers.dev"
    }

    /// Statistics may be served by the existing TikTok worker or by the newer
    /// AVEN backend. OAuth itself stays on BackendURL; this list is read-only and
    /// only used to retrieve already-authorized TikTok counters.
    private var tiktokStatsBackendBases: [String] {
        var bases = [tiktokBackendBase]
        if let path = Bundle.main.path(forResource: "AVENConfig", ofType: "plist"),
           let plist = NSDictionary(contentsOfFile: path),
           let raw = plist["AIBackendURL"] as? String,
           !raw.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            let normalized = raw.hasSuffix("/") ? String(raw.dropLast()) : raw
            if !bases.contains(normalized) { bases.append(normalized) }
        }
        return bases
    }

    private var syncTimer: Timer?

    init() {
        self.apiClient = AppContainer.makeAPIClient()

        if let data = UserDefaults.standard.data(forKey: tikTokAccountKey),
           let account = try? JSONDecoder().decode(ConnectedTikTokAccount.self, from: data) {
            self._connectedTikTokAccount = Published(initialValue: account)
            if AVENTikTokStatsState.hasVerifiedStats {
                AVENGrowthChallengeEngine.bootstrap(account: account)
            }
        }

        scheduleSyncIfNeeded()
    }

    func makeHomeViewModel() -> HomeViewModel {
        HomeViewModel(apiClient: apiClient)
    }

    // ── TikTok Stats Sync ─────────────────────────────────────────────────────
    // TikTok's v2 User Info response normally nests counters in data.user.
    // The AVEN worker may also flatten them. This decoder accepts both shapes and
    // only marks a sync successful when at least one counter field truly exists.

    func syncTikTokStats() {
        guard let account = connectedTikTokAccount, !account.openId.isEmpty else { return }

        Task {
            var lastFailure = "Die TikTok-Verbindung ist aktiv, aber es wurden noch keine Statistikfelder geliefert."

            // Try the existing TikTok worker first. If that worker only returns
            // identity data, also try the newer AVEN backend. Each backend is
            // tested with and without an explicit fields parameter because older
            // worker versions accepted only open_id.
            for base in tiktokStatsBackendBases {
                for includeFields in [true, false] {
                    guard var components = URLComponents(string: "\(base)/auth/tiktok/userinfo") else { continue }
                    var items = [URLQueryItem(name: "open_id", value: account.openId)]
                    if includeFields {
                        items.append(URLQueryItem(
                            name: "fields",
                            value: "open_id,display_name,avatar_url,username,follower_count,following_count,likes_count,video_count"
                        ))
                    }
                    components.queryItems = items
                    guard let url = components.url else { continue }

                    do {
                        var request = URLRequest(url: url, timeoutInterval: 20)
                        request.cachePolicy = .reloadIgnoringLocalCacheData
                        let (data, response) = try await URLSession.shared.data(for: request)
                        guard let http = response as? HTTPURLResponse else {
                            lastFailure = "Keine gültige Antwort vom TikTok-Backend."
                            continue
                        }
                        guard (200..<300).contains(http.statusCode) else {
                            let raw = String(data: data, encoding: .utf8) ?? ""
                            if http.statusCode == 401 || http.statusCode == 403 || raw.localizedCaseInsensitiveContains("scope") {
                                lastFailure = "TikTok-Statistikzugriff fehlt. Öffne den TikTok Account in AVEN und tippe auf ‘Statistiken aktivieren’."
                            } else {
                                lastFailure = "TikTok-Stats konnten nicht aktualisiert werden (HTTP \(http.statusCode))."
                            }
                            continue
                        }

                        guard let stats = TikTokStatsPayloadDecoder.decode(data), stats.hasAnyCounter else {
                            lastFailure = "TikTok ist verbunden, aber der aktuelle Login hat noch keinen user.info.stats-Zugriff. Bitte Statistikzugriff einmal aktivieren."
                            continue
                        }

                        await MainActor.run {
                            let wasVerified = AVENTikTokStatsState.hasVerifiedStats
                            let resolvedUsername: String = {
                                guard let username = stats.username?.trimmingCharacters(in: .whitespacesAndNewlines), !username.isEmpty else {
                                    return account.username
                                }
                                return username.hasPrefix("@") ? username : "@\(username)"
                            }()

                            let updated = ConnectedTikTokAccount(
                                openId: account.openId,
                                username: resolvedUsername,
                                displayName: stats.displayName ?? account.displayName,
                                avatarUrl: stats.avatarURL ?? account.avatarUrl,
                                followers: max(0, stats.followers ?? account.followers),
                                following: max(0, stats.following ?? account.following),
                                likes: max(0, stats.likes ?? account.likes),
                                videoCount: max(0, stats.videoCount ?? account.videoCount)
                            )

                            connectedTikTokAccount = updated
                            AVENTikTokStatsState.markVerified()
                            UserDefaults.standard.set(Date(), forKey: "aven.tiktok.lastSync")

                            if wasVerified {
                                AVENGrowthChallengeEngine.sync(account: updated)
                            } else {
                                AVENGrowthChallengeEngine.rebase(account: updated)
                            }

                            NotificationCenter.default.post(name: .analysisDidComplete, object: nil)
                            NotificationCenter.default.post(name: .growthMissionDidUpdate, object: nil)
                        }
                        return
                    } catch {
                        lastFailure = "TikTok-Stats konnten gerade nicht synchronisiert werden: \(error.localizedDescription)"
                    }
                }
            }

            AVENTikTokStatsState.setError(lastFailure)
            NotificationCenter.default.post(name: .growthMissionDidUpdate, object: nil)
        }
    }

    /// Free: refresh on app foreground. Pro: every 15 min. Pro+: every 5 min.
    func scheduleSyncIfNeeded() {
        syncTimer?.invalidate()
        syncTimer = nil

        let interval: TimeInterval
        switch videoCredits.currentPlan {
        case .free:
            return
        case .pro:
            interval = 15 * 60
        case .proPlus:
            interval = 5 * 60
        }

        syncTimer = Timer.scheduledTimer(withTimeInterval: interval, repeats: true) { [weak self] _ in
            self?.syncTikTokStats()
        }
    }
}

enum AppTab: Hashable {
    case home, analytics, create, actionPlan, profile
}

extension AppContainer {
    static var preview: AppContainer { AppContainer() }
}
