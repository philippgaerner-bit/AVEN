import Foundation
import Combine

// ─── HomeViewModel ────────────────────────────────────────────────────────────
// All business logic for the Homescreen lives here.
// Views are dumb — they only read @Published state and call methods.

@MainActor
final class HomeViewModel: ObservableObject {
    @Published var state: HomeViewState = .empty

    private let apiClient: AVENAPIClient

    init(apiClient: AVENAPIClient) {
        self.apiClient = apiClient
        // Refresh home data whenever an analysis completes (score + metrics update)
        NotificationCenter.default.addObserver(
            forName: .analysisDidComplete,
            object:  nil,
            queue:   .main
        ) { [weak self] _ in
            Task { @MainActor [weak self] in await self?.load() }
        }
    }

    // ── Actions ───────────────────────────────────────────────────────────────

    func load() async {
        state.isLoading = true
        state.error     = nil
        do {
            let data  = try await apiClient.getHomeData(period: state.period)
            state     = Self.map(data: data, period: state.period)
        } catch {
            state.isLoading = false
            state.error = L("Data could not be loaded.", "Daten konnten nicht geladen werden.")
        }
    }

    func selectPeriod(_ period: HomeViewState.Period) {
        state.period = period
        Task { await load() }
    }

    // ── Mapping (static → testable without MainActor) ─────────────────────────

    static func map(data: HomeData, period: HomeViewState.Period) -> HomeViewState {
        let profile  = mapProfile(data.profile)
        let metrics  = mapMetrics(data.metrics)
        let score    = mapScore(data.score)
        let actions  = mapActions(data.actions)

        return HomeViewState(
            profile:   profile,
            metrics:   metrics,
            score:     score,
            actions:   actions,
            period:    period,
            isLoading: false,
            error:     nil
        )
    }

    static func mapProfile(_ p: ProfileData) -> ConnectedProfile {
        let platform: ConnectedProfile.SocialPlatform = p.platform == "instagram" ? .instagram : .tiktok
        return ConnectedProfile(
            id:          p.id,
            platform:    platform,
            username:    p.username,
            displayName: p.displayName,
            avatarURL:   p.avatarURL.flatMap { URL(string: $0) }
        )
    }

    static func mapMetrics(_ m: MetricsData) -> [ProfileMetric] {
        func metric(_ label: String, _ value: Int, _ change: Double) -> ProfileMetric {
            ProfileMetric(
                label: label,
                value: formatCount(value),
                change: value < 0 ? "–" : formatChange(change),
                isPositive: change >= 0
            )
        }
        return [
            metric(L("Followers", "Follower"), m.followers, m.followersChange),
            metric("Views", m.views, m.viewsChange),
            metric("Likes", m.likes, m.likesChange),
        ]
    }

    static func mapScore(_ s: ScoreData) -> AVENScore {
        let status: String
        let explanation: String
        switch s.total {
        case 80...100:
            status = L("Strong", "Stark");        explanation = L("Your profile is set up very well.", "Dein Profil ist sehr gut aufgestellt.")
        case 60...79:
            status = L("Good", "Gut");          explanation = L("Solid foundation with clear growth levers.", "Solide Basis mit klaren Wachstumshebeln.")
        case 40...59:
            status = L("Needs improvement", "Verbesserbar"); explanation = L("Fundamental issues are limiting your growth.", "Grundlegende Probleme begrenzen dein Wachstum.")
        default:
            status = L("Critical", "Kritisch");     explanation = L("Important foundation issues are blocking the rest.", "Wichtige Fundament-Issues blockieren den Rest.")
        }
        let dims = s.dimensions.map {
            ScoreDimension(name: $0.name, value: $0.value, detail: $0.detail, tip: $0.tip)
        }
        return AVENScore(total: s.total, status: status, explanation: explanation,
                         trend: .stable, dimensions: dims)
    }

    static func mapActions(_ raw: [ActionData]) -> [GrowthActionItem] {
        raw
            .filter { !$0.isBlocked || $0.severity != "polish" }
            .sorted { $0.priority < $1.priority }
            .map { a in
                let sev: GrowthActionItem.Severity = {
                    switch a.severity {
                    case "foundation": return .foundation
                    case "lever":      return .lever
                    default:           return .polish
                    }
                }()
                return GrowthActionItem(
                    id: a.id, title: a.title, category: a.category,
                    impact: a.impact, priority: a.priority,
                    severity: sev, isBlocked: a.isBlocked
                )
            }
    }

    // ── Formatting helpers ────────────────────────────────────────────────────

    static func formatCount(_ n: Int) -> String {
        if n < 0 { return "–" }
        switch n {
        case 1_000_000...: return String(format: "%.1fM", Double(n) / 1_000_000)
        case 1_000...:     return String(format: "%.1fK", Double(n) / 1_000)
        default:           return "\(n)"
        }
    }

    static func formatChange(_ pct: Double) -> String {
        let sign = pct >= 0 ? "+" : ""
        return String(format: "%@%.1f%%", sign, pct)
    }

    static func scoreStatus(for total: Int) -> String {
        switch total {
        case 80...100: return "Stark"
        case 60...79:  return "Gut"
        case 40...59:  return "Verbesserbar"
        default:       return "Kritisch"
        }
    }
}
