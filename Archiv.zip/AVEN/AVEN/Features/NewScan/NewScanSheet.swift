import SwiftUI
import PhotosUI
import UIKit

// ─── New profile analysis ─────────────────────────────────────────────────────
// One user-visible operation:
// 1) Vision/OCR extracts evidence from the real screenshot.
// 2) AVEN AI evaluates that evidence, decides the final 20–100 score, writes the
//    strengths/weaknesses and creates 2–3 concrete coaching tasks.
// Local OCR is evidence only. A failed AI call is never shown as a finished AI result.

struct NewScanSheet: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var vm = ScanViewModel()

    var body: some View {
        ZStack {
            AVENColor.backgroundPrimary.ignoresSafeArea()

            Group {
                switch vm.state {
                case .idle:
                    ScanIdleView(vm: vm)
                case .imagePicked:
                    ScanPreviewView(vm: vm)
                case .analyzing:
                    ScanAnalyzingView(stage: vm.analysisStage)
                case .result(let result):
                    ScanResultView(result: result, vm: vm) { dismiss() }
                case .failed(let message):
                    ScanFailedView(message: message, vm: vm)
                }
            }
            .animation(.easeInOut(duration: 0.25), value: vm.stateTag)
        }
        .presentationDetents([.large])
        .presentationCornerRadius(28)
        .presentationBackground(AVENColor.backgroundPrimary)
    }
}

// MARK: - Idle

private struct ScanIdleView: View {
    @ObservedObject var vm: ScanViewModel
    @State private var photoItem: PhotosPickerItem?
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(spacing: AVENSpacing.xl) {
            ScanDragHandle()
            Spacer()

            ZStack {
                Circle()
                    .fill(
                        LinearGradient(
                            colors: [AVENColor.accentPurple.opacity(0.18), AVENColor.accentBlue.opacity(0.09)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(width: 100, height: 100)
                Image(systemName: "camera.viewfinder")
                    .font(.system(size: 42, weight: .medium))
                    .foregroundStyle(
                        LinearGradient(
                            colors: [AVENColor.accentPurple, AVENColor.accentBlue],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
            }

            VStack(spacing: 9) {
                Text("Neue Profilanalyse")
                    .font(AVENFont.display(26))
                    .foregroundColor(AVENColor.textPrimary)

                Text(L("Upload a current screenshot of your TikTok profile. AVEN analyzes strengths, weaknesses, your score and the next concrete steps in one pass.", "Lade einen aktuellen Screenshot deines TikTok-Profils hoch. AVEN analysiert Stärken, Schwächen, Score und deine nächsten konkreten Schritte in einem Durchgang."))
                    .font(AVENFont.body(14))
                    .foregroundColor(AVENColor.textSecondary)
                    .multilineTextAlignment(.center)
                    .lineSpacing(4)
                    .padding(.horizontal, 24)
            }

            Spacer()

            VStack(spacing: 10) {
                PhotosPicker(selection: $photoItem, matching: .images, photoLibrary: .shared()) {
                    Label(L("Choose screenshot", "Screenshot auswählen"), systemImage: "photo")
                        .font(AVENFont.body(16, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 15)
                        .background(
                            LinearGradient(
                                colors: [AVENColor.accentPurple, AVENColor.accentBlue],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .clipShape(RoundedRectangle(cornerRadius: AVENRadius.md, style: .continuous))
                        .shadow(color: AVENColor.accentPurple.opacity(0.25), radius: 12, y: 4)
                }
                .buttonStyle(.plain)
                .onChange(of: photoItem) { _, item in
                    Task { await vm.loadImage(from: item) }
                }

                Button("Abbrechen") { dismiss() }
                    .font(AVENFont.body(14))
                    .foregroundColor(AVENColor.textSecondary)
                    .padding(.vertical, 10)
            }
            .padding(.horizontal, 18)
            .padding(.bottom, 18)
        }
    }
}

// MARK: - Preview

private struct ScanPreviewView: View {
    @ObservedObject var vm: ScanViewModel
    @EnvironmentObject private var container: AppContainer
    @State private var showPaywall = false

    private var image: UIImage? {
        if case .imagePicked(let image) = vm.state { return image }
        return nil
    }

    var body: some View {
        VStack(spacing: 18) {
            ScanDragHandle()

            VStack(spacing: 5) {
                Text("Screenshot bereit")
                    .font(AVENFont.display(22))
                    .foregroundColor(AVENColor.textPrimary)
                Text("AVEN nutzt nur das, was im Screenshot und in deinen verbundenen TikTok-Daten wirklich erkennbar ist.")
                    .font(AVENFont.body(11.5))
                    .foregroundColor(AVENColor.textSecondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 24)
            }

            if let image {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(maxHeight: 360)
                    .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 18, style: .continuous)
                            .strokeBorder(AVENColor.borderSubtle, lineWidth: 0.7)
                    )
                    .padding(.horizontal, 18)
            }

            Spacer()

            VStack(spacing: 10) {
                AVENPrimaryButton(title: L("Analyze with AVEN AI", "Mit AVEN AI analysieren"), icon: "sparkles") {
                    guard container.subscription.canAnalyzeProfile else {
                        showPaywall = true
                        return
                    }
                    Task { await vm.startAnalysis(subscription: container.subscription) }
                }

                Button(L("Choose another image", "Anderes Bild wählen")) { vm.reset() }
                    .font(AVENFont.body(14))
                    .foregroundColor(AVENColor.textSecondary)
                    .padding(.vertical, 10)
            }
            .padding(.horizontal, 18)
            .padding(.bottom, 18)
        }
        .sheet(isPresented: $showPaywall) { PaywallView() }
    }
}

// MARK: - Analyzing

private struct ScanAnalyzingView: View {
    let stage: ScanAnalysisStage
    @State private var pulse = false
    @State private var rotate = false

    var body: some View {
        VStack(spacing: 24) {
            ScanDragHandle()
            Spacer()

            ZStack {
                Circle()
                    .stroke(AVENColor.accentPurple.opacity(0.12), lineWidth: 1)
                    .frame(width: 142, height: 142)
                    .scaleEffect(pulse ? 1.08 : 0.96)

                Circle()
                    .fill(
                        RadialGradient(
                            colors: [AVENColor.accentPurple.opacity(0.18), AVENColor.accentBlue.opacity(0.04), .clear],
                            center: .center,
                            startRadius: 5,
                            endRadius: 62
                        )
                    )
                    .frame(width: 120, height: 120)

                Circle()
                    .trim(from: 0.08, to: 0.74)
                    .stroke(
                        LinearGradient(
                            colors: [AVENColor.accentPurple, AVENColor.accentBlue],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ),
                        style: StrokeStyle(lineWidth: 4, lineCap: .round)
                    )
                    .frame(width: 86, height: 86)
                    .rotationEffect(.degrees(rotate ? 360 : 0))

                Image(systemName: "sparkles")
                    .font(.system(size: 28, weight: .medium))
                    .foregroundStyle(
                        LinearGradient(
                            colors: [AVENColor.accentPurple, AVENColor.accentBlue],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
            }

            VStack(spacing: 7) {
                Text("AVEN analysiert dein Profil")
                    .font(AVENFont.display(22))
                    .foregroundColor(AVENColor.textPrimary)

                Text(stage.label)
                    .font(AVENFont.body(13))
                    .foregroundColor(AVENColor.textSecondary)
                    .contentTransition(.opacity)
            }

            VStack(spacing: 8) {
                ScanStageRow(title: L("Reading profile evidence", "Profil-Evidenz erkennen"), done: stage.rawValue >= 1)
                ScanStageRow(title: L("Evaluating strengths & weaknesses", "Stärken & Schwächen bewerten"), done: stage.rawValue >= 2)
                ScanStageRow(title: L("Creating score & Action Plan", "Score & Aktionsplan erstellen"), done: stage.rawValue >= 3)
            }
            .padding(.horizontal, 44)

            Spacer()
            Spacer()
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 1.05).repeatForever(autoreverses: true)) { pulse = true }
            withAnimation(.linear(duration: 1.4).repeatForever(autoreverses: false)) { rotate = true }
        }
    }
}

private struct ScanStageRow: View {
    let title: String
    let done: Bool

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: done ? "checkmark.circle.fill" : "circle")
                .font(.system(size: 12, weight: .semibold))
                .foregroundColor(done ? AVENColor.accentPurple : AVENColor.textMuted)
            Text(title)
                .font(AVENFont.body(11.5, weight: done ? .medium : .regular))
                .foregroundColor(done ? AVENColor.textPrimary : AVENColor.textMuted)
            Spacer()
        }
    }
}

// MARK: - Result

private struct ScanResultView: View {
    let result: ScanAnalysisResult
    @ObservedObject var vm: ScanViewModel
    let dismiss: () -> Void
    @EnvironmentObject private var container: AppContainer
    @State private var appeared = false

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 15) {
                ScanDragHandle()

                HStack(spacing: 6) {
                    Image(systemName: "sparkles")
                    Text("AVEN AI PROFILANALYSE")
                }
                .font(.system(size: 9.5, weight: .bold, design: .rounded))
                .tracking(0.7)
                .foregroundColor(AVENColor.accentPurple)
                .padding(.horizontal, 10)
                .padding(.vertical, 5)
                .background(AVENColor.accentPurple.opacity(0.08))
                .clipShape(Capsule())

                VStack(spacing: 8) {
                    Text(L("Your AVEN Score", "Dein AVEN Score"))
                        .font(AVENFont.body(13))
                        .foregroundColor(AVENColor.textSecondary)

                    ScoreArcView(score: appeared ? result.score : 0, size: 158)
                        .animation(.spring(response: 1.0, dampingFraction: 0.74), value: appeared)

                    Text(result.score == 100 ? "Perfect Profile" : result.status)
                        .font(AVENFont.display(21))
                        .foregroundStyle(
                            LinearGradient(
                                colors: [AVENColor.accentPurple, AVENColor.accentBlue],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                }

                if !result.dimensions.isEmpty {
                    ScanScoreBreakdownCard(dimensions: result.dimensions, total: result.score)
                }

                ScanFindingCard(title: L("Strengths", "Stärken"), icon: "checkmark.circle.fill", items: result.strengths, positive: true)

                if !result.weaknesses.isEmpty {
                    ScanFindingCard(title: L("Improvement potential", "Verbesserungspotenzial"), icon: "arrow.up.right.circle.fill", items: result.weaknesses, positive: false)
                }

                if !result.recommendedBio.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    ScanBioCard(bio: result.recommendedBio)
                }

                if result.score == 100 {
                    HStack(spacing: 10) {
                        Image(systemName: "trophy.fill")
                            .foregroundColor(AVENColor.textPositive)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(L("AVEN Challenge completed", "AVEN Challenge bestanden"))
                                .font(AVENFont.body(13, weight: .semibold))
                                .foregroundColor(AVENColor.textPrimary)
                            Text(L("The current analysis found no relevant profile weakness.", "Die aktuelle Analyse hat keine relevante Profil-Schwäche mehr erkannt."))
                                .font(AVENFont.body(10.5))
                                .foregroundColor(AVENColor.textSecondary)
                        }
                        Spacer()
                    }
                    .padding(13)
                    .background(AVENColor.textPositive.opacity(0.07))
                    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                }

                VStack(spacing: 9) {
                    AVENPrimaryButton(title: result.score == 100 ? L("Open Action Plan", "Zum Aktionsplan") : L("View concrete tasks", "Konkrete Aufgaben ansehen"), icon: "checklist") {
                        dismiss()
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.30) {
                            container.selectedTab = .actionPlan
                        }
                    }

                    Button(L("Start new analysis", "Neue Analyse starten")) { vm.reset() }
                        .font(AVENFont.body(14))
                        .foregroundColor(AVENColor.textSecondary)
                        .padding(.vertical, 10)
                }
                .padding(.bottom, 24)
            }
            .padding(.horizontal, 16)
        }
        .onAppear { withAnimation { appeared = true } }
    }
}

private struct ScanScoreBreakdownCard: View {
    let dimensions: [AnalysisDimension]
    let total: Int

    var body: some View {
        AVENCard {
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(L("How your score is built", "So setzt sich dein Score zusammen"))
                            .font(AVENFont.body(14, weight: .semibold))
                            .foregroundColor(AVENColor.textPrimary)
                        Text(L("Every point comes from one visible profile criterion.", "Jeder Punkt stammt aus einem sichtbaren Profil-Kriterium."))
                            .font(AVENFont.body(10.5))
                            .foregroundColor(AVENColor.textSecondary)
                    }
                    Spacer()
                    Text("\(total)/100")
                        .font(.system(size: 14, weight: .bold, design: .rounded))
                        .foregroundColor(AVENColor.accentPurple)
                }

                ForEach(dimensions, id: \.avenCriterionKey) { dimension in
                    VStack(alignment: .leading, spacing: 5) {
                        HStack {
                            Text(dimension.localizedName)
                                .font(AVENFont.body(11.5, weight: .medium))
                                .foregroundColor(AVENColor.textPrimary)
                            Spacer()
                            Text("\(max(0, dimension.score))/\(dimension.avenMaxScore)")
                                .font(AVENFont.body(10.5, weight: .bold))
                                .foregroundColor(dimension.score == dimension.avenMaxScore ? AVENColor.textPositive : AVENColor.accentPurple)
                        }

                        GeometryReader { geo in
                            ZStack(alignment: .leading) {
                                Capsule().fill(AVENColor.backgroundSecondary)
                                Capsule()
                                    .fill(LinearGradient(colors: [AVENColor.accentPurple, AVENColor.accentBlue], startPoint: .leading, endPoint: .trailing))
                                    .frame(width: geo.size.width * CGFloat(max(0, dimension.normalizedPercent)) / 100)
                            }
                        }
                        .frame(height: 5)

                        if !dimension.tip.isEmpty {
                            Text(dimension.tip)
                                .font(AVENFont.body(9.8))
                                .foregroundColor(AVENColor.textSecondary)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    }
                }

                if total < 100 {
                    Text(L("\(100 - total) points to Perfect Profile — the tasks below target exactly these gaps.", "Noch \(100 - total) Punkte bis Perfect Profile – die Aufgaben unten zielen genau auf diese Lücken."))
                        .font(AVENFont.body(10.5, weight: .semibold))
                        .foregroundColor(AVENColor.accentPurple)
                }
            }
        }
    }
}

private struct ScanFindingCard: View {
    let title: String
    let icon: String
    let items: [String]
    let positive: Bool

    var body: some View {
        AVENCard {
            VStack(alignment: .leading, spacing: 10) {
                HStack(spacing: 7) {
                    Image(systemName: icon)
                        .foregroundColor(positive ? AVENColor.textPositive : AVENColor.accentPurple)
                    Text(title)
                        .font(AVENFont.body(14, weight: .semibold))
                        .foregroundColor(AVENColor.textPrimary)
                }

                if items.isEmpty {
                    Text(L("No reliable assessment available.", "Keine sichere Aussage verfügbar."))
                        .font(AVENFont.body(12))
                        .foregroundColor(AVENColor.textMuted)
                } else {
                    ForEach(items, id: \.self) { item in
                        HStack(alignment: .top, spacing: 8) {
                            Circle()
                                .fill(positive ? AVENColor.textPositive : AVENColor.accentPurple)
                                .frame(width: 5, height: 5)
                                .padding(.top, 6)
                            Text(item)
                                .font(AVENFont.body(12))
                                .foregroundColor(AVENColor.textSecondary)
                                .lineSpacing(3)
                        }
                    }
                }
            }
        }
    }
}

private struct ScanBioCard: View {
    let bio: String
    @State private var copied = false

    var body: some View {
        AVENCard(accentBorder: true) {
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    Label(L("AVEN Bio suggestion", "AVEN Bio-Vorschlag"), systemImage: "text.quote")
                        .font(AVENFont.body(14, weight: .semibold))
                        .foregroundColor(AVENColor.textPrimary)
                    Spacer()
                    Button {
                        UIPasteboard.general.string = bio
                        withAnimation { copied = true }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                            withAnimation { copied = false }
                        }
                    } label: {
                        Label(copied ? "Kopiert" : "Kopieren", systemImage: copied ? "checkmark" : "doc.on.doc")
                            .font(AVENFont.body(10.5, weight: .semibold))
                            .foregroundColor(copied ? AVENColor.textPositive : AVENColor.accentPurple)
                    }
                }

                Text(bio)
                    .font(AVENFont.body(13))
                    .foregroundColor(AVENColor.textSecondary)
                    .lineSpacing(4)
                    .textSelection(.enabled)
            }
        }
    }
}

// MARK: - Failure

private struct ScanFailedView: View {
    let message: String
    @ObservedObject var vm: ScanViewModel

    var body: some View {
        VStack(spacing: 20) {
            ScanDragHandle()
            Spacer()

            Image(systemName: "exclamationmark.triangle")
                .font(.system(size: 44, weight: .medium))
                .foregroundColor(AVENColor.textNegative)

            VStack(spacing: 8) {
                Text("Analyse nicht abgeschlossen")
                    .font(AVENFont.display(21))
                    .foregroundColor(AVENColor.textPrimary)

                Text(message)
                    .font(AVENFont.body(13))
                    .foregroundColor(AVENColor.textSecondary)
                    .multilineTextAlignment(.center)
                    .lineSpacing(4)
                    .padding(.horizontal, 30)
            }

            Text(L("Your existing AVEN Score and Action Plan were not changed.", "Dein bisheriger AVEN Score und Aktionsplan wurden nicht verändert."))
                .font(AVENFont.body(10.5))
                .foregroundColor(AVENColor.textMuted)
                .multilineTextAlignment(.center)

            Spacer()

            AVENPrimaryButton(title: "Erneut versuchen", icon: "arrow.clockwise") { vm.reset() }
                .padding(.horizontal, 20)
                .padding(.bottom, 20)
        }
    }
}

private struct ScanDragHandle: View {
    var body: some View {
        Capsule()
            .fill(AVENColor.borderSubtle)
            .frame(width: 36, height: 4)
            .padding(.top, 8)
    }
}

// MARK: - ViewModel

enum ScanAnalysisStage: Int {
    case evidence = 1
    case evaluation = 2
    case plan = 3

    var label: String {
        switch self {
        case .evidence: return L("Detecting profile evidence …", "Profil-Evidenz wird erkannt …")
        case .evaluation: return L("AVEN AI is evaluating strengths and weaknesses …", "AVEN AI bewertet Stärken und Schwächen …")
        case .plan: return L("Creating score and concrete tasks …", "Score und konkrete Aufgaben werden erstellt …")
        }
    }
}

@MainActor
final class ScanViewModel: ObservableObject {
    @Published var state: ScanFlowState = .idle
    @Published var analysisStage: ScanAnalysisStage = .evidence

    var stateTag: Int {
        switch state {
        case .idle: return 0
        case .imagePicked: return 1
        case .analyzing: return 2
        case .result: return 3
        case .failed: return 4
        }
    }

    func loadImage(from item: PhotosPickerItem?) async {
        guard let item else { return }
        guard let data = try? await item.loadTransferable(type: Data.self),
              let image = UIImage(data: data) else {
            state = .failed(L("The image could not be loaded.", "Das Bild konnte nicht geladen werden."))
            return
        }
        withAnimation { state = .imagePicked(image) }
    }

    func startAnalysis(subscription: AVENSubscriptionService) async {
        guard case .imagePicked(let image) = state else {
            state = .failed(L("No screenshot selected.", "Kein Screenshot ausgewählt."))
            return
        }

        let previousRecord = AVENAnalysisStore.load()
        let previousStore = AVENAnalysisPersistenceSnapshot.capture()
        let previousRecordTimestamp = previousRecord?.timestamp
        let previousTasks = AVENAIActionPlanStore.latestTasksForVerification()
        let analysisStarted = Date()

        analysisStage = .evidence
        withAnimation { state = .analyzing }

        async let minimumDelay: Void = Task.sleep(nanoseconds: 2_300_000_000)
        let localResult = await ProfileImageAnalyzer().analyze(image: image)

        guard let localRecord = AVENAnalysisStore.load(),
              localRecord.timestamp.timeIntervalSince(analysisStarted) > -1.5,
              previousRecordTimestamp == nil || localRecord.timestamp != previousRecordTimestamp else {
            previousStore.restore()
            try? await minimumDelay
            state = .failed(L("AVEN could not read enough reliable profile evidence from this screenshot. Upload a sharp screenshot showing the bio, name and profile area.", "AVEN konnte aus diesem Screenshot nicht genügend verlässliche Profil-Evidenz lesen. Bitte lade einen scharfen Screenshot mit Bio, Name und Profilbereich hoch."))
            return
        }

        analysisStage = .evaluation

        do {
            let account = Self.persistedTikTokAccount()
            let review = try await AVENBackend.analyzeProfileUnified(
                record: localRecord,
                localResult: localResult,
                account: account,
                previousRecord: previousRecord,
                previousTasks: previousTasks
            )

            analysisStage = .plan

            // Previous tasks only earn XP when the new profile analysis can clearly
            // verify that those exact improvements are now present.
            AVENAIActionPlanStore.grantResolvedTasks(ids: review.resolvedTaskIDs)

            let finalRecord = AnalysisRecord(
                analysisScore: review.score,
                status: Self.scoreLabel(review.score),
                strengths: review.strengths,
                weaknesses: review.weaknesses,
                dimensions: review.dimensions,
                taskIDs: review.tasks.map(\.id),
                platform: localRecord.platform,
                timestamp: localRecord.timestamp
            )

            AVENAnalysisPersistenceSnapshot.finalize(record: finalRecord)

            if review.score < 100 {
                AVENAIActionPlanStore.save(tasks: review.tasks, for: finalRecord)
            } else {
                AVENAIActionPlanStore.savePerfectProfile(for: finalRecord)
            }

            try? await minimumDelay

            let result = ScanAnalysisResult(
                score: review.score,
                status: Self.scoreLabel(review.score),
                strengths: review.strengths,
                weaknesses: review.weaknesses,
                suggestions: [],
                platform: localResult.platform,
                recommendedBio: review.recommendedBio ?? "",
                bioIsStrong: review.recommendedBio == nil,
                dimensions: review.dimensions
            )

            _ = subscription.consumeProfileAnalysis()
            withAnimation { state = .result(result) }
        } catch {
            previousStore.restore()
            try? await minimumDelay
            let message = error.localizedDescription.isEmpty
                ? L("AVEN AI could not complete the analysis. Please try again.", "AVEN AI konnte die Analyse nicht vollständig abschließen. Bitte erneut versuchen.")
                : error.localizedDescription
            withAnimation { state = .failed(message) }
        }
    }

    func reset() {
        analysisStage = .evidence
        withAnimation { state = .idle }
    }

    private static func persistedTikTokAccount() -> ConnectedTikTokAccount? {
        guard let data = UserDefaults.standard.data(forKey: "aven.connectedTikTokAccount") else { return nil }
        return try? JSONDecoder().decode(ConnectedTikTokAccount.self, from: data)
    }

    private static func scoreLabel(_ score: Int) -> String {
        switch score {
        case 100: return "Perfect Profile"
        case 90...99: return L("Excellent", "Hervorragend")
        case 80...89: return L("Very strong", "Sehr stark")
        case 65...79: return L("Good", "Gut")
        case 50...64: return L("Solid foundation", "Solide Basis")
        case 35...49: return L("Improvement potential", "Verbesserungspotenzial")
        default: return L("High potential", "Großes Potenzial")
        }
    }
}

// MARK: - Transactional analysis persistence
// ProfileImageAnalyzer currently stores its local evidence score immediately.
// This wrapper makes that write temporary: AI failure restores the old state;
// AI success replaces the temporary local score/history entry with the AI result.

private struct AVENAnalysisPersistenceSnapshot {
    let analysisData: Data?
    let scoreObject: Any?
    let historyData: Data?
    let doneObject: Any?

    static func capture() -> AVENAnalysisPersistenceSnapshot {
        let d = UserDefaults.standard
        return AVENAnalysisPersistenceSnapshot(
            analysisData: d.data(forKey: "aven.lastAnalysis"),
            scoreObject: d.object(forKey: "aven.avenScore.total"),
            historyData: d.data(forKey: "aven.scoreHistory"),
            doneObject: d.object(forKey: "aven.hasCompletedAnalysis")
        )
    }

    func restore() {
        let d = UserDefaults.standard
        Self.restoreValue(analysisData, key: "aven.lastAnalysis", defaults: d)
        Self.restoreValue(scoreObject, key: "aven.avenScore.total", defaults: d)
        Self.restoreValue(historyData, key: "aven.scoreHistory", defaults: d)
        Self.restoreValue(doneObject, key: "aven.hasCompletedAnalysis", defaults: d)
        NotificationCenter.default.post(name: .analysisDidComplete, object: nil)
    }

    static func finalize(record: AnalysisRecord) {
        let d = UserDefaults.standard
        if let data = try? JSONEncoder().encode(record) {
            d.set(data, forKey: "aven.lastAnalysis")
        }
        d.set(min(100, max(20, record.analysisScore)), forKey: "aven.avenScore.total")
        d.set(true, forKey: "aven.hasCompletedAnalysis")

        var history: [ScoreHistoryEntry] = {
            guard let data = d.data(forKey: "aven.scoreHistory"),
                  let decoded = try? JSONDecoder().decode([ScoreHistoryEntry].self, from: data) else { return [] }
            return decoded
        }()

        let entry = ScoreHistoryEntry(score: record.analysisScore, date: record.timestamp, reason: record.weaknesses.first)
        if let last = history.indices.last,
           abs(history[last].date.timeIntervalSince(record.timestamp)) < 5 {
            history[last] = entry
        } else {
            history.append(entry)
        }
        if history.count > 365 { history = Array(history.suffix(365)) }
        if let data = try? JSONEncoder().encode(history) {
            d.set(data, forKey: "aven.scoreHistory")
        }

        if record.analysisScore < 100 {
            d.removeObject(forKey: "aven.celebration.shown.v1")
        }

        NotificationCenter.default.post(name: .analysisDidComplete, object: nil)
    }

    private static func restoreValue(_ value: Any?, key: String, defaults: UserDefaults) {
        if let value { defaults.set(value, forKey: key) }
        else { defaults.removeObject(forKey: key) }
    }
}

// MARK: - Compact unified AVEN AI profile review

private struct AVENUnifiedProfileReview {
    let score: Int
    let strengths: [String]
    let weaknesses: [String]
    let dimensions: [AnalysisDimension]
    let recommendedBio: String?
    let tasks: [AVENAIPlanTask]
    let resolvedTaskIDs: [String]
}

private extension AVENBackend {
    static func analyzeProfileUnified(
        record: AnalysisRecord,
        localResult: ScanAnalysisResult,
        account: ConnectedTikTokAccount?,
        previousRecord: AnalysisRecord?,
        previousTasks: [AVENAIPlanTask]
    ) async throws -> AVENUnifiedProfileReview {
        let context = compactProfileContext(
            record: record,
            localResult: localResult,
            account: account,
            previousRecord: previousRecord,
            previousTasks: previousTasks
        )

        // A line protocol is materially more reliable than nested JSON through the
        // conversational /coach endpoint. JSON is still accepted as a fallback so
        // older backend/model behaviour remains compatible.
        let firstQuestion = """
        Evaluate ONLY visible TikTok profile quality. Never invent. Followers, likes, views and emoji usage have zero score impact. Missing evidence must not be treated as a defect.
        Use CLEAR PASS CRITERIA, not perfectionism. Award FULL category points when the visible profile satisfies the category; never subtract points merely because something could theoretically be even better. Allowed scores only: positioning 0/5/10/15/20; bio 0/5/10/15/20; branding 0/5/10/15; cta 0/5/10/15; content 0/5/10/15/20; structure 0/5/10.
        Full points: positioning=clear niche/promise; bio=clear useful value proposition; branding=coherent name/avatar/identity; cta=clear next action or useful link; content=visible posts strongly match the niche; structure=visible profile elements are coherent and complete. If all six pass, score MUST be 100/100.
        Give 2-3 tasks only for failed criteria. BIO blank if already strong; otherwise refine existing wording/voice, never generic filler or invented claims.

        Output ONLY:
        AVEN_PROFILE_V2
        DIM§positioning§N§reason
        DIM§bio§N§reason
        DIM§branding§N§reason
        DIM§cta§N§reason
        DIM§content§N§reason
        DIM§structure§N§reason
        STRENGTH§text
        WEAKNESS§text
        BIO§optional copy
        RESOLVED§id1,id2
        TASK§Title§category§points§40§Problem§Solution§Done when§copy
        TASK§Title§category§points§40§Problem§Solution§Done when§copy
        END
        """

        let firstReply = try await askCoachForProfileWithRetry(question: firstQuestion, avenContext: context)

        if let review = parseProfileProtocol(
            firstReply,
            record: record,
            previousRecord: previousRecord,
            previousTasks: previousTasks
        ) {
            return review
        }

        if let root = compactJSONObject(from: firstReply),
           let review = parseUnifiedProfileReview(
                root,
                record: record,
                previousRecord: previousRecord,
                previousTasks: previousTasks
           ) {
            return review
        }

        // Second attempt stays tiny and never embeds the malformed first response,
        // avoiding the old "Question too long" failure mode.
        let repairQuestion = """
        Re-output the same evaluation ONLY as AVEN_PROFILE_V2 lines. Six DIM rows in order: positioning 0-20, bio 0-20, branding 0-15, cta 0-15, content 0-20, structure 0-10. Then strengths, weaknesses, optional BIO, RESOLVED, 2-3 TASK rows if total <100, END. Use § separators only; no Markdown.
        """

        let repairedReply = try await askCoachForProfileWithRetry(question: repairQuestion, avenContext: context)

        if let repaired = parseProfileProtocol(
            repairedReply,
            record: record,
            previousRecord: previousRecord,
            previousTasks: previousTasks
        ) {
            return repaired
        }

        if let repairedRoot = compactJSONObject(from: repairedReply),
           let repaired = parseUnifiedProfileReview(
                repairedRoot,
                record: record,
                previousRecord: previousRecord,
                previousTasks: previousTasks
           ) {
            return repaired
        }

        AVENBackendDiagnostics.failure(
            "/coach · profile-analysis",
            "AI-Antwort konnte weder als AVEN_PROFILE_V1 noch als JSON gelesen werden."
        )
        throw AVENBackendError.validation("AVEN AI konnte die Profilanalyse nicht sauber strukturieren. Bitte erneut analysieren.")
    }

    static func compactProfileContext(
        record: AnalysisRecord,
        localResult: ScanAnalysisResult,
        account: ConnectedTikTokAccount?,
        previousRecord: AnalysisRecord?,
        previousTasks: [AVENAIPlanTask]
    ) -> String {
        var lines: [String] = []
        lines.append("CURRENT PROFILE EVIDENCE")
        lines.append("Platform: \(record.platform)")
        if let ocr = UserDefaults.standard.string(forKey: "aven.profileEvidence.currentOCR"), !ocr.isEmpty {
            lines.append("VISIBLE OCR TEXT FROM CURRENT SCREENSHOT: \(ocr)")
        }

        if let previousRecord {
            lines.append("VORHERIGE PROFILANALYSE: \(previousRecord.analysisScore)/100")
            if !previousRecord.weaknesses.isEmpty {
                lines.append("Vorherige Schwächen: " + previousRecord.weaknesses.prefix(3).joined(separator: " | "))
            }
            for dimension in previousRecord.dimensions.prefix(6) {
                lines.append("Previous rubric \(dimension.localizedName): \(dimension.score)/\(dimension.avenMaxScore)")
            }
        }

        if let account, AVENTikTokStatsState.hasVerifiedStats {
            lines.append("Echte TikTok-Zähler: \(account.followers) Follower, \(account.likes) Likes, \(account.videoCount) Videos")
        }

        if !record.strengths.isEmpty {
            lines.append("Sichtbare Stärken: " + record.strengths.prefix(4).joined(separator: " | "))
        }
        if !record.weaknesses.isEmpty {
            lines.append("Sichtbare Schwächen: " + record.weaknesses.prefix(4).joined(separator: " | "))
        }

        for dimension in record.dimensions.prefix(6) {
            let positives = dimension.positives.prefix(1).joined(separator: "; ")
            let negatives = dimension.negatives.prefix(1).joined(separator: "; ")
            lines.append("OCR evidence \(dimension.name) | + \(positives.isEmpty ? "not clearly detected" : positives) | - \(negatives.isEmpty ? "not clearly detected" : negatives)")
        }

        if let goal = AVENUserGoalStore.current {
            lines.append("Nutzerziel: \(goal.title), Ziel \(goal.target) \(goal.unit), Zeitraum \(goal.deadline)")
        }

        if !previousTasks.isEmpty {
            lines.append("FRÜHERE AUFGABEN – nur ID zurückgeben wenn jetzt eindeutig umgesetzt:")
            for task in previousTasks.prefix(3) {
                let compactDetail = task.detail.replacingOccurrences(of: "\n", with: " ")
                lines.append("ID=\(task.id) | \(task.title) | \(String(compactDetail.prefix(180)))")
            }
        }

        return String(lines.joined(separator: "\n").prefix(1_200))
    }

    /// Profile analysis is read-only, so a short retry is safe when iOS reports
    /// a transient connection loss. This specifically addresses NSURLSession's
    /// "network connection was lost" failure without fabricating an AI result.
    static func askCoachForProfileWithRetry(question: String, avenContext: String) async throws -> String {
        var lastError: Error?
        for attempt in 0..<3 {
            do {
                return try await askCoach(question: question, history: [], avenContext: avenContext)
            } catch {
                lastError = error
                guard attempt < 2, isTransientProfileAIError(error) else { throw error }
                let delay = UInt64(650_000_000 * (attempt + 1))
                try? await Task.sleep(nanoseconds: delay)
            }
        }
        throw lastError ?? AVENBackendError.invalidResponse
    }

    static func isTransientProfileAIError(_ error: Error) -> Bool {
        if let urlError = error as? URLError {
            return [
                .networkConnectionLost, .timedOut, .cannotConnectToHost,
                .cannotFindHost, .dnsLookupFailed, .notConnectedToInternet
            ].contains(urlError.code)
        }
        if case AVENBackendError.serverError(let message) = error {
            let lower = message.lowercased()
            return lower.contains("502") || lower.contains("503") || lower.contains("504")
                || lower.contains("tempor") || lower.contains("overload")
        }
        return false
    }

    static func parseProfileProtocol(
        _ text: String,
        record: AnalysisRecord,
        previousRecord: AnalysisRecord?,
        previousTasks: [AVENAIPlanTask]
    ) -> AVENUnifiedProfileReview? {
        var strengths: [String] = []
        var weaknesses: [String] = []
        var recommendedBio = ""
        var resolvedIDs: [String] = []
        var rawTasks: [[String: Any]] = []
        var rawDimensions: [[String: Any]] = []

        let normalizedText = text
            .replacingOccurrences(of: "```text", with: "")
            .replacingOccurrences(of: "```", with: "")
            .replacingOccurrences(of: "\r\n", with: "\n")

        for rawLine in normalizedText.components(separatedBy: .newlines) {
            let line = rawLine.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !line.isEmpty else { continue }

            let upper = line.uppercased()
            if upper == "AVEN_PROFILE_V2" || upper == "AVEN_PROFILE_V1" || upper == "END" { continue }

            let parts = profileProtocolParts(line)
            guard let first = parts.first else { continue }
            let key = profileProtocolKey(first)

            switch key {
            case "DIM":
                guard parts.count >= 4 else { continue }
                let criterionKey = (protocolText(parts[safe: 1] ?? "") ?? "").lowercased()
                let points = flexibleInt(parts[safe: 2] ?? "") ?? -1
                let reason = protocolText(parts[3...].joined(separator: "§")) ?? ""
                rawDimensions.append([
                    "key": criterionKey,
                    "score": points,
                    "reason": reason
                ])

            case "STRENGTH":
                if parts.count >= 2, let value = protocolText(parts.dropFirst().joined(separator: "§")) {
                    strengths.append(value)
                }

            case "WEAKNESS":
                if parts.count >= 2, let value = protocolText(parts.dropFirst().joined(separator: "§")) {
                    weaknesses.append(value)
                }

            case "BIO":
                if parts.count >= 2 {
                    recommendedBio = protocolText(parts.dropFirst().joined(separator: "§")) ?? ""
                }

            case "RESOLVED":
                if parts.count >= 2 {
                    resolvedIDs = parts.dropFirst().joined(separator: "§")
                        .components(separatedBy: ",")
                        .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                        .filter { !$0.isEmpty }
                }

            case "TASK":
                guard parts.count >= 5 else { continue }
                let title = protocolText(parts[safe: 1] ?? "") ?? ""
                let category = (protocolText(parts[safe: 2] ?? "") ?? "profile").lowercased()
                let pointWeight = flexibleInt(parts[safe: 3] ?? "") ?? 1
                let xp = flexibleInt(parts[safe: 4] ?? "") ?? 40
                let problem = protocolText(parts[safe: 5] ?? "") ?? ""
                let solution = protocolText(parts[safe: 6] ?? "") ?? ""
                let doneWhen = protocolText(parts[safe: 7] ?? "") ?? ""
                let copyText = protocolText(parts.count > 8 ? parts[8...].joined(separator: "§") : "") ?? ""

                rawTasks.append([
                    "title": title,
                    "category": category,
                    "scorePotential": max(1, pointWeight),
                    "xp": xp,
                    "problem": problem,
                    "solution": solution,
                    "doneWhen": doneWhen,
                    "copyText": copyText
                ])

            default:
                continue
            }
        }

        guard rawDimensions.count >= 6 else { return nil }

        var root: [String: Any] = [
            "dimensions": rawDimensions,
            "strengths": Array(strengths.prefix(4)),
            "weaknesses": Array(weaknesses.prefix(4)),
            "resolvedTaskIds": resolvedIDs,
            "tasks": rawTasks
        ]
        if !recommendedBio.isEmpty { root["recommendedBio"] = recommendedBio }

        return parseUnifiedProfileReview(
            root,
            record: record,
            previousRecord: previousRecord,
            previousTasks: previousTasks
        )
    }

    static func profileProtocolParts(_ line: String) -> [String] {
        if line.contains("§") {
            return line.components(separatedBy: "§")
        }
        if line.contains("|") {
            return line.components(separatedBy: "|")
        }
        if let colon = line.firstIndex(of: ":") {
            return [
                String(line[..<colon]),
                String(line[line.index(after: colon)...])
            ]
        }
        return [line]
    }

    static func profileProtocolKey(_ raw: String) -> String {
        let cleaned = raw
            .trimmingCharacters(in: CharacterSet(charactersIn: " -*•\t0123456789.)"))
            .replacingOccurrences(of: "*", with: "")
            .uppercased()

        if cleaned.hasPrefix("DIM") || cleaned.hasPrefix("CRITERION") { return "DIM" }
        if cleaned.hasPrefix("TASK") { return "TASK" }
        if cleaned.hasPrefix("STRENGTH") || cleaned.hasPrefix("STAERKE") || cleaned.hasPrefix("STÄRKE") { return "STRENGTH" }
        if cleaned.hasPrefix("WEAKNESS") || cleaned.hasPrefix("SCHWAECHE") || cleaned.hasPrefix("SCHWÄCHE") { return "WEAKNESS" }
        if cleaned.hasPrefix("RESOLVED") { return "RESOLVED" }
        if cleaned.hasPrefix("SCORE") { return "SCORE" }
        if cleaned.hasPrefix("BIO") { return "BIO" }
        return cleaned
    }

    static func protocolText(_ value: String) -> String? {
        let decoded = value
            .replacingOccurrences(of: "↵", with: "\n")
            .replacingOccurrences(of: "\\n", with: "\n")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        return decoded.isEmpty ? nil : decoded
    }

    static func compactJSONObject(from text: String) -> [String: Any]? {
        var cleaned = text
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "```json", with: "")
            .replacingOccurrences(of: "```JSON", with: "")
            .replacingOccurrences(of: "```", with: "")
            .replacingOccurrences(of: "“", with: "\"")
            .replacingOccurrences(of: "”", with: "\"")
            .replacingOccurrences(of: "’", with: "'")

        guard let start = cleaned.firstIndex(of: "{"),
              let end = cleaned.lastIndex(of: "}"),
              start <= end else { return nil }
        cleaned = String(cleaned[start...end])

        guard let data = cleaned.data(using: .utf8),
              let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return nil }
        return root
    }

    static func parseUnifiedProfileReview(
        _ root: [String: Any],
        record: AnalysisRecord,
        previousRecord: AnalysisRecord?,
        previousTasks: [AVENAIPlanTask]
    ) -> AVENUnifiedProfileReview? {
        let payload = (root["analysis"] as? [String: Any])
            ?? (root["result"] as? [String: Any])
            ?? (root["profileAnalysis"] as? [String: Any])
            ?? root

        guard var dimensions = parseRubricDimensions(payload["dimensions"] ?? payload["criteria"] ?? payload["rubric"]) else {
            return nil
        }
        dimensions = enforceMinimumVisibleProfileScore(dimensions)
        let score = min(100, max(20, dimensions.reduce(0) { $0 + max(0, $1.score) }))

        var strengths = Array(flexibleStrings(payload["strengths"]).prefix(4))
        var weaknesses = Array(flexibleStrings(payload["weaknesses"]).prefix(4))

        if strengths.isEmpty {
            strengths = Array(flexibleStrings(payload["pros"] ?? payload["positive"]).prefix(4))
        }
        if weaknesses.isEmpty {
            weaknesses = Array(flexibleStrings(payload["improvements"] ?? payload["potentials"] ?? payload["negative"]).prefix(4))
        }

        // A perfect rubric is the only route to 100. Minor prose "weaknesses" from
        // the model are ignored when all six criteria are truly maxed out.
        if score == 100 {
            weaknesses = []
        } else if weaknesses.isEmpty {
            weaknesses = dimensions
                .filter { $0.score < $0.avenMaxScore }
                .sorted { ($0.avenMaxScore - $0.score) > ($1.avenMaxScore - $1.score) }
                .prefix(3)
                .map { $0.tip }
                .filter { !$0.isEmpty }
        }

        if strengths.isEmpty {
            strengths = dimensions
                .filter { $0.normalizedPercent >= 75 }
                .sorted { $0.normalizedPercent > $1.normalizedPercent }
                .prefix(3)
                .map { $0.tip }
                .filter { !$0.isEmpty }
        }
        guard !strengths.isEmpty || !weaknesses.isEmpty else { return nil }

        var recommendedBio = flexibleString(payload["recommendedBio"] ?? payload["recommended_bio"])
        if let bioDimension = dimensions.first(where: { $0.avenCriterionKey == "bio" }), bioDimension.score >= 18 {
            recommendedBio = nil
        }
        let rawTasks = flexibleTaskArray(payload)
        var parsedTasks: [AVENAIPlanTask] = []
        var seen = Set<String>()
        var bioTaskCount = 0

        for raw in rawTasks.prefix(5) {
            let title = flexibleString(raw["title"] ?? raw["task"] ?? raw["name"])?
                .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            let category = (flexibleString(raw["category"] ?? raw["type"]) ?? "profile").lowercased()
            let xp = min(80, max(20, flexibleInt(raw["xp"] ?? raw["rewardXP"] ?? raw["reward_xp"]) ?? 40))
            let rawPotential = max(1, flexibleInt(raw["scorePotential"] ?? raw["score_potential"] ?? raw["pointWeight"] ?? raw["points"]) ?? 1)

            let explicitDetail = flexibleString(raw["detail"] ?? raw["description"])
            let problem = flexibleString(raw["problem"] ?? raw["issue"] ?? raw["reason"])
            let solution = flexibleString(raw["solution"] ?? raw["action"] ?? raw["recommendation"])
            let doneWhen = flexibleString(raw["doneWhen"] ?? raw["done_when"] ?? raw["successCriteria"] ?? raw["success_criteria"])

            var detailParts: [String] = []
            if let explicitDetail, !explicitDetail.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                detailParts.append(explicitDetail.trimmingCharacters(in: .whitespacesAndNewlines))
            } else {
                if let problem, !problem.isEmpty { detailParts.append(L("Problem identified: \(problem)", "Problem erkannt: \(problem)")) }
                if let solution, !solution.isEmpty { detailParts.append(L("Concrete solution: \(solution)", "Konkrete Lösung: \(solution)")) }
                if let doneWhen, !doneWhen.isEmpty { detailParts.append(L("Done when: \(doneWhen)", "Erledigt wenn: \(doneWhen)")) }
            }
            let detail = detailParts.joined(separator: "\n")

            var copyText = flexibleString(
                raw["copyText"] ?? raw["copy_text"] ?? raw["suggestion"] ?? raw["proposal"] ?? raw["example"]
            )?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            if category == "bio", copyText.isEmpty {
                copyText = recommendedBio ?? solution ?? ""
            }

            guard !title.isEmpty, !detail.isEmpty else { continue }
            let normalized = title.lowercased().filter { $0.isLetter || $0.isNumber }
            guard !normalized.isEmpty, !seen.contains(normalized) else { continue }

            let isBio = category == "bio"
            if isBio {
                guard !copyText.isEmpty else { continue }
                if bioTaskCount >= 1 { continue }
                bioTaskCount += 1
            }

            seen.insert(normalized)
            let slug = title.lowercased()
                .replacingOccurrences(of: " ", with: "-")
                .filter { $0.isLetter || $0.isNumber || $0 == "-" }
            let id = "profile-\(category)-\(String(slug.prefix(32)))"
            let packedDetail = copyText.isEmpty
                ? detail
                : detail + "\nAVEN_COPY_START\n" + copyText + "\nAVEN_COPY_END"

            parsedTasks.append(
                AVENAIPlanTask(
                    id: id,
                    title: title,
                    detail: packedDetail,
                    priority: "medium", // legacy storage field; not shown
                    category: category,
                    xp: xp,
                    requiresProof: false,
                    scorePotential: rawPotential
                )
            )
            if parsedTasks.count == 3 { break }
        }

        if score < 100 && parsedTasks.count < 2 { return nil }
        if score == 100 { parsedTasks = [] }

        let previousIDs = Set(previousTasks.map(\.id))
        let currentTaskIDs = Set(parsedTasks.map(\.id))
        let resolvedCandidates = flexibleStrings(
            payload["resolvedTaskIds"] ?? payload["resolved_task_ids"] ?? payload["resolvedTasks"]
        )
        let resolved = resolvedCandidates.filter {
            previousIDs.contains($0) && !currentTaskIDs.contains($0)
        }

        // The task potentials are explanatory only. They add up exactly to the
        // current gap so the user can see a complete path to 100. Actual points
        // are awarded only by a NEW analysis of the changed profile.
        let tasks = distributeScorePotential(
            parsedTasks,
            remainingGap: max(0, 100 - score)
        )

        return AVENUnifiedProfileReview(
            score: score,
            strengths: strengths,
            weaknesses: weaknesses,
            dimensions: dimensions,
            recommendedBio: recommendedBio?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false ? recommendedBio : nil,
            tasks: tasks,
            resolvedTaskIDs: resolved
        )
    }

    static func parseRubricDimensions(_ value: Any?) -> [AnalysisDimension]? {
        var entries: [[String: Any]] = []

        if let array = value as? [[String: Any]] {
            entries = array
        } else if let dictionary = value as? [String: Any] {
            for (key, raw) in dictionary {
                if let item = raw as? [String: Any] {
                    var merged = item
                    merged["key"] = merged["key"] ?? key
                    entries.append(merged)
                } else if let points = flexibleInt(raw) {
                    entries.append(["key": key, "score": points, "reason": ""])
                }
            }
        }

        guard !entries.isEmpty else { return nil }

        var byKey: [String: AnalysisDimension] = [:]
        for entry in entries {
            let rawKey = (flexibleString(entry["key"] ?? entry["id"] ?? entry["category"] ?? entry["name"]) ?? "").lowercased()
            let inferred = AVENScoreRubric.spec(for: rawKey) != nil
                ? rawKey
                : AVENScoreRubric.inferredKey(from: rawKey)
            guard let criterionKey = inferred,
                  let spec = AVENScoreRubric.spec(for: criterionKey),
                  let rawPoints = flexibleInt(entry["score"] ?? entry["points"] ?? entry["value"]) else { continue }

            let points = snapRubricScore(rawPoints, maxScore: spec.maxScore)
            let reason = flexibleString(entry["reason"] ?? entry["detail"] ?? entry["explanation"] ?? entry["why"]) ?? ""
            let dimension = AnalysisDimension(
                key: spec.id,
                name: spec.englishName,
                score: points,
                maxScore: spec.maxScore,
                positives: points >= Int(Double(spec.maxScore) * 0.75) && !reason.isEmpty ? [reason] : [],
                negatives: points < spec.maxScore && !reason.isEmpty ? [reason] : [],
                tip: reason
            )
            byKey[spec.id] = dimension
        }

        let ordered = AVENScoreRubric.criteria.compactMap { byKey[$0.id] }
        return ordered.count == AVENScoreRubric.criteria.count ? ordered : nil
    }


    static func snapRubricScore(_ raw: Int, maxScore: Int) -> Int {
        let value = min(maxScore, max(0, raw))
        switch maxScore {
        case 20:
            if value >= 17 { return 20 }
            if value >= 12 { return 15 }
            if value >= 7 { return 10 }
            if value >= 3 { return 5 }
            return 0
        case 15:
            if value >= 12 { return 15 }
            if value >= 7 { return 10 }
            if value >= 3 { return 5 }
            return 0
        case 10:
            if value >= 8 { return 10 }
            if value >= 3 { return 5 }
            return 0
        default:
            return value
        }
    }

    static func enforceMinimumVisibleProfileScore(_ dimensions: [AnalysisDimension]) -> [AnalysisDimension] {
        var result = dimensions
        var total = result.reduce(0) { $0 + max(0, $1.score) }
        guard total < 20 else { return result }

        var index = 0
        while total < 20 && !result.isEmpty {
            let position = index % result.count
            let current = result[position]
            if current.score < current.avenMaxScore {
                result[position] = AnalysisDimension(
                    key: current.key,
                    name: current.name,
                    score: current.score + 1,
                    maxScore: current.maxScore,
                    positives: current.positives,
                    negatives: current.negatives,
                    tip: current.tip
                )
                total += 1
            }
            index += 1
            if index > 500 { break }
        }
        return result
    }

    static func distributeScorePotential(_ tasks: [AVENAIPlanTask], remainingGap: Int) -> [AVENAIPlanTask] {
        guard !tasks.isEmpty, remainingGap > 0 else {
            return tasks.map {
                AVENAIPlanTask(id: $0.id, title: $0.title, detail: $0.detail, priority: $0.priority,
                               category: $0.category, xp: $0.xp, requiresProof: $0.requiresProof, scorePotential: 0)
            }
        }

        let weights = tasks.map { max(1, $0.scorePotential ?? 1) }
        let totalWeight = max(1, weights.reduce(0, +))
        var allocations = weights.map { max(0, Int((Double(remainingGap) * Double($0) / Double(totalWeight)).rounded(.down))) }
        var assigned = allocations.reduce(0, +)
        var i = 0
        while assigned < remainingGap {
            allocations[i % allocations.count] += 1
            assigned += 1
            i += 1
        }

        return zip(tasks, allocations).map { task, potential in
            AVENAIPlanTask(
                id: task.id,
                title: task.title,
                detail: task.detail,
                priority: task.priority,
                category: task.category,
                xp: task.xp,
                requiresProof: task.requiresProof,
                scorePotential: potential
            )
        }
    }

    static func flexibleTaskArray(_ root: [String: Any]) -> [[String: Any]] {
        let candidates: [Any?] = [
            root["tasks"],
            root["actions"],
            root["actionPlan"],
            root["action_plan"]
        ]

        for candidate in candidates {
            if let array = candidate as? [[String: Any]] { return array }
            if let dictionary = candidate as? [String: Any] {
                if let array = dictionary["tasks"] as? [[String: Any]] { return array }
                if let array = dictionary["actions"] as? [[String: Any]] { return array }
            }
        }
        return []
    }

    static func flexibleInt(_ value: Any?) -> Int? {
        if let value = value as? Int { return value }
        if let value = value as? NSNumber { return value.intValue }
        if let value = value as? Double { return Int(value.rounded()) }
        if let value = value as? String {
            let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
            if let int = Int(trimmed) { return int }
            if let double = Double(trimmed) { return Int(double.rounded()) }

            // Also accept common model variants such as "72/100" or "Score: 72".
            if let start = trimmed.firstIndex(where: { $0.isNumber || $0 == "-" }) {
                let tail = trimmed[start...]
                let token = tail.prefix { $0.isNumber || $0 == "." || $0 == "-" }
                if let int = Int(token) { return int }
                if let double = Double(token) { return Int(double.rounded()) }
            }
        }
        return nil
    }

    static func flexibleString(_ value: Any?) -> String? {
        if let string = value as? String {
            let trimmed = string.trimmingCharacters(in: .whitespacesAndNewlines)
            return trimmed.isEmpty ? nil : trimmed
        }
        if let number = value as? NSNumber { return number.stringValue }
        return nil
    }

    static func flexibleStrings(_ value: Any?) -> [String] {
        if let array = value as? [String] {
            return array
                .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                .filter { !$0.isEmpty }
        }
        if let array = value as? [Any] {
            return array.compactMap { item in
                if let string = flexibleString(item) { return string }
                if let dictionary = item as? [String: Any] {
                    return flexibleString(dictionary["text"] ?? dictionary["title"] ?? dictionary["value"])
                }
                return nil
            }
        }
        if let string = flexibleString(value) {
            return string
                .components(separatedBy: .newlines)
                .flatMap { $0.components(separatedBy: "•") }
                .map {
                    $0.trimmingCharacters(in: CharacterSet(charactersIn: " -–—\t"))
                }
                .filter { !$0.isEmpty }
        }
        return []
    }
}

private extension Array {
    subscript(safe index: Index) -> Element? {
        indices.contains(index) ? self[index] : nil
    }
}
