import SwiftUI
import UIKit

// ─── Action Plan ──────────────────────────────────────────────────────────────
// Clear separation:
// • AVEN Challenge = profile quality (20–100, only a new analysis changes it)
// • Next Steps      = 2–3 concrete AI tasks from the latest profile analysis
// • Challenges       = measurable follower/like milestones from synced TikTok data

struct ActionPlanView: View {
    @StateObject private var vm = ActionPlanViewModel()
    @EnvironmentObject private var container: AppContainer
    @State private var showPaywall = false
    @State private var refreshToken = UUID()

    var body: some View {
        ZStack {
            AVENColor.backgroundPrimary.ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 16) {
                    header

                    if AVENAnalysisStore.hasCompletedAnalysis {
                        avenChallengeCard
                    }

                    growthChallengesSection

                    if AVENAnalysisStore.hasCompletedAnalysis {
                        nextStepsSection
                    } else {
                        firstAnalysisCard
                    }

                    Color.clear.frame(height: 18)
                }
                .padding(.horizontal, 16)
                .padding(.top, 10)
            }
        }
        .sheet(isPresented: $showPaywall) { PaywallView() }
        .onAppear {
            vm.reload()
            if let account = container.connectedTikTokAccount, AVENTikTokStatsState.hasVerifiedStats {
                AVENGrowthChallengeEngine.bootstrap(account: account)
            }
            refreshToken = UUID()
        }
        .onReceive(NotificationCenter.default.publisher(for: .analysisDidComplete)) { _ in
            vm.reload()
            refreshToken = UUID()
        }
        .onReceive(NotificationCenter.default.publisher(for: .aiActionPlanDidUpdate)) { _ in
            vm.reload()
        }
        .onReceive(NotificationCenter.default.publisher(for: .growthMissionDidUpdate)) { _ in
            refreshToken = UUID()
        }
    }

    private var header: some View {
        HStack(alignment: .center) {
            VStack(alignment: .leading, spacing: 4) {
                Text("Aktionsplan")
                    .font(.system(size: 28, weight: .bold, design: .rounded))
                    .foregroundColor(AVENColor.textPrimary)
                Text("Konkrete Schritte. Echte Daten. Kein Rätselraten.")
                    .font(AVENFont.body(12.5))
                    .foregroundColor(AVENColor.textSecondary)
            }
            Spacer()
            ZStack {
                Circle()
                    .fill(AVENColor.accentPurple.opacity(0.09))
                    .frame(width: 40, height: 40)
                Image(systemName: "sparkles")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(AVENColor.accentPurple)
            }
        }
    }

    // MARK: AVEN Challenge

    private var avenChallengeCard: some View {
        let score = AVENAnalysisStore.currentScore
        let complete = score >= 100

        return VStack(alignment: .leading, spacing: 13) {
            HStack(spacing: 11) {
                ZStack {
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .fill((complete ? AVENColor.textPositive : AVENColor.accentPurple).opacity(0.10))
                        .frame(width: 44, height: 44)
                    Image(systemName: complete ? "trophy.fill" : "target")
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundColor(complete ? AVENColor.textPositive : AVENColor.accentPurple)
                }

                VStack(alignment: .leading, spacing: 3) {
                    Text(complete ? L("AVEN Challenge completed", "AVEN Challenge bestanden") : "AVEN Challenge")
                        .font(AVENFont.body(15, weight: .semibold))
                        .foregroundColor(AVENColor.textPrimary)
                    Text(complete ? L("Perfect Profile by the AVEN standard", "Perfect Profile nach dem AVEN Standard") : L("Improve your profile to 100/100", "Verbessere dein Profil bis 100/100"))
                        .font(AVENFont.body(10.5))
                        .foregroundColor(AVENColor.textSecondary)
                }
                Spacer()
                Text("\(score)/100")
                    .font(.system(size: 16, weight: .bold, design: .rounded))
                    .foregroundColor(complete ? AVENColor.textPositive : AVENColor.accentPurple)
            }

            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    Capsule().fill(AVENColor.backgroundSecondary)
                    Capsule()
                        .fill(
                            LinearGradient(
                                colors: [AVENColor.accentPurple, AVENColor.accentBlue],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .frame(width: geo.size.width * min(1, max(0, CGFloat(score) / 100)))
                        .animation(.spring(response: 0.65), value: score)
                }
            }
            .frame(height: 7)

            if complete {
                Text("Deine letzte AVEN AI Analyse hat keine relevante Profilschwäche mehr erkannt. Aufgaben erhöhen den Score niemals künstlich.")
                    .font(AVENFont.body(10.5))
                    .foregroundColor(AVENColor.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)
            } else {
                VStack(alignment: .leading, spacing: 6) {
                    Text(L("\(max(0, 100 - score)) points to Perfect Profile", "Noch \(max(0, 100 - score)) Punkte bis Perfect Profile"))
                        .font(AVENFont.body(11.5, weight: .semibold))
                        .foregroundColor(AVENColor.textPrimary)
                    Text("Setze die konkreten Aufgaben unten in TikTok um und starte danach eine neue Profilanalyse. Nur die neue Analyse kann deinen AVEN Score verändern und die Umsetzung für XP bestätigen.")
                        .font(AVENFont.body(10.5))
                        .foregroundColor(AVENColor.textSecondary)
                        .lineSpacing(3)
                }
            }
        }
        .padding(15)
        .background(
            LinearGradient(
                colors: [AVENColor.backgroundCard, (complete ? AVENColor.textPositive : AVENColor.accentPurple).opacity(0.025)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .strokeBorder((complete ? AVENColor.textPositive : AVENColor.accentPurple).opacity(0.14), lineWidth: 0.7)
        )
        .shadow(color: AVENColor.cardShadow, radius: 7, y: 2)
    }

    // MARK: Challenges

    private var growthChallengesSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .firstTextBaseline) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Challenges")
                        .font(AVENFont.body(17, weight: .semibold))
                        .foregroundColor(AVENColor.textPrimary)
                    Text("Automatisch mit deinen verbundenen TikTok-Zählern geprüft")
                        .font(AVENFont.body(10.5))
                        .foregroundColor(AVENColor.textMuted)
                }
                Spacer()

                if container.connectedTikTokAccount != nil {
                    Button {
                        container.syncTikTokStats()
                    } label: {
                        Image(systemName: "arrow.clockwise")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundColor(AVENColor.accentPurple)
                            .frame(width: 31, height: 31)
                            .background(AVENColor.accentPurple.opacity(0.08))
                            .clipShape(Circle())
                    }
                    .buttonStyle(PressButtonStyle())
                }
            }

            if let account = container.connectedTikTokAccount, AVENTikTokStatsState.hasVerifiedStats {
                let follower = AVENGrowthChallengeEngine.challenge(metric: .followers, account: account)
                let likes = AVENGrowthChallengeEngine.challenge(metric: .likes, account: account)

                GrowthChallengeCard(challenge: follower, lastSync: lastSyncText)
                    .id("followers-\(refreshToken)-\(account.followers)")
                GrowthChallengeCard(challenge: likes, lastSync: lastSyncText)
                    .id("likes-\(refreshToken)-\(account.likes)")
            } else if container.connectedTikTokAccount != nil {
                HStack(alignment: .top, spacing: 11) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 10, style: .continuous)
                            .fill(AVENColor.accentPurple.opacity(0.08))
                            .frame(width: 39, height: 39)
                        Image(systemName: "arrow.triangle.2.circlepath")
                            .foregroundColor(AVENColor.accentPurple)
                    }
                    VStack(alignment: .leading, spacing: 4) {
                        Text("TikTok-Stats werden synchronisiert")
                            .font(AVENFont.body(13, weight: .semibold))
                            .foregroundColor(AVENColor.textPrimary)
                        Text(AVENTikTokStatsState.lastError.isEmpty
                             ? "AVEN wartet auf die echten Follower- und Like-Zähler von TikTok. Es werden keine 0-Werte als echte Daten behandelt."
                             : AVENTikTokStatsState.lastError)
                            .font(AVENFont.body(10.5))
                            .foregroundColor(AVENColor.textSecondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    Spacer()
                }
                .padding(14)
                .background(AVENColor.backgroundCard)
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            } else {
                Button {
                    container.showTikTokAccount = true
                } label: {
                    HStack(spacing: 11) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 10, style: .continuous)
                                .fill(AVENColor.accentPurple.opacity(0.08))
                                .frame(width: 39, height: 39)
                            Image(systemName: "link")
                                .foregroundColor(AVENColor.accentPurple)
                        }
                        VStack(alignment: .leading, spacing: 3) {
                            Text("TikTok verbinden")
                                .font(AVENFont.body(13, weight: .semibold))
                                .foregroundColor(AVENColor.textPrimary)
                            Text("Erst echte Account-Zähler schalten Follower- und Like-Challenges frei.")
                                .font(AVENFont.body(10.5))
                                .foregroundColor(AVENColor.textSecondary)
                                .multilineTextAlignment(.leading)
                        }
                        Spacer()
                        Image(systemName: "chevron.right")
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundColor(AVENColor.textMuted)
                    }
                    .padding(14)
                    .background(AVENColor.backgroundCard)
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                }
                .buttonStyle(PressButtonStyle())
            }
        }
    }

    private var lastSyncText: String {
        guard let date = UserDefaults.standard.object(forKey: "aven.tiktok.lastSync") as? Date else {
            return L("TikTok data from the latest account state", "TikTok-Daten vom letzten Account-Stand")
        }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: AVENLocalization.isGerman ? "de_AT" : "en_US")
        formatter.timeStyle = .short
        formatter.dateStyle = Calendar.current.isDateInToday(date) ? .none : .short
        return L("TikTok sync: \(formatter.string(from: date))", "TikTok-Sync: \(formatter.string(from: date))")
    }

    // MARK: Next steps

    @ViewBuilder
    private var nextStepsSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .firstTextBaseline) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Deine nächsten Schritte")
                        .font(AVENFont.body(17, weight: .semibold))
                        .foregroundColor(AVENColor.textPrimary)
                    Text("Direkt aus deiner letzten AVEN AI Profilanalyse")
                        .font(AVENFont.body(10.5))
                        .foregroundColor(AVENColor.textMuted)
                }
                Spacer()
                if !vm.items.isEmpty {
                    Text(L("\(vm.items.count) tasks", "\(vm.items.count) Aufgaben"))
                        .font(AVENFont.body(10, weight: .semibold))
                        .foregroundColor(AVENColor.accentPurple)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(AVENColor.accentPurple.opacity(0.07))
                        .clipShape(Capsule())
                }
            }

            if AVENAnalysisStore.currentScore >= 100 {
                HStack(spacing: 11) {
                    Image(systemName: "checkmark.seal.fill")
                        .font(.system(size: 25))
                        .foregroundColor(AVENColor.textPositive)
                    VStack(alignment: .leading, spacing: 3) {
                        Text("Keine Profilaufgaben offen")
                            .font(AVENFont.body(13, weight: .semibold))
                            .foregroundColor(AVENColor.textPrimary)
                        Text("Dein Profil hat in der aktuellen Analyse 100/100 erreicht. Challenges laufen unabhängig davon weiter.")
                            .font(AVENFont.body(10.5))
                            .foregroundColor(AVENColor.textSecondary)
                    }
                    Spacer()
                }
                .padding(14)
                .background(AVENColor.textPositive.opacity(0.06))
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            } else if vm.items.isEmpty {
                VStack(spacing: 10) {
                    Image(systemName: "sparkles")
                        .font(.system(size: 24))
                        .foregroundColor(AVENColor.accentPurple)
                    Text("Aktionsplan mit AVEN AI aktualisieren")
                        .font(AVENFont.body(13, weight: .semibold))
                        .foregroundColor(AVENColor.textPrimary)
                    Text("Starte eine neue Profilanalyse. AVEN erstellt daraus 2–3 konkrete, direkt umsetzbare Aufgaben.")
                        .font(AVENFont.body(10.5))
                        .foregroundColor(AVENColor.textSecondary)
                        .multilineTextAlignment(.center)
                    Button("Neue Profilanalyse") {
                        container.showNewScan = true
                    }
                    .font(AVENFont.body(11.5, weight: .semibold))
                    .foregroundColor(AVENColor.accentPurple)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 18)
                .background(AVENColor.backgroundCard)
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            } else {
                let visibleItems = container.subscription.hasActionPlan ? vm.items : Array(vm.items.prefix(1))
                ForEach(Array(visibleItems.enumerated()), id: \.element.task.id) { index, item in
                    CoachingTaskCard(
                        task: item.task,
                        number: index + 1,
                        locked: item.locked,
                        onReanalyze: { container.showNewScan = true },
                        onLocked: { showPaywall = true }
                    )
                }
                if !container.subscription.hasActionPlan && vm.items.count > 1 {
                    Button { showPaywall = true } label: {
                        HStack(spacing: 10) {
                            Image(systemName: "lock.fill")
                            VStack(alignment: .leading, spacing: 2) {
                                Text(L("Unlock the full Action Plan", "Vollständigen Aktionsplan freischalten"))
                                    .font(AVENFont.body(12.5, weight: .semibold))
                                Text(L("FREE shows your most important next step. PRO unlocks the complete plan.", "FREE zeigt deinen wichtigsten nächsten Schritt. PRO schaltet den vollständigen Plan frei."))
                                    .font(AVENFont.body(10.5))
                            }
                            Spacer()
                            Image(systemName: "chevron.right")
                        }
                        .foregroundColor(AVENColor.accentPurple)
                        .padding(14)
                        .background(AVENColor.accentPurple.opacity(0.07))
                        .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
                    }.buttonStyle(.plain)
                }
            }
        }
    }

    private var firstAnalysisCard: some View {
        VStack(spacing: 10) {
            Image(systemName: "camera.viewfinder")
                .font(.system(size: 28))
                .foregroundColor(AVENColor.accentPurple)
            Text("Starte deine erste Profilanalyse")
                .font(AVENFont.body(14, weight: .semibold))
                .foregroundColor(AVENColor.textPrimary)
            Text("Danach erstellt AVEN AI deinen ehrlichen Score, deine Stärken und Schwächen sowie 2–3 konkrete Aufgaben.")
                .font(AVENFont.body(10.5))
                .foregroundColor(AVENColor.textSecondary)
                .multilineTextAlignment(.center)
            Button("Profil analysieren") { container.showNewScan = true }
                .font(AVENFont.body(11.5, weight: .semibold))
                .foregroundColor(AVENColor.accentPurple)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 20)
        .padding(.horizontal, 20)
        .background(AVENColor.backgroundCard)
        .clipShape(RoundedRectangle(cornerRadius: 17, style: .continuous))
    }
}

// MARK: - Challenge UI

private struct GrowthChallengeCard: View {
    let challenge: AVENLiveGrowthChallenge
    let lastSync: String

    var body: some View {
        VStack(alignment: .leading, spacing: 11) {
            HStack(spacing: 10) {
                ZStack {
                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                        .fill(AVENColor.accentPurple.opacity(0.09))
                        .frame(width: 39, height: 39)
                    Image(systemName: challenge.metric.icon)
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(AVENColor.accentPurple)
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text(challenge.metric.challengeTitle)
                        .font(AVENFont.body(13.5, weight: .semibold))
                        .foregroundColor(AVENColor.textPrimary)
                    Text(L("Next goal: \(challenge.target.formatted()) \(challenge.metric.unit)", "Nächstes Ziel: \(challenge.target.formatted()) \(challenge.metric.unit)"))
                        .font(AVENFont.body(10.5))
                        .foregroundColor(AVENColor.textSecondary)
                }
                Spacer()
                Text("+\(challenge.rewardXP) XP")
                    .font(.system(size: 10.5, weight: .bold, design: .rounded))
                    .foregroundColor(AVENColor.accentPurple)
                    .padding(.horizontal, 9)
                    .padding(.vertical, 5)
                    .background(AVENColor.accentPurple.opacity(0.08))
                    .clipShape(Capsule())
            }

            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    Capsule().fill(AVENColor.backgroundSecondary)
                    Capsule()
                        .fill(
                            LinearGradient(
                                colors: [AVENColor.accentPurple, AVENColor.accentBlue],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .frame(width: geo.size.width * challenge.progress)
                }
            }
            .frame(height: 7)

            HStack(alignment: .firstTextBaseline) {
                Text("\(challenge.current.formatted()) / \(challenge.target.formatted()) \(challenge.metric.unit)")
                    .font(AVENFont.body(11, weight: .semibold))
                    .foregroundColor(AVENColor.textPrimary)
                Spacer()
                Text(lastSync)
                    .font(AVENFont.body(9.2))
                    .foregroundColor(AVENColor.textMuted)
            }

            Text(L("AVEN completes this challenge automatically as soon as a successful TikTok sync reports at least \(challenge.target.formatted()) \(challenge.metric.unit). The next stage starts immediately afterwards.", "AVEN hakt die Challenge automatisch ab, sobald ein erfolgreicher TikTok-Sync mindestens \(challenge.target.formatted()) \(challenge.metric.unit) meldet. Danach startet direkt die nächste Stufe."))
                .font(AVENFont.body(9.8))
                .foregroundColor(AVENColor.textSecondary)
                .lineSpacing(2)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(14)
        .background(
            LinearGradient(
                colors: [AVENColor.backgroundCard, AVENColor.accentPurple.opacity(0.025)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .clipShape(RoundedRectangle(cornerRadius: 17, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 17, style: .continuous)
                .strokeBorder(AVENColor.accentPurple.opacity(0.11), lineWidth: 0.7)
        )
    }
}

// MARK: - Coaching task

private struct CoachingTaskCard: View {
    let task: AVENAIPlanTask
    let number: Int
    let locked: Bool
    let onReanalyze: () -> Void
    let onLocked: () -> Void

    @State private var expanded = true
    @State private var copied = false

    private var copyText: String? {
        guard let start = task.detail.range(of: "AVEN_COPY_START"),
              let end = task.detail.range(of: "AVEN_COPY_END"),
              start.upperBound <= end.lowerBound else { return nil }
        let value = String(task.detail[start.upperBound..<end.lowerBound])
            .trimmingCharacters(in: .whitespacesAndNewlines)
        return value.isEmpty ? nil : value
    }

    private var cleanDetail: String {
        guard let start = task.detail.range(of: "AVEN_COPY_START"),
              let end = task.detail.range(of: "AVEN_COPY_END"),
              start.lowerBound <= end.upperBound else { return task.detail }
        var text = task.detail
        text.removeSubrange(start.lowerBound..<end.upperBound)
        return text.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private var icon: String {
        switch task.category.lowercased() {
        case "bio": return "text.alignleft"
        case "content": return "play.rectangle.fill"
        case "profile": return "person.crop.circle"
        case "engagement": return "bubble.left.and.bubble.right.fill"
        case "timing": return "clock.fill"
        case "goal": return "target"
        default: return "sparkles"
        }
    }

    var body: some View {
        VStack(spacing: 0) {
            Button {
                if locked { onLocked() }
                else { withAnimation(.spring(response: 0.34)) { expanded.toggle() } }
            } label: {
                HStack(spacing: 12) {
                    ZStack {
                        Circle()
                            .fill(AVENColor.accentPurple.opacity(0.08))
                            .frame(width: 38, height: 38)
                        if locked {
                            Image(systemName: "lock.fill")
                                .font(.system(size: 12))
                                .foregroundColor(AVENColor.textMuted)
                        } else {
                            Image(systemName: icon)
                                .font(.system(size: 14, weight: .medium))
                                .foregroundColor(AVENColor.accentPurple)
                        }
                    }

                    VStack(alignment: .leading, spacing: 4) {
                        Text(L("STEP \(number)", "SCHRITT \(number)"))
                            .font(.system(size: 8.5, weight: .bold, design: .rounded))
                            .tracking(0.6)
                            .foregroundColor(AVENColor.accentPurple)
                        Text(locked ? L("Another personal task", "Weitere persönliche Aufgabe") : task.title)
                            .font(AVENFont.body(14, weight: .semibold))
                            .foregroundColor(locked ? AVENColor.textMuted : AVENColor.textPrimary)
                            .multilineTextAlignment(.leading)
                            .lineLimit(2)
                    }

                    Spacer(minLength: 8)

                    if locked {
                        Text("PRO")
                            .font(.system(size: 9, weight: .bold))
                            .foregroundColor(AVENColor.accentPurple)
                    } else {
                        VStack(alignment: .trailing, spacing: 5) {
                            Text("+\(task.xp) XP")
                                .font(.system(size: 10.5, weight: .bold, design: .rounded))
                                .foregroundColor(AVENColor.accentPurple)
                            Image(systemName: expanded ? "chevron.up" : "chevron.down")
                                .font(.system(size: 9.5, weight: .semibold))
                                .foregroundColor(AVENColor.textMuted)
                        }
                    }
                }
                .padding(14)
            }
            .buttonStyle(.plain)

            if expanded && !locked {
                Divider().opacity(0.45).padding(.horizontal, 14)

                VStack(alignment: .leading, spacing: 12) {
                    Text(cleanDetail)
                        .font(AVENFont.body(11.5))
                        .foregroundColor(AVENColor.textSecondary)
                        .lineSpacing(4)
                        .fixedSize(horizontal: false, vertical: true)

                    if let potential = task.scorePotential, potential > 0 {
                        HStack(spacing: 7) {
                            Image(systemName: "chart.line.uptrend.xyaxis")
                                .font(.system(size: 10.5, weight: .semibold))
                                .foregroundColor(AVENColor.accentPurple)
                            Text(L("Score potential: up to +\(potential) AVEN points", "Score-Potenzial: bis zu +\(potential) AVEN Punkte"))
                                .font(AVENFont.body(10.5, weight: .semibold))
                                .foregroundColor(AVENColor.accentPurple)
                        }
                        .padding(.horizontal, 10)
                        .padding(.vertical, 8)
                        .background(AVENColor.accentPurple.opacity(0.06))
                        .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                    }

                    if let copyText {
                        VStack(alignment: .leading, spacing: 8) {
                            HStack {
                                Label("AVEN Vorschlag", systemImage: "sparkles")
                                    .font(AVENFont.body(11, weight: .semibold))
                                    .foregroundColor(AVENColor.textPrimary)
                                Spacer()
                                Button {
                                    UIPasteboard.general.string = copyText
                                    withAnimation { copied = true }
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                                        withAnimation { copied = false }
                                    }
                                } label: {
                                    Label(copied ? "Kopiert" : "Kopieren", systemImage: copied ? "checkmark" : "doc.on.doc")
                                        .font(AVENFont.body(10, weight: .semibold))
                                        .foregroundColor(copied ? AVENColor.textPositive : AVENColor.accentPurple)
                                }
                            }

                            Text(copyText)
                                .font(AVENFont.body(12.5, weight: .medium))
                                .foregroundColor(AVENColor.textPrimary)
                                .lineSpacing(4)
                                .textSelection(.enabled)
                                .padding(11)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .background(AVENColor.accentPurple.opacity(0.055))
                                .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))
                        }
                    }

                    HStack(alignment: .top, spacing: 7) {
                        Image(systemName: "checkmark.shield")
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundColor(AVENColor.accentBlue)
                            .padding(.top, 1)
                        Text(L("Make the change on TikTok. Your next profile analysis checks the real new profile evidence. If the task is verified, you receive the XP once.", "Setze die Änderung in TikTok um. Bei deiner nächsten Profilanalyse prüft AVEN die echte neue Profil-Evidenz. Wird diese Aufgabe bestätigt, erhältst du die XP einmalig."))
                            .font(AVENFont.body(9.8))
                            .foregroundColor(AVENColor.textSecondary)
                            .lineSpacing(2)
                    }

                    Button(action: onReanalyze) {
                        HStack(spacing: 7) {
                            Image(systemName: "camera.viewfinder")
                            Text("Profil neu analysieren")
                            Spacer()
                            Image(systemName: "arrow.right")
                        }
                        .font(AVENFont.body(11.5, weight: .semibold))
                        .foregroundColor(.white)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 10)
                        .background(
                            LinearGradient(
                                colors: [AVENColor.accentPurple, AVENColor.accentBlue],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))
                    }
                    .buttonStyle(PressButtonStyle())
                }
                .padding(.horizontal, 14)
                .padding(.top, 12)
                .padding(.bottom, 14)
                .transition(.opacity.combined(with: .move(edge: .top)))
            }
        }
        .background(AVENColor.backgroundCard)
        .clipShape(RoundedRectangle(cornerRadius: 17, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 17, style: .continuous)
                .strokeBorder(AVENColor.borderSubtle, lineWidth: 0.6)
        )
        .shadow(color: AVENColor.cardShadow, radius: 6, y: 2)
    }
}

// MARK: - ViewModel

@MainActor
final class ActionPlanViewModel: ObservableObject {
    struct Item: Identifiable {
        let task: AVENAIPlanTask
        let locked: Bool
        var id: String { task.id }
    }

    @Published var items: [Item] = []

    private var isProUser: Bool {
        #if DEBUG
        return true
        #else
        let plan = UserDefaults.standard.string(forKey: "aven.currentPlan") ?? "FREE"
        return plan == "PRO" || plan == "PRO+"
        #endif
    }

    private let freeUnlockLimit = 3

    init() {
        reload()
        NotificationCenter.default.addObserver(forName: .analysisDidComplete, object: nil, queue: .main) { [weak self] _ in
            self?.reload()
        }
        NotificationCenter.default.addObserver(forName: .aiActionPlanDidUpdate, object: nil, queue: .main) { [weak self] _ in
            self?.reload()
        }
    }

    static func buildFromAnalysis(
        record: AnalysisRecord,
        goal: AccountGoal,
        isProUser: Bool,
        freeLimit: Int
    ) -> [GrowthActionItem] {
        guard let aiTasks = AVENAIActionPlanStore.load(for: record) else { return [] }
        var unlocked = 0
        return Array(aiTasks.prefix(3)).enumerated().map { index, task in
            let locked: Bool
            if isProUser {
                locked = false
            } else if unlocked < freeLimit {
                unlocked += 1
                locked = false
            } else {
                locked = true
            }

            return GrowthActionItem(
                id: task.id,
                title: task.title,
                category: task.category,
                impact: task.xp,
                priority: index + 1,
                severity: .lever,
                isBlocked: false,
                requiresProof: false,
                isProLocked: locked,
                isCompleted: false,
                detail: task.detail
            )
        }
    }

    func reload() {
        guard let record = AVENAnalysisStore.load(), record.analysisScore < 100,
              let tasks = AVENAIActionPlanStore.load(for: record) else {
            withAnimation(.spring(response: 0.35)) { items = [] }
            return
        }

        var unlocked = 0
        let mapped = Array(tasks.prefix(3)).map { task -> Item in
            let locked: Bool
            if isProUser {
                locked = false
            } else if unlocked < freeUnlockLimit {
                unlocked += 1
                locked = false
            } else {
                locked = true
            }
            return Item(task: task, locked: locked)
        }

        withAnimation(.spring(response: 0.35)) { items = mapped }
    }
}

// MARK: - AI plan verification helpers
// These helpers intentionally use the existing snapshot format/key, so no model or
// Xcode project changes are required.

extension AVENAIActionPlanStore {
    static func latestTasksForVerification() -> [AVENAIPlanTask] {
        guard let data = UserDefaults.standard.data(forKey: "aven.aiActionPlan.v1"),
              let snapshot = try? JSONDecoder().decode(AVENAIPlanSnapshot.self, from: data) else { return [] }
        return Array(snapshot.tasks.prefix(3))
    }

    static func grantResolvedTasks(ids: [String]) {
        guard !ids.isEmpty else { return }
        let resolved = Set(ids)
        for task in latestTasksForVerification() where resolved.contains(task.id) {
            _ = AVENXPStore.grantOnce(key: "action-verified.\(task.id)", amount: task.xp)
        }
    }

    static func savePerfectProfile(for analysis: AnalysisRecord) {
        let snapshot = AVENAIPlanSnapshot(analysisTimestamp: analysis.timestamp, createdAt: Date(), tasks: [])
        if let data = try? JSONEncoder().encode(snapshot) {
            UserDefaults.standard.set(data, forKey: "aven.aiActionPlan.v1")
        }
        NotificationCenter.default.post(name: .aiActionPlanDidUpdate, object: nil)
    }
}

// MARK: - Measurable follower/like challenges

enum AVENLiveGrowthMetric: String, CaseIterable {
    case followers
    case likes

    var unit: String { self == .followers ? "Follower" : "Likes" }
    var icon: String { self == .followers ? "person.2.fill" : "heart.fill" }
    var challengeTitle: String { self == .followers ? "Follower Challenge" : "Like Challenge" }
}

struct AVENLiveGrowthChallenge {
    let metric: AVENLiveGrowthMetric
    let current: Int
    let target: Int
    let rewardXP: Int

    var progress: CGFloat {
        guard target > 0 else { return 0 }
        return min(1, max(0, CGFloat(current) / CGFloat(target)))
    }
}

enum AVENGrowthChallengeEngine {
    private static let followerTargets = [100, 200, 500, 1_000, 2_500, 5_000, 10_000, 25_000, 50_000, 100_000, 250_000, 500_000, 1_000_000]
    private static let likeTargets = [1_000, 2_500, 5_000, 10_000, 25_000, 50_000, 100_000, 250_000, 500_000, 1_000_000]

    static func bootstrap(account: ConnectedTikTokAccount) {
        for metric in AVENLiveGrowthMetric.allCases {
            let key = targetKey(metric)
            guard UserDefaults.standard.object(forKey: key) == nil else { continue }
            let current = value(metric, account: account)
            UserDefaults.standard.set(nextTarget(after: current, metric: metric), forKey: key)
        }
    }

    static func rebase(account: ConnectedTikTokAccount) {
        for metric in AVENLiveGrowthMetric.allCases {
            let current = value(metric, account: account)
            UserDefaults.standard.set(nextTarget(after: current, metric: metric), forKey: targetKey(metric))
        }
        NotificationCenter.default.post(name: .growthMissionDidUpdate, object: nil)
    }

    static func reset() {
        for metric in AVENLiveGrowthMetric.allCases {
            UserDefaults.standard.removeObject(forKey: targetKey(metric))
        }
        NotificationCenter.default.post(name: .growthMissionDidUpdate, object: nil)
    }

    static func sync(account: ConnectedTikTokAccount) {
        bootstrap(account: account)

        for metric in AVENLiveGrowthMetric.allCases {
            let current = value(metric, account: account)
            let key = targetKey(metric)
            var target = UserDefaults.standard.integer(forKey: key)
            if target <= 0 {
                target = nextTarget(after: current, metric: metric)
                UserDefaults.standard.set(target, forKey: key)
                continue
            }

            var safety = 0
            while current >= target && safety < 20 {
                let grantKey = metric == .followers
                    ? "followers.\(target)"
                    : "growth-challenge.likes.\(target)"
                _ = AVENXPStore.grantOnce(
                    key: grantKey,
                    amount: reward(metric: metric, target: target)
                )
                target = nextTarget(after: target, metric: metric)
                UserDefaults.standard.set(target, forKey: key)
                safety += 1
            }
        }

        NotificationCenter.default.post(name: .growthMissionDidUpdate, object: nil)
    }

    static func challenge(metric: AVENLiveGrowthMetric, account: ConnectedTikTokAccount) -> AVENLiveGrowthChallenge {
        bootstrap(account: account)
        let current = value(metric, account: account)
        let stored = UserDefaults.standard.integer(forKey: targetKey(metric))
        let target = stored > current ? stored : nextTarget(after: current, metric: metric)
        if stored != target { UserDefaults.standard.set(target, forKey: targetKey(metric)) }
        return AVENLiveGrowthChallenge(
            metric: metric,
            current: current,
            target: target,
            rewardXP: reward(metric: metric, target: target)
        )
    }

    private static func value(_ metric: AVENLiveGrowthMetric, account: ConnectedTikTokAccount) -> Int {
        max(0, metric == .followers ? account.followers : account.likes)
    }

    private static func targetKey(_ metric: AVENLiveGrowthMetric) -> String {
        "aven.growthChallenge.\(metric.rawValue).target.v1"
    }

    private static func nextTarget(after value: Int, metric: AVENLiveGrowthMetric) -> Int {
        let targets = metric == .followers ? followerTargets : likeTargets
        if let target = targets.first(where: { $0 > value }) { return target }

        let step: Int
        switch metric {
        case .followers:
            step = value < 5_000_000 ? 500_000 : 1_000_000
        case .likes:
            step = value < 5_000_000 ? 1_000_000 : 5_000_000
        }
        return ((max(0, value) / step) + 1) * step
    }

    private static func reward(metric: AVENLiveGrowthMetric, target: Int) -> Int {
        switch metric {
        case .followers:
            switch target {
            case ..<500: return 60
            case ..<2_500: return 90
            case ..<10_000: return 120
            case ..<100_000: return 160
            default: return 200
            }
        case .likes:
            switch target {
            case ..<5_000: return 60
            case ..<25_000: return 90
            case ..<100_000: return 120
            case ..<500_000: return 160
            default: return 200
            }
        }
    }
}
