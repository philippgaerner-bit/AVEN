/**
 * Finding-Templates des Creator-Score-Modells v1.
 *
 * 12 feste Vorlagen. Kein Sprachmodell bestimmt deren Existenz, Impact oder Priorität.
 *
 * Invariante beim Import:
 *   Kein CriterionId darf in zwei Templates vorkommen (verhindert doppelte Impact-Zählung).
 *
 * Architekturregeln:
 * - Kein Import aus Datenbank, Netzwerk, KI-SDKs oder Cloud-Diensten.
 */

import type { CriterionId } from "./criterion-ids.js";
import type { FindingSeverity } from "./types.js";
import { CRITERION_BY_ID } from "./criterion-table.js";
import { ScoringDomainError } from "./criterion-table.js";

// ─── Template-Typ ────────────────────────────────────────────────────────────

export interface FindingTemplate {
  /** Eindeutiger Bezeichner — stabile Referenz für Tests und Aktionsplan */
  readonly templateId: string;
  /** Anzeige-Titel (Beobachtung, kein Vorwurf) — fester Produkttext */
  readonly title: string;
  readonly severity: FindingSeverity;
  /** Kriterien, die zu diesem Finding gehören — disjunkt über alle Templates */
  readonly criterionIds: ReadonlyArray<CriterionId>;
}

// ─── Die 12 V1-Templates ─────────────────────────────────────────────────────

const TEMPLATES_RAW: ReadonlyArray<FindingTemplate> = [
  {
    templateId: "bio_positioning_unclear",
    title: "Deine Bio macht nicht sofort klar, für wen dein Profil ist.",
    severity: "foundation",
    criterionIds: ["bio_target_audience", "bio_outcome"],
  },
  {
    templateId: "bio_cta_missing",
    title: "Deiner Bio fehlt ein klarer nächster Schritt.",
    severity: "lever",
    criterionIds: ["bio_cta"],
  },
  {
    templateId: "bio_first_line_weak",
    title: "Die erste Zeile deiner Bio nutzt ihren Platz nicht optimal.",
    severity: "lever",
    criterionIds: ["bio_first_line", "bio_no_filler"],
  },
  {
    templateId: "content_hook_weak",
    title: "Dein Content braucht stärkere Einstiege.",
    severity: "foundation",
    criterionIds: ["content_hook"],
  },
  {
    templateId: "covers_unclear",
    title: "Deine Covers kommunizieren den Inhalt nicht schnell genug.",
    severity: "lever",
    criterionIds: ["content_cover", "content_text_position"],
  },
  {
    templateId: "content_structure_inconsistent",
    title: "Deinem Content fehlt eine erkennbare Struktur.",
    severity: "lever",
    criterionIds: ["content_recurring", "content_regularity"],
  },
  {
    templateId: "feed_inconsistent",
    title: "Dein Feed wirkt noch nicht wie eine zusammenhängende Marke.",
    severity: "polish",
    criterionIds: ["feed_color_world", "feed_cover_pattern"],
  },
  {
    templateId: "feed_topic_unclear",
    title: "Auf den ersten Blick ist dein Hauptthema nicht klar genug.",
    severity: "foundation",
    criterionIds: ["feed_topic"],
  },
  {
    templateId: "branding_inconsistent",
    title: "Dein Branding ist noch nicht eindeutig wiedererkennbar.",
    severity: "polish",
    criterionIds: ["brand_colors", "brand_font", "brand_theme", "brand_recognizable"],
  },
  {
    templateId: "profile_picture_weak",
    title: "Dein Profilbild könnte schneller wiedererkannt werden.",
    severity: "lever",
    criterionIds: [
      "profile_pic_recognition",
      "profile_pic_subject",
      "profile_pic_contrast",
      "profile_pic_color_fit",
    ],
  },
  {
    templateId: "identity_unclear",
    title: "Name und Username kommunizieren deine Positionierung noch nicht optimal.",
    severity: "lever",
    criterionIds: [
      "username_pronounceable",
      "username_clean",
      "name_field_topic",
      "username_name_match",
    ],
  },
  {
    templateId: "engagement_structure_weak",
    title: "Dein Content schafft noch zu wenig Anlass zur Interaktion.",
    severity: "lever",
    criterionIds: [
      "engagement_captions",
      "engagement_replies",
      "engagement_opinion",
      "engagement_cta_end",
    ],
  },
];

// ─── Fail-fast Invariante beim Import ────────────────────────────────────────

(function validateTemplates() {
  const seenCriterionIds = new Map<string, string>(); // criterionId → templateId

  for (const tmpl of TEMPLATES_RAW) {
    // 1. Alle CriterionIds müssen bekannt sein
    for (const id of tmpl.criterionIds) {
      if (CRITERION_BY_ID[id] === undefined) {
        throw new ScoringDomainError(
          `[VYRO FindingTemplates] Template "${tmpl.templateId}" referenziert ` +
            `unbekannte CriterionId: "${id}"`
        );
      }
    }

    // 2. Disjunktheit: kein CriterionId in zwei Templates
    for (const id of tmpl.criterionIds) {
      const prev = seenCriterionIds.get(id);
      if (prev !== undefined) {
        throw new ScoringDomainError(
          `[VYRO FindingTemplates] CriterionId "${id}" erscheint in zwei Templates: ` +
            `"${prev}" und "${tmpl.templateId}". ` +
            `Das würde zu doppelter Impact-Zählung führen.`
        );
      }
      seenCriterionIds.set(id, tmpl.templateId);
    }

    // 3. templateId eindeutig
    // (läuft automatisch durch die seenCriterionIds-Map, aber explizit für templateId)
  }

  // 4. Keine doppelten templateIds
  const seenTemplateIds = new Set<string>();
  for (const tmpl of TEMPLATES_RAW) {
    if (seenTemplateIds.has(tmpl.templateId)) {
      throw new ScoringDomainError(
        `[VYRO FindingTemplates] Doppelte templateId: "${tmpl.templateId}"`
      );
    }
    seenTemplateIds.add(tmpl.templateId);
  }
})();

// ─── Öffentliche Konstanten ──────────────────────────────────────────────────

/** Alle 12 V1-Finding-Templates */
export const FINDING_TEMPLATES: ReadonlyArray<FindingTemplate> = TEMPLATES_RAW;

/** Schnellzugriff nach templateId */
export const FINDING_TEMPLATE_BY_ID: Readonly<Record<string, FindingTemplate>> =
  Object.fromEntries(
    TEMPLATES_RAW.map((t) => [t.templateId, t])
  ) as Readonly<Record<string, FindingTemplate>>;

/**
 * Alle CriterionIds die in irgendeinem Template referenziert werden.
 * Nützlich für Vollständigkeitsprüfungen.
 */
export const TEMPLATE_CRITERION_IDS: ReadonlySet<CriterionId> = new Set(
  TEMPLATES_RAW.flatMap((t) => [...t.criterionIds])
);
