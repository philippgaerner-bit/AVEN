/**
 * Öffentliches Interface des @vyro/shared/scoring-Moduls.
 *
 * Alles, was andere Pakete importieren dürfen, wird hier re-exportiert.
 */

// Kriterien-IDs
export {
  ALL_CRITERION_IDS,
  BIO_CRITERION_IDS,
  CONTENT_CRITERION_IDS,
  FEED_CRITERION_IDS,
  BRAND_CRITERION_IDS,
  PROFILE_PIC_CRITERION_IDS,
  USERNAME_CRITERION_IDS,
  ENGAGEMENT_CRITERION_IDS,
  EXPECTED_CRITERION_COUNT,
} from "./criterion-ids.js";

export type { CriterionId } from "./criterion-ids.js";

// Kategorien
export {
  CATEGORIES,
  CATEGORY_IDS,
  CATEGORY_BY_ID,
  EXPECTED_CATEGORY_COUNT,
  EXPECTED_TOTAL_MAX_POINTS,
} from "./categories.js";

export type { CategoryId, CategoryDefinition } from "./categories.js";

// Alle Typen
export {
  SCORING_MODEL_VERSION,
  CRITERION_STATES,
  OBSERVATION_SOURCES,
  FINDING_SEVERITIES,
  FINDING_STATUSES,
  MINIMUM_COVERAGE_FOR_DISPLAY,
} from "./types.js";

export type {
  ScoringModelVersion,
  CriterionState,
  ObservationSource,
  CriterionObservation,
  ObservationPackage,
  CategoryScore,
  ScoreSet,
  CoverageReport,
  ScoringResult,
  FindingSeverity,
  FindingStatus,
  Finding,
  CriterionDefinition,
} from "./types.js";

// Kriterientabelle
export {
  CRITERION_TABLE,
  CRITERION_BY_ID,
  pointsForState,
  ScoringDomainError,
} from "./criterion-table.js";

// Bewertungskern
export { calculateScore } from "./calculate-score.js";

// Finding-Templates und Befundbildung
export {
  FINDING_TEMPLATES,
  FINDING_TEMPLATE_BY_ID,
} from "./finding-templates.js";

export type { FindingTemplate } from "./finding-templates.js";

export {
  buildFindings,
  selectTopFindings,
  verifyNachrechenbarkeit,
} from "./build-findings.js";
