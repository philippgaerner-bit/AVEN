/**
 * Kategorie-Definitionen und Maximalwerte des Creator-Score-Modells.
 *
 * Die Summe aller Kategorie-Maximalwerte muss exakt 100 ergeben.
 * Diese Regel ist durch eine Invariante in __tests__/ abgesichert.
 *
 * Architekturregeln:
 * - Keine Imports aus Datenbank, Netzwerk, KI-SDKs oder Cloud-Diensten.
 * - Diese Datei ist deterministisch und zustandslos.
 */

import type { CriterionId } from "./criterion-ids.js";
import {
  BIO_CRITERION_IDS,
  CONTENT_CRITERION_IDS,
  FEED_CRITERION_IDS,
  BRAND_CRITERION_IDS,
  PROFILE_PIC_CRITERION_IDS,
  USERNAME_CRITERION_IDS,
  ENGAGEMENT_CRITERION_IDS,
} from "./criterion-ids.js";

// ─── Kategorie-ID ────────────────────────────────────────────────────────────

export const CATEGORY_IDS = [
  "bio",
  "content",
  "feed",
  "brand",
  "profilePic",
  "username",
  "engagement",
] as const;

export type CategoryId = (typeof CATEGORY_IDS)[number];

export const EXPECTED_CATEGORY_COUNT = 7 as const;

// ─── Kategorie-Definition ────────────────────────────────────────────────────

export interface CategoryDefinition {
  /** Eindeutiger Bezeichner der Kategorie */
  readonly id: CategoryId;
  /** Anzeigename */
  readonly label: string;
  /** Maximale Punktzahl dieser Kategorie (muss > 0 sein) */
  readonly maxPoints: number;
  /** Alle Kriterien, die zu dieser Kategorie gehören */
  readonly criterionIds: ReadonlyArray<CriterionId>;
}

// ─── Kategorietabelle ────────────────────────────────────────────────────────

/**
 * Unveränderliche Kategorietabelle.
 *
 * Gewichtung begründet im Score-Modell-Dokument:
 *   bio        18 — Flaschenhals der Profil-Conversion, direkt änderbar
 *   content    20 — größter Wachstumshebel, größtes Verbesserungspotenzial
 *   feed       16 — kumulativer Wiedererkennungseffekt
 *   brand      14 — langsamere, aber nachhaltige Wirkung
 *   profilePic 10 — wichtig, aber niedrige Wirkungsobergrenze
 *   username   10 — wichtig, aber niedrige Wirkungsobergrenze
 *   engagement 12 — messbare Einladung zum Reagieren
 *               ──
 *              100
 */
export const CATEGORIES: ReadonlyArray<CategoryDefinition> = [
  {
    id: "bio",
    label: "Bio",
    maxPoints: 18,
    criterionIds: BIO_CRITERION_IDS,
  },
  {
    id: "content",
    label: "Content-Struktur",
    maxPoints: 20,
    criterionIds: CONTENT_CRITERION_IDS,
  },
  {
    id: "feed",
    label: "Feed",
    maxPoints: 16,
    criterionIds: FEED_CRITERION_IDS,
  },
  {
    id: "brand",
    label: "Branding",
    maxPoints: 14,
    criterionIds: BRAND_CRITERION_IDS,
  },
  {
    id: "profilePic",
    label: "Profilbild",
    maxPoints: 10,
    criterionIds: PROFILE_PIC_CRITERION_IDS,
  },
  {
    id: "username",
    label: "Username & Name",
    maxPoints: 10,
    criterionIds: USERNAME_CRITERION_IDS,
  },
  {
    id: "engagement",
    label: "Engagement-Struktur",
    maxPoints: 12,
    criterionIds: ENGAGEMENT_CRITERION_IDS,
  },
] as const;

/** Erwartete Gesamtpunktzahl aller Kategorien — muss exakt 100 ergeben */
export const EXPECTED_TOTAL_MAX_POINTS = 100 as const;

/** Schnellzugriff: Kategorie nach ID */
export const CATEGORY_BY_ID: Readonly<Record<CategoryId, CategoryDefinition>> =
  Object.fromEntries(
    CATEGORIES.map((cat) => [cat.id, cat])
  ) as Readonly<Record<CategoryId, CategoryDefinition>>;
