/**
 * Kriterientabelle des Creator-Score-Modells v1.
 *
 * Enthält alle 31 CriterionDefinitions mit ihren Punktwerten und Regeln.
 * Diese Datei ist die einzige Quelle der Wahrheit für Einzelgewichte.
 *
 * Zwei Invarianten werden beim Import geprüft (fail-fast):
 *   1. Summe aller maxPoints = 100
 *   2. Summe je Kategorie = CategoryDefinition.maxPoints
 *
 * Architekturregeln:
 * - Kein Import aus Datenbank, Netzwerk, KI-SDKs oder Cloud-Diensten.
 * - Reine Datenkonstante, keine Laufzeitlogik.
 */

import type { CriterionDefinition } from "./types.js";
import { CATEGORIES } from "./categories.js";

// ─── Kriterientabelle ────────────────────────────────────────────────────────

/**
 * Alle 31 Kriterien-Definitionen, geordnet nach Kategorie.
 *
 * Partial-Regel (aufgerundet):
 *   maxPoints 5 → partial = 3
 *   maxPoints 4 → partial = 2
 *   maxPoints 3 → partial = 2
 *   maxPoints 2 → partial = 1
 *   maxPoints 1 → partial nicht erlaubt (zu wenig Spielraum)
 */
const CRITERION_TABLE_RAW: ReadonlyArray<CriterionDefinition> = [
  // ── Bio (5 Kriterien, max. 18) ─────────────────────────────────────────────
  { id: "bio_target_audience", categoryId: "bio",        maxPoints: 5, allowsPartial: false },
  { id: "bio_outcome",         categoryId: "bio",        maxPoints: 5, allowsPartial: false },
  { id: "bio_cta",             categoryId: "bio",        maxPoints: 3, allowsPartial: false },
  { id: "bio_first_line",      categoryId: "bio",        maxPoints: 3, allowsPartial: true  },
  { id: "bio_no_filler",       categoryId: "bio",        maxPoints: 2, allowsPartial: true  },

  // ── Content (6 Kriterien, max. 20) ─────────────────────────────────────────
  { id: "content_hook",          categoryId: "content",  maxPoints: 5, allowsPartial: true  },
  { id: "content_cover",         categoryId: "content",  maxPoints: 4, allowsPartial: true  },
  { id: "content_recurring",     categoryId: "content",  maxPoints: 4, allowsPartial: false },
  { id: "content_length",        categoryId: "content",  maxPoints: 3, allowsPartial: false },
  { id: "content_text_position", categoryId: "content",  maxPoints: 2, allowsPartial: false },
  { id: "content_regularity",    categoryId: "content",  maxPoints: 2, allowsPartial: true  },

  // ── Feed (4 Kriterien, max. 16) ────────────────────────────────────────────
  { id: "feed_color_world",   categoryId: "feed",        maxPoints: 5, allowsPartial: true  },
  { id: "feed_cover_pattern", categoryId: "feed",        maxPoints: 4, allowsPartial: true  },
  { id: "feed_topic",         categoryId: "feed",        maxPoints: 4, allowsPartial: false },
  { id: "feed_pinned",        categoryId: "feed",        maxPoints: 3, allowsPartial: false },

  // ── Branding (4 Kriterien, max. 14) ────────────────────────────────────────
  { id: "brand_colors",       categoryId: "brand",       maxPoints: 4, allowsPartial: true  },
  { id: "brand_font",         categoryId: "brand",       maxPoints: 3, allowsPartial: false },
  { id: "brand_theme",        categoryId: "brand",       maxPoints: 4, allowsPartial: true  },
  { id: "brand_recognizable", categoryId: "brand",       maxPoints: 3, allowsPartial: false },

  // ── Profilbild (4 Kriterien, max. 10) ──────────────────────────────────────
  { id: "profile_pic_recognition", categoryId: "profilePic", maxPoints: 4, allowsPartial: true  },
  { id: "profile_pic_subject",     categoryId: "profilePic", maxPoints: 3, allowsPartial: false },
  { id: "profile_pic_contrast",    categoryId: "profilePic", maxPoints: 2, allowsPartial: false },
  { id: "profile_pic_color_fit",   categoryId: "profilePic", maxPoints: 1, allowsPartial: false },

  // ── Username & Name (4 Kriterien, max. 10) ─────────────────────────────────
  { id: "username_pronounceable", categoryId: "username", maxPoints: 3, allowsPartial: true  },
  { id: "username_clean",         categoryId: "username", maxPoints: 2, allowsPartial: false },
  { id: "name_field_topic",       categoryId: "username", maxPoints: 4, allowsPartial: false },
  { id: "username_name_match",    categoryId: "username", maxPoints: 1, allowsPartial: false },

  // ── Engagement (4 Kriterien, max. 12) ──────────────────────────────────────
  { id: "engagement_captions", categoryId: "engagement", maxPoints: 4, allowsPartial: true  },
  { id: "engagement_replies",  categoryId: "engagement", maxPoints: 3, allowsPartial: false },
  { id: "engagement_opinion",  categoryId: "engagement", maxPoints: 3, allowsPartial: true  },
  { id: "engagement_cta_end",  categoryId: "engagement", maxPoints: 2, allowsPartial: false },
] as const;

// ─── Fail-fast Invariantenprüfung (läuft beim Import) ───────────────────────

(function validateCriterionTable() {
  // 1. Gesamtsumme muss 100 ergeben
  const totalSum = CRITERION_TABLE_RAW.reduce((acc, c) => acc + c.maxPoints, 0);
  if (totalSum !== 100) {
    throw new Error(
      `[VYRO Scoring] Invariante verletzt: Summe aller Kriterien-maxPoints = ${totalSum}, erwartet 100`
    );
  }

  // 2. Kategoriensummen müssen mit CategoryDefinition.maxPoints übereinstimmen
  for (const category of CATEGORIES) {
    const categoryCriteria = CRITERION_TABLE_RAW.filter(
      (c) => c.categoryId === category.id
    );
    const categorySum = categoryCriteria.reduce((acc, c) => acc + c.maxPoints, 0);
    if (categorySum !== category.maxPoints) {
      throw new Error(
        `[VYRO Scoring] Invariante verletzt: Kategorie "${category.id}" — ` +
          `Summe der Kriterien = ${categorySum}, erwartet ${category.maxPoints}`
      );
    }
  }
})();

// ─── Öffentliche Schnittstellen ──────────────────────────────────────────────

/** Alle 31 Kriterien-Definitionen als unveränderliches Array */
export const CRITERION_TABLE: ReadonlyArray<CriterionDefinition> = CRITERION_TABLE_RAW;

/** Schnellzugriff: CriterionDefinition nach ID */
export const CRITERION_BY_ID: Readonly<
  Record<string, CriterionDefinition>
> = Object.fromEntries(
  CRITERION_TABLE_RAW.map((c) => [c.id, c])
) as Readonly<Record<string, CriterionDefinition>>;

/**
 * Berechnet die Punkte für einen gegebenen Zustand und eine Kriteriumsdefinition.
 *
 * Partial-Regel: Math.ceil(maxPoints / 2)
 * Beispiele: 5→3, 4→2, 3→2, 2→1
 *
 * Wirf einen Fehler wenn `partial` auf einem Kriterium ohne allowsPartial geliefert wird.
 * Das ist ein ungültiges ObservationPackage, kein Laufzeitfehler der Pipeline.
 */
export function pointsForState(
  def: CriterionDefinition,
  state: "fulfilled" | "partial" | "missing" | "unavailable"
): number | "unavailable" {
  switch (state) {
    case "fulfilled":
      return def.maxPoints;
    case "partial":
      if (!def.allowsPartial) {
        throw new ScoringDomainError(
          `Kriterium "${def.id}" erlaubt keinen partial-Zustand (allowsPartial = false). ` +
            `Das ObservationPackage ist ungültig.`
        );
      }
      return Math.ceil(def.maxPoints / 2);
    case "missing":
      return 0;
    case "unavailable":
      return "unavailable";
  }
}

// ─── Domain-Fehlerklasse ─────────────────────────────────────────────────────

/**
 * Wird geworfen bei ungültigen ObservationPackages.
 * Kein Laufzeitfehler der Pipeline — das ist ein Programmierfehler im Aufrufer.
 */
export class ScoringDomainError extends Error {
  override readonly name = "ScoringDomainError";
  constructor(message: string) {
    super(message);
  }
}
