/**
 * calculateScore — Herzstück des Creator-Score-Bewertungskerns.
 *
 * REINE FUNKTION:
 * - Keine Datenbank
 * - Kein Netzwerk
 * - Keine Uhrzeit / Date.now()
 * - Kein Zufall / Math.random()
 * - Keine globalen veränderlichen Zustände
 *
 * Gleiche Eingabe → gleiche Ausgabe, immer, ohne Ausnahme.
 *
 * Architekturregeln:
 * - Kein Import aus Datenbank, Netzwerk, KI-SDKs oder Cloud-Diensten.
 */

import {
  SCORING_MODEL_VERSION,
  MINIMUM_COVERAGE_FOR_DISPLAY,
  type ObservationPackage,
  type ScoringResult,
  type ScoreSet,
  type CoverageReport,
  type CategoryScore,
} from "./types.js";

import { ALL_CRITERION_IDS, type CriterionId } from "./criterion-ids.js";
import { CATEGORIES, type CategoryId } from "./categories.js";
import {
  CRITERION_BY_ID,
  pointsForState,
  ScoringDomainError,
} from "./criterion-table.js";

// ─── Öffentliche Funktion ────────────────────────────────────────────────────

/**
 * Berechnet den Creator Score aus einem ObservationPackage.
 *
 * Ablauf:
 *  1. Eingabe validieren (Version, Duplikate, unbekannte IDs, partial auf non-partial)
 *  2. Fehlende CriterionIds als `unavailable` ergänzen
 *  3. Punkte je Kriterium berechnen
 *  4. Kategorie-Rohwerte und Kategorie-Nenner berechnen
 *  5. CoverageReport berechnen
 *  6. Gesamtscore normalisieren (rawPoints / checkedPoints * 100, gerundet)
 *  7. ScoringResult zurückgeben
 *
 * Trägheitskorridor (priorScoreSet): in V1 noch nicht aktiv.
 * appliedPriorSmoothing ist immer false.
 *
 * @throws ScoringDomainError bei ungültigem ObservationPackage
 */
export function calculateScore(pkg: ObservationPackage): ScoringResult {
  // ── Schritt 1: Eingabe validieren ──────────────────────────────────────────
  validatePackage(pkg);

  // ── Schritt 2: Beobachtungsmap aufbauen (fehlende → unavailable) ──────────
  const stateMap = buildStateMap(pkg);

  // ── Schritt 3: Punkte je Kriterium berechnen ──────────────────────────────
  // pointsForState wirft ScoringDomainError bei partial auf non-partial
  // (wird in validatePackage bereits geprüft, aber defence in depth)
  const pointMap = new Map<CriterionId, number | "unavailable">();
  for (const id of ALL_CRITERION_IDS) {
    const state = stateMap.get(id) ?? "unavailable";
    const def = CRITERION_BY_ID[id];
    if (def === undefined) {
      // Sollte durch validatePackage nie passieren
      throw new ScoringDomainError(`Interne Fehler: keine Definition für "${id}"`);
    }
    pointMap.set(id, pointsForState(def, state));
  }

  // ── Schritt 4: Kategorie-Rohwerte und -Nenner ─────────────────────────────
  type CategoryAccumulator = {
    rawPoints: number;
    checkedMaxPoints: number;
    unavailablePoints: number;
  };

  const categoryAccumulators = new Map<CategoryId, CategoryAccumulator>();
  for (const cat of CATEGORIES) {
    categoryAccumulators.set(cat.id, {
      rawPoints: 0,
      checkedMaxPoints: 0,
      unavailablePoints: 0,
    });
  }

  let globalRawPoints = 0;
  let globalUnavailablePoints = 0;
  const unavailableCriterionIds: CriterionId[] = [];

  for (const id of ALL_CRITERION_IDS) {
    const def = CRITERION_BY_ID[id]!;
    const pts = pointMap.get(id)!;
    const acc = categoryAccumulators.get(def.categoryId)!;

    if (pts === "unavailable") {
      acc.unavailablePoints += def.maxPoints;
      globalUnavailablePoints += def.maxPoints;
      unavailableCriterionIds.push(id);
    } else {
      acc.rawPoints += pts;
      acc.checkedMaxPoints += def.maxPoints;
      globalRawPoints += pts;
    }
  }

  // ── Schritt 5: CoverageReport ─────────────────────────────────────────────
  const checkedPoints = 100 - globalUnavailablePoints;
  const coverageRatio = checkedPoints / 100;
  const belowDisplayThreshold = coverageRatio < MINIMUM_COVERAGE_FOR_DISPLAY;

  const coverageReport: CoverageReport = {
    rawPoints: globalRawPoints,
    checkedPoints,
    unavailablePoints: globalUnavailablePoints,
    totalPoints: 100,
    coverageRatio,
    unavailableCriterionIds,
    belowDisplayThreshold,
  };

  // ── Schritt 6: Gesamtscore normalisieren ──────────────────────────────────
  // Bei checkedPoints = 0 (alle unavailable): Score = 0 intern, aber nicht displayable
  const normalizedTotal =
    checkedPoints === 0
      ? 0
      : Math.round((globalRawPoints / checkedPoints) * 100);

  // ── Schritt 7: Kategorien normalisieren ───────────────────────────────────
  const bio       = normalizeCategoryScore(categoryAccumulators.get("bio")!);
  const content   = normalizeCategoryScore(categoryAccumulators.get("content")!);
  const feed      = normalizeCategoryScore(categoryAccumulators.get("feed")!);
  const brand     = normalizeCategoryScore(categoryAccumulators.get("brand")!);
  const profilePic = normalizeCategoryScore(categoryAccumulators.get("profilePic")!);
  const username  = normalizeCategoryScore(categoryAccumulators.get("username")!);
  const engagement = normalizeCategoryScore(categoryAccumulators.get("engagement")!);

  const scoreSet: ScoreSet = {
    total: normalizedTotal,
    bio,
    content,
    feed,
    brand,
    profilePic,
    username,
    engagement,
  };

  // ── Schritt 8: ScoringResult zurückgeben ──────────────────────────────────
  if (belowDisplayThreshold) {
    return {
      displayable: false,
      scoreSet,
      coverageReport,
      appliedPriorSmoothing: false,
    };
  }

  return {
    displayable: true,
    scoreSet,
    coverageReport,
    appliedPriorSmoothing: false,
  };
}

// ─── Hilfsfunktionen ─────────────────────────────────────────────────────────

/**
 * Berechnet alle vier CategoryScore-Felder korrekt.
 *
 * rawPoints        = tatsächlich erreichte Punkte
 * checkedMaxPoints = Punkte prüfbarer Kriterien
 * normalizedPoints = round(rawPoints / checkedMaxPoints * fullMaxPoints)
 * fullMaxPoints    = festes Kategorie-Maximum
 *
 * Invarianten:
 *   rawPoints <= checkedMaxPoints
 *   normalizedPoints <= fullMaxPoints
 *   Bei checkedMaxPoints = 0: normalizedPoints = 0
 */
function normalizeCategoryScore(
  acc: { rawPoints: number; checkedMaxPoints: number; unavailablePoints: number }
): CategoryScore {
  const fullMaxPoints = acc.checkedMaxPoints + acc.unavailablePoints;
  if (acc.checkedMaxPoints === 0) {
    return {
      rawPoints: 0,
      checkedMaxPoints: 0,
      normalizedPoints: 0,
      fullMaxPoints,
    };
  }
  const normalizedPoints = Math.round(
    (acc.rawPoints / acc.checkedMaxPoints) * fullMaxPoints
  );
  return {
    rawPoints: acc.rawPoints,
    checkedMaxPoints: acc.checkedMaxPoints,
    normalizedPoints,
    fullMaxPoints,
  };
}

/**
 * Baut eine Map von CriterionId → State aus dem Package.
 * Fehlende Kriterien erhalten implizit den Zustand `unavailable`.
 */
function buildStateMap(
  pkg: ObservationPackage
): Map<CriterionId, "fulfilled" | "partial" | "missing" | "unavailable"> {
  const map = new Map<
    CriterionId,
    "fulfilled" | "partial" | "missing" | "unavailable"
  >();
  for (const obs of pkg.observations) {
    map.set(obs.id, obs.state);
  }
  return map;
}

/**
 * Validiert ein ObservationPackage vor der Berechnung.
 *
 * Wirft ScoringDomainError bei:
 *   - falscher scoringModelVersion
 *   - doppelter CriterionId
 *   - unbekannter CriterionId
 *   - partial auf einem Kriterium mit allowsPartial = false
 */
function validatePackage(pkg: ObservationPackage): void {
  // 1. Versionscheck
  if (pkg.scoringModelVersion !== SCORING_MODEL_VERSION) {
    throw new ScoringDomainError(
      `Ungültige scoringModelVersion: "${pkg.scoringModelVersion}". ` +
        `Erwartet: "${SCORING_MODEL_VERSION}".`
    );
  }

  // 2. Duplikate und unbekannte IDs
  const seenIds = new Set<string>();
  for (const obs of pkg.observations) {
    if (seenIds.has(obs.id)) {
      throw new ScoringDomainError(
        `CriterionId "${obs.id}" kommt mehrfach im ObservationPackage vor.`
      );
    }
    seenIds.add(obs.id);

    const def = CRITERION_BY_ID[obs.id];
    if (def === undefined) {
      throw new ScoringDomainError(
        `Unbekannte CriterionId: "${obs.id}". ` +
          `Prüfe ob die Pipeline-Version zur Scoring-Modell-Version passt.`
      );
    }

    // 3. partial nur bei allowsPartial = true
    if (obs.state === "partial" && !def.allowsPartial) {
      throw new ScoringDomainError(
        `Kriterium "${obs.id}" erlaubt keinen partial-Zustand (allowsPartial = false). ` +
          `Das ObservationPackage ist ungültig.`
      );
    }
  }
}
