/**
 * Zentrale Typdefinitionen des Creator-Score-Bewertungskerns.
 *
 * Architekturregeln:
 * - Keine Imports aus Datenbank, Netzwerk, KI-SDKs oder Cloud-Diensten.
 * - Alle Typen sind reine Datenstrukturen (keine Klassen, keine Methoden).
 * - Zustandslos, serialisierbar, versioniert.
 */

import type { CriterionId } from "./criterion-ids.js";
import type { CategoryId } from "./categories.js";

// ─── Versionierung ───────────────────────────────────────────────────────────

/**
 * Aktuelle Version des Score-Modells.
 *
 * Muss erhöht werden bei jeder Änderung an:
 *   - Kriteriengewichten
 *   - Kategoriegewichten
 *   - Schwellenwerten (Trägheitskorridor, Abdeckungsgrenze)
 *   - Befundvorlagen
 *   - Rundungsregeln
 *
 * Vergangene Scans behalten ihre gespeicherte Version.
 * Ein Vergleich zweier Scans ist nur innerhalb derselben Version valide.
 */
export const SCORING_MODEL_VERSION = "v1.0.0" as const;
export type ScoringModelVersion = typeof SCORING_MODEL_VERSION;

// ─── Kriterium-Beobachtungszustand ──────────────────────────────────────────

/**
 * Vier mögliche Zustände eines Kriteriums nach Beobachtung.
 *
 * fulfilled   — Kriterium vollständig erfüllt, volle Punkte
 * partial     — Kriterium teilweise erfüllt, halbe Punkte (nur bei erlaubten Kriterien)
 * missing     — Kriterium nicht erfüllt, 0 Punkte
 * unavailable — Kriterium konnte aus dem Screenshot nicht geprüft werden,
 *               fällt aus Zähler UND Nenner heraus
 */
export const CRITERION_STATES = [
  "fulfilled",
  "partial",
  "missing",
  "unavailable",
] as const;

export type CriterionState = (typeof CRITERION_STATES)[number];

// ─── Beobachtungsquelle ──────────────────────────────────────────────────────

/**
 * Klasse der Beobachtungsquelle (aus der Analyse-Pipeline).
 *
 * A — deterministischer Algorithmus (reine Berechnung, Messung, Zählung)
 * B — Vision-Modell (visuelle Ähnlichkeit, Motiverkennung)
 * C — Sprachmodell (semantische Textanalyse)
 *
 * Nur Klasse A ist vollständig reproduzierbar ohne Modellaufruf.
 * B und C können bei identischen Eingaben minimal abweichen;
 * dagegen wirken: feste Modellversionen, Temperatur 0, Doppelaufruf bei Grenzfällen.
 */
export const OBSERVATION_SOURCES = ["A", "B", "C"] as const;
export type ObservationSource = (typeof OBSERVATION_SOURCES)[number];

// ─── Einzelne Kriterium-Beobachtung ─────────────────────────────────────────

/**
 * Ergebnis der Beobachtung eines einzelnen Kriteriums.
 * Wird von der Analyse-Pipeline erzeugt und an den Bewertungskern übergeben.
 *
 * Der Bewertungskern wertet ausschließlich `state` aus —
 * `source` dient der Nachvollziehbarkeit und dem Monitoring.
 */
export interface CriterionObservation {
  /** Welches Kriterium wurde beobachtet */
  readonly id: CriterionId;
  /** Ergebnis der Beobachtung */
  readonly state: CriterionState;
  /** Methode, mit der die Beobachtung erzeugt wurde */
  readonly source: ObservationSource;
}

// ─── Beobachtungspaket ───────────────────────────────────────────────────────

/**
 * Vollständige Eingabe für den Bewertungskern.
 *
 * Enthält bis zu 31 Beobachtungen (oder eine Teilmenge, wenn Kriterien
 * `unavailable` sind und deshalb weggelassen wurden — der Kern behandelt
 * fehlende Einträge wie `unavailable`).
 */
export interface ObservationPackage {
  /** Beobachtungen aller geprüften Kriterien */
  readonly observations: ReadonlyArray<CriterionObservation>;

  /**
   * Score des unmittelbar vorangegangenen Scans desselben Profils.
   * Wird für den Trägheitskorridor verwendet (verhindert Score-Sprünge
   * durch marginale Änderungen an der Schwelle).
   * Fehlt beim allerersten Scan.
   */
  readonly priorScoreSet?: ScoreSet;

  /**
   * Versionskennung je Modellaufruf.
   * Schlüssel: logischer Adapterbezeichner (z. B. "ocr", "vision", "language")
   * Wert: Modellkennung des Anbieters (z. B. "gemini-2.0-flash-001")
   */
  readonly modelVersions: Readonly<Record<string, string>>;

  /** Version der Analyse-Pipeline (Stufen 0–6) */
  readonly pipelineVersion: string;

  /** Version des Score-Modells, das für die Bewertung verwendet wird */
  readonly scoringModelVersion: ScoringModelVersion;
}

// ─── Score-Ergebnis ──────────────────────────────────────────────────────────

/**
 * Score-Werte einer einzelnen Kategorie.
 *
 * Vier klar getrennte Bedeutungen:
 *
 *   rawPoints        — tatsächlich erreichte Rohpunkte aus prüfbaren Kriterien
 *   checkedMaxPoints — maximale Punkte der tatsächlich prüfbaren Kriterien
 *   normalizedPoints — Leistung hochskaliert auf fullMaxPoints (für Score-Anzeige)
 *   fullMaxPoints    — festes Kategorie-Maximum (unveränderlich)
 *
 * Beispiel Content (max. 20 Pkt):
 *   content_hook (5 Pkt) unavailable, 12 von 15 restlichen erreicht
 *   → rawPoints = 12, checkedMaxPoints = 15, normalizedPoints = 16, fullMaxPoints = 20
 *
 * Invarianten:
 *   rawPoints <= checkedMaxPoints
 *   normalizedPoints <= fullMaxPoints
 *   checkedMaxPoints + unavailablePoints = fullMaxPoints  (unavailablePoints implizit)
 *
 * App-Anzeige:
 *   „12 / 15 geprüft"    → rawPoints / checkedMaxPoints
 *   „16 / 20"             → normalizedPoints / fullMaxPoints
 */
export interface CategoryScore {
  /** Tatsächlich erreichte Rohpunkte aus prüfbaren Kriterien (0 … checkedMaxPoints) */
  readonly rawPoints: number;
  /** Maximale Punkte der prüfbaren Kriterien (< fullMaxPoints wenn unavailable-Kriterien existieren) */
  readonly checkedMaxPoints: number;
  /**
   * Auf fullMaxPoints hochskalierte Leistung — für normalisierte Score-Darstellung.
   * Berechnung: round(rawPoints / checkedMaxPoints * fullMaxPoints)
   * Bei checkedMaxPoints = 0: normalizedPoints = 0
   */
  readonly normalizedPoints: number;
  /** Festes Kategorie-Maximum aus CategoryDefinition.maxPoints (unveränderlich) */
  readonly fullMaxPoints: number;
}

/**
 * Vollständiges Score-Ergebnis nach Bewertung.
 *
 * globalNormalized = round(globalRawPoints / globalCheckedPoints * 100)
 */
export interface ScoreSet {
  /**
   * Normalisierter Gesamtscore 0–100.
   * Berechnung: round(globalRawPoints / globalCheckedPoints * 100)
   */
  readonly total: number;

  // Kategoriescores
  readonly bio: CategoryScore;
  readonly content: CategoryScore;
  readonly feed: CategoryScore;
  readonly brand: CategoryScore;
  readonly profilePic: CategoryScore;
  readonly username: CategoryScore;
  readonly engagement: CategoryScore;
}

// ─── Abdeckungsbericht ───────────────────────────────────────────────────────

/**
 * Detailliertere Abdeckungsinformation für Admin-Oberfläche und Debugging.
 */
export interface CoverageReport {
  /** Rohpunkte erreicht (Summe aus fulfilled/partial-Punkte) */
  readonly rawPoints: number;
  /** Prüfbare Punkte gesamt (100 − unavailablePoints) */
  readonly checkedPoints: number;
  /** Punkte aus unavailable-Kriterien (aus Nenner entfernt) */
  readonly unavailablePoints: number;
  /** Gesamtpunkte ohne Normalisierung (immer 100) */
  readonly totalPoints: number;
  /** Abdeckungsgrad (checkedPoints / 100), Wert 0.0–1.0 */
  readonly coverageRatio: number;
  /** IDs der nicht prüfbaren Kriterien */
  readonly unavailableCriterionIds: ReadonlyArray<CriterionId>;
  /** true wenn coverageRatio < MINIMUM_COVERAGE_FOR_DISPLAY */
  readonly belowDisplayThreshold: boolean;
}

/** Mindestabdeckung, unterhalb derer der Score nicht angezeigt wird */
export const MINIMUM_COVERAGE_FOR_DISPLAY = 0.60 as const;

// ─── Scoring-Ergebnis ────────────────────────────────────────────────────────

/**
 * Vollständige Ausgabe des Bewertungskerns.
 *
 * Union-Typ: `displayable` muss vor Anzeige geprüft werden.
 * `scoreSet` ist in BEIDEN Varianten vorhanden (Admin/Debugging).
 */
export type ScoringResult =
  | {
      readonly displayable: true;
      readonly scoreSet: ScoreSet;
      readonly coverageReport: CoverageReport;
      readonly appliedPriorSmoothing: false;
    }
  | {
      readonly displayable: false;
      readonly scoreSet: ScoreSet;
      readonly coverageReport: CoverageReport;
      readonly appliedPriorSmoothing: false;
    };

// ─── Befund ──────────────────────────────────────────────────────────────────

/**
 * Schweregrad eines Befunds.
 *
 * foundation — ≥ 8 Punkte verloren oder blockierendes Problem
 *              Blockiert polish-Findings im Aktionsplan
 * lever      — 4–7 Punkte, in unter 15 Minuten behebbar
 * polish     — ≤ 3 Punkte oder hoher Aufwand
 */
export const FINDING_SEVERITIES = ["foundation", "lever", "polish"] as const;
export type FindingSeverity = (typeof FINDING_SEVERITIES)[number];

/** Bearbeitungsstatus eines Befunds (für Aktionsplan-Tracking) */
export const FINDING_STATUSES = ["open", "completed", "dismissed"] as const;
export type FindingStatus = (typeof FINDING_STATUSES)[number];

/**
 * Ein konkreter Befund für ein Profil.
 *
 * Entsteht deterministisch aus dem ObservationPackage in buildFindings().
 * Kein Sprachmodell bestimmt Existenz, Impact oder Priorität.
 */
export interface Finding {
  /** Laufende Nummer innerhalb des Scans — stabile Sortierreferenz */
  readonly id: number;
  /** Bezeichner der FindingTemplate */
  readonly templateId: string;
  /** Anzeige-Titel (Beobachtung, kein Vorwurf) */
  readonly title: string;
  /** Schweregrad */
  readonly severity: FindingSeverity;
  /** Betroffene Kriterium-IDs */
  readonly criterionIds: ReadonlyArray<CriterionId>;
  /** Betroffene Kategorie-IDs (ggf. mehrere bei Querwirkungen) */
  readonly categoryIds: ReadonlyArray<CategoryId>;
  /**
   * Verlorene Punkte insgesamt durch dieses Finding.
   * = Summe aller (maxPoints − awardedRawPoints) der betroffenen Kriterien
   * für Kriterien im Zustand missing oder partial.
   * unavailable-Kriterien tragen niemals zu lostPoints bei.
   */
  readonly lostPoints: number;
  /**
   * Impact = lostPoints.
   * Alias für die App-Darstellung des Impact-Chips (+N Punkte).
   */
  readonly impact: number;
  /** Sortierpriorität (1 = höchste), deterministisch berechnet */
  readonly priority: number;
  /** Immer 'open' bei initialer Berechnung */
  readonly status: FindingStatus;
  /**
   * true wenn mindestens ein offenes foundation-Finding existiert
   * und dieses Finding Severity 'polish' hat.
   * Solche Findings werden im Top-3-Aktionsplan übersprungen.
   */
  readonly blockedByFoundation: boolean;
}

// ─── Kriterium-Definition ────────────────────────────────────────────────────

/**
 * Definition eines Kriteriums in der Kriterientabelle.
 */
export interface CriterionDefinition {
  readonly id: CriterionId;
  readonly categoryId: CategoryId;
  readonly maxPoints: number;
  readonly allowsPartial: boolean;
}
