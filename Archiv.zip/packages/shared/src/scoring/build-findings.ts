/**
 * Deterministische Befundbildung (Pipeline-Stufe 5).
 *
 * Kein Sprachmodell bestimmt:
 *   - ob ein Finding existiert
 *   - wie hoch sein Impact ist
 *   - welche Priorität es besitzt
 *   - welche Kriterien betroffen sind
 *
 * Das Sprachmodell darf später nur die fertigen Befunde erklären.
 *
 * Architekturregeln:
 * - Kein Import aus Datenbank, Netzwerk, KI-SDKs oder Cloud-Diensten.
 * - Reine Funktionen, deterministisch.
 */

import type { CriterionId } from "./criterion-ids.js";
import { ALL_CRITERION_IDS } from "./criterion-ids.js";
import { CATEGORY_BY_ID } from "./categories.js";
import type { CategoryId } from "./categories.js";
import type {
  ObservationPackage,
  ScoringResult,
  Finding,
} from "./types.js";
import { CRITERION_BY_ID, pointsForState, ScoringDomainError } from "./criterion-table.js";
import { FINDING_TEMPLATES } from "./finding-templates.js";

// ─── Öffentliche API ─────────────────────────────────────────────────────────

/**
 * Erzeugt alle Findings aus einem bereits berechneten ScoringResult.
 *
 * Voraussetzung: `scoringResult` wurde von `calculateScore(pkg)` erzeugt
 * und `pkg` ist identisch mit dem Package, das übergeben wird.
 *
 * Ablauf:
 *  1. Verlustpunkte je Kriterium berechnen
 *  2. Je Template: existiert ein Finding? (≥ 1 Kriterium mit lostPoints > 0)
 *  3. Impact = Summe lostPoints der betroffenen Kriterien
 *  4. Findings sortieren (foundation > lever > polish, dann Impact ↓, dann templateId)
 *  5. Priorität vergeben (1-basiert)
 *  6. blockedByFoundation setzen
 *
 * @throws ScoringDomainError bei inkonsistenten Eingaben
 */
export function buildFindings(
  pkg: ObservationPackage,
  scoringResult: ScoringResult
): ReadonlyArray<Finding> {
  // ── Schritt 1: Verlustpunkte je Kriterium ─────────────────────────────────
  const stateMap = buildStateMap(pkg);
  const lostPointsMap = new Map<CriterionId, number>();

  for (const id of ALL_CRITERION_IDS) {
    const def = CRITERION_BY_ID[id];
    if (def === undefined) continue;

    const state = stateMap.get(id) ?? "unavailable";

    if (state === "unavailable") {
      // unavailable bedeutet „wir wissen es nicht" — kein lostPoints
      lostPointsMap.set(id, 0);
      continue;
    }

    const awardedRaw = pointsForState(def, state);
    if (typeof awardedRaw !== "number") {
      // pointsForState wirft bei partial+!allowsPartial — sollte durch validatePackage verhindert sein
      lostPointsMap.set(id, 0);
      continue;
    }

    lostPointsMap.set(id, def.maxPoints - awardedRaw);
  }

  // ── Schritt 2–3: Findings aus Templates erzeugen ─────────────────────────
  const unsortedFindings: Array<Omit<Finding, "priority" | "blockedByFoundation">> = [];

  for (const tmpl of FINDING_TEMPLATES) {
    // Verlustpunkte aller Template-Kriterien summieren
    // (nur missing/partial tragen bei; unavailable = 0)
    let totalLost = 0;
    for (const criterionId of tmpl.criterionIds) {
      totalLost += lostPointsMap.get(criterionId) ?? 0;
    }

    // Finding entsteht nur wenn mindestens ein Kriterium nicht erfüllt ist
    if (totalLost === 0) continue;

    // Kategorie-IDs aus den Kriterien ableiten (dedupliziert, stabile Reihenfolge)
    const categoryIds = deriveDistinctCategoryIds(tmpl.criterionIds);

    unsortedFindings.push({
      id: 0, // wird nach Sortierung gesetzt
      templateId: tmpl.templateId,
      title: tmpl.title,
      severity: tmpl.severity,
      criterionIds: tmpl.criterionIds,
      categoryIds,
      lostPoints: totalLost,
      impact: totalLost,
      status: "open",
    });
  }

  // ── Schritt 4: Deterministisch sortieren ─────────────────────────────────
  const SEVERITY_ORDER: Record<string, number> = {
    foundation: 0,
    lever: 1,
    polish: 2,
  };

  const sorted = [...unsortedFindings].sort((a, b) => {
    // 1. Severity (foundation → lever → polish)
    const sevDiff =
      (SEVERITY_ORDER[a.severity] ?? 99) - (SEVERITY_ORDER[b.severity] ?? 99);
    if (sevDiff !== 0) return sevDiff;

    // 2. Impact absteigend
    if (b.impact !== a.impact) return b.impact - a.impact;

    // 3. Alphabetisch nach templateId (stabil)
    return a.templateId.localeCompare(b.templateId);
  });

  // ── Schritt 5: Priorität vergeben ─────────────────────────────────────────
  const hasOpenFoundation = sorted.some((f) => f.severity === "foundation");

  const findings: Finding[] = sorted.map((f, idx) => ({
    ...f,
    id: idx + 1,
    priority: idx + 1,
    blockedByFoundation: hasOpenFoundation && f.severity === "polish",
  }));

  return findings;
}

/**
 * Wählt die Top-N Findings für den Aktionsplan aus.
 *
 * Regeln:
 *   - blockedByFoundation = true → überspringen
 *   - Reihenfolge bleibt die von buildFindings() (bereits sortiert)
 *   - Maximal `limit` Findings
 *   - Originales Array wird nicht verändert
 */
export function selectTopFindings(
  findings: ReadonlyArray<Finding>,
  limit = 3
): ReadonlyArray<Finding> {
  const result: Finding[] = [];
  for (const f of findings) {
    if (result.length >= limit) break;
    if (f.blockedByFoundation) continue;
    result.push(f);
  }
  return result;
}

/**
 * Prüft sechs Invarianten der Nachrechenbarkeit.
 *
 * Gibt `true` zurück wenn alle bestehen, wirft `ScoringDomainError` bei Verletzung.
 * Für CI-Pflichtprüfung.
 */
export function verifyNachrechenbarkeit(
  pkg: ObservationPackage,
  scoringResult: ScoringResult,
  findings: ReadonlyArray<Finding>
): true {
  // 1. Summe aller CriterionDefinition.maxPoints = 100
  const criterionSum = Object.values(CRITERION_BY_ID).reduce(
    (acc, def) => acc + def.maxPoints,
    0
  );
  if (criterionSum !== 100) {
    throw new ScoringDomainError(
      `verifyNachrechenbarkeit: Summe Criterion.maxPoints = ${criterionSum}, erwartet 100`
    );
  }

  // 2. Summe Kategorie-Maxima = 100
  const catSum = Object.values(CATEGORY_BY_ID).reduce(
    (acc, cat) => acc + cat.maxPoints,
    0
  );
  if (catSum !== 100) {
    throw new ScoringDomainError(
      `verifyNachrechenbarkeit: Summe Kategorie-Maxima = ${catSum}, erwartet 100`
    );
  }

  // 3 + 4: Je Finding: impact = Summe lostPoints, unavailable erzeugt kein lostPoints
  const stateMap = buildStateMap(pkg);

  for (const finding of findings) {
    let expectedImpact = 0;

    for (const criterionId of finding.criterionIds) {
      const def = CRITERION_BY_ID[criterionId];
      if (def === undefined) {
        throw new ScoringDomainError(
          `verifyNachrechenbarkeit: unbekannte CriterionId "${criterionId}" in Finding "${finding.templateId}"`
        );
      }

      const state = stateMap.get(criterionId) ?? "unavailable";

      if (state === "unavailable") {
        // Invariante 4: unavailable erzeugt kein lostPoints
        continue;
      }

      const awarded = pointsForState(def, state);
      if (typeof awarded === "number") {
        expectedImpact += def.maxPoints - awarded;
      }
    }

    // Invariante 3: impact === berechnete Summe
    if (finding.impact !== expectedImpact) {
      throw new ScoringDomainError(
        `verifyNachrechenbarkeit: Finding "${finding.templateId}" — ` +
          `impact = ${finding.impact}, erwartet ${expectedImpact}`
      );
    }
  }

  // 5. Kein CriterionId doppelt in zwei Findings gezählt
  const criterionInFinding = new Map<string, string>();
  for (const finding of findings) {
    for (const criterionId of finding.criterionIds) {
      const prev = criterionInFinding.get(criterionId);
      if (prev !== undefined) {
        throw new ScoringDomainError(
          `verifyNachrechenbarkeit: CriterionId "${criterionId}" in zwei Findings: ` +
            `"${prev}" und "${finding.templateId}"`
        );
      }
      criterionInFinding.set(criterionId, finding.templateId);
    }
  }

  // 6. Summe Finding-Impacts <= insgesamt verlorene prüfbare Rohpunkte
  const totalFindingImpact = findings.reduce((acc, f) => acc + f.impact, 0);
  const cr = scoringResult.coverageReport;
  const totalLost = cr.checkedPoints - cr.rawPoints;

  if (totalFindingImpact > totalLost) {
    throw new ScoringDomainError(
      `verifyNachrechenbarkeit: Summe Finding-Impacts (${totalFindingImpact}) > ` +
        `Gesamtverlust prüfbarer Punkte (${totalLost}). ` +
        `Findings dürfen nicht mehr Impact zuschreiben als tatsächlich verloren wurde.`
    );
  }

  return true;
}

// ─── Hilfsfunktionen ─────────────────────────────────────────────────────────

function buildStateMap(
  pkg: ObservationPackage
): Map<CriterionId, "fulfilled" | "partial" | "missing" | "unavailable"> {
  const map = new Map<
    CriterionId,
    "fulfilled" | "partial" | "missing" | "unavailable"
  >();
  for (const obs of pkg.observations) {
    map.set(obs.id, obs.state);
  }
  return map;
}

/**
 * Leitet die eindeutigen Kategorie-IDs aus einer Liste von Kriterien ab.
 * Reihenfolge folgt der Originalreihenfolge der Kriterien.
 */
function deriveDistinctCategoryIds(
  criterionIds: ReadonlyArray<CriterionId>
): ReadonlyArray<CategoryId> {
  const seen = new Set<CategoryId>();
  const result: CategoryId[] = [];
  for (const id of criterionIds) {
    const def = CRITERION_BY_ID[id];
    if (def && !seen.has(def.categoryId)) {
      seen.add(def.categoryId);
      result.push(def.categoryId);
    }
  }
  return result;
}
