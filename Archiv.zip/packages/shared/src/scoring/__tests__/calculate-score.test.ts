/**
 * Tests für calculateScore.
 *
 * Struktur:
 *  A–L  Unit-Tests für spezifizierte Fälle
 *  M    Property-Tests (10.000 deterministisch erzeugte Pakete)
 */

import { describe, it } from "node:test";
import assert from "node:assert/strict";

import {
  calculateScore,
  ScoringDomainError,
  CRITERION_TABLE,
  CRITERION_BY_ID,
} from "../index.js";

import { ALL_CRITERION_IDS, type CriterionId } from "../criterion-ids.js";
import { SCORING_MODEL_VERSION, type ObservationPackage } from "../types.js";

// ─── Hilfsfunktionen ─────────────────────────────────────────────────────────

function makePackage(
  overrides: Partial<{
    observations: ObservationPackage["observations"];
    scoringModelVersion: string;
    priorScoreSet: ObservationPackage["priorScoreSet"];
  }> = {}
): ObservationPackage {
  return {
    observations: overrides.observations ?? [],
    modelVersions: { ocr: "test-v1", vision: "test-v1", language: "test-v1" },
    pipelineVersion: "v1.0.0",
    scoringModelVersion: (overrides.scoringModelVersion ??
      SCORING_MODEL_VERSION) as typeof SCORING_MODEL_VERSION,
    ...(overrides.priorScoreSet !== undefined
      ? { priorScoreSet: overrides.priorScoreSet }
      : {}),
  };
}

function allFulfilled(): ObservationPackage["observations"] {
  return ALL_CRITERION_IDS.map((id) => ({
    id,
    state: "fulfilled" as const,
    source: "A" as const,
  }));
}

function allMissing(): ObservationPackage["observations"] {
  return ALL_CRITERION_IDS.map((id) => ({
    id,
    state: "missing" as const,
    source: "A" as const,
  }));
}

function allUnavailable(): ObservationPackage["observations"] {
  return ALL_CRITERION_IDS.map((id) => ({
    id,
    state: "unavailable" as const,
    source: "A" as const,
  }));
}

function withState(
  id: CriterionId,
  state: "fulfilled" | "partial" | "missing" | "unavailable"
): ObservationPackage["observations"] {
  return ALL_CRITERION_IDS.map((cid) => ({
    id: cid,
    state: cid === id ? state : ("fulfilled" as const),
    source: "A" as const,
  }));
}

// ─── A: Alle fulfilled → Score 100, Coverage 100 % ─────────────────────────

describe("A: Alle fulfilled", () => {
  it("ergibt Score 100", () => {
    const result = calculateScore(makePackage({ observations: allFulfilled() }));
    assert.equal(result.scoreSet.total, 100);
  });

  it("Coverage = 1.0", () => {
    const result = calculateScore(makePackage({ observations: allFulfilled() }));
    assert.equal(result.coverageReport.coverageRatio, 1.0);
  });

  it("checkedPoints = 100", () => {
    const result = calculateScore(makePackage({ observations: allFulfilled() }));
    assert.equal(result.coverageReport.checkedPoints, 100);
  });

  it("ist displayable", () => {
    const result = calculateScore(makePackage({ observations: allFulfilled() }));
    assert.equal(result.displayable, true);
  });

  it("keine unavailable Kriterien", () => {
    const result = calculateScore(makePackage({ observations: allFulfilled() }));
    assert.equal(result.coverageReport.unavailableCriterionIds.length, 0);
  });

  it("appliedPriorSmoothing ist false", () => {
    const result = calculateScore(makePackage({ observations: allFulfilled() }));
    assert.equal(result.appliedPriorSmoothing, false);
  });
});

// ─── B: Alle missing → Score 0, Coverage 100 % ─────────────────────────────

describe("B: Alle missing", () => {
  it("ergibt Score 0", () => {
    const result = calculateScore(makePackage({ observations: allMissing() }));
    assert.equal(result.scoreSet.total, 0);
  });

  it("Coverage = 1.0", () => {
    const result = calculateScore(makePackage({ observations: allMissing() }));
    assert.equal(result.coverageReport.coverageRatio, 1.0);
  });

  it("ist displayable (Coverage = 100 %)", () => {
    const result = calculateScore(makePackage({ observations: allMissing() }));
    assert.equal(result.displayable, true);
  });

  it("rawPoints = 0", () => {
    const result = calculateScore(makePackage({ observations: allMissing() }));
    assert.equal(result.coverageReport.rawPoints, 0);
  });
});

// ─── C: Alle unavailable → Coverage 0 %, nicht displayable ─────────────────

describe("C: Alle unavailable", () => {
  it("Coverage = 0", () => {
    const result = calculateScore(makePackage({ observations: allUnavailable() }));
    assert.equal(result.coverageReport.coverageRatio, 0);
  });

  it("ist NICHT displayable", () => {
    const result = calculateScore(makePackage({ observations: allUnavailable() }));
    assert.equal(result.displayable, false);
  });

  it("checkedPoints = 0", () => {
    const result = calculateScore(makePackage({ observations: allUnavailable() }));
    assert.equal(result.coverageReport.checkedPoints, 0);
  });

  it("unavailablePoints = 100", () => {
    const result = calculateScore(makePackage({ observations: allUnavailable() }));
    assert.equal(result.coverageReport.unavailablePoints, 100);
  });

  it("alle 31 Kriterien sind unavailable", () => {
    const result = calculateScore(makePackage({ observations: allUnavailable() }));
    assert.equal(result.coverageReport.unavailableCriterionIds.length, 31);
  });
});

// ─── D: partial auf 5-Punkte-Kriterium → 3 Punkte ──────────────────────────

describe("D: partial auf content_hook (5 Pkt, allowsPartial = true)", () => {
  it("bringt 3 Punkte (ceil(5/2))", () => {
    // Alle anderen fulfilled → Gesamtmax 100, hook bringt 3 statt 5
    // Score = (100 - 5 + 3) / 100 * 100 = 98
    const obs = withState("content_hook", "partial");
    const result = calculateScore(makePackage({ observations: obs }));
    assert.equal(result.scoreSet.total, 98);
  });
});

// ─── E: partial auf 3-Punkte-Kriterium → 2 Punkte ──────────────────────────

describe("E: partial auf bio_cta (3 Pkt, allowsPartial = false)", () => {
  // bio_cta hat allowsPartial = false → Fehler erwartet
  it("wirft ScoringDomainError", () => {
    const obs = withState("bio_cta", "partial");
    assert.throws(
      () => calculateScore(makePackage({ observations: obs })),
      ScoringDomainError
    );
  });
});

// ─── E2: partial auf echtem 3-Punkte+allowsPartial Kriterium ────────────────

describe("E2: partial auf bio_first_line (3 Pkt, allowsPartial = true)", () => {
  it("bringt 2 Punkte (ceil(3/2))", () => {
    const obs = withState("bio_first_line", "partial");
    const result = calculateScore(makePackage({ observations: obs }));
    // 100 - 3 + 2 = 99
    assert.equal(result.scoreSet.total, 99);
  });
});

// ─── F: partial auf binärem Kriterium → Fehler ──────────────────────────────

describe("F: partial auf binärem Kriterium (allowsPartial = false)", () => {
  it("bio_target_audience partial → ScoringDomainError", () => {
    const obs = withState("bio_target_audience", "partial");
    assert.throws(
      () => calculateScore(makePackage({ observations: obs })),
      ScoringDomainError
    );
  });

  it("content_recurring partial → ScoringDomainError", () => {
    const obs = withState("content_recurring", "partial");
    assert.throws(
      () => calculateScore(makePackage({ observations: obs })),
      ScoringDomainError
    );
  });

  it("feed_pinned partial → ScoringDomainError", () => {
    const obs = withState("feed_pinned", "partial");
    assert.throws(
      () => calculateScore(makePackage({ observations: obs })),
      ScoringDomainError
    );
  });

  it("profile_pic_color_fit (1 Pkt) partial → ScoringDomainError", () => {
    const obs = withState("profile_pic_color_fit", "partial");
    assert.throws(
      () => calculateScore(makePackage({ observations: obs })),
      ScoringDomainError
    );
  });
});

// ─── G: doppelte CriterionId → Fehler ───────────────────────────────────────

describe("G: doppelte CriterionId", () => {
  it("wirft ScoringDomainError", () => {
    const obs: ObservationPackage["observations"] = [
      { id: "bio_outcome", state: "fulfilled", source: "A" },
      { id: "bio_outcome", state: "missing",   source: "A" },
    ];
    assert.throws(
      () => calculateScore(makePackage({ observations: obs })),
      ScoringDomainError
    );
  });
});

// ─── H: fehlende CriterionId → wird unavailable ─────────────────────────────

describe("H: fehlende CriterionId → unavailable", () => {
  it("leeres observations-Array → alle 31 unavailable", () => {
    const result = calculateScore(makePackage({ observations: [] }));
    assert.equal(result.coverageReport.unavailableCriterionIds.length, 31);
    assert.equal(result.displayable, false);
  });

  it("eine ID fehlt → Coverage leicht unter 100 %", () => {
    // bio_target_audience (5 Pkt) fehlt → checkedPoints = 95
    const obs = ALL_CRITERION_IDS
      .filter((id) => id !== "bio_target_audience")
      .map((id) => ({ id, state: "fulfilled" as const, source: "A" as const }));
    const result = calculateScore(makePackage({ observations: obs }));
    assert.equal(result.coverageReport.checkedPoints, 95);
    assert.equal(result.coverageReport.unavailableCriterionIds.length, 1);
    assert.ok(result.coverageReport.unavailableCriterionIds.includes("bio_target_audience"));
  });

  it("fehlende ID wird in den Score eingerechnet als 0 (normalisiert)", () => {
    // Alle fulfilled außer bio_target_audience fehlt (5 Pkt)
    // rawPoints = 95, checkedPoints = 95 → Score = 100
    const obs = ALL_CRITERION_IDS
      .filter((id) => id !== "bio_target_audience")
      .map((id) => ({ id, state: "fulfilled" as const, source: "A" as const }));
    const result = calculateScore(makePackage({ observations: obs }));
    assert.equal(result.scoreSet.total, 100);
  });
});

// ─── I: falsche scoringModelVersion → Fehler ────────────────────────────────

describe("I: falsche scoringModelVersion", () => {
  it("wirft ScoringDomainError", () => {
    assert.throws(
      () =>
        calculateScore(
          makePackage({ scoringModelVersion: "v0.9.0" })
        ),
      ScoringDomainError
    );
  });

  it("wirft ScoringDomainError auch bei leerem String", () => {
    assert.throws(
      () =>
        calculateScore(
          makePackage({ scoringModelVersion: "" })
        ),
      ScoringDomainError
    );
  });
});

// ─── J: Normalisierungsbeispiel 60 von 80 geprüft → Score 75, Coverage 80 % ─

describe("J: 60 von 80 prüfbaren Rohpunkten → Score 75", () => {
  it("Score = 75, Coverage = 80 %", () => {
    // Strategie: 20 Punkte unavailable machen, von den restlichen 80 → 60 erreichen
    // Wir nehmen bio_target_audience (5) + bio_outcome (5) + content_hook (5) + content_cover (4) + feed_color_world (5) = 24 Pkt unavailable
    // Dann etwas feiner: wir wollen genau 20 unavailable und 60 von 80 erreicht
    //
    // unavailable: bio_target_audience (5) + bio_outcome (5) + bio_cta (3) + bio_first_line (3) + bio_no_filler (2) = 18
    //   + content_hook (5) - wir brauchen noch 2 → nein, zu viel
    // Versuche: unavailable = feed_color_world(5) + feed_cover_pattern(4) + feed_topic(4) + feed_pinned(3) = 16 → nein
    // Direkter: wir setzen genau die richtigen Kriterien unavailable auf 20 Pkt
    // brand_colors(4) + brand_font(3) + brand_theme(4) + brand_recognizable(3) = 14 → nein
    // Nehmen wir: bio_target_audience(5) + bio_outcome(5) + content_hook(5) + content_cover(5?=4) = 19, noch 1 fehlt
    //   + bio_no_filler(2) → 5+5+5+4+2 = 21 → zu viel
    //   + content_text_position(2) → 5+5+5+4+2 = zu viel
    // Einfacher: bio(18) + content_hook(5) - 3 = nein
    //
    // Konkret: unavailable = [bio_target_audience=5, bio_outcome=5, bio_cta=3, bio_first_line=3, bio_no_filler=2] = 18
    //   noch 2 fehlen: content_text_position=2 → 20 total unavailable ✓
    // checked = 80, dann alle anderen fulfilled → rawPoints = 80
    // Wir wollen rawPoints = 60 → 20 Punkte von 80 müssen missing sein
    // missing: z.B. content_hook(5) = 5, content_cover(4) = 4, feed_pinned(3) = 3, brand_font(3) = 3, profile_pic_subject(3) = 3, username_clean(2) = 2 → 20 missing

    const unavailableIds = new Set([
      "bio_target_audience",   // 5
      "bio_outcome",           // 5
      "bio_cta",               // 3
      "bio_first_line",        // 3
      "bio_no_filler",         // 2
      "content_text_position", // 2
      // total unavailable = 20
    ]);

    const missingIds = new Set([
      "content_hook",          // 5
      "content_cover",         // 4
      "feed_pinned",           // 3
      "brand_font",            // 3
      "profile_pic_subject",   // 3
      "username_clean",        // 2
      // total missing = 20 → rawPoints = 80 - 20 = 60
    ]);

    const obs: ObservationPackage["observations"] = ALL_CRITERION_IDS.map((id) => ({
      id,
      state: unavailableIds.has(id)
        ? "unavailable"
        : missingIds.has(id)
        ? "missing"
        : "fulfilled",
      source: "A" as const,
    }));

    const result = calculateScore(makePackage({ observations: obs }));

    assert.equal(result.coverageReport.unavailablePoints, 20, "unavailablePoints = 20");
    assert.equal(result.coverageReport.checkedPoints, 80, "checkedPoints = 80");
    assert.equal(result.coverageReport.rawPoints, 60, "rawPoints = 60");
    assert.equal(
      Math.round((60 / 80) * 100),
      75,
      "Normalisierung: 60/80*100 = 75"
    );
    assert.equal(result.scoreSet.total, 75, "Score = 75");
    assert.equal(result.coverageReport.coverageRatio, 0.8, "Coverage = 0.8");
    assert.equal(result.displayable, true, "ist displayable (80 % > 60 %)");
  });
});

// ─── K: Coverage exakt 60 % → displayable ──────────────────────────────────

describe("K: Coverage exakt 60 % → displayable", () => {
  it("60 Punkte checked, 40 unavailable → displayable = true", () => {
    // unavailable: bio(18) + content_hook(5) + content_cover(4) + content_recurring(4) + content_length(3) + content_text_position(2) + content_regularity(2) = 18+20=38 → zu viel
    // unavailable = 40 Punkte:
    // bio_target_audience(5) + bio_outcome(5) + bio_cta(3) + bio_first_line(3) + bio_no_filler(2) = 18
    // + content_hook(5) + content_cover(4) + content_recurring(4) + content_length(3) + content_text_position(2) + content_regularity(2) = 20
    // Wir brauchen 40: 18 + 22 → zu viel
    // bio(18) + feed_color_world(5) + feed_cover_pattern(4) + feed_topic(4) + feed_pinned(3) = 18+16 = 34 → noch 6 fehlen
    //   + brand_colors(4) + brand_font(3) = 7 → 34+7 = 41 → zu viel
    //   + brand_colors(4) = 38 → noch 2 → username_name_match(1) + brand_font nein ...
    // Einfacher: unavailable = bio(18) + content_hook(5) + content_cover(4) + content_recurring(4) + content_length(4? nein, 3) = 18+5+4+4+3 = 34... + 6 mehr
    //   content_regularity(2) + content_text_position(2) + nein wir wollen genau 40
    // bio(18) + feed(16) + 6 weitere:
    //   brand_colors(4) + brand_font(3) = 7 → 18+16+7 = 41
    //   brand_colors(4) + username_name_match(1) + profile_pic_color_fit(1) = 6 → 18+16+6 = 40 ✓

    const unavailableIds = new Set([
      // Bio: 18 Pkt
      "bio_target_audience","bio_outcome","bio_cta","bio_first_line","bio_no_filler",
      // Feed: 16 Pkt
      "feed_color_world","feed_cover_pattern","feed_topic","feed_pinned",
      // +6 Pkt
      "brand_colors",            // 4
      "username_name_match",     // 1
      "profile_pic_color_fit",   // 1
    ]);

    // Kontrollrechnung
    const unavailablePts = [...unavailableIds].reduce((acc, id) => {
      const def = CRITERION_BY_ID[id];
      return acc + (def?.maxPoints ?? 0);
    }, 0);
    assert.equal(unavailablePts, 40, `Vorbedingung: unavailable = ${unavailablePts} Pkt`);

    const obs: ObservationPackage["observations"] = ALL_CRITERION_IDS.map((id) => ({
      id,
      state: unavailableIds.has(id) ? "unavailable" : "fulfilled",
      source: "A" as const,
    }));

    const result = calculateScore(makePackage({ observations: obs }));
    assert.equal(result.coverageReport.coverageRatio, 0.6, "Coverage = 0.6");
    assert.equal(result.displayable, true, "exakt 60 % → displayable");
  });
});

// ─── L: Coverage < 60 % → nicht displayable ─────────────────────────────────

describe("L: Coverage unter 60 % → nicht displayable", () => {
  it("41 Punkte unavailable → Coverage 59 % → nicht displayable", () => {
    // Wir nehmen K-Setup und machen zusätzlich username_name_match (1 Pkt) → schon drin
    // Besser: nehmen wir K und ergänzen noch brand_font(3) statt brand_colors(4)+name_match(1)+pic(1)
    // Stattdessen: direkt 41 unavailable
    // bio(18) + feed(16) + brand_colors(4) + brand_font(3) = 41

    const unavailableIds = new Set([
      "bio_target_audience","bio_outcome","bio_cta","bio_first_line","bio_no_filler",  // 18
      "feed_color_world","feed_cover_pattern","feed_topic","feed_pinned",               // 16
      "brand_colors",  // 4
      "brand_font",    // 3
      // total = 41
    ]);

    const unavailablePts = [...unavailableIds].reduce(
      (acc, id) => acc + (CRITERION_BY_ID[id]?.maxPoints ?? 0),
      0
    );
    assert.equal(unavailablePts, 41, `Vorbedingung: ${unavailablePts} Pkt unavailable`);

    const obs: ObservationPackage["observations"] = ALL_CRITERION_IDS.map((id) => ({
      id,
      state: unavailableIds.has(id) ? "unavailable" : "fulfilled",
      source: "A" as const,
    }));

    const result = calculateScore(makePackage({ observations: obs }));
    assert.equal(result.coverageReport.coverageRatio, 0.59, "Coverage = 0.59");
    assert.equal(result.displayable, false, "59 % < 60 % → nicht displayable");
  });
});

// ─── M: Property-Tests ───────────────────────────────────────────────────────

describe("M: Property-Tests (10.000 deterministische Pakete)", () => {
  /**
   * Deterministischer Pseudo-Zufallsgenerator (LCG).
   * Fester Seed → immer dieselbe Sequenz.
   */
  function makeLcg(seed: number) {
    let state = seed;
    return function next(): number {
      // Park-Miller LCG
      state = (state * 48271) % 2147483647;
      return state / 2147483647; // [0, 1)
    };
  }

  /**
   * Erzeugt ein gültiges ObservationPackage aus einem Float [0,1).
   * Verschiedene Werte → verschiedene Verteilungen von Zuständen.
   */
  function generateValidPackage(rng: () => number): ObservationPackage {
    const observations: ObservationPackage["observations"] = ALL_CRITERION_IDS
      .map((id) => {
        const def = CRITERION_BY_ID[id]!;
        const r = rng();
        let state: "fulfilled" | "partial" | "missing" | "unavailable";
        if (r < 0.15) {
          state = "unavailable";
        } else if (r < 0.30) {
          state = "missing";
        } else if (r < 0.50 && def.allowsPartial) {
          state = "partial";
        } else {
          state = "fulfilled";
        }
        return { id, state, source: "A" as const };
      });
    return makePackage({ observations });
  }

  const ITERATIONS = 10_000;
  const rng = makeLcg(42); // fester Seed

  it(`Score niemals < 0 oder > 100 (${ITERATIONS} Pakete)`, () => {
    for (let i = 0; i < ITERATIONS; i++) {
      const pkg = generateValidPackage(rng);
      const result = calculateScore(pkg);
      assert.ok(
        result.scoreSet.total >= 0 && result.scoreSet.total <= 100,
        `Iteration ${i}: Score = ${result.scoreSet.total}`
      );
    }
  });

  it(`Coverage immer zwischen 0 und 1 (${ITERATIONS} Pakete)`, () => {
    const rng2 = makeLcg(137);
    for (let i = 0; i < ITERATIONS; i++) {
      const pkg = generateValidPackage(rng2);
      const result = calculateScore(pkg);
      const cr = result.coverageReport.coverageRatio;
      assert.ok(
        cr >= 0 && cr <= 1,
        `Iteration ${i}: coverageRatio = ${cr}`
      );
    }
  });

  it(`checkedPoints + unavailablePoints = 100 (${ITERATIONS} Pakete)`, () => {
    const rng3 = makeLcg(999);
    for (let i = 0; i < ITERATIONS; i++) {
      const pkg = generateValidPackage(rng3);
      const result = calculateScore(pkg);
      const cr = result.coverageReport;
      assert.equal(
        cr.checkedPoints + cr.unavailablePoints,
        100,
        `Iteration ${i}: ${cr.checkedPoints} + ${cr.unavailablePoints} ≠ 100`
      );
    }
  });

  it(`keine Kategorie überschreitet ihr Maximum (${ITERATIONS} Pakete)`, () => {
    const rng4 = makeLcg(2024);
    const catMaxMap = new Map([
      ["bio", 18], ["content", 20], ["feed", 16], ["brand", 14],
      ["profilePic", 10], ["username", 10], ["engagement", 12],
    ]);
    for (let i = 0; i < ITERATIONS; i++) {
      const pkg = generateValidPackage(rng4);
      const result = calculateScore(pkg);
      for (const [catId, max] of catMaxMap) {
        const catKey = catId as keyof typeof result.scoreSet;
        const catScore = result.scoreSet[catKey] as { normalizedPoints: number };
        assert.ok(
          catScore.normalizedPoints <= max,
          `Iteration ${i}: ${catId}.normalizedPoints = ${catScore.normalizedPoints} > max ${max}`
        );
      }
    }
  });

  it(`gleiche Eingabe → gleiche Ausgabe (Reproduzierbarkeit, 1.000 Pakete)`, () => {
    // Für Reproduzierbarkeit verwenden wir 1.000 Pakete (nicht 10.000, reicht)
    const rng5a = makeLcg(7);
    const rng5b = makeLcg(7); // identischer Seed

    for (let i = 0; i < 1_000; i++) {
      const pkgA = generateValidPackage(rng5a);
      const pkgB = generateValidPackage(rng5b);
      const resultA = calculateScore(pkgA);
      const resultB = calculateScore(pkgB);

      // Pakete müssen identisch sein (deterministischer Generator)
      assert.equal(
        resultA.scoreSet.total,
        resultB.scoreSet.total,
        `Iteration ${i}: Score A=${resultA.scoreSet.total} ≠ B=${resultB.scoreSet.total}`
      );
      assert.equal(
        resultA.coverageReport.coverageRatio,
        resultB.coverageReport.coverageRatio,
        `Iteration ${i}: Coverage A≠B`
      );
      assert.equal(
        resultA.displayable,
        resultB.displayable,
        `Iteration ${i}: displayable A≠B`
      );
    }
  });

  it(`displayable = false genau wenn coverageRatio < 0.60 (${ITERATIONS} Pakete)`, () => {
    const rng6 = makeLcg(314);
    for (let i = 0; i < ITERATIONS; i++) {
      const pkg = generateValidPackage(rng6);
      const result = calculateScore(pkg);
      const expectedDisplayable = result.coverageReport.coverageRatio >= 0.60;
      assert.equal(
        result.displayable,
        expectedDisplayable,
        `Iteration ${i}: coverage=${result.coverageReport.coverageRatio}, displayable=${result.displayable}`
      );
    }
  });

  it(`rawPoints niemals > checkedPoints (${ITERATIONS} Pakete)`, () => {
    const rng7 = makeLcg(1729);
    for (let i = 0; i < ITERATIONS; i++) {
      const pkg = generateValidPackage(rng7);
      const result = calculateScore(pkg);
      const cr = result.coverageReport;
      assert.ok(
        cr.rawPoints <= cr.checkedPoints,
        `Iteration ${i}: rawPoints ${cr.rawPoints} > checkedPoints ${cr.checkedPoints}`
      );
    }
  });

  it(`rawPoints >= 0 (${ITERATIONS} Pakete)`, () => {
    const rng8 = makeLcg(1618);
    for (let i = 0; i < ITERATIONS; i++) {
      const pkg = generateValidPackage(rng8);
      const result = calculateScore(pkg);
      assert.ok(
        result.coverageReport.rawPoints >= 0,
        `Iteration ${i}: rawPoints = ${result.coverageReport.rawPoints}`
      );
    }
  });
});

// ─── Zusatz: Partial-Punktberechnung direkt testen ───────────────────────────

describe("Partial-Rundungsregeln (ceil)", () => {
  it("maxPoints 5 → partial = 3 (ceil(5/2))", () => {
    // content_hook hat maxPoints 5, allowsPartial true
    const obs = withState("content_hook", "partial");
    // alle anderen fulfilled → total = 100 - 5 + 3 = 98
    const result = calculateScore(makePackage({ observations: obs }));
    assert.equal(result.scoreSet.total, 98);
  });

  it("maxPoints 4 → partial = 2 (ceil(4/2))", () => {
    // content_cover hat maxPoints 4, allowsPartial true
    const obs = withState("content_cover", "partial");
    const result = calculateScore(makePackage({ observations: obs }));
    assert.equal(result.scoreSet.total, 98); // 100 - 4 + 2 = 98
  });

  it("maxPoints 3 → partial = 2 (ceil(3/2))", () => {
    // bio_first_line hat maxPoints 3, allowsPartial true
    const obs = withState("bio_first_line", "partial");
    const result = calculateScore(makePackage({ observations: obs }));
    assert.equal(result.scoreSet.total, 99); // 100 - 3 + 2 = 99
  });

  it("maxPoints 2 → partial = 1 (ceil(2/2))", () => {
    // bio_no_filler hat maxPoints 2, allowsPartial true
    const obs = withState("bio_no_filler", "partial");
    const result = calculateScore(makePackage({ observations: obs }));
    assert.equal(result.scoreSet.total, 99); // 100 - 2 + 1 = 99
  });
});

// ─── Zusatz: unbekannte CriterionId → Fehler ─────────────────────────────────

describe("Unbekannte CriterionId", () => {
  it("wirft ScoringDomainError", () => {
    const obs: ObservationPackage["observations"] = [
      // TypeScript würde das normalerweise verhindern — wir casten für den Test
      { id: "bio_does_not_exist" as CriterionId, state: "fulfilled", source: "A" },
    ];
    assert.throws(
      () => calculateScore(makePackage({ observations: obs })),
      ScoringDomainError
    );
  });
});

// ─── Zusatz: CategoryScore-Struktur ─────────────────────────────────────────

describe("ScoreSet-Struktur", () => {
  it("Kategorien haben rawPoints, checkedMaxPoints, normalizedPoints, fullMaxPoints", () => {
    const result = calculateScore(makePackage({ observations: allFulfilled() }));
    const ss = result.scoreSet;
    // alle vier Felder vorhanden und korrekte Typen
    assert.ok(typeof ss.bio.rawPoints === "number");
    assert.ok(typeof ss.bio.checkedMaxPoints === "number");
    assert.ok(typeof ss.bio.normalizedPoints === "number");
    assert.ok(typeof ss.bio.fullMaxPoints === "number");
    // fullMaxPoints = festes Kategorie-Maximum
    assert.equal(ss.bio.fullMaxPoints, 18);
    assert.equal(ss.content.fullMaxPoints, 20);
    assert.equal(ss.feed.fullMaxPoints, 16);
    assert.equal(ss.brand.fullMaxPoints, 14);
    assert.equal(ss.profilePic.fullMaxPoints, 10);
    assert.equal(ss.username.fullMaxPoints, 10);
    assert.equal(ss.engagement.fullMaxPoints, 12);
  });

  it("A: alle Content-Kriterien fulfilled → rawPoints=20, checkedMaxPoints=20, normalizedPoints=20, fullMaxPoints=20", () => {
    const result = calculateScore(makePackage({ observations: allFulfilled() }));
    const c = result.scoreSet.content;
    assert.equal(c.rawPoints, 20);
    assert.equal(c.checkedMaxPoints, 20);
    assert.equal(c.normalizedPoints, 20);
    assert.equal(c.fullMaxPoints, 20);
  });

  it("B: content_hook unavailable, übrige fulfilled → rawPoints=15, checkedMaxPoints=15, normalizedPoints=20, fullMaxPoints=20", () => {
    const obs: ObservationPackage["observations"] = ALL_CRITERION_IDS.map((id) => ({
      id,
      state: id === "content_hook" ? "unavailable" : "fulfilled",
      source: "A" as const,
    }));
    const result = calculateScore(makePackage({ observations: obs }));
    const c = result.scoreSet.content;
    assert.equal(c.rawPoints, 15,           "rawPoints = 15");
    assert.equal(c.checkedMaxPoints, 15,    "checkedMaxPoints = 15");
    assert.equal(c.normalizedPoints, 20,    "normalizedPoints = 20 (15/15*20)");
    assert.equal(c.fullMaxPoints, 20,       "fullMaxPoints = 20");
  });

  it("C: content_hook unavailable, 12 von 15 erreicht → rawPoints=12, checkedMaxPoints=15, normalizedPoints=16, fullMaxPoints=20", () => {
    // content_hook(5) unavailable; content_cover(4) missing; rest fulfilled
    // rawContent = 20 - 4 = 16? Nein: nur Content-Kriterien:
    // content_hook(5) unavailable, content_cover(4) missing, content_recurring(4)+content_length(3)+content_text_position(2)+content_regularity(2)=11 fulfilled → raw = 11? Nein...
    // Ziel: rawPoints=12 von checkedMaxPoints=15
    // checkedMaxPoints = 15 (content_hook=5 unavailable → 20-5=15)
    // missing soll 3 Pkt: content_length(3) missing → rawPoints = 15-3 = 12 ✓
    const obs: ObservationPackage["observations"] = ALL_CRITERION_IDS.map((id) => ({
      id,
      state:
        id === "content_hook"   ? "unavailable" :
        id === "content_length" ? "missing" :
        "fulfilled",
      source: "A" as const,
    }));
    const result = calculateScore(makePackage({ observations: obs }));
    const c = result.scoreSet.content;
    assert.equal(c.rawPoints, 12,           "rawPoints = 12");
    assert.equal(c.checkedMaxPoints, 15,    "checkedMaxPoints = 15");
    assert.equal(c.normalizedPoints, 16,    "normalizedPoints = round(12/15*20) = 16");
    assert.equal(c.fullMaxPoints, 20,       "fullMaxPoints = 20");
  });

  it("D: alle Content-Kriterien unavailable → rawPoints=0, checkedMaxPoints=0, normalizedPoints=0, fullMaxPoints=20", () => {
    const obs: ObservationPackage["observations"] = ALL_CRITERION_IDS.map((id) => ({
      id,
      state: id.startsWith("content_") ? "unavailable" : "fulfilled",
      source: "A" as const,
    }));
    const result = calculateScore(makePackage({ observations: obs }));
    const c = result.scoreSet.content;
    assert.equal(c.rawPoints, 0,         "rawPoints = 0");
    assert.equal(c.checkedMaxPoints, 0,  "checkedMaxPoints = 0");
    assert.equal(c.normalizedPoints, 0,  "normalizedPoints = 0");
    assert.equal(c.fullMaxPoints, 20,    "fullMaxPoints = 20");
  });

  it("rawPoints <= checkedMaxPoints und normalizedPoints <= fullMaxPoints (1000 Pakete)", () => {
    function makeLcg2(seed: number) {
      let s = seed;
      return () => { s = (s * 48271) % 2147483647; return s / 2147483647; };
    }
    const rng = makeLcg2(555);
    for (let i = 0; i < 1000; i++) {
      const obs: ObservationPackage["observations"] = ALL_CRITERION_IDS.map((id) => {
        const r = rng();
        return {
          id,
          state: (r < 0.2 ? "unavailable" : r < 0.4 ? "missing" : "fulfilled") as "fulfilled" | "missing" | "unavailable",
          source: "A" as const,
        };
      });
      const result = calculateScore(makePackage({ observations: obs }));
      const ss = result.scoreSet;
      for (const key of ["bio","content","feed","brand","profilePic","username","engagement"] as const) {
        const cat = ss[key];
        assert.ok(cat.rawPoints <= cat.checkedMaxPoints,
          `Iter ${i} ${key}: rawPoints ${cat.rawPoints} > checkedMaxPoints ${cat.checkedMaxPoints}`);
        assert.ok(cat.normalizedPoints <= cat.fullMaxPoints,
          `Iter ${i} ${key}: normalizedPoints ${cat.normalizedPoints} > fullMaxPoints ${cat.fullMaxPoints}`);
      }
    }
  });

  it("bei unavailable Kriterien sinkt checkedMaxPoints der Kategorie", () => {
    // content_hook (5 Pkt) unavailable → content.checkedMaxPoints = 15
    const obs: ObservationPackage["observations"] = ALL_CRITERION_IDS.map((id) => ({
      id,
      state: id === "content_hook" ? "unavailable" : "fulfilled",
      source: "A" as const,
    }));
    const result = calculateScore(makePackage({ observations: obs }));
    assert.equal(result.scoreSet.content.checkedMaxPoints, 15);
  });
});
