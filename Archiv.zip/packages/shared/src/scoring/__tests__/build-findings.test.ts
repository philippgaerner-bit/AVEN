/**
 * Tests für buildFindings, selectTopFindings, verifyNachrechenbarkeit.
 *
 * Fälle A–N: spezifizierte Unit-Tests
 * Fälle O–T: Property-Tests (10.000 deterministische Pakete)
 */

import { describe, it } from "node:test";
import assert from "node:assert/strict";

import {
  calculateScore,
  buildFindings,
  selectTopFindings,
  verifyNachrechenbarkeit,
  FINDING_TEMPLATES,
  ScoringDomainError,
} from "../index.js";

import { ALL_CRITERION_IDS, type CriterionId } from "../criterion-ids.js";
import { SCORING_MODEL_VERSION, type ObservationPackage } from "../types.js";
import { CRITERION_BY_ID } from "../criterion-table.js";

// ─── Hilfsfunktionen ─────────────────────────────────────────────────────────

function makePackage(
  observations: ObservationPackage["observations"] = []
): ObservationPackage {
  return {
    observations,
    modelVersions: { ocr: "test-v1" },
    pipelineVersion: "v1.0.0",
    scoringModelVersion: SCORING_MODEL_VERSION,
  };
}

function allState(
  state: "fulfilled" | "missing" | "unavailable"
): ObservationPackage["observations"] {
  return ALL_CRITERION_IDS.map((id) => ({ id, state, source: "A" as const }));
}

function withStates(
  overrides: Partial<Record<string, "fulfilled" | "partial" | "missing" | "unavailable">>
): ObservationPackage["observations"] {
  return ALL_CRITERION_IDS.map((id) => ({
    id,
    state: (overrides[id] ?? "fulfilled") as "fulfilled" | "partial" | "missing" | "unavailable",
    source: "A" as const,
  }));
}

function runAll(observations: ObservationPackage["observations"]) {
  const pkg = makePackage(observations);
  const scoringResult = calculateScore(pkg);
  const findings = buildFindings(pkg, scoringResult);
  return { pkg, scoringResult, findings };
}

// ─── A: Alle fulfilled → 0 Findings ─────────────────────────────────────────

describe("A: Alle fulfilled → 0 Findings", () => {
  it("buildFindings gibt leeres Array zurück", () => {
    const { findings } = runAll(allState("fulfilled"));
    assert.equal(findings.length, 0);
  });

  it("verifyNachrechenbarkeit ist true", () => {
    const { pkg, scoringResult, findings } = runAll(allState("fulfilled"));
    assert.equal(verifyNachrechenbarkeit(pkg, scoringResult, findings), true);
  });
});

// ─── B: Alle missing → alle 12 Findings ─────────────────────────────────────

describe("B: Alle missing → alle 12 Findings", () => {
  it("gibt genau 12 Findings zurück", () => {
    const { findings } = runAll(allState("missing"));
    assert.equal(findings.length, 12);
  });

  it("alle 12 templateIds sind vorhanden", () => {
    const { findings } = runAll(allState("missing"));
    const foundIds = new Set(findings.map((f) => f.templateId));
    for (const tmpl of FINDING_TEMPLATES) {
      assert.ok(foundIds.has(tmpl.templateId), `Missing: ${tmpl.templateId}`);
    }
  });

  it("alle status = 'open'", () => {
    const { findings } = runAll(allState("missing"));
    for (const f of findings) {
      assert.equal(f.status, "open");
    }
  });

  it("verifyNachrechenbarkeit ist true", () => {
    const { pkg, scoringResult, findings } = runAll(allState("missing"));
    assert.equal(verifyNachrechenbarkeit(pkg, scoringResult, findings), true);
  });
});

// ─── C: Alle unavailable → 0 Findings ───────────────────────────────────────

describe("C: Alle unavailable → 0 Findings", () => {
  it("buildFindings gibt leeres Array zurück", () => {
    const { findings } = runAll(allState("unavailable"));
    assert.equal(findings.length, 0);
  });
});

// ─── D: Nur bio_cta missing → exakt bio_cta_missing, impact 3 ───────────────

describe("D: Nur bio_cta missing", () => {
  it("genau ein Finding: bio_cta_missing", () => {
    const { findings } = runAll(withStates({ bio_cta: "missing" }));
    assert.equal(findings.length, 1);
    assert.equal(findings[0]!.templateId, "bio_cta_missing");
  });

  it("impact = 3 (maxPoints von bio_cta)", () => {
    const { findings } = runAll(withStates({ bio_cta: "missing" }));
    assert.equal(findings[0]!.impact, 3);
    assert.equal(findings[0]!.lostPoints, 3);
  });

  it("verifyNachrechenbarkeit ist true", () => {
    const { pkg, scoringResult, findings } = runAll(withStates({ bio_cta: "missing" }));
    assert.equal(verifyNachrechenbarkeit(pkg, scoringResult, findings), true);
  });
});

// ─── E: content_hook partial → impact 2 (5-3=2) ─────────────────────────────

describe("E: content_hook partial (maxPoints=5, awarded=3)", () => {
  it("Finding content_hook_weak mit impact 2", () => {
    // content_hook: allowsPartial=true, maxPoints=5, partial → awarded=3, lost=2
    const { findings } = runAll(withStates({ content_hook: "partial" }));
    const f = findings.find((f) => f.templateId === "content_hook_weak");
    assert.ok(f !== undefined, "content_hook_weak nicht gefunden");
    assert.equal(f.impact, 2, "5 - ceil(5/2)=3 → lost = 2");
  });

  it("verifyNachrechenbarkeit ist true", () => {
    const { pkg, scoringResult, findings } = runAll(withStates({ content_hook: "partial" }));
    assert.equal(verifyNachrechenbarkeit(pkg, scoringResult, findings), true);
  });
});

// ─── F: bio_target_audience + bio_outcome missing → bio_positioning_unclear, impact 10 ──

describe("F: bio_target_audience + bio_outcome missing", () => {
  it("genau ein Finding: bio_positioning_unclear", () => {
    const { findings } = runAll(withStates({
      bio_target_audience: "missing",
      bio_outcome: "missing",
    }));
    const matches = findings.filter((f) => f.templateId === "bio_positioning_unclear");
    assert.equal(matches.length, 1);
  });

  it("impact = 10 (5+5)", () => {
    const { findings } = runAll(withStates({
      bio_target_audience: "missing",
      bio_outcome: "missing",
    }));
    const f = findings.find((f) => f.templateId === "bio_positioning_unclear");
    assert.ok(f !== undefined);
    assert.equal(f.impact, 10);
  });
});

// ─── G: Foundation + polish → polish.blockedByFoundation = true ──────────────

describe("G: foundation + polish Findings", () => {
  it("polish.blockedByFoundation = true wenn foundation offen", () => {
    // bio_positioning_unclear ist foundation (bio_target_audience + bio_outcome missing)
    // branding_inconsistent ist polish (brand_* missing)
    const { findings } = runAll(withStates({
      bio_target_audience: "missing",
      bio_outcome: "missing",
      brand_colors: "missing",
      brand_font: "missing",
      brand_theme: "missing",
      brand_recognizable: "missing",
    }));

    const foundation = findings.filter((f) => f.severity === "foundation");
    const polish = findings.filter((f) => f.severity === "polish");

    assert.ok(foundation.length > 0, "Kein foundation-Finding");
    assert.ok(polish.length > 0, "Kein polish-Finding");

    for (const f of polish) {
      assert.equal(f.blockedByFoundation, true, `${f.templateId}: blockedByFoundation sollte true sein`);
    }
    for (const f of foundation) {
      assert.equal(f.blockedByFoundation, false, `${f.templateId}: foundation ist nie blocked`);
    }
  });
});

// ─── H: Nur polish → blockedByFoundation = false ─────────────────────────────

describe("H: Nur polish-Findings (kein foundation)", () => {
  it("blockedByFoundation = false", () => {
    // feed_inconsistent = polish: feed_color_world + feed_cover_pattern
    // branding_inconsistent = polish: brand_*
    const { findings } = runAll(withStates({
      feed_color_world: "missing",
      feed_cover_pattern: "missing",
      brand_colors: "missing",
      brand_font: "missing",
      brand_theme: "missing",
      brand_recognizable: "missing",
    }));
    const polishFindings = findings.filter((f) => f.severity === "polish");
    assert.ok(polishFindings.length > 0, "Kein polish-Finding erzeugt");
    for (const f of polishFindings) {
      assert.equal(f.blockedByFoundation, false, `${f.templateId}: sollte nicht blocked sein`);
    }
  });
});

// ─── I: Top 3 enthält keine blockierten polish-Findings ──────────────────────

describe("I: selectTopFindings überspringt blockierte polish-Findings", () => {
  it("Top 3 ohne blocked polish", () => {
    // Alle missing → 12 Findings, davon 2 polish (blocked)
    const { findings } = runAll(allState("missing"));
    const top3 = selectTopFindings(findings, 3);
    for (const f of top3) {
      assert.equal(f.blockedByFoundation, false, `Blocked finding in Top 3: ${f.templateId}`);
    }
    assert.ok(top3.length <= 3);
  });

  it("Gibt maximal `limit` Findings zurück", () => {
    const { findings } = runAll(allState("missing"));
    assert.equal(selectTopFindings(findings, 3).length, 3);
    assert.equal(selectTopFindings(findings, 1).length, 1);
    assert.equal(selectTopFindings(findings, 0).length, 0);
  });
});

// ─── J: Alphabetische templateId-Sortierung bei Gleichstand ──────────────────

describe("J: Alphabetische Sortierung bei gleicher Severity und gleichem Impact", () => {
  it("Findings mit gleichem severity+impact sind nach templateId sortiert", () => {
    // Alle missing → mehrere lever-Findings entstehen
    const { findings } = runAll(allState("missing"));
    const levers = findings.filter((f) => f.severity === "lever");

    // Prüfen ob korrekt sortiert (descending impact, dann alphabetisch)
    for (let i = 0; i < levers.length - 1; i++) {
      const a = levers[i]!;
      const b = levers[i + 1]!;
      if (a.impact === b.impact) {
        assert.ok(
          a.templateId.localeCompare(b.templateId) <= 0,
          `${a.templateId} sollte vor ${b.templateId} stehen`
        );
      } else {
        assert.ok(a.impact >= b.impact, "Lever-Findings nicht nach Impact sortiert");
      }
    }
  });
});

// ─── K: Kein CriterionId in zwei Templates ───────────────────────────────────

describe("K: Template-Disjunktheit", () => {
  it("kein CriterionId erscheint in zwei Templates", () => {
    const seen = new Map<string, string>();
    for (const tmpl of FINDING_TEMPLATES) {
      for (const id of tmpl.criterionIds) {
        const prev = seen.get(id);
        assert.ok(
          !prev,
          `CriterionId "${id}" in "${prev}" UND "${tmpl.templateId}"`
        );
        seen.set(id, tmpl.templateId);
      }
    }
  });
});

// ─── L: Summe Finding-Impact <= Gesamtverlust ────────────────────────────────

describe("L: Summe Finding-Impact <= Gesamtverlust", () => {
  it("alle missing: Finding-Impact <= totalLost", () => {
    const { pkg, scoringResult, findings } = runAll(allState("missing"));
    const totalFindingImpact = findings.reduce((acc, f) => acc + f.impact, 0);
    const cr = scoringResult.coverageReport;
    const totalLost = cr.checkedPoints - cr.rawPoints;
    assert.ok(
      totalFindingImpact <= totalLost,
      `${totalFindingImpact} > ${totalLost}`
    );
  });

  it("gemischte Zustände: Finding-Impact <= totalLost", () => {
    const { pkg, scoringResult, findings } = runAll(withStates({
      bio_target_audience: "missing",
      content_hook: "partial",
      feed_topic: "missing",
    }));
    const totalFindingImpact = findings.reduce((acc, f) => acc + f.impact, 0);
    const cr = scoringResult.coverageReport;
    const totalLost = cr.checkedPoints - cr.rawPoints;
    assert.ok(totalFindingImpact <= totalLost);
  });
});

// ─── M: Reproduzierbarkeit ───────────────────────────────────────────────────

describe("M: Gleiche Eingabe → exakt gleiche Finding-Reihenfolge", () => {
  it("identische packagee → identische Findings", () => {
    const obs = withStates({
      bio_target_audience: "missing",
      content_hook: "partial",
      brand_colors: "missing",
    });
    const { findings: f1 } = runAll(obs);
    const { findings: f2 } = runAll(obs);
    assert.equal(f1.length, f2.length);
    for (let i = 0; i < f1.length; i++) {
      assert.equal(f1[i]!.templateId, f2[i]!.templateId);
      assert.equal(f1[i]!.impact, f2[i]!.impact);
      assert.equal(f1[i]!.priority, f2[i]!.priority);
    }
  });
});

// ─── N: selectTopFindings mutiert nicht ──────────────────────────────────────

describe("N: selectTopFindings verändert das Original-Array nicht", () => {
  it("Original-Array unverändert nach selectTopFindings", () => {
    const { findings } = runAll(allState("missing"));
    const originalLength = findings.length;
    const originalFirst = findings[0]!.templateId;

    const top = selectTopFindings(findings as Finding[], 3);

    assert.equal(findings.length, originalLength, "Länge verändert");
    assert.equal(findings[0]!.templateId, originalFirst, "Erstes Element verändert");
    assert.ok(top.length <= 3);
  });
});

// ─── Zusatz: Impact-Korrektheit im Detail ────────────────────────────────────

describe("Impact-Korrektheit", () => {
  it("missing 5-Punkte-Kriterium → lostPoints = 5", () => {
    const { findings } = runAll(withStates({ bio_target_audience: "missing" }));
    // bio_target_audience ist in bio_positioning_unclear
    // aber bio_outcome ist fulfilled → partial template impact
    const f = findings.find((f) => f.templateId === "bio_positioning_unclear");
    assert.ok(f !== undefined);
    // bio_target_audience(5 missing) + bio_outcome(5 fulfilled=0 lost) = 5
    assert.equal(f.impact, 5);
  });

  it("missing 3-Punkte-Kriterium → lostPoints = 3", () => {
    const { findings } = runAll(withStates({ bio_cta: "missing" }));
    const f = findings.find((f) => f.templateId === "bio_cta_missing");
    assert.ok(f !== undefined);
    assert.equal(f.impact, 3);
  });

  it("partial 4-Punkte-Kriterium → lostPoints = 2 (4 - ceil(4/2)=2)", () => {
    // content_cover: maxPoints=4, allowsPartial=true, partial→awarded=2, lost=2
    const { findings } = runAll(withStates({ content_cover: "partial" }));
    const f = findings.find((f) => f.templateId === "covers_unclear");
    assert.ok(f !== undefined, "covers_unclear nicht gefunden");
    // content_text_position(2 Pkt) ist fulfilled → lost=0
    // content_cover(4 Pkt) partial → lost=2
    assert.equal(f.impact, 2);
  });

  it("unavailable Kriterium → kein lostPoints", () => {
    // bio_target_audience unavailable, bio_outcome missing
    const { findings } = runAll(withStates({
      bio_target_audience: "unavailable",
      bio_outcome: "missing",
    }));
    const f = findings.find((f) => f.templateId === "bio_positioning_unclear");
    // bio_target_audience unavailable → 0 lost; bio_outcome missing → 5 lost
    assert.ok(f !== undefined);
    assert.equal(f.impact, 5);
  });
});

// ─── Zusatz: Sortierreihenfolge foundation > lever > polish ──────────────────

describe("Sortierreihenfolge", () => {
  it("foundation kommt vor lever kommt vor polish", () => {
    const { findings } = runAll(allState("missing"));
    const severities = findings.map((f) => f.severity);
    let lastSeverityOrder = -1;
    const ORDER: Record<string, number> = { foundation: 0, lever: 1, polish: 2 };
    for (const sev of severities) {
      const ord = ORDER[sev] ?? 99;
      assert.ok(ord >= lastSeverityOrder, `Severity-Reihenfolge verletzt: ${sev}`);
      lastSeverityOrder = ord;
    }
  });

  it("priority-Nummern sind 1-basiert und aufsteigend", () => {
    const { findings } = runAll(allState("missing"));
    for (let i = 0; i < findings.length; i++) {
      assert.equal(findings[i]!.priority, i + 1);
    }
  });
});

// ─── O–T: Property-Tests ─────────────────────────────────────────────────────

describe("Property-Tests buildFindings (10.000 Pakete)", () => {
  function makeLcg(seed: number) {
    let s = seed;
    return () => { s = (s * 48271) % 2147483647; return s / 2147483647; };
  }

  function generateValidPackage(rng: () => number): ObservationPackage {
    const obs = ALL_CRITERION_IDS.map((id) => {
      const def = CRITERION_BY_ID[id]!;
      const r = rng();
      let state: "fulfilled" | "partial" | "missing" | "unavailable";
      if (r < 0.15) state = "unavailable";
      else if (r < 0.30) state = "missing";
      else if (r < 0.50 && def.allowsPartial) state = "partial";
      else state = "fulfilled";
      return { id, state, source: "A" as const };
    });
    return makePackage(obs);
  }

  const ITER = 10_000;

  it(`O: kein negativer Finding-Impact (${ITER} Pakete)`, () => {
    const rng = makeLcg(101);
    for (let i = 0; i < ITER; i++) {
      const pkg = generateValidPackage(rng);
      const sr = calculateScore(pkg);
      const findings = buildFindings(pkg, sr);
      for (const f of findings) {
        assert.ok(f.impact >= 0, `Iter ${i}: ${f.templateId} impact = ${f.impact}`);
      }
    }
  });

  it(`P: kein Finding mit impact = 0 (${ITER} Pakete)`, () => {
    const rng = makeLcg(202);
    for (let i = 0; i < ITER; i++) {
      const pkg = generateValidPackage(rng);
      const sr = calculateScore(pkg);
      const findings = buildFindings(pkg, sr);
      for (const f of findings) {
        assert.ok(f.impact > 0, `Iter ${i}: ${f.templateId} impact = 0 (sollte nicht entstehen)`);
      }
    }
  });

  it(`Q: kein unavailable-Kriterium in Finding-Impact (${ITER} Pakete)`, () => {
    // Wenn alle Kriterien eines Templates unavailable sind → kein Finding
    const rng = makeLcg(303);
    for (let i = 0; i < ITER; i++) {
      const pkg = generateValidPackage(rng);
      const sr = calculateScore(pkg);
      const findings = buildFindings(pkg, sr);
      // Prüfen per verifyNachrechenbarkeit (Invariante 4)
      assert.equal(verifyNachrechenbarkeit(pkg, sr, findings), true,
        `Iter ${i}: verifyNachrechenbarkeit fehlgeschlagen`);
    }
  });

  it(`R: Findings immer deterministisch sortiert (${ITER} Pakete)`, () => {
    const rng = makeLcg(404);
    const ORDER: Record<string, number> = { foundation: 0, lever: 1, polish: 2 };
    for (let i = 0; i < ITER; i++) {
      const pkg = generateValidPackage(rng);
      const sr = calculateScore(pkg);
      const findings = buildFindings(pkg, sr);
      for (let j = 0; j < findings.length - 1; j++) {
        const a = findings[j]!;
        const b = findings[j + 1]!;
        const aOrd = ORDER[a.severity] ?? 99;
        const bOrd = ORDER[b.severity] ?? 99;
        if (aOrd !== bOrd) {
          assert.ok(aOrd < bOrd, `Iter ${i}: ${a.severity} nach ${b.severity}`);
        } else if (a.impact !== b.impact) {
          assert.ok(a.impact >= b.impact, `Iter ${i}: Impact ${a.impact} nach ${b.impact}`);
        } else {
          assert.ok(
            a.templateId.localeCompare(b.templateId) <= 0,
            `Iter ${i}: ${a.templateId} nach ${b.templateId}`
          );
        }
      }
    }
  });

  it(`S: selectTopFindings.length <= 3 (${ITER} Pakete)`, () => {
    const rng = makeLcg(505);
    for (let i = 0; i < ITER; i++) {
      const pkg = generateValidPackage(rng);
      const sr = calculateScore(pkg);
      const findings = buildFindings(pkg, sr);
      const top = selectTopFindings(findings);
      assert.ok(top.length <= 3, `Iter ${i}: top.length = ${top.length}`);
    }
  });

  it(`T: verifyNachrechenbarkeit true für alle gültigen Pakete (${ITER} Pakete)`, () => {
    const rng = makeLcg(606);
    for (let i = 0; i < ITER; i++) {
      const pkg = generateValidPackage(rng);
      const sr = calculateScore(pkg);
      const findings = buildFindings(pkg, sr);
      assert.equal(
        verifyNachrechenbarkeit(pkg, sr, findings),
        true,
        `Iter ${i}: verifyNachrechenbarkeit fehlgeschlagen`
      );
    }
  });
});

// Typ-Import für N-Test
import type { Finding } from "../types.js";
