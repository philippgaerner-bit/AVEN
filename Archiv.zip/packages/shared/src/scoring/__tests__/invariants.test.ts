/**
 * Invarianten-Tests für den Creator-Score-Bewertungskern.
 *
 * Deckt ab:
 *  - Kriterien-IDs (31 exakt, keine Duplikate, alle vorhanden)
 *  - Kategorien (7 exakt, Summe = 100, keine Lücken)
 *  - Kriterientabelle (31 Definitionen, Summen, allowsPartial)
 *  - Typen und Konstanten
 *  - Versionierung
 */

import { describe, it } from "node:test";
import assert from "node:assert/strict";

import {
  ALL_CRITERION_IDS,
  EXPECTED_CRITERION_COUNT,
  CATEGORIES,
  CATEGORY_IDS,
  EXPECTED_CATEGORY_COUNT,
  EXPECTED_TOTAL_MAX_POINTS,
  SCORING_MODEL_VERSION,
  CRITERION_STATES,
  OBSERVATION_SOURCES,
  FINDING_SEVERITIES,
  MINIMUM_COVERAGE_FOR_DISPLAY,
  CRITERION_TABLE,
  CRITERION_BY_ID,
} from "../index.js";

// ─── Kriterien-IDs ───────────────────────────────────────────────────────────

describe("Kriterien-IDs", () => {
  it("enthält exakt 31 Einträge", () => {
    assert.equal(
      ALL_CRITERION_IDS.length,
      31,
      `Erwartet 31 Kriterien, gefunden: ${ALL_CRITERION_IDS.length}`
    );
  });

  it("EXPECTED_CRITERION_COUNT ist die feste Konstante 31", () => {
    assert.equal(EXPECTED_CRITERION_COUNT, 31);
  });

  it("ALL_CRITERION_IDS.length === EXPECTED_CRITERION_COUNT", () => {
    assert.equal(ALL_CRITERION_IDS.length, EXPECTED_CRITERION_COUNT);
  });

  it("enthält keine doppelten IDs", () => {
    const unique = new Set(ALL_CRITERION_IDS);
    assert.equal(
      unique.size,
      ALL_CRITERION_IDS.length,
      `Doppelte CriterionIds gefunden`
    );
  });

  it("enthält alle 5 Bio-Kriterien", () => {
    const expected = ["bio_target_audience","bio_outcome","bio_cta","bio_first_line","bio_no_filler"];
    for (const id of expected) {
      assert.ok((ALL_CRITERION_IDS as readonly string[]).includes(id), `Fehlt: ${id}`);
    }
  });

  it("enthält alle 6 Content-Kriterien", () => {
    const expected = ["content_hook","content_cover","content_recurring","content_length","content_text_position","content_regularity"];
    for (const id of expected) {
      assert.ok((ALL_CRITERION_IDS as readonly string[]).includes(id), `Fehlt: ${id}`);
    }
  });

  it("enthält alle 4 Feed-Kriterien", () => {
    for (const id of ["feed_color_world","feed_cover_pattern","feed_topic","feed_pinned"]) {
      assert.ok((ALL_CRITERION_IDS as readonly string[]).includes(id), `Fehlt: ${id}`);
    }
  });

  it("enthält alle 4 Branding-Kriterien", () => {
    for (const id of ["brand_colors","brand_font","brand_theme","brand_recognizable"]) {
      assert.ok((ALL_CRITERION_IDS as readonly string[]).includes(id), `Fehlt: ${id}`);
    }
  });

  it("enthält alle 4 Profilbild-Kriterien", () => {
    for (const id of ["profile_pic_recognition","profile_pic_subject","profile_pic_contrast","profile_pic_color_fit"]) {
      assert.ok((ALL_CRITERION_IDS as readonly string[]).includes(id), `Fehlt: ${id}`);
    }
  });

  it("enthält alle 4 Username-Kriterien", () => {
    for (const id of ["username_pronounceable","username_clean","name_field_topic","username_name_match"]) {
      assert.ok((ALL_CRITERION_IDS as readonly string[]).includes(id), `Fehlt: ${id}`);
    }
  });

  it("enthält alle 4 Engagement-Kriterien", () => {
    for (const id of ["engagement_captions","engagement_replies","engagement_opinion","engagement_cta_end"]) {
      assert.ok((ALL_CRITERION_IDS as readonly string[]).includes(id), `Fehlt: ${id}`);
    }
  });

  it("alle IDs sind nicht-leere Strings", () => {
    for (const id of ALL_CRITERION_IDS) {
      assert.ok(typeof id === "string" && id.length > 0);
    }
  });
});

// ─── Kategorien ──────────────────────────────────────────────────────────────

describe("Kategorien", () => {
  it("enthält exakt 7 Kategorien", () => {
    assert.equal(CATEGORIES.length, EXPECTED_CATEGORY_COUNT);
    assert.equal(EXPECTED_CATEGORY_COUNT, 7);
  });

  it("CATEGORY_IDS hat exakt 7 Einträge", () => {
    assert.equal(CATEGORY_IDS.length, 7);
  });

  it("alle Kategorie-IDs sind in CATEGORY_IDS enthalten", () => {
    for (const cat of CATEGORIES) {
      assert.ok((CATEGORY_IDS as readonly string[]).includes(cat.id), `Fehlt: ${cat.id}`);
    }
  });

  it("enthält keine doppelten Kategorie-IDs", () => {
    const ids = CATEGORIES.map((c) => c.id);
    assert.equal(new Set(ids).size, ids.length);
  });

  it("Summe der Kategorie-Maximalwerte ergibt exakt 100", () => {
    const sum = CATEGORIES.reduce((acc, cat) => acc + cat.maxPoints, 0);
    assert.equal(sum, EXPECTED_TOTAL_MAX_POINTS);
    assert.equal(EXPECTED_TOTAL_MAX_POINTS, 100);
  });

  it("keine Kategorie hat Maximalwert ≤ 0", () => {
    for (const cat of CATEGORIES) {
      assert.ok(cat.maxPoints > 0, `${cat.id}: maxPoints = ${cat.maxPoints}`);
    }
  });

  it("jede Kategorie hat mindestens ein Kriterium", () => {
    for (const cat of CATEGORIES) {
      assert.ok(cat.criterionIds.length > 0, `${cat.id} hat keine Kriterien`);
    }
  });

  it("kein Kriterium erscheint in mehr als einer Kategorie", () => {
    const seen = new Map<string, string>();
    for (const cat of CATEGORIES) {
      for (const id of cat.criterionIds) {
        assert.ok(!seen.has(id), `${id} in ${seen.get(id)} UND ${cat.id}`);
        seen.set(id, cat.id);
      }
    }
  });

  it("alle Kriterien aller Kategorien sind in ALL_CRITERION_IDS", () => {
    const allIds = new Set(ALL_CRITERION_IDS as readonly string[]);
    for (const cat of CATEGORIES) {
      for (const id of cat.criterionIds) {
        assert.ok(allIds.has(id), `${id} (${cat.id}) nicht in ALL_CRITERION_IDS`);
      }
    }
  });

  it("alle ALL_CRITERION_IDS sind in genau einer Kategorie", () => {
    const categorized = new Set<string>();
    for (const cat of CATEGORIES) {
      for (const id of cat.criterionIds) categorized.add(id);
    }
    for (const id of ALL_CRITERION_IDS) {
      assert.ok(categorized.has(id), `${id} in keiner Kategorie`);
    }
    assert.equal(categorized.size, ALL_CRITERION_IDS.length);
  });

  it("Bio = 18, Content = 20, Feed = 16, Brand = 14, ProfilePic = 10, Username = 10, Engagement = 12", () => {
    const expected: Array<[string, number]> = [
      ["bio", 18], ["content", 20], ["feed", 16], ["brand", 14],
      ["profilePic", 10], ["username", 10], ["engagement", 12],
    ];
    for (const [id, pts] of expected) {
      const cat = CATEGORIES.find((c) => c.id === id);
      assert.ok(cat, `Kategorie nicht gefunden: ${id}`);
      assert.equal(cat.maxPoints, pts, `${id}: erwartet ${pts}, gefunden ${cat.maxPoints}`);
    }
  });
});

// ─── Kriterientabelle ────────────────────────────────────────────────────────

describe("Kriterientabelle", () => {
  it("enthält exakt 31 Definitionen", () => {
    assert.equal(CRITERION_TABLE.length, 31);
  });

  it("exakt eine Definition pro CriterionId", () => {
    const ids = CRITERION_TABLE.map((c) => c.id);
    assert.equal(new Set(ids).size, ids.length, "Doppelte Definitionen gefunden");
    assert.equal(ids.length, ALL_CRITERION_IDS.length);
  });

  it("alle ALL_CRITERION_IDS haben eine Definition", () => {
    for (const id of ALL_CRITERION_IDS) {
      assert.ok(CRITERION_BY_ID[id] !== undefined, `Keine Definition für: ${id}`);
    }
  });

  it("Summe aller maxPoints = 100", () => {
    const sum = CRITERION_TABLE.reduce((acc, c) => acc + c.maxPoints, 0);
    assert.equal(sum, 100, `Summe = ${sum}, erwartet 100`);
  });

  it("Kategoriensummen stimmen mit CategoryDefinition.maxPoints überein", () => {
    const expected: Array<[string, number]> = [
      ["bio", 18], ["content", 20], ["feed", 16], ["brand", 14],
      ["profilePic", 10], ["username", 10], ["engagement", 12],
    ];
    for (const [catId, expected_pts] of expected) {
      const sum = CRITERION_TABLE
        .filter((c) => c.categoryId === catId)
        .reduce((acc, c) => acc + c.maxPoints, 0);
      assert.equal(sum, expected_pts, `Kategorie ${catId}: Summe ${sum}, erwartet ${expected_pts}`);
    }
  });

  it("alle maxPoints > 0", () => {
    for (const c of CRITERION_TABLE) {
      assert.ok(c.maxPoints > 0, `${c.id}: maxPoints = ${c.maxPoints}`);
    }
  });

  it("allowsPartial ist genau wie in der Spezifikation definiert", () => {
    const partialExpected: Record<string, boolean> = {
      bio_target_audience: false, bio_outcome: false, bio_cta: false,
      bio_first_line: true, bio_no_filler: true,
      content_hook: true, content_cover: true, content_recurring: false,
      content_length: false, content_text_position: false, content_regularity: true,
      feed_color_world: true, feed_cover_pattern: true, feed_topic: false, feed_pinned: false,
      brand_colors: true, brand_font: false, brand_theme: true, brand_recognizable: false,
      profile_pic_recognition: true, profile_pic_subject: false,
      profile_pic_contrast: false, profile_pic_color_fit: false,
      username_pronounceable: true, username_clean: false,
      name_field_topic: false, username_name_match: false,
      engagement_captions: true, engagement_replies: false,
      engagement_opinion: true, engagement_cta_end: false,
    };
    for (const [id, expected] of Object.entries(partialExpected)) {
      const def = CRITERION_BY_ID[id];
      assert.ok(def !== undefined, `Keine Definition für: ${id}`);
      assert.equal(
        def.allowsPartial, expected,
        `${id}: allowsPartial = ${def.allowsPartial}, erwartet ${expected}`
      );
    }
  });

  it("profile_pic_color_fit hat maxPoints 1 und allowsPartial false", () => {
    const def = CRITERION_BY_ID["profile_pic_color_fit"];
    assert.ok(def !== undefined);
    assert.equal(def.maxPoints, 1);
    assert.equal(def.allowsPartial, false);
  });
});

// ─── Versionierung ───────────────────────────────────────────────────────────

describe("Versionierung", () => {
  it("SCORING_MODEL_VERSION ist 'v1.0.0'", () => {
    assert.equal(SCORING_MODEL_VERSION, "v1.0.0");
  });
});

// ─── Typen und Konstanten ────────────────────────────────────────────────────

describe("CriterionState", () => {
  it("enthält exakt fulfilled, partial, missing, unavailable", () => {
    assert.equal(CRITERION_STATES.length, 4);
    for (const s of ["fulfilled","partial","missing","unavailable"]) {
      assert.ok((CRITERION_STATES as readonly string[]).includes(s), `Fehlt: ${s}`);
    }
  });
});

describe("ObservationSource", () => {
  it("enthält exakt A, B, C", () => {
    assert.equal(OBSERVATION_SOURCES.length, 3);
    for (const s of ["A","B","C"]) {
      assert.ok((OBSERVATION_SOURCES as readonly string[]).includes(s));
    }
  });
});

describe("FindingSeverity", () => {
  it("enthält foundation, lever, polish", () => {
    assert.equal(FINDING_SEVERITIES.length, 3);
    for (const s of ["foundation","lever","polish"]) {
      assert.ok((FINDING_SEVERITIES as readonly string[]).includes(s));
    }
  });
});

describe("Abdeckungsschwelle", () => {
  it("MINIMUM_COVERAGE_FOR_DISPLAY ist 0.60", () => {
    assert.equal(MINIMUM_COVERAGE_FOR_DISPLAY, 0.60);
  });
});
