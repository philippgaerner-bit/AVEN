/**
 * Alle 31 Kriterien-IDs des Creator-Score-Modells v1.
 *
 * Diese Liste ist die einzige Quelle der Wahrheit für alle Kriterien-Bezeichner.
 * Änderungen hier erfordern eine neue SCORING_MODEL_VERSION.
 *
 * Architekturregeln:
 * - Keine Imports aus Datenbank, Netzwerk, KI-SDKs oder Cloud-Diensten.
 * - Diese Datei ist eine reine Typdefinition ohne Seiteneffekte.
 */

// ─── Bio (5 Kriterien, max. 18 Punkte) ──────────────────────────────────────

/**
 * 1.1  Nennt eine Zielgruppe oder ein Für-wen
 * 1.2  Nennt ein Ergebnis oder einen Nutzen
 * 1.3  Enthält eine Handlungsaufforderung
 * 1.4  Erste Zeile funktioniert allein
 * 1.5  Frei von Floskeln ohne Aussage
 */
export const BIO_CRITERION_IDS = [
  "bio_target_audience",
  "bio_outcome",
  "bio_cta",
  "bio_first_line",
  "bio_no_filler",
] as const;

// ─── Content-Struktur (6 Kriterien, max. 20 Punkte) ─────────────────────────

/**
 * 2.1  Erkennbarer Hook in den ersten Sekunden
 * 2.2  Titel/Cover kommuniziert den Inhalt
 * 2.3  Wiederkehrende Formate erkennbar
 * 2.4  Video-Länge passt zum Format
 * 2.5  Text im Bild lesbar und nicht verdeckt
 * 2.6  Regelmäßige Veröffentlichung
 */
export const CONTENT_CRITERION_IDS = [
  "content_hook",
  "content_cover",
  "content_recurring",
  "content_length",
  "content_text_position",
  "content_regularity",
] as const;

// ─── Feed (4 Kriterien, max. 16 Punkte) ─────────────────────────────────────

/**
 * 3.1  Erkennbare Farbwelt über mehrere Beiträge
 * 3.2  Cover folgen einem sichtbaren Muster
 * 3.3  Erste neun Beiträge zeigen das Thema
 * 3.4  Angeheftete Beiträge werden genutzt
 */
export const FEED_CRITERION_IDS = [
  "feed_color_world",
  "feed_cover_pattern",
  "feed_topic",
  "feed_pinned",
] as const;

// ─── Branding (4 Kriterien, max. 14 Punkte) ─────────────────────────────────

/**
 * 4.1  Wiederkehrende Farben über alle Elemente
 * 4.2  Einheitliche Schrift in Covern und Grafiken
 * 4.3  Ein durchgehendes Thema statt vieler
 * 4.4  Wiedererkennbares visuelles Merkmal
 */
export const BRAND_CRITERION_IDS = [
  "brand_colors",
  "brand_font",
  "brand_theme",
  "brand_recognizable",
] as const;

// ─── Profilbild (4 Kriterien, max. 10 Punkte) ───────────────────────────────

/**
 * 5.1  Motiv in kleiner Darstellung erkennbar
 * 5.2  Gesicht oder klares Symbol, nicht beides
 * 5.3  Kontrast zum Hintergrund ausreichend
 * 5.4  Passt zur Farbwelt des Profils
 */
export const PROFILE_PIC_CRITERION_IDS = [
  "profile_pic_recognition",
  "profile_pic_subject",
  "profile_pic_contrast",
  "profile_pic_color_fit",
] as const;

// ─── Username & Name (4 Kriterien, max. 10 Punkte) ──────────────────────────

/**
 * 6.1  Aussprechbar und merkbar
 * 6.2  Frei von Zahlenketten und Sonderzeichen
 * 6.3  Namensfeld nennt Thema oder Nutzen
 * 6.4  Username und Name stimmen überein
 */
export const USERNAME_CRITERION_IDS = [
  "username_pronounceable",
  "username_clean",
  "name_field_topic",
  "username_name_match",
] as const;

// ─── Engagement-Struktur (4 Kriterien, max. 12 Punkte) ──────────────────────

/**
 * 7.1  Captions enthalten Fragen oder Aufforderungen
 * 7.2  Auf Kommentare wird sichtbar geantwortet
 * 7.3  Content erzeugt Anlass zur Meinung
 * 7.4  Handlungsaufforderung am Videoende erkennbar
 */
export const ENGAGEMENT_CRITERION_IDS = [
  "engagement_captions",
  "engagement_replies",
  "engagement_opinion",
  "engagement_cta_end",
] as const;

// ─── Gesamt-Array ────────────────────────────────────────────────────────────

/**
 * Vollständige, geordnete Liste aller 31 Kriterien-IDs.
 * Wird für Invariantenprüfungen und die Kriterientabelle verwendet.
 */
export const ALL_CRITERION_IDS = [
  ...BIO_CRITERION_IDS,
  ...CONTENT_CRITERION_IDS,
  ...FEED_CRITERION_IDS,
  ...BRAND_CRITERION_IDS,
  ...PROFILE_PIC_CRITERION_IDS,
  ...USERNAME_CRITERION_IDS,
  ...ENGAGEMENT_CRITERION_IDS,
] as const;

/** Literal-Union aller 31 Kriterien-IDs */
export type CriterionId = (typeof ALL_CRITERION_IDS)[number];

/**
 * Verbindliche Gesamtzahl der Kriterien in V1 — jede Abweichung ist ein Modellfehler.
 *
 * Diese Konstante ist FEST und darf NICHT dynamisch von ALL_CRITERION_IDS.length
 * abgeleitet werden. Sie ist die Invariante, die verhindert, dass versehentlich
 * Kriterien gelöscht oder hinzugefügt werden ohne bewusste Versionierung.
 *
 * Änderung dieser Zahl erfordert: neue SCORING_MODEL_VERSION + Migration.
 */
export const EXPECTED_CRITERION_COUNT = 31 as const;
