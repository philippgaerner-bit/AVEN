/**
 * Strukturvalidierung von Golden Cases.
 *
 * Prüft die FORM eines Golden Case — nicht ob die erwarteten Werte
 * inhaltlich korrekt sind. Das leistet der Golden Runner.
 *
 * Reine Funktionen: keine Datenbank, kein Netzwerk, keine KI.
 */

import type {
  GoldenCase,
  GoldenValidationError,
  GoldenValidationResult,
} from "./types.js";
import { GOLDEN_PLATFORMS, MAX_TOP_FINDINGS } from "./types.js";
import { SCORING_MODEL_VERSION } from "../scoring/types.js";
import { CRITERION_BY_ID } from "../scoring/criterion-table.js";
import { FINDING_TEMPLATE_BY_ID } from "../scoring/finding-templates.js";

// ─── Einzelner Fall ──────────────────────────────────────────────────────────

/**
 * Validiert einen einzelnen Golden Case.
 *
 * Geprüft wird:
 *   - gültige Plattform
 *   - gültige CriterionIds im input
 *   - gültige FindingTemplateIds in expected
 *   - korrekte scoringModelVersion
 *   - Score zwischen 0 und 100
 *   - Coverage zwischen 0 und 1
 *   - maximal MAX_TOP_FINDINGS TopFindings
 *   - keine doppelten FindingTemplateIds
 *   - topFindingTemplateIds ⊆ findingTemplateIds
 *
 * Gibt eine Liste von Fehlern zurück (leer = gültig).
 */
export function validateGoldenCase(
  goldenCase: GoldenCase
): ReadonlyArray<GoldenValidationError> {
  const errors: GoldenValidationError[] = [];
  const id = goldenCase.id;

  const err = (field: string, message: string): void => {
    errors.push({ caseId: id, field, message });
  };

  // ── ID nicht leer ──────────────────────────────────────────────────────────
  if (typeof goldenCase.id !== "string" || goldenCase.id.trim() === "") {
    err("id", "id muss ein nicht-leerer String sein");
  }

  // ── Plattform ──────────────────────────────────────────────────────────────
  if (!(GOLDEN_PLATFORMS as readonly string[]).includes(goldenCase.platform)) {
    err(
      "platform",
      `Ungültige Plattform: "${String(goldenCase.platform)}". ` +
        `Erlaubt: ${GOLDEN_PLATFORMS.join(", ")}`
    );
  }

  // ── CriterionIds im input ──────────────────────────────────────────────────
  const seenCriterionIds = new Set<string>();
  for (const obs of goldenCase.input.observations) {
    if (CRITERION_BY_ID[obs.id] === undefined) {
      err(
        "input.observations",
        `Unbekannte CriterionId: "${String(obs.id)}"`
      );
    }
    if (seenCriterionIds.has(obs.id)) {
      err(
        "input.observations",
        `Doppelte CriterionId im input: "${String(obs.id)}"`
      );
    }
    seenCriterionIds.add(obs.id);
  }

  // ── scoringModelVersion: input UND metadata ────────────────────────────────
  if (goldenCase.input.scoringModelVersion !== SCORING_MODEL_VERSION) {
    err(
      "input.scoringModelVersion",
      `Falsche scoringModelVersion: "${goldenCase.input.scoringModelVersion}". ` +
        `Erwartet: "${SCORING_MODEL_VERSION}"`
    );
  }
  if (goldenCase.metadata.scoringModelVersion !== SCORING_MODEL_VERSION) {
    err(
      "metadata.scoringModelVersion",
      `Falsche scoringModelVersion in metadata: "${goldenCase.metadata.scoringModelVersion}". ` +
        `Erwartet: "${SCORING_MODEL_VERSION}"`
    );
  }

  // ── Score-Bereich ──────────────────────────────────────────────────────────
  const total = goldenCase.expected.totalScore;
  if (typeof total !== "number" || Number.isNaN(total)) {
    err("expected.totalScore", "totalScore muss eine Zahl sein");
  } else if (total < 0 || total > 100) {
    err(
      "expected.totalScore",
      `totalScore außerhalb 0–100: ${total}`
    );
  }

  // ── Coverage-Bereich ───────────────────────────────────────────────────────
  const cov = goldenCase.expected.coverageRatio;
  if (typeof cov !== "number" || Number.isNaN(cov)) {
    err("expected.coverageRatio", "coverageRatio muss eine Zahl sein");
  } else if (cov < 0 || cov > 1) {
    err(
      "expected.coverageRatio",
      `coverageRatio außerhalb 0–1: ${cov}`
    );
  }

  // ── FindingTemplateIds gültig und eindeutig ────────────────────────────────
  const seenFindingIds = new Set<string>();
  for (const templateId of goldenCase.expected.findingTemplateIds) {
    if (FINDING_TEMPLATE_BY_ID[templateId] === undefined) {
      err(
        "expected.findingTemplateIds",
        `Unbekannte FindingTemplateId: "${templateId}"`
      );
    }
    if (seenFindingIds.has(templateId)) {
      err(
        "expected.findingTemplateIds",
        `Doppelte FindingTemplateId: "${templateId}"`
      );
    }
    seenFindingIds.add(templateId);
  }

  // ── TopFindings: Anzahl, Gültigkeit, Eindeutigkeit, Teilmenge ──────────────
  const topIds = goldenCase.expected.topFindingTemplateIds;
  if (topIds.length > MAX_TOP_FINDINGS) {
    err(
      "expected.topFindingTemplateIds",
      `Mehr als ${MAX_TOP_FINDINGS} TopFindings: ${topIds.length}`
    );
  }

  const seenTopIds = new Set<string>();
  for (const templateId of topIds) {
    if (FINDING_TEMPLATE_BY_ID[templateId] === undefined) {
      err(
        "expected.topFindingTemplateIds",
        `Unbekannte FindingTemplateId in TopFindings: "${templateId}"`
      );
    }
    if (seenTopIds.has(templateId)) {
      err(
        "expected.topFindingTemplateIds",
        `Doppelte FindingTemplateId in TopFindings: "${templateId}"`
      );
    }
    seenTopIds.add(templateId);

    if (!seenFindingIds.has(templateId)) {
      err(
        "expected.topFindingTemplateIds",
        `TopFinding "${templateId}" ist nicht in findingTemplateIds enthalten`
      );
    }
  }

  return errors;
}

// ─── Ganzes Set ──────────────────────────────────────────────────────────────

/**
 * Validiert ein komplettes Golden Set.
 *
 * Zusätzlich zur Einzelvalidierung wird geprüft:
 *   - alle Case-IDs sind eindeutig
 */
export function validateGoldenSet(
  cases: ReadonlyArray<GoldenCase>
): GoldenValidationResult {
  const errors: GoldenValidationError[] = [];

  // Eindeutige IDs über das gesamte Set
  const seenIds = new Set<string>();
  for (const c of cases) {
    if (seenIds.has(c.id)) {
      errors.push({
        caseId: c.id,
        field: "id",
        message: `Doppelte Golden-Case-ID: "${c.id}"`,
      });
    }
    seenIds.add(c.id);
  }

  // Einzelvalidierung
  for (const c of cases) {
    errors.push(...validateGoldenCase(c));
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}
