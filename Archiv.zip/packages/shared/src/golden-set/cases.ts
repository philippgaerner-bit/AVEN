/**
 * Die fixierten Golden Cases des Creator-Score-Modells.
 *
 * ═══════════════════════════════════════════════════════════════════════
 *  WARNUNG — DIESE WERTE DÜRFEN NICHT AUTOMATISCH ÜBERSCHRIEBEN WERDEN
 * ═══════════════════════════════════════════════════════════════════════
 *
 * Die `expected`-Werte wurden EINMAL mit der Engine berechnet und dann
 * dauerhaft fixiert. Wenn ein Golden Test fehlschlägt, bedeutet das:
 * Das Verhalten der Engine hat sich geändert.
 *
 * Dann gilt:
 *   1. Prüfen, ob die Änderung beabsichtigt war
 *   2. Falls ja: SCORING_MODEL_VERSION erhöhen, Werte bewusst neu fixieren,
 *      GOLDEN_SET_VERSION erhöhen
 *   3. Falls nein: den Fehler in der Engine beheben
 *
 * NIEMALS die expected-Werte anpassen, nur damit der Test wieder grün wird.
 *
 * ── DATENSCHUTZ ────────────────────────────────────────────────────────
 * Alle Fälle sind vollständig synthetisch. Sie enthalten keine echten
 * Usernames, Bios, Profilbilder oder Screenshots. Das ObservationPackage
 * besteht ausschließlich aus diskreten Kriteriumszuständen.
 * Siehe docs/golden-set.md.
 */

import type { GoldenCase } from "./types.js";
import { GOLDEN_SET_VERSION } from "./types.js";
import { SCORING_MODEL_VERSION } from "../scoring/types.js";
import type { ObservationPackage, CriterionState } from "../scoring/types.js";
import { ALL_CRITERION_IDS } from "../scoring/criterion-ids.js";

/**
 * Baut ein ObservationPackage: alle Kriterien `fulfilled`,
 * überschrieben durch die angegebenen Abweichungen.
 */
function buildInput(
  overrides: Partial<Record<string, CriterionState>>
): ObservationPackage {
  return {
    observations: ALL_CRITERION_IDS.map((id) => ({
      id,
      state: (overrides[id] ?? "fulfilled") as CriterionState,
      source: "A" as const,
    })),
    modelVersions: {
      ocr: "golden-v1",
      vision: "golden-v1",
      language: "golden-v1",
    },
    pipelineVersion: "v1.0.0",
    scoringModelVersion: SCORING_MODEL_VERSION,
  };
}

// ─── Die 10 Referenzfälle ────────────────────────────────────────────────────

export const GOLDEN_CASES: ReadonlyArray<GoldenCase> = [
  // Perfektes Profil — alle 31 Kriterien erfüllt
  {
    id: "gc-001-perfect",
    description: "Perfektes Profil — alle 31 Kriterien erfüllt",
    platform: "instagram",
    input: buildInput({
      // keine Abweichungen — alle fulfilled
    }),
    expected: {
      totalScore: 100,
      displayable: true,
      coverageRatio: 1,
      categoryScores: {
        bio: { rawPoints: 18, checkedMaxPoints: 18, normalizedPoints: 18, fullMaxPoints: 18 },
        content: { rawPoints: 20, checkedMaxPoints: 20, normalizedPoints: 20, fullMaxPoints: 20 },
        feed: { rawPoints: 16, checkedMaxPoints: 16, normalizedPoints: 16, fullMaxPoints: 16 },
        brand: { rawPoints: 14, checkedMaxPoints: 14, normalizedPoints: 14, fullMaxPoints: 14 },
        profilePic: { rawPoints: 10, checkedMaxPoints: 10, normalizedPoints: 10, fullMaxPoints: 10 },
        username: { rawPoints: 10, checkedMaxPoints: 10, normalizedPoints: 10, fullMaxPoints: 10 },
        engagement: { rawPoints: 12, checkedMaxPoints: 12, normalizedPoints: 12, fullMaxPoints: 12 },
      },
      findingTemplateIds: [],
      topFindingTemplateIds: [],
    },
    metadata: {
      goldenSetVersion: GOLDEN_SET_VERSION,
      scoringModelVersion: SCORING_MODEL_VERSION,
      fixtureId: "synth-perfect-01",
      sourceType: "synthetic",
      notes: "Obergrenze des Modells. Score muss 100 sein, 0 Findings.",
    },
  },

  // Komplett schwaches Profil — alle Kriterien missing
  {
    id: "gc-002-weak-all",
    description: "Komplett schwaches Profil — alle Kriterien missing",
    platform: "tiktok",
    input: buildInput({
      bio_target_audience: "missing",
      bio_outcome: "missing",
      bio_cta: "missing",
      bio_first_line: "missing",
      bio_no_filler: "missing",
      content_hook: "missing",
      content_cover: "missing",
      content_recurring: "missing",
      content_length: "missing",
      content_text_position: "missing",
      content_regularity: "missing",
      feed_color_world: "missing",
      feed_cover_pattern: "missing",
      feed_topic: "missing",
      feed_pinned: "missing",
      brand_colors: "missing",
      brand_font: "missing",
      brand_theme: "missing",
      brand_recognizable: "missing",
      profile_pic_recognition: "missing",
      profile_pic_subject: "missing",
      profile_pic_contrast: "missing",
      profile_pic_color_fit: "missing",
      username_pronounceable: "missing",
      username_clean: "missing",
      name_field_topic: "missing",
      username_name_match: "missing",
      engagement_captions: "missing",
      engagement_replies: "missing",
      engagement_opinion: "missing",
      engagement_cta_end: "missing",
    }),
    expected: {
      totalScore: 0,
      displayable: true,
      coverageRatio: 1,
      categoryScores: {
        bio: { rawPoints: 0, checkedMaxPoints: 18, normalizedPoints: 0, fullMaxPoints: 18 },
        content: { rawPoints: 0, checkedMaxPoints: 20, normalizedPoints: 0, fullMaxPoints: 20 },
        feed: { rawPoints: 0, checkedMaxPoints: 16, normalizedPoints: 0, fullMaxPoints: 16 },
        brand: { rawPoints: 0, checkedMaxPoints: 14, normalizedPoints: 0, fullMaxPoints: 14 },
        profilePic: { rawPoints: 0, checkedMaxPoints: 10, normalizedPoints: 0, fullMaxPoints: 10 },
        username: { rawPoints: 0, checkedMaxPoints: 10, normalizedPoints: 0, fullMaxPoints: 10 },
        engagement: { rawPoints: 0, checkedMaxPoints: 12, normalizedPoints: 0, fullMaxPoints: 12 },
      },
      findingTemplateIds: ["bio_positioning_unclear", "content_hook_weak", "feed_topic_unclear", "engagement_structure_weak", "identity_unclear", "profile_picture_weak", "content_structure_inconsistent", "covers_unclear", "bio_first_line_weak", "bio_cta_missing", "branding_inconsistent", "feed_inconsistent"],
      topFindingTemplateIds: ["bio_positioning_unclear", "content_hook_weak", "feed_topic_unclear"],
    },
    metadata: {
      goldenSetVersion: GOLDEN_SET_VERSION,
      scoringModelVersion: SCORING_MODEL_VERSION,
      fixtureId: "synth-weak-01",
      sourceType: "synthetic",
      notes: "Untergrenze. Score 0, alle 12 Findings aktiv, Coverage 100 %.",
    },
  },

  // Starke Bio, schwacher Content
  {
    id: "gc-003-strong-bio-weak-content",
    description: "Starke Bio, schwacher Content",
    platform: "instagram",
    input: buildInput({
      content_hook: "missing",
      content_cover: "missing",
      content_recurring: "missing",
      content_length: "missing",
      content_text_position: "missing",
      content_regularity: "missing",
    }),
    expected: {
      totalScore: 80,
      displayable: true,
      coverageRatio: 1,
      categoryScores: {
        bio: { rawPoints: 18, checkedMaxPoints: 18, normalizedPoints: 18, fullMaxPoints: 18 },
        content: { rawPoints: 0, checkedMaxPoints: 20, normalizedPoints: 0, fullMaxPoints: 20 },
        feed: { rawPoints: 16, checkedMaxPoints: 16, normalizedPoints: 16, fullMaxPoints: 16 },
        brand: { rawPoints: 14, checkedMaxPoints: 14, normalizedPoints: 14, fullMaxPoints: 14 },
        profilePic: { rawPoints: 10, checkedMaxPoints: 10, normalizedPoints: 10, fullMaxPoints: 10 },
        username: { rawPoints: 10, checkedMaxPoints: 10, normalizedPoints: 10, fullMaxPoints: 10 },
        engagement: { rawPoints: 12, checkedMaxPoints: 12, normalizedPoints: 12, fullMaxPoints: 12 },
      },
      findingTemplateIds: ["content_hook_weak", "content_structure_inconsistent", "covers_unclear"],
      topFindingTemplateIds: ["content_hook_weak", "content_structure_inconsistent", "covers_unclear"],
    },
    metadata: {
      goldenSetVersion: GOLDEN_SET_VERSION,
      scoringModelVersion: SCORING_MODEL_VERSION,
      fixtureId: "synth-bio-strong-01",
      sourceType: "synthetic_modeled",
      notes: "Bio vollständig, Content komplett missing. Prüft Kategorietrennung.",
    },
  },

  // Schwache Bio, starker Content
  {
    id: "gc-004-weak-bio-strong-content",
    description: "Schwache Bio, starker Content",
    platform: "tiktok",
    input: buildInput({
      bio_target_audience: "missing",
      bio_outcome: "missing",
      bio_cta: "missing",
      bio_first_line: "missing",
      bio_no_filler: "missing",
    }),
    expected: {
      totalScore: 82,
      displayable: true,
      coverageRatio: 1,
      categoryScores: {
        bio: { rawPoints: 0, checkedMaxPoints: 18, normalizedPoints: 0, fullMaxPoints: 18 },
        content: { rawPoints: 20, checkedMaxPoints: 20, normalizedPoints: 20, fullMaxPoints: 20 },
        feed: { rawPoints: 16, checkedMaxPoints: 16, normalizedPoints: 16, fullMaxPoints: 16 },
        brand: { rawPoints: 14, checkedMaxPoints: 14, normalizedPoints: 14, fullMaxPoints: 14 },
        profilePic: { rawPoints: 10, checkedMaxPoints: 10, normalizedPoints: 10, fullMaxPoints: 10 },
        username: { rawPoints: 10, checkedMaxPoints: 10, normalizedPoints: 10, fullMaxPoints: 10 },
        engagement: { rawPoints: 12, checkedMaxPoints: 12, normalizedPoints: 12, fullMaxPoints: 12 },
      },
      findingTemplateIds: ["bio_positioning_unclear", "bio_first_line_weak", "bio_cta_missing"],
      topFindingTemplateIds: ["bio_positioning_unclear", "bio_first_line_weak", "bio_cta_missing"],
    },
    metadata: {
      goldenSetVersion: GOLDEN_SET_VERSION,
      scoringModelVersion: SCORING_MODEL_VERSION,
      fixtureId: "synth-content-strong-01",
      sourceType: "synthetic_modeled",
      notes: "Umkehrung von gc-003. Bio missing, Rest erfüllt.",
    },
  },

  // Schwaches Branding — alle brand_*-Kriterien missing
  {
    id: "gc-005-weak-branding",
    description: "Schwaches Branding — alle brand_*-Kriterien missing",
    platform: "instagram",
    input: buildInput({
      brand_colors: "missing",
      brand_font: "missing",
      brand_theme: "missing",
      brand_recognizable: "missing",
    }),
    expected: {
      totalScore: 86,
      displayable: true,
      coverageRatio: 1,
      categoryScores: {
        bio: { rawPoints: 18, checkedMaxPoints: 18, normalizedPoints: 18, fullMaxPoints: 18 },
        content: { rawPoints: 20, checkedMaxPoints: 20, normalizedPoints: 20, fullMaxPoints: 20 },
        feed: { rawPoints: 16, checkedMaxPoints: 16, normalizedPoints: 16, fullMaxPoints: 16 },
        brand: { rawPoints: 0, checkedMaxPoints: 14, normalizedPoints: 0, fullMaxPoints: 14 },
        profilePic: { rawPoints: 10, checkedMaxPoints: 10, normalizedPoints: 10, fullMaxPoints: 10 },
        username: { rawPoints: 10, checkedMaxPoints: 10, normalizedPoints: 10, fullMaxPoints: 10 },
        engagement: { rawPoints: 12, checkedMaxPoints: 12, normalizedPoints: 12, fullMaxPoints: 12 },
      },
      findingTemplateIds: ["branding_inconsistent"],
      topFindingTemplateIds: ["branding_inconsistent"],
    },
    metadata: {
      goldenSetVersion: GOLDEN_SET_VERSION,
      scoringModelVersion: SCORING_MODEL_VERSION,
      fixtureId: "synth-brand-weak-01",
      sourceType: "synthetic",
      notes: "Isoliert die polish-Severity von branding_inconsistent.",
    },
  },

  // Schwaches Profilbild — alle profile_pic_*-Kriterien missing
  {
    id: "gc-006-weak-profile-pic",
    description: "Schwaches Profilbild — alle profile_pic_*-Kriterien missing",
    platform: "tiktok",
    input: buildInput({
      profile_pic_recognition: "missing",
      profile_pic_subject: "missing",
      profile_pic_contrast: "missing",
      profile_pic_color_fit: "missing",
    }),
    expected: {
      totalScore: 90,
      displayable: true,
      coverageRatio: 1,
      categoryScores: {
        bio: { rawPoints: 18, checkedMaxPoints: 18, normalizedPoints: 18, fullMaxPoints: 18 },
        content: { rawPoints: 20, checkedMaxPoints: 20, normalizedPoints: 20, fullMaxPoints: 20 },
        feed: { rawPoints: 16, checkedMaxPoints: 16, normalizedPoints: 16, fullMaxPoints: 16 },
        brand: { rawPoints: 14, checkedMaxPoints: 14, normalizedPoints: 14, fullMaxPoints: 14 },
        profilePic: { rawPoints: 0, checkedMaxPoints: 10, normalizedPoints: 0, fullMaxPoints: 10 },
        username: { rawPoints: 10, checkedMaxPoints: 10, normalizedPoints: 10, fullMaxPoints: 10 },
        engagement: { rawPoints: 12, checkedMaxPoints: 12, normalizedPoints: 12, fullMaxPoints: 12 },
      },
      findingTemplateIds: ["profile_picture_weak"],
      topFindingTemplateIds: ["profile_picture_weak"],
    },
    metadata: {
      goldenSetVersion: GOLDEN_SET_VERSION,
      scoringModelVersion: SCORING_MODEL_VERSION,
      fixtureId: "synth-pic-weak-01",
      sourceType: "synthetic",
      notes: "Isoliert profile_picture_weak (lever, 10 Punkte).",
    },
  },

  // Schwaches Engagement — alle engagement_*-Kriterien missing
  {
    id: "gc-007-weak-engagement",
    description: "Schwaches Engagement — alle engagement_*-Kriterien missing",
    platform: "instagram",
    input: buildInput({
      engagement_captions: "missing",
      engagement_replies: "missing",
      engagement_opinion: "missing",
      engagement_cta_end: "missing",
    }),
    expected: {
      totalScore: 88,
      displayable: true,
      coverageRatio: 1,
      categoryScores: {
        bio: { rawPoints: 18, checkedMaxPoints: 18, normalizedPoints: 18, fullMaxPoints: 18 },
        content: { rawPoints: 20, checkedMaxPoints: 20, normalizedPoints: 20, fullMaxPoints: 20 },
        feed: { rawPoints: 16, checkedMaxPoints: 16, normalizedPoints: 16, fullMaxPoints: 16 },
        brand: { rawPoints: 14, checkedMaxPoints: 14, normalizedPoints: 14, fullMaxPoints: 14 },
        profilePic: { rawPoints: 10, checkedMaxPoints: 10, normalizedPoints: 10, fullMaxPoints: 10 },
        username: { rawPoints: 10, checkedMaxPoints: 10, normalizedPoints: 10, fullMaxPoints: 10 },
        engagement: { rawPoints: 0, checkedMaxPoints: 12, normalizedPoints: 0, fullMaxPoints: 12 },
      },
      findingTemplateIds: ["engagement_structure_weak"],
      topFindingTemplateIds: ["engagement_structure_weak"],
    },
    metadata: {
      goldenSetVersion: GOLDEN_SET_VERSION,
      scoringModelVersion: SCORING_MODEL_VERSION,
      fixtureId: "synth-eng-weak-01",
      sourceType: "synthetic",
      notes: "Isoliert engagement_structure_weak (lever, 12 Punkte).",
    },
  },

  // Coverage exakt 60 % — Grenzfall displayable = true
  {
    id: "gc-008-coverage-just-above-60",
    description: "Coverage exakt 60 % — Grenzfall displayable = true",
    platform: "tiktok",
    input: buildInput({
      bio_target_audience: "unavailable",
      bio_outcome: "unavailable",
      bio_cta: "unavailable",
      bio_first_line: "unavailable",
      bio_no_filler: "unavailable",
      feed_color_world: "unavailable",
      feed_cover_pattern: "unavailable",
      feed_topic: "unavailable",
      feed_pinned: "unavailable",
      brand_colors: "unavailable",
      profile_pic_color_fit: "unavailable",
      username_name_match: "unavailable",
    }),
    expected: {
      totalScore: 100,
      displayable: true,
      coverageRatio: 0.6,
      categoryScores: {
        bio: { rawPoints: 0, checkedMaxPoints: 0, normalizedPoints: 0, fullMaxPoints: 18 },
        content: { rawPoints: 20, checkedMaxPoints: 20, normalizedPoints: 20, fullMaxPoints: 20 },
        feed: { rawPoints: 0, checkedMaxPoints: 0, normalizedPoints: 0, fullMaxPoints: 16 },
        brand: { rawPoints: 10, checkedMaxPoints: 10, normalizedPoints: 14, fullMaxPoints: 14 },
        profilePic: { rawPoints: 9, checkedMaxPoints: 9, normalizedPoints: 10, fullMaxPoints: 10 },
        username: { rawPoints: 9, checkedMaxPoints: 9, normalizedPoints: 10, fullMaxPoints: 10 },
        engagement: { rawPoints: 12, checkedMaxPoints: 12, normalizedPoints: 12, fullMaxPoints: 12 },
      },
      findingTemplateIds: [],
      topFindingTemplateIds: [],
    },
    metadata: {
      goldenSetVersion: GOLDEN_SET_VERSION,
      scoringModelVersion: SCORING_MODEL_VERSION,
      fixtureId: "synth-cov60-01",
      sourceType: "synthetic",
      notes: "40 Punkte unavailable: Bio (18) + Feed (16) + brand_colors (4) + username_name_match (1) + profile_pic_color_fit (1). Prüft die Anzeigeschwelle von unten.",
    },
  },

  // Coverage 59 % — displayable = false
  {
    id: "gc-009-coverage-below-60",
    description: "Coverage 59 % — displayable = false",
    platform: "instagram",
    input: buildInput({
      bio_target_audience: "unavailable",
      bio_outcome: "unavailable",
      bio_cta: "unavailable",
      bio_first_line: "unavailable",
      bio_no_filler: "unavailable",
      feed_color_world: "unavailable",
      feed_cover_pattern: "unavailable",
      feed_topic: "unavailable",
      feed_pinned: "unavailable",
      brand_colors: "unavailable",
      brand_font: "unavailable",
    }),
    expected: {
      totalScore: 100,
      displayable: false,
      coverageRatio: 0.59,
      categoryScores: {
        bio: { rawPoints: 0, checkedMaxPoints: 0, normalizedPoints: 0, fullMaxPoints: 18 },
        content: { rawPoints: 20, checkedMaxPoints: 20, normalizedPoints: 20, fullMaxPoints: 20 },
        feed: { rawPoints: 0, checkedMaxPoints: 0, normalizedPoints: 0, fullMaxPoints: 16 },
        brand: { rawPoints: 7, checkedMaxPoints: 7, normalizedPoints: 14, fullMaxPoints: 14 },
        profilePic: { rawPoints: 10, checkedMaxPoints: 10, normalizedPoints: 10, fullMaxPoints: 10 },
        username: { rawPoints: 10, checkedMaxPoints: 10, normalizedPoints: 10, fullMaxPoints: 10 },
        engagement: { rawPoints: 12, checkedMaxPoints: 12, normalizedPoints: 12, fullMaxPoints: 12 },
      },
      findingTemplateIds: [],
      topFindingTemplateIds: [],
    },
    metadata: {
      goldenSetVersion: GOLDEN_SET_VERSION,
      scoringModelVersion: SCORING_MODEL_VERSION,
      fixtureId: "synth-cov59-01",
      sourceType: "synthetic",
      notes: "41 Punkte unavailable: Bio (18) + Feed (16) + brand_colors (4) + brand_font (3). Score wird nicht angezeigt.",
    },
  },

  // Mischung aus Foundation, Lever und Polish
  {
    id: "gc-010-mixed-severities",
    description: "Mischung aus Foundation, Lever und Polish",
    platform: "tiktok",
    input: buildInput({
      bio_target_audience: "missing",
      bio_outcome: "missing",
      bio_cta: "missing",
      content_hook: "partial",
      feed_color_world: "missing",
      feed_cover_pattern: "partial",
      engagement_captions: "partial",
    }),
    expected: {
      totalScore: 76,
      displayable: true,
      coverageRatio: 1,
      categoryScores: {
        bio: { rawPoints: 5, checkedMaxPoints: 18, normalizedPoints: 5, fullMaxPoints: 18 },
        content: { rawPoints: 18, checkedMaxPoints: 20, normalizedPoints: 18, fullMaxPoints: 20 },
        feed: { rawPoints: 9, checkedMaxPoints: 16, normalizedPoints: 9, fullMaxPoints: 16 },
        brand: { rawPoints: 14, checkedMaxPoints: 14, normalizedPoints: 14, fullMaxPoints: 14 },
        profilePic: { rawPoints: 10, checkedMaxPoints: 10, normalizedPoints: 10, fullMaxPoints: 10 },
        username: { rawPoints: 10, checkedMaxPoints: 10, normalizedPoints: 10, fullMaxPoints: 10 },
        engagement: { rawPoints: 10, checkedMaxPoints: 12, normalizedPoints: 10, fullMaxPoints: 12 },
      },
      findingTemplateIds: ["bio_positioning_unclear", "content_hook_weak", "bio_cta_missing", "engagement_structure_weak", "feed_inconsistent"],
      topFindingTemplateIds: ["bio_positioning_unclear", "content_hook_weak", "bio_cta_missing"],
    },
    metadata: {
      goldenSetVersion: GOLDEN_SET_VERSION,
      scoringModelVersion: SCORING_MODEL_VERSION,
      fixtureId: "synth-mixed-01",
      sourceType: "synthetic_modeled",
      notes: "foundation: bio_positioning_unclear + content_hook_weak. lever: bio_cta_missing. polish: feed_inconsistent (blockiert). Prüft die Blockierregel und die Top-3-Auswahl.",
    },
  },
];
