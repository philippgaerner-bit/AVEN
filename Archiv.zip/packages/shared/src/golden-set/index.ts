/**
 * Öffentliches Interface des Golden-Set-Systems.
 *
 * Zweck: automatische Regressionsprüfung des Bewertungskerns
 * gegen fixierte Referenzfälle.
 */

// Typen und Konstanten
export {
  GOLDEN_SET_VERSION,
  GOLDEN_PLATFORMS,
  GOLDEN_SOURCE_TYPES,
  MAX_TOP_FINDINGS,
} from "./types.js";

export type {
  GoldenSetVersion,
  GoldenPlatform,
  GoldenSourceType,
  GoldenCase,
  GoldenExpected,
  GoldenMetadata,
  ExpectedCategoryScore,
  ExpectedCategoryScores,
  GoldenMismatch,
  GoldenRunResult,
  GoldenValidationError,
  GoldenValidationResult,
} from "./types.js";

// Validierung
export { validateGoldenCase, validateGoldenSet } from "./validate.js";

// Runner
export { runGoldenCase, runGoldenSet, formatMismatches } from "./runner.js";

// Die fixierten Fälle
export { GOLDEN_CASES } from "./cases.js";
