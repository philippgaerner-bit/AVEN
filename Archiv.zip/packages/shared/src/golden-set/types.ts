/**
 * Typdefinitionen des Golden-Set-Systems.
 *
 * Zweck: Jede zukünftige Änderung am Bewertungskern wird automatisch
 * gegen bekannte Referenzfälle geprüft. Ändert sich ein Ergebnis,
 * schlägt der Test fehl — auch wenn die Änderung beabsichtigt war.
 *
 * Architekturregeln:
 * - Keine Imports aus Datenbank, Netzwerk, KI-SDKs oder Cloud-Diensten.
 * - Reine Datenstrukturen, deterministisch, serialisierbar.
 * - Enthält AUSSCHLIESSLICH synthetische Daten (siehe docs/golden-set.md).
 */

import type {
  ObservationPackage,
  ScoringModelVersion,
} from "../scoring/types.js";

// ─── Versionierung ───────────────────────────────────────────────────────────

/**
 * Version des Golden Sets selbst.
 *
 * Wird erhöht bei:
 *   - Hinzufügen oder Entfernen von Golden Cases
 *   - Bewusster Aktualisierung von expected-Werten
 *
 * Unabhängig von SCORING_MODEL_VERSION: Ein Golden Set kann wachsen,
 * ohne dass sich das Score-Modell ändert.
 */
export const GOLDEN_SET_VERSION = "v1.0.0" as const;
export type GoldenSetVersion = typeof GOLDEN_SET_VERSION;

// ─── Plattform ───────────────────────────────────────────────────────────────

export const GOLDEN_PLATFORMS = ["tiktok", "instagram"] as const;
export type GoldenPlatform = (typeof GOLDEN_PLATFORMS)[number];

// ─── Herkunftstyp ────────────────────────────────────────────────────────────

/**
 * Woher stammt der Fall?
 *
 * synthetic          — vollständig konstruiert, keine reale Vorlage
 * synthetic_modeled  — nachempfunden einem realen Profilmuster, aber ohne
 *                      echte Daten (keine Namen, Bios, Bilder)
 *
 * Es gibt bewusst KEINEN Typ für echte Profildaten.
 * Echte Screenshots liegen niemals im Repository.
 */
export const GOLDEN_SOURCE_TYPES = ["synthetic", "synthetic_modeled"] as const;
export type GoldenSourceType = (typeof GOLDEN_SOURCE_TYPES)[number];

// ─── Erwartete Kategoriewerte ────────────────────────────────────────────────

/**
 * Erwartete Werte einer Kategorie.
 * Spiegelt CategoryScore aus dem Bewertungskern.
 */
export interface ExpectedCategoryScore {
  readonly rawPoints: number;
  readonly checkedMaxPoints: number;
  readonly normalizedPoints: number;
  readonly fullMaxPoints: number;
}

/** Alle sieben Kategorien mit ihren erwarteten Werten */
export interface ExpectedCategoryScores {
  readonly bio: ExpectedCategoryScore;
  readonly content: ExpectedCategoryScore;
  readonly feed: ExpectedCategoryScore;
  readonly brand: ExpectedCategoryScore;
  readonly profilePic: ExpectedCategoryScore;
  readonly username: ExpectedCategoryScore;
  readonly engagement: ExpectedCategoryScore;
}

// ─── Erwartetes Ergebnis ─────────────────────────────────────────────────────

/**
 * Das vollständige erwartete Ergebnis eines Golden Case.
 *
 * Diese Werte werden EINMAL mit der Engine berechnet und dann
 * dauerhaft fixiert. Sie dürfen nicht automatisch überschrieben werden.
 */
export interface GoldenExpected {
  /** Normalisierter Gesamtscore 0–100 */
  readonly totalScore: number;
  /** Ob der Score angezeigt werden darf (coverage >= 0.60) */
  readonly displayable: boolean;
  /** Abdeckungsgrad 0.0–1.0 */
  readonly coverageRatio: number;
  /** Erwartete Werte aller sieben Kategorien */
  readonly categoryScores: ExpectedCategoryScores;
  /**
   * Alle erzeugten Finding-Template-IDs, in exakter Sortierreihenfolge.
   * Reihenfolge ist Teil der Erwartung — sie muss deterministisch sein.
   */
  readonly findingTemplateIds: ReadonlyArray<string>;
  /**
   * Die per selectTopFindings(findings, 3) ausgewählten Template-IDs.
   * Maximal 3 Einträge.
   */
  readonly topFindingTemplateIds: ReadonlyArray<string>;
}

// ─── Metadaten ───────────────────────────────────────────────────────────────

export interface GoldenMetadata {
  /** Version des Golden Sets zum Zeitpunkt der Fixierung */
  readonly goldenSetVersion: GoldenSetVersion;
  /** Version des Score-Modells, gegen das fixiert wurde */
  readonly scoringModelVersion: ScoringModelVersion;
  /**
   * Stabile Kennung des zugrundeliegenden Fixture-Musters.
   * Rein synthetisch — verweist niemals auf ein reales Profil.
   */
  readonly fixtureId: string;
  readonly sourceType: GoldenSourceType;
  /** Freitext für Kontext, z. B. was der Fall abdecken soll */
  readonly notes?: string;
}

// ─── Golden Case ─────────────────────────────────────────────────────────────

/**
 * Ein vollständiger Referenzfall.
 *
 * DATENSCHUTZ: Enthält ausschließlich synthetische Daten.
 * Keine echten Usernames, Bios, Profilbilder oder Screenshots.
 * Das ObservationPackage enthält nur diskrete Kriteriumszustände —
 * keine Freitexte, keine Bilddaten.
 */
export interface GoldenCase {
  /** Eindeutige, stabile Kennung innerhalb des Golden Sets */
  readonly id: string;
  /** Was dieser Fall abdeckt — für Menschen lesbar */
  readonly description: string;
  readonly platform: GoldenPlatform;
  /** Eingabe für den Bewertungskern */
  readonly input: ObservationPackage;
  /** Fixiertes erwartetes Ergebnis */
  readonly expected: GoldenExpected;
  readonly metadata: GoldenMetadata;
}

// ─── Validierungs- und Laufergebnisse ────────────────────────────────────────

/** Eine einzelne festgestellte Abweichung */
export interface GoldenMismatch {
  /** Pfad des abweichenden Feldes, z. B. "expected.categoryScores.bio.rawPoints" */
  readonly field: string;
  readonly expected: unknown;
  readonly actual: unknown;
}

/** Ergebnis eines einzelnen Golden Runs */
export interface GoldenRunResult {
  readonly caseId: string;
  readonly passed: boolean;
  readonly mismatches: ReadonlyArray<GoldenMismatch>;
}

/** Ein Validierungsfehler in der Struktur eines Golden Case */
export interface GoldenValidationError {
  readonly caseId: string;
  readonly field: string;
  readonly message: string;
}

/** Ergebnis der Strukturvalidierung eines Golden Sets */
export interface GoldenValidationResult {
  readonly valid: boolean;
  readonly errors: ReadonlyArray<GoldenValidationError>;
}

/** Maximale Anzahl Top-Findings */
export const MAX_TOP_FINDINGS = 3 as const;
