/**
 * Golden Runner — führt einen Referenzfall durch die Engine und
 * vergleicht das Ergebnis feldweise mit den fixierten Erwartungswerten.
 *
 * Ablauf:
 *   ObservationPackage → calculateScore → buildFindings → selectTopFindings
 *   → feldweiser Vergleich mit expected
 *
 * Bei Abweichung wird exakt benannt: Feld, expected, actual.
 *
 * Reine Funktionen: keine Datenbank, kein Netzwerk, keine KI.
 */

import type {
  GoldenCase,
  GoldenRunResult,
  GoldenMismatch,
  ExpectedCategoryScore,
} from "./types.js";
import { MAX_TOP_FINDINGS } from "./types.js";
import { calculateScore } from "../scoring/calculate-score.js";
import { buildFindings, selectTopFindings } from "../scoring/build-findings.js";
import type { CategoryScore } from "../scoring/types.js";

// ─── Kategorie-Schlüssel ─────────────────────────────────────────────────────

const CATEGORY_KEYS = [
  "bio",
  "content",
  "feed",
  "brand",
  "profilePic",
  "username",
  "engagement",
] as const;

// ─── Einzelner Fall ──────────────────────────────────────────────────────────

/**
 * Führt einen Golden Case aus und vergleicht mit den Erwartungswerten.
 *
 * Gibt IMMER ein Ergebnis zurück — wirft nicht bei Abweichung.
 * Nur bei einem ungültigen ObservationPackage wirft die Engine
 * (ScoringDomainError), das ist dann ein Fehler im Golden Case selbst.
 */
export function runGoldenCase(goldenCase: GoldenCase): GoldenRunResult {
  const mismatches: GoldenMismatch[] = [];

  const compare = (field: string, expected: unknown, actual: unknown): void => {
    if (expected !== actual) {
      mismatches.push({ field, expected, actual });
    }
  };

  // ── Engine ausführen ───────────────────────────────────────────────────────
  const scoringResult = calculateScore(goldenCase.input);
  const findings = buildFindings(goldenCase.input, scoringResult);
  const topFindings = selectTopFindings(findings, MAX_TOP_FINDINGS);

  const exp = goldenCase.expected;

  // ── Gesamtscore ────────────────────────────────────────────────────────────
  compare("expected.totalScore", exp.totalScore, scoringResult.scoreSet.total);

  // ── Displayable ────────────────────────────────────────────────────────────
  compare("expected.displayable", exp.displayable, scoringResult.displayable);

  // ── Coverage ───────────────────────────────────────────────────────────────
  compare(
    "expected.coverageRatio",
    exp.coverageRatio,
    scoringResult.coverageReport.coverageRatio
  );

  // ── Kategoriewerte ─────────────────────────────────────────────────────────
  for (const key of CATEGORY_KEYS) {
    const expectedCat: ExpectedCategoryScore = exp.categoryScores[key];
    const actualCat: CategoryScore = scoringResult.scoreSet[key];

    compare(
      `expected.categoryScores.${key}.rawPoints`,
      expectedCat.rawPoints,
      actualCat.rawPoints
    );
    compare(
      `expected.categoryScores.${key}.checkedMaxPoints`,
      expectedCat.checkedMaxPoints,
      actualCat.checkedMaxPoints
    );
    compare(
      `expected.categoryScores.${key}.normalizedPoints`,
      expectedCat.normalizedPoints,
      actualCat.normalizedPoints
    );
    compare(
      `expected.categoryScores.${key}.fullMaxPoints`,
      expectedCat.fullMaxPoints,
      actualCat.fullMaxPoints
    );
  }

  // ── Findings: Anzahl und Reihenfolge ───────────────────────────────────────
  const actualFindingIds = findings.map((f) => f.templateId);

  compare(
    "expected.findingTemplateIds.length",
    exp.findingTemplateIds.length,
    actualFindingIds.length
  );

  const findingCount = Math.max(
    exp.findingTemplateIds.length,
    actualFindingIds.length
  );
  for (let i = 0; i < findingCount; i++) {
    compare(
      `expected.findingTemplateIds[${i}]`,
      exp.findingTemplateIds[i],
      actualFindingIds[i]
    );
  }

  // ── TopFindings: Anzahl und Reihenfolge ────────────────────────────────────
  const actualTopIds = topFindings.map((f) => f.templateId);

  compare(
    "expected.topFindingTemplateIds.length",
    exp.topFindingTemplateIds.length,
    actualTopIds.length
  );

  const topCount = Math.max(
    exp.topFindingTemplateIds.length,
    actualTopIds.length
  );
  for (let i = 0; i < topCount; i++) {
    compare(
      `expected.topFindingTemplateIds[${i}]`,
      exp.topFindingTemplateIds[i],
      actualTopIds[i]
    );
  }

  return {
    caseId: goldenCase.id,
    passed: mismatches.length === 0,
    mismatches,
  };
}

// ─── Ganzes Set ──────────────────────────────────────────────────────────────

/**
 * Führt alle Golden Cases aus.
 */
export function runGoldenSet(
  cases: ReadonlyArray<GoldenCase>
): ReadonlyArray<GoldenRunResult> {
  return cases.map((c) => runGoldenCase(c));
}

// ─── Fehlerformatierung ──────────────────────────────────────────────────────

/**
 * Formatiert Abweichungen für Testausgaben.
 * Nennt exakt Feld, expected und actual.
 */
export function formatMismatches(result: GoldenRunResult): string {
  if (result.passed) return `[${result.caseId}] bestanden`;

  const lines = result.mismatches.map(
    (m) =>
      `  ${m.field}\n` +
      `    expected: ${JSON.stringify(m.expected)}\n` +
      `    actual:   ${JSON.stringify(m.actual)}`
  );
  return `[${result.caseId}] ${result.mismatches.length} Abweichung(en):\n${lines.join("\n")}`;
}
