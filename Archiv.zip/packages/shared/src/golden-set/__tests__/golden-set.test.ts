/**
 * Tests des Golden-Set-Systems.
 *
 *   A  Strukturvalidierung (gültige und ungültige Fälle)
 *   B  Golden Runner (Erfolg und absichtliche Fehler)
 *   C  Alle 10 Golden Cases laufen durch
 *   D  Determinismus (100 Läufe je Fall)
 */

import { describe, it } from "node:test";
import assert from "node:assert/strict";

import {
  GOLDEN_CASES,
  GOLDEN_SET_VERSION,
  MAX_TOP_FINDINGS,
  validateGoldenCase,
  validateGoldenSet,
  runGoldenCase,
  runGoldenSet,
  formatMismatches,
} from "../index.js";

import type { GoldenCase } from "../types.js";
import { SCORING_MODEL_VERSION } from "../../scoring/types.js";
import { calculateScore } from "../../scoring/calculate-score.js";
import {
  buildFindings,
  selectTopFindings,
} from "../../scoring/build-findings.js";

// ─── Hilfsfunktion: gültigen Fall klonen und gezielt verfälschen ────────────

function firstCase(): GoldenCase {
  const c = GOLDEN_CASES[0];
  assert.ok(c !== undefined, "GOLDEN_CASES ist leer");
  return c;
}

/** Tiefe Kopie über strukturiertes Klonen (kein JSON — behält Zahlen exakt) */
function cloneCase(c: GoldenCase): GoldenCase {
  return structuredClone(c) as GoldenCase;
}

// ═══════════════════════════════════════════════════════════════════════════
//  A — Strukturvalidierung
// ═══════════════════════════════════════════════════════════════════════════

describe("A: Strukturvalidierung", () => {
  it("gültiger Golden Case → keine Fehler", () => {
    const errors = validateGoldenCase(firstCase());
    assert.equal(
      errors.length,
      0,
      `Unerwartete Fehler: ${JSON.stringify(errors, null, 2)}`
    );
  });

  it("das gesamte Golden Set ist strukturell gültig", () => {
    const result = validateGoldenSet(GOLDEN_CASES);
    assert.equal(
      result.valid,
      true,
      `Validierungsfehler:\n${result.errors
        .map((e) => `  [${e.caseId}] ${e.field}: ${e.message}`)
        .join("\n")}`
    );
  });

  it("alle Golden-Case-IDs sind eindeutig", () => {
    const ids = GOLDEN_CASES.map((c) => c.id);
    assert.equal(new Set(ids).size, ids.length, "Doppelte IDs im Golden Set");
  });

  it("ungültige Plattform → Fehler", () => {
    const broken = cloneCase(firstCase());
    (broken as { platform: string }).platform = "youtube";
    const errors = validateGoldenCase(broken);
    assert.ok(
      errors.some((e) => e.field === "platform"),
      "Ungültige Plattform wurde nicht erkannt"
    );
  });

  it("unbekannte CriterionId → Fehler", () => {
    const broken = cloneCase(firstCase());
    (broken.input.observations as Array<{ id: string }>)[0]!.id =
      "criterion_does_not_exist";
    const errors = validateGoldenCase(broken);
    assert.ok(
      errors.some((e) => e.field === "input.observations"),
      "Unbekannte CriterionId wurde nicht erkannt"
    );
  });

  it("unbekannte FindingTemplateId → Fehler", () => {
    const broken = cloneCase(firstCase());
    (broken.expected as { findingTemplateIds: string[] }).findingTemplateIds = [
      "template_does_not_exist",
    ];
    const errors = validateGoldenCase(broken);
    assert.ok(
      errors.some((e) => e.field === "expected.findingTemplateIds"),
      "Unbekannte FindingTemplateId wurde nicht erkannt"
    );
  });

  it("falsche scoringModelVersion im input → Fehler", () => {
    const broken = cloneCase(firstCase());
    (broken.input as { scoringModelVersion: string }).scoringModelVersion =
      "v0.9.0";
    const errors = validateGoldenCase(broken);
    assert.ok(
      errors.some((e) => e.field === "input.scoringModelVersion"),
      "Falsche scoringModelVersion im input wurde nicht erkannt"
    );
  });

  it("falsche scoringModelVersion in metadata → Fehler", () => {
    const broken = cloneCase(firstCase());
    (broken.metadata as { scoringModelVersion: string }).scoringModelVersion =
      "v0.9.0";
    const errors = validateGoldenCase(broken);
    assert.ok(
      errors.some((e) => e.field === "metadata.scoringModelVersion"),
      "Falsche scoringModelVersion in metadata wurde nicht erkannt"
    );
  });

  it("mehr als drei TopFindings → Fehler", () => {
    const broken = cloneCase(firstCase());
    (broken.expected as { findingTemplateIds: string[] }).findingTemplateIds = [
      "bio_cta_missing",
      "content_hook_weak",
      "covers_unclear",
      "feed_topic_unclear",
    ];
    (
      broken.expected as { topFindingTemplateIds: string[] }
    ).topFindingTemplateIds = [
      "bio_cta_missing",
      "content_hook_weak",
      "covers_unclear",
      "feed_topic_unclear",
    ];
    const errors = validateGoldenCase(broken);
    assert.ok(
      errors.some(
        (e) =>
          e.field === "expected.topFindingTemplateIds" &&
          e.message.includes(String(MAX_TOP_FINDINGS))
      ),
      "Mehr als 3 TopFindings wurden nicht erkannt"
    );
  });

  it("doppelte FindingTemplateIds → Fehler", () => {
    const broken = cloneCase(firstCase());
    (broken.expected as { findingTemplateIds: string[] }).findingTemplateIds = [
      "bio_cta_missing",
      "bio_cta_missing",
    ];
    const errors = validateGoldenCase(broken);
    assert.ok(
      errors.some(
        (e) =>
          e.field === "expected.findingTemplateIds" &&
          e.message.includes("Doppelte")
      ),
      "Doppelte FindingTemplateIds wurden nicht erkannt"
    );
  });

  it("doppelte CriterionId im input → Fehler", () => {
    const broken = cloneCase(firstCase());
    const obs = broken.input.observations as Array<{ id: string }>;
    obs[1]!.id = obs[0]!.id;
    const errors = validateGoldenCase(broken);
    assert.ok(
      errors.some(
        (e) =>
          e.field === "input.observations" && e.message.includes("Doppelte")
      ),
      "Doppelte CriterionId wurde nicht erkannt"
    );
  });

  it("Score außerhalb 0–100 → Fehler", () => {
    const broken = cloneCase(firstCase());
    (broken.expected as { totalScore: number }).totalScore = 101;
    const errors = validateGoldenCase(broken);
    assert.ok(
      errors.some((e) => e.field === "expected.totalScore"),
      "Score > 100 wurde nicht erkannt"
    );
  });

  it("negativer Score → Fehler", () => {
    const broken = cloneCase(firstCase());
    (broken.expected as { totalScore: number }).totalScore = -1;
    const errors = validateGoldenCase(broken);
    assert.ok(errors.some((e) => e.field === "expected.totalScore"));
  });

  it("Coverage außerhalb 0–1 → Fehler", () => {
    const broken = cloneCase(firstCase());
    (broken.expected as { coverageRatio: number }).coverageRatio = 1.5;
    const errors = validateGoldenCase(broken);
    assert.ok(
      errors.some((e) => e.field === "expected.coverageRatio"),
      "Coverage > 1 wurde nicht erkannt"
    );
  });

  it("TopFinding nicht in findingTemplateIds → Fehler", () => {
    const broken = cloneCase(firstCase());
    (broken.expected as { findingTemplateIds: string[] }).findingTemplateIds = [
      "bio_cta_missing",
    ];
    (
      broken.expected as { topFindingTemplateIds: string[] }
    ).topFindingTemplateIds = ["content_hook_weak"];
    const errors = validateGoldenCase(broken);
    assert.ok(
      errors.some((e) =>
        e.message.includes("nicht in findingTemplateIds enthalten")
      ),
      "TopFinding außerhalb findingTemplateIds wurde nicht erkannt"
    );
  });
});

// ═══════════════════════════════════════════════════════════════════════════
//  B — Golden Runner
// ═══════════════════════════════════════════════════════════════════════════

describe("B: Golden Runner", () => {
  it("erfolgreicher Golden Run → passed = true, keine Mismatches", () => {
    const result = runGoldenCase(firstCase());
    assert.equal(result.passed, true, formatMismatches(result));
    assert.equal(result.mismatches.length, 0);
  });

  it("absichtlich falscher Score → Mismatch mit Feld, expected, actual", () => {
    const broken = cloneCase(firstCase());
    const originalScore = broken.expected.totalScore;
    (broken.expected as { totalScore: number }).totalScore = originalScore - 7;

    const result = runGoldenCase(broken);
    assert.equal(result.passed, false, "Falscher Score wurde nicht erkannt");

    const m = result.mismatches.find((m) => m.field === "expected.totalScore");
    assert.ok(m !== undefined, "Kein Mismatch für totalScore");
    assert.equal(m.expected, originalScore - 7, "expected falsch gemeldet");
    assert.equal(m.actual, originalScore, "actual falsch gemeldet");
  });

  it("absichtlich falsches Finding → Mismatch", () => {
    // gc-002 hat 12 Findings — wir verfälschen das erste
    const withFindings = GOLDEN_CASES.find(
      (c) => c.expected.findingTemplateIds.length > 0
    );
    assert.ok(withFindings !== undefined, "Kein Case mit Findings gefunden");

    const broken = cloneCase(withFindings);
    (broken.expected as { findingTemplateIds: string[] }).findingTemplateIds[0] =
      "identity_unclear";

    const result = runGoldenCase(broken);
    assert.equal(result.passed, false, "Falsches Finding wurde nicht erkannt");
    assert.ok(
      result.mismatches.some((m) =>
        m.field.startsWith("expected.findingTemplateIds")
      ),
      "Kein Mismatch für findingTemplateIds"
    );
  });

  it("absichtlich falsche Coverage → Mismatch", () => {
    const broken = cloneCase(firstCase());
    (broken.expected as { coverageRatio: number }).coverageRatio = 0.42;
    const result = runGoldenCase(broken);
    assert.equal(result.passed, false);
    assert.ok(
      result.mismatches.some((m) => m.field === "expected.coverageRatio")
    );
  });

  it("absichtlich falsches displayable → Mismatch", () => {
    const broken = cloneCase(firstCase());
    (broken.expected as { displayable: boolean }).displayable =
      !broken.expected.displayable;
    const result = runGoldenCase(broken);
    assert.equal(result.passed, false);
    assert.ok(
      result.mismatches.some((m) => m.field === "expected.displayable")
    );
  });

  it("absichtlich falscher Kategoriewert → Mismatch mit exaktem Feldpfad", () => {
    const broken = cloneCase(firstCase());
    const original = broken.expected.categoryScores.bio.rawPoints;
    (
      broken.expected.categoryScores.bio as { rawPoints: number }
    ).rawPoints = original + 3;

    const result = runGoldenCase(broken);
    assert.equal(result.passed, false);

    const m = result.mismatches.find(
      (m) => m.field === "expected.categoryScores.bio.rawPoints"
    );
    assert.ok(m !== undefined, "Kein Mismatch für bio.rawPoints");
    assert.equal(m.expected, original + 3);
    assert.equal(m.actual, original);
  });

  it("absichtlich falsche Top-Finding-Reihenfolge → Mismatch", () => {
    const withTop = GOLDEN_CASES.find(
      (c) => c.expected.topFindingTemplateIds.length >= 2
    );
    assert.ok(withTop !== undefined, "Kein Case mit ≥2 TopFindings");

    const broken = cloneCase(withTop);
    const top = broken.expected.topFindingTemplateIds as string[];
    [top[0], top[1]] = [top[1]!, top[0]!]; // vertauschen

    const result = runGoldenCase(broken);
    assert.equal(result.passed, false, "Vertauschte Reihenfolge nicht erkannt");
  });

  it("formatMismatches nennt Feld, expected und actual", () => {
    const broken = cloneCase(firstCase());
    (broken.expected as { totalScore: number }).totalScore = 1;
    const result = runGoldenCase(broken);
    const text = formatMismatches(result);

    assert.ok(text.includes("expected.totalScore"), "Feldname fehlt");
    assert.ok(text.includes("expected:"), "expected-Label fehlt");
    assert.ok(text.includes("actual:"), "actual-Label fehlt");
  });
});

// ═══════════════════════════════════════════════════════════════════════════
//  C — Alle 10 Golden Cases
// ═══════════════════════════════════════════════════════════════════════════

describe("C: Alle Golden Cases", () => {
  it("das Golden Set enthält mindestens 10 Fälle", () => {
    assert.ok(
      GOLDEN_CASES.length >= 10,
      `Nur ${GOLDEN_CASES.length} Fälle, mindestens 10 erwartet`
    );
  });

  it("alle Golden Cases laufen erfolgreich durch", () => {
    const results = runGoldenSet(GOLDEN_CASES);
    const failed = results.filter((r) => !r.passed);
    assert.equal(
      failed.length,
      0,
      `${failed.length} Fall/Fälle fehlgeschlagen:\n${failed
        .map(formatMismatches)
        .join("\n\n")}`
    );
  });

  // Einzeltests je Fall — bei Fehlschlag ist sofort sichtbar, welcher Fall bricht
  for (const goldenCase of GOLDEN_CASES) {
    it(`${goldenCase.id} — ${goldenCase.description}`, () => {
      const result = runGoldenCase(goldenCase);
      assert.equal(result.passed, true, formatMismatches(result));
    });
  }

  it("alle Fälle tragen die aktuelle GOLDEN_SET_VERSION", () => {
    for (const c of GOLDEN_CASES) {
      assert.equal(
        c.metadata.goldenSetVersion,
        GOLDEN_SET_VERSION,
        `${c.id}: falsche goldenSetVersion`
      );
    }
  });

  it("alle Fälle tragen die aktuelle SCORING_MODEL_VERSION", () => {
    for (const c of GOLDEN_CASES) {
      assert.equal(
        c.metadata.scoringModelVersion,
        SCORING_MODEL_VERSION,
        `${c.id}: falsche scoringModelVersion in metadata`
      );
    }
  });

  it("beide Plattformen sind vertreten", () => {
    const platforms = new Set(GOLDEN_CASES.map((c) => c.platform));
    assert.ok(platforms.has("tiktok"), "Kein TikTok-Fall");
    assert.ok(platforms.has("instagram"), "Kein Instagram-Fall");
  });

  it("alle Fälle sind synthetisch (Datenschutz)", () => {
    for (const c of GOLDEN_CASES) {
      assert.ok(
        c.metadata.sourceType === "synthetic" ||
          c.metadata.sourceType === "synthetic_modeled",
        `${c.id}: sourceType "${c.metadata.sourceType}" ist nicht synthetisch`
      );
    }
  });

  it("Grenzfall Coverage ≥ 60 % ist displayable", () => {
    const c = GOLDEN_CASES.find((c) => c.id === "gc-008-coverage-just-above-60");
    assert.ok(c !== undefined, "gc-008 nicht gefunden");
    assert.equal(c.expected.coverageRatio, 0.6);
    assert.equal(c.expected.displayable, true);
  });

  it("Grenzfall Coverage < 60 % ist nicht displayable", () => {
    const c = GOLDEN_CASES.find((c) => c.id === "gc-009-coverage-below-60");
    assert.ok(c !== undefined, "gc-009 nicht gefunden");
    assert.ok(c.expected.coverageRatio < 0.6);
    assert.equal(c.expected.displayable, false);
  });

  it("perfektes Profil hat Score 100 und keine Findings", () => {
    const c = GOLDEN_CASES.find((c) => c.id === "gc-001-perfect");
    assert.ok(c !== undefined);
    assert.equal(c.expected.totalScore, 100);
    assert.equal(c.expected.findingTemplateIds.length, 0);
  });

  it("komplett schwaches Profil hat Score 0 und alle 12 Findings", () => {
    const c = GOLDEN_CASES.find((c) => c.id === "gc-002-weak-all");
    assert.ok(c !== undefined);
    assert.equal(c.expected.totalScore, 0);
    assert.equal(c.expected.findingTemplateIds.length, 12);
    assert.equal(c.expected.topFindingTemplateIds.length, 3);
  });

  it("kein Fall hat mehr als MAX_TOP_FINDINGS TopFindings", () => {
    for (const c of GOLDEN_CASES) {
      assert.ok(
        c.expected.topFindingTemplateIds.length <= MAX_TOP_FINDINGS,
        `${c.id}: ${c.expected.topFindingTemplateIds.length} TopFindings`
      );
    }
  });
});

// ═══════════════════════════════════════════════════════════════════════════
//  D — Determinismus
// ═══════════════════════════════════════════════════════════════════════════

describe("D: Determinismus (100 Läufe je Fall)", () => {
  const RUNS = 100;

  it(`jeder Golden Case liefert bei ${RUNS} Läufen identische Ergebnisse`, () => {
    for (const goldenCase of GOLDEN_CASES) {
      // Referenzlauf
      const ref = calculateScore(goldenCase.input);
      const refFindings = buildFindings(goldenCase.input, ref);
      const refTop = selectTopFindings(refFindings, MAX_TOP_FINDINGS);

      for (let i = 0; i < RUNS; i++) {
        const sr = calculateScore(goldenCase.input);
        const findings = buildFindings(goldenCase.input, sr);
        const top = selectTopFindings(findings, MAX_TOP_FINDINGS);

        // Score
        assert.equal(
          sr.scoreSet.total,
          ref.scoreSet.total,
          `${goldenCase.id} Lauf ${i}: Score abweichend`
        );

        // Coverage
        assert.equal(
          sr.coverageReport.coverageRatio,
          ref.coverageReport.coverageRatio,
          `${goldenCase.id} Lauf ${i}: Coverage abweichend`
        );

        // Displayable
        assert.equal(
          sr.displayable,
          ref.displayable,
          `${goldenCase.id} Lauf ${i}: displayable abweichend`
        );

        // Kategoriewerte
        for (const key of [
          "bio",
          "content",
          "feed",
          "brand",
          "profilePic",
          "username",
          "engagement",
        ] as const) {
          assert.deepEqual(
            sr.scoreSet[key],
            ref.scoreSet[key],
            `${goldenCase.id} Lauf ${i}: Kategorie ${key} abweichend`
          );
        }

        // Findings inkl. Reihenfolge
        assert.equal(
          findings.length,
          refFindings.length,
          `${goldenCase.id} Lauf ${i}: Finding-Anzahl abweichend`
        );
        for (let j = 0; j < findings.length; j++) {
          assert.equal(
            findings[j]!.templateId,
            refFindings[j]!.templateId,
            `${goldenCase.id} Lauf ${i}: Finding ${j} abweichend`
          );
          assert.equal(
            findings[j]!.impact,
            refFindings[j]!.impact,
            `${goldenCase.id} Lauf ${i}: Finding ${j} impact abweichend`
          );
          assert.equal(
            findings[j]!.priority,
            refFindings[j]!.priority,
            `${goldenCase.id} Lauf ${i}: Finding ${j} priority abweichend`
          );
        }

        // TopFindings inkl. Reihenfolge
        assert.equal(top.length, refTop.length);
        for (let j = 0; j < top.length; j++) {
          assert.equal(
            top[j]!.templateId,
            refTop[j]!.templateId,
            `${goldenCase.id} Lauf ${i}: TopFinding ${j} abweichend`
          );
        }
      }
    }
  });

  it(`runGoldenCase ist bei ${RUNS} Läufen stabil`, () => {
    for (const goldenCase of GOLDEN_CASES) {
      for (let i = 0; i < RUNS; i++) {
        const result = runGoldenCase(goldenCase);
        assert.equal(
          result.passed,
          true,
          `${goldenCase.id} Lauf ${i}: ${formatMismatches(result)}`
        );
      }
    }
  });
});
