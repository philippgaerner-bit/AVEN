/**
 * Einstiegspunkt — nur Start-Logik, keine Business-Logik.
 */
import { loadConfig } from "./config/index.js";
import { createApp } from "./app.js";

async function main(): Promise<void> {
  const config = loadConfig(process.env);
  const app = await createApp(config);

  const shutdown = async (signal: string): Promise<void> => {
    app.log.info(`${signal} empfangen — Server wird gestoppt...`);
    await app.close();
    process.exit(0);
  };

  process.on("SIGTERM", () => void shutdown("SIGTERM"));
  process.on("SIGINT",  () => void shutdown("SIGINT"));

  await app.listen({ port: config.port, host: "0.0.0.0" });
}

main().catch((err) => {
  console.error("[VYRO] Start fehlgeschlagen:", err);
  process.exit(1);
});
