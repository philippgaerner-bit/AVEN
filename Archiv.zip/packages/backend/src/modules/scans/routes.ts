/**
 * Scan routes.
 *
 * POST /scans  — upload screenshot, create scan, enqueue job
 * GET  /scans/:id — read own scan status
 *
 * Image bytes are accepted as raw body (content-type: image/*).
 * Identity is resolved from Authorization header.
 */

import type { FastifyInstance } from "fastify";
import type { DbContext } from "../../db/client.js";
import { AppError } from "../../errors/index.js";
import { resolveIdentityFromHeader } from "../users/routes.js";
import { ingestUpload, getScanById, SUPPORTED_CONTENT_TYPES } from "./service.js";
import { getScanResult } from "./results.js";
import type { AssetStorage } from "./storage.js";
import type { AnalysisJobQueue } from "./queue.js";
import { listCreatorProfiles } from "../profiles/service.js";

const errorSchema = {
  type: "object",
  properties: { error: { type: "object", properties: { code: { type: "string" }, message: { type: "string" } } } },
} as const;

export async function registerScanRoutes(
  app: FastifyInstance,
  ctx: DbContext,
  storage: AssetStorage,
  queue: AnalysisJobQueue,
): Promise<void> {
  /**
   * POST /scans
   *
   * Accepts raw image bytes. Content-Type must be image/jpeg, image/png, or image/webp.
   * Required headers:
   *   Content-Type: image/jpeg | image/png | image/webp
   *   Authorization: Bearer <token>
   *   Idempotency-Key: <uuid>
   *   X-Creator-Profile-Id: <uuid>
   *   X-Platform: tiktok | instagram
   */
  app.post(
    "/scans",
    {
      config: { rawBody: true },
      schema: {
        operationId: "createScan",
        summary:     "Upload profile screenshot and create scan",
        response: {
          201: {
            type: "object",
            required: ["scanId", "status"],
            properties: {
              scanId:     { type: "string", format: "uuid" },
              status:     { type: "string" },
              expiresAt:  { type: "string", format: "date-time" },
            },
          },
          400: errorSchema, 401: errorSchema, 409: errorSchema,
        },
      },
    },
    async (req, reply) => {
      const identity = await resolveIdentityFromHeader(ctx, req.headers["authorization"]);
      if (!identity) throw AppError.unauthorized("Authentication required");

      const idempotencyKey = req.headers["idempotency-key"] as string | undefined;
      if (!idempotencyKey) throw AppError.validationError("Idempotency-Key header is required");

      const profileId = req.headers["x-creator-profile-id"] as string | undefined;
      if (!profileId) throw AppError.validationError("X-Creator-Profile-Id header is required");

      const platform = req.headers["x-platform"] as string | undefined;
      if (!platform || !["tiktok","instagram"].includes(platform)) {
        throw AppError.validationError("X-Platform header must be tiktok or instagram");
      }

      // Verify caller owns the profile
      const profiles = await listCreatorProfiles(ctx, identity);
      const ownsProfile = profiles.some((p) => p.id === profileId);
      if (!ownsProfile) throw AppError.forbidden("You do not own this creator profile");

      const contentType = req.headers["content-type"]?.split(";")[0]?.trim() ?? "";
      const bytes = req.body instanceof Buffer
        ? new Uint8Array(req.body)
        : req.body instanceof Uint8Array
        ? req.body
        : new Uint8Array(0);

      const ownerKey = identity.type === "user"
        ? identity.userId
        : identity.anonymousSessionId;

      const result = await ingestUpload(ctx, storage, queue, {
        ownerKey,
        creatorProfileId: profileId,
        platform: platform as "tiktok" | "instagram",
        bytes,
        contentType,
        idempotencyKey,
      });

      return reply.status(201).send({
        scanId:    result.scanId,
        status:    result.status,
        expiresAt: result.expiresAt.toISOString(),
      });
    },
  );

  /**
   * GET /scans/:id
   * Returns scan status. Only the profile owner can read it.
   */
  app.get(
    "/scans/:id",
    {
      schema: {
        operationId: "getScan",
        summary:     "Get scan status",
        params: { type: "object", required: ["id"], properties: { id: { type: "string" } } },
        response: {
          200: {
            type: "object",
            required: ["id", "status", "platform"],
            properties: {
              id:       { type: "string" },
              status:   { type: "string" },
              platform: { type: "string" },
            },
          },
          401: errorSchema, 403: errorSchema, 404: errorSchema,
        },
      },
    },
    async (req, reply) => {
      const identity = await resolveIdentityFromHeader(ctx, req.headers["authorization"]);
      if (!identity) throw AppError.unauthorized("Authentication required");

      const { id } = req.params as { id: string };
      const scan = await getScanById(ctx, id);
      if (!scan) throw AppError.notFound("Scan");

      // Ownership check: caller must own the profile that owns the scan
      const profiles = await listCreatorProfiles(ctx, identity);
      const ownsProfile = profiles.some((p) => p.id === scan.creatorProfileId);
      if (!ownsProfile) throw AppError.forbidden("You do not own this scan");

      // For completed scans, return enriched result; otherwise return status only
      const result = await getScanResult(ctx, id);
      if (!result) throw AppError.notFound("Scan result");

      return reply.status(200).send({
        id:            result.id,
        status:        result.status,
        platform:      result.platform,
        createdAt:     result.createdAt.toISOString(),
        ...(result.completedAt ? { completedAt: result.completedAt.toISOString() } : {}),
        ...(result.failedAt    ? { failedAt:    result.failedAt.toISOString() }    : {}),
        // Safe failure info — never expose provider/internal error text
        ...(result.failureCode && result.status === "failed"
          ? { failureCode: result.failureCode }
          : {}),
        // Score data (only if completed and displayable)
        ...(result.status === "completed" ? {
          totalScore:    result.totalScore,
          displayable:   result.displayable,
          coverageRatio: result.coverageRatio,
          findings:      result.findings,
        } : {}),
      });
    },
  );
}
