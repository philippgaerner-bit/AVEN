/**
 * Provider-neutral analysis job queue.
 *
 * Production: Cloud Tasks (Phase 5.5+)
 * Development/test: InMemoryJobQueue (this file)
 */

// ─── Job payload ──────────────────────────────────────────────────────────────

export interface AnalysisJob {
  readonly scanId:           string;
  readonly creatorProfileId: string;
  readonly storageKey:       string;
  readonly platform:         "tiktok" | "instagram";
  readonly pipelineVersion:  string;
  /** Optional deduplication key — same key → at-most-once processing */
  readonly deduplicationKey?: string;
}

// ─── Interface ────────────────────────────────────────────────────────────────

export interface AnalysisJobQueue {
  /**
   * Enqueues a scan for analysis.
   * If deduplicationKey is set and an identical key is already queued,
   * the implementation may silently ignore the duplicate.
   */
  enqueueScan(job: AnalysisJob): Promise<{ jobId: string; deduplicated: boolean }>;

  /** Test/admin helper — number of queued jobs */
  queuedCount(): Promise<number>;
}

// ─── In-memory implementation ─────────────────────────────────────────────────

export class InMemoryJobQueue implements AnalysisJobQueue {
  private readonly jobs: Map<string, AnalysisJob> = new Map(); // jobId → job
  private readonly dedupKeys: Set<string> = new Set();
  private seq = 0;

  async enqueueScan(job: AnalysisJob): Promise<{ jobId: string; deduplicated: boolean }> {
    if (job.deduplicationKey) {
      if (this.dedupKeys.has(job.deduplicationKey)) {
        // Already queued — return stable jobId based on dedup key
        const existing = [...this.jobs.entries()].find(
          ([, j]) => j.deduplicationKey === job.deduplicationKey,
        );
        return { jobId: existing?.[0] ?? `dup-${job.deduplicationKey}`, deduplicated: true };
      }
      this.dedupKeys.add(job.deduplicationKey);
    }

    const jobId = `job-${++this.seq}`;
    this.jobs.set(jobId, job);
    return { jobId, deduplicated: false };
  }

  async queuedCount(): Promise<number> {
    return this.jobs.size;
  }

  /** Test helper: list all enqueued jobs */
  allJobs(): ReadonlyArray<AnalysisJob> {
    return [...this.jobs.values()];
  }

  /** Test helper: reset */
  clear(): void {
    this.jobs.clear();
    this.dedupKeys.clear();
    this.seq = 0;
  }
}
