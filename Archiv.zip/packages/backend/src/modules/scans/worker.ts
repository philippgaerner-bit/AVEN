/**
 * Analysis worker.
 *
 * Consumes a queued AnalysisJob, runs the existing deterministic pipeline,
 * persists results, and transitions the scan to completed or failed.
 *
 * Safety rules:
 *  - Completed scans are never reprocessed (idempotency)
 *  - Partial writes on failure → scan is marked failed, no corrupt state
 *  - Raw image bytes are never logged
 *  - Provider errors → scan failed with safe failure code
 *  - No fake results on pipeline failure
 */

import type { DbContext } from "../../db/client.js";
import type { AssetStorage } from "./storage.js";
import type { AnalysisJob } from "./queue.js";
import type { ImageProcessor, OCRProvider, VisionObservationProvider } from "../pipeline/providers.js";
import { runAnalysisPipeline, PIPELINE_VERSION } from "../pipeline/orchestrator.js";
import { isPipelineSuccess } from "../pipeline/types.js";
import { updateScanStatus, persistPipelineResult } from "./results.js";
import { uploadedAssets } from "../../db/drizzle-schema.js";
import { eq } from "drizzle-orm";

// ─── Worker providers ─────────────────────────────────────────────────────────

export interface WorkerProviders {
  readonly imageProcessor: ImageProcessor;
  readonly ocr:            OCRProvider;
  readonly vision:         VisionObservationProvider;
}

// ─── Worker result ────────────────────────────────────────────────────────────

export interface WorkerResult {
  readonly success:        boolean;
  readonly scanId:         string;
  readonly skipped:        boolean; // true if scan already completed
  readonly failureReason?: string;
}

// ─── Worker ───────────────────────────────────────────────────────────────────

export async function processAnalysisJob(
  job: AnalysisJob,
  ctx: DbContext,
  storage: AssetStorage,
  providers: WorkerProviders,
): Promise<WorkerResult> {
  const { scanId } = job;

  // ── Step 1: Mark processing ────────────────────────────────────────────────
  try {
    await updateScanStatus(ctx, scanId, "processing");
  } catch (e) {
    // If conflict (already processing or completed/failed), check if completed
    const msg = String(e);
    if (msg.includes("completed")) {
      return { success: true, scanId, skipped: true };
    }
    if (msg.includes("Invalid scan transition") || msg.includes("failed")) {
      // Already terminal — skip
      return { success: true, scanId, skipped: true };
    }
    return { success: false, scanId, skipped: false, failureReason: `Status transition failed: ${msg}` };
  }

  // ── Step 2: Load image bytes ───────────────────────────────────────────────
  let bytes: Uint8Array | null;
  try {
    bytes = await storage.get(job.storageKey);
  } catch (e) {
    await safeFail(ctx, scanId, `storage_read_error: ${String(e)}`);
    return { success: false, scanId, skipped: false, failureReason: "Storage read failed" };
  }

  if (!bytes) {
    await safeFail(ctx, scanId, "asset_not_found");
    return { success: false, scanId, skipped: false, failureReason: "Asset not found in storage" };
  }

  // ── Step 3: Run pipeline ───────────────────────────────────────────────────
  const imageMetadata = {
    storageKey:  job.storageKey,
    contentType: "image/jpeg" as const, // content type from job in production
    byteSize:    bytes.byteLength,
    bytes,
  };

  let pipelineResult;
  try {
    pipelineResult = await runAnalysisPipeline(
      imageMetadata,
      job.creatorProfileId,
      { imageProcessor: providers.imageProcessor, ocr: providers.ocr, vision: providers.vision },
    );
  } catch (e) {
    await safeFail(ctx, scanId, `pipeline_exception: ${String(e)}`);
    return { success: false, scanId, skipped: false, failureReason: "Pipeline threw unexpectedly" };
  }

  // ── Step 4: Handle pipeline failure ───────────────────────────────────────
  if (!isPipelineSuccess(pipelineResult)) {
    await safeFail(ctx, scanId, pipelineResult.reason);
    return {
      success:       false,
      scanId,
      skipped:       false,
      failureReason: `Pipeline failed at ${pipelineResult.failedAtStage}: ${pipelineResult.reason}`,
    };
  }

  // ── Step 5: Persist results ────────────────────────────────────────────────
  let persisted: boolean;
  try {
    persisted = await persistPipelineResult(ctx, scanId, pipelineResult);
  } catch (e) {
    await safeFail(ctx, scanId, `persistence_error`);
    return { success: false, scanId, skipped: false, failureReason: `Persistence failed: ${String(e)}` };
  }

  if (!persisted) {
    // Already completed — idempotent skip
    return { success: true, scanId, skipped: true };
  }

  // ── Step 6: Mark scan completed ────────────────────────────────────────────
  try {
    const ss = pipelineResult.scoringResult;
    await updateScanStatus(ctx, scanId, "completed", {
      scoringModelVersion: pipelineResult.cacheKey.scoringModelVersion,
      pipelineVersion:     pipelineResult.pipelineVersion,
      coverage:            String(ss.coverageReport.coverageRatio),
      displayable:         ss.displayable,
      totalScore:          ss.displayable ? ss.scoreSet.total : null,
      completedAt:         new Date(),
    });
  } catch (e) {
    await safeFail(ctx, scanId, "completion_transition_error");
    return { success: false, scanId, skipped: false, failureReason: "Could not mark scan completed" };
  }

  // ── Step 7: Cleanup temporary asset ───────────────────────────────────────
  try {
    await storage.delete(job.storageKey);
    // Mark deletedAt in DB
    await ctx.db
      .update(uploadedAssets)
      .set({ deletedAt: new Date() })
      .where(eq(uploadedAssets.scanId, scanId));
  } catch {
    // Asset cleanup failure is non-fatal — log only, scan is already complete
    // In production this would emit a metric/alarm
  }

  return { success: true, scanId, skipped: false };
}

// ─── Helper ───────────────────────────────────────────────────────────────────

async function safeFail(ctx: DbContext, scanId: string, code: string): Promise<void> {
  try {
    await updateScanStatus(ctx, scanId, "failed", {
      failureCode: code.slice(0, 200), // cap length; never log raw provider errors
      failedAt:    new Date(),
    });
  } catch {
    // If this also fails (e.g. already failed), ignore — best effort
  }
}
