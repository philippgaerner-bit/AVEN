/**
 * Provider-neutral asset storage abstraction.
 *
 * Production: GCS (Phase 5.5+)
 * Development/test: InMemoryAssetStorage (this file)
 *
 * Rules:
 *  - Only storageKey is exposed; no public permanent URLs
 *  - Raw bytes are never logged
 *  - Deletion confirms the bytes are gone (sets deletedAt in DB separately)
 */

// ─── Interface ────────────────────────────────────────────────────────────────

export interface AssetStorage {
  /** Stores bytes under storageKey. Idempotent: overwrites if key exists. */
  put(storageKey: string, bytes: Uint8Array, contentType: string): Promise<void>;

  /** Retrieves bytes. Returns null if not found or already deleted. */
  get(storageKey: string): Promise<Uint8Array | null>;

  /** Deletes bytes. Idempotent: does not throw if key is absent. */
  delete(storageKey: string): Promise<void>;

  /** Returns true if the key exists and has not been deleted. */
  exists(storageKey: string): Promise<boolean>;
}

// ─── In-memory implementation (test / development) ───────────────────────────

export class InMemoryAssetStorage implements AssetStorage {
  private readonly store = new Map<string, Uint8Array>();

  async put(storageKey: string, bytes: Uint8Array, _contentType: string): Promise<void> {
    this.store.set(storageKey, bytes);
  }

  async get(storageKey: string): Promise<Uint8Array | null> {
    return this.store.get(storageKey) ?? null;
  }

  async delete(storageKey: string): Promise<void> {
    this.store.delete(storageKey);
  }

  async exists(storageKey: string): Promise<boolean> {
    return this.store.has(storageKey);
  }

  /** Test helper: number of stored objects */
  get size(): number { return this.store.size; }

  /** Test helper: list all keys */
  keys(): string[] { return [...this.store.keys()]; }
}

// ─── Storage key generation ───────────────────────────────────────────────────

/**
 * Generates a storage key for an uploaded asset.
 * Format: uploads/<scanId>/<assetId>.<ext>
 * Never contains user-supplied filenames.
 */
export function buildStorageKey(scanId: string, assetId: string, ext: "jpg" | "png" | "webp"): string {
  return `uploads/${scanId}/${assetId}.${ext}`;
}

export function contentTypeToExt(ct: string): "jpg" | "png" | "webp" | null {
  if (ct === "image/jpeg") return "jpg";
  if (ct === "image/png")  return "png";
  if (ct === "image/webp") return "webp";
  return null;
}
