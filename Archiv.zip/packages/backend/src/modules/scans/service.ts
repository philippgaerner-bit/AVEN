/**
 * Upload service — validates images, creates scans, persists assets, enqueues jobs.
 *
 * Security rules:
 *  - Client-supplied filename is never used; storageKey is server-generated
 *  - Content type is validated strictly
 *  - Bytes are never logged
 *  - expiresAt always set (default: 24 h)
 *  - Idempotency: same idempotencyKey + ownerKey → same scan, no duplicate
 */

import { createHash } from "node:crypto";
import type { DbContext } from "../../db/client.js";
import { scans, uploadedAssets, idempotencyKeys } from "../../db/drizzle-schema.js";
import { eq, and } from "drizzle-orm";
import { AppError } from "../../errors/index.js";
import type { AssetStorage } from "./storage.js";
import { buildStorageKey, contentTypeToExt } from "./storage.js";
import type { AnalysisJobQueue } from "./queue.js";
import { PIPELINE_VERSION } from "../pipeline/orchestrator.js";
import type { ScanStatus } from "../../db/enums.js";

// ─── Constants ────────────────────────────────────────────────────────────────

export const SUPPORTED_CONTENT_TYPES = ["image/jpeg", "image/png", "image/webp"] as const;
export type SupportedContentType = (typeof SUPPORTED_CONTENT_TYPES)[number];

/** Default maximum upload size: 10 MB */
export const DEFAULT_MAX_BYTES = 10 * 1024 * 1024;

/** Asset retention: 24 hours */
export const ASSET_RETENTION_HOURS = 24;

// ─── Valid scan status transitions ────────────────────────────────────────────

const VALID_TRANSITIONS: Readonly<Record<ScanStatus, ReadonlyArray<ScanStatus>>> = {
  accepted:   ["processing", "failed"],
  processing: ["completed", "failed"],
  completed:  [], // terminal
  failed:     [], // terminal
};

export function isValidTransition(from: ScanStatus, to: ScanStatus): boolean {
  return (VALID_TRANSITIONS[from] as readonly string[]).includes(to);
}

// ─── Upload validation ────────────────────────────────────────────────────────

export interface UploadValidationResult {
  readonly valid: boolean;
  readonly contentType: SupportedContentType | null;
  readonly byteSize: number;
  readonly rejectionReason?: string;
}

export function validateUpload(
  bytes: Uint8Array,
  contentType: string,
  maxBytes = DEFAULT_MAX_BYTES,
): UploadValidationResult {
  if (bytes.length === 0) {
    return { valid: false, contentType: null, byteSize: 0, rejectionReason: "Empty file" };
  }
  if (bytes.length > maxBytes) {
    return { valid: false, contentType: null, byteSize: bytes.length,
      rejectionReason: `File too large: ${bytes.length} bytes (max ${maxBytes})` };
  }
  if (!(SUPPORTED_CONTENT_TYPES as readonly string[]).includes(contentType)) {
    return { valid: false, contentType: null, byteSize: bytes.length,
      rejectionReason: `Unsupported content type: ${contentType}. Supported: ${SUPPORTED_CONTENT_TYPES.join(", ")}` };
  }
  return { valid: true, contentType: contentType as SupportedContentType, byteSize: bytes.length };
}

// ─── Idempotency helpers ──────────────────────────────────────────────────────

function buildRequestFingerprint(
  ownerKey: string, idempotencyKey: string, platform: string,
): string {
  return createHash("sha256")
    .update(`${ownerKey}|${idempotencyKey}|POST|/scans|${platform}`)
    .digest("hex");
}

function expiresAt(hours: number): Date {
  const d = new Date();
  d.setHours(d.getHours() + hours);
  return d;
}

// ─── Upload result ────────────────────────────────────────────────────────────

export interface UploadResult {
  readonly scanId:     string;
  readonly assetId:    string;
  readonly status:     ScanStatus;
  readonly storageKey: string;
  readonly expiresAt:  Date;
  readonly jobId:      string;
  readonly idempotent: boolean;
}

// ─── Upload service ───────────────────────────────────────────────────────────

/**
 * Validates and ingests a profile screenshot.
 *
 * Flow:
 *   1. Validate content type + byte size
 *   2. Check idempotency key
 *   3. Create scan row (status: accepted)
 *   4. Generate storage key + persist bytes
 *   5. Create uploaded_asset row (with expiresAt)
 *   6. Enqueue analysis job
 *   7. Cache idempotency response
 */
export async function ingestUpload(
  ctx: DbContext,
  storage: AssetStorage,
  queue: AnalysisJobQueue,
  params: {
    ownerKey:        string;   // userId or anonymousSessionId
    creatorProfileId: string;
    platform:        "tiktok" | "instagram";
    bytes:           Uint8Array;
    contentType:     string;
    idempotencyKey:  string;
    maxBytes?:       number;
  },
): Promise<UploadResult> {
  const { ownerKey, creatorProfileId, platform, bytes, contentType, idempotencyKey } = params;

  // 1. Validate upload
  const validation = validateUpload(bytes, contentType, params.maxBytes);
  if (!validation.valid) {
    throw AppError.validationError(validation.rejectionReason ?? "Invalid upload");
  }

  const fingerprint = buildRequestFingerprint(ownerKey, idempotencyKey, platform);
  const idempotencyExpiry = expiresAt(24);

  // 2. Idempotency check
  const existing = await ctx.db
    .select()
    .from(idempotencyKeys)
    .where(and(
      eq(idempotencyKeys.ownerKey,       ownerKey),
      eq(idempotencyKeys.idempotencyKey, idempotencyKey),
    ))
    .limit(1);

  if (existing[0]) {
    const raw = existing[0].responseBodyJson;
    if (raw) {
      const cached = (typeof raw === "string" ? JSON.parse(raw) : raw) as UploadResult;
      return { ...cached, idempotent: true };
    }
  }

  // 3. Create scan
  const [scanRow] = await ctx.db
    .insert(scans)
    .values({ creatorProfileId, status: "accepted", platform })
    .returning({ id: scans.id });
  if (!scanRow) throw AppError.internal("Failed to create scan");

  const scanId  = scanRow.id;
  const assetId = crypto.randomUUID();
  const ext     = contentTypeToExt(validation.contentType!)!;
  const key     = buildStorageKey(scanId, assetId, ext);
  const assetExp = expiresAt(ASSET_RETENTION_HOURS);

  // 4. Persist bytes — bytes never logged, only storageKey is recorded
  await storage.put(key, bytes, contentType);

  // 5. Create uploaded_asset row
  await ctx.db
    .insert(uploadedAssets)
    .values({
      id:          assetId,
      scanId,
      storageKey:  key,
      contentType: validation.contentType!,
      byteSize:    validation.byteSize,
      expiresAt:   assetExp,
    });

  // 6. Enqueue job
  const { jobId } = await queue.enqueueScan({
    scanId,
    creatorProfileId,
    storageKey:       key,
    platform,
    pipelineVersion:  PIPELINE_VERSION,
    deduplicationKey: `${ownerKey}:${scanId}`,
  });

  const result: UploadResult = {
    scanId, assetId, status: "accepted", storageKey: key,
    expiresAt: assetExp, jobId, idempotent: false,
  };

  // 7. Cache idempotency result
  await ctx.db
    .insert(idempotencyKeys)
    .values({
      ownerKey,
      idempotencyKey,
      requestFingerprint: fingerprint,
      responseStatus:     201,
      responseBodyJson:   result as unknown,
      expiresAt:          idempotencyExpiry,
    })
    .onConflictDoNothing();

  return result;
}

// ─── Scan status transitions ──────────────────────────────────────────────────

export async function transitionScanStatus(
  ctx: DbContext,
  scanId: string,
  to: ScanStatus,
): Promise<void> {
  const [row] = await ctx.db
    .select({ status: scans.status })
    .from(scans)
    .where(eq(scans.id, scanId))
    .limit(1);

  if (!row) throw AppError.notFound("Scan");
  if (!isValidTransition(row.status, to)) {
    throw AppError.conflict(`Invalid scan status transition: ${row.status} → ${to}`);
  }

  const now = new Date();
  await ctx.db
    .update(scans)
    .set({
      status: to,
      ...(to === "completed" ? { completedAt: now } : {}),
      ...(to === "failed"    ? { failedAt:    now } : {}),
    })
    .where(eq(scans.id, scanId));
}

export async function getScanById(
  ctx: DbContext,
  scanId: string,
): Promise<{ id: string; status: ScanStatus; creatorProfileId: string; platform: string; createdAt: Date } | null> {
  const [row] = await ctx.db
    .select({
      id: scans.id, status: scans.status,
      creatorProfileId: scans.creatorProfileId,
      platform: scans.platform, createdAt: scans.createdAt,
    })
    .from(scans)
    .where(eq(scans.id, scanId))
    .limit(1);
  return row ?? null;
}
