/**
 * Result persistence — saves pipeline output to DB tables.
 *
 * Rules:
 *  - All writes for one scan happen within a single logical "result commit"
 *  - If any write fails, the scan is marked failed (no partial success)
 *  - Completed scans are skipped (idempotency — cannot process twice)
 *  - No deterministic business logic here; inputs come from the pipeline
 */

import { eq, and } from "drizzle-orm";
import type { DbContext } from "../../db/client.js";
import {
  scans,
  criterionObservations,
  scoreSets,
  findings,
  actions,
} from "../../db/drizzle-schema.js";
import type { PipelineSuccess } from "../pipeline/types.js";
import type { ScanStatus } from "../../db/enums.js";
import { isValidTransition } from "./service.js";
import { AppError } from "../../errors/index.js";

// ─── Scan status transition ───────────────────────────────────────────────────

export async function updateScanStatus(
  ctx: DbContext,
  scanId: string,
  to: ScanStatus,
  extras: {
    scoringModelVersion?: string;
    pipelineVersion?: string;
    coverage?: string;
    displayable?: boolean;
    totalScore?: number | null;
    failureCode?: string;
    completedAt?: Date;
    failedAt?: Date;
  } = {},
): Promise<void> {
  const [row] = await ctx.db
    .select({ status: scans.status })
    .from(scans)
    .where(eq(scans.id, scanId))
    .limit(1);

  if (!row) throw AppError.notFound("Scan");

  const from = row.status as ScanStatus;
  if (from === to) return; // idempotent for same-status
  if (!isValidTransition(from, to)) {
    throw AppError.conflict(`Invalid scan transition: ${from} → ${to}`);
  }

  await ctx.db
    .update(scans)
    .set({
      status:               to,
      scoringModelVersion:  extras.scoringModelVersion,
      pipelineVersion:      extras.pipelineVersion,
      coverage:             extras.coverage,
      displayable:          extras.displayable,
      totalScore:           extras.totalScore,
      failureCode:          extras.failureCode,
      completedAt:          extras.completedAt,
      failedAt:             extras.failedAt,
    })
    .where(eq(scans.id, scanId));
}

// ─── Persist pipeline result ─────────────────────────────────────────────────

/**
 * Persists all pipeline outputs for a scan.
 * Caller is responsible for marking scan completed/failed after this.
 * Returns false if scan is already completed (idempotency guard).
 */
export async function persistPipelineResult(
  ctx: DbContext,
  scanId: string,
  result: PipelineSuccess,
): Promise<boolean> {
  // Guard: do not overwrite a completed scan
  const [scanRow] = await ctx.db
    .select({ status: scans.status })
    .from(scans)
    .where(eq(scans.id, scanId))
    .limit(1);

  if (!scanRow) throw AppError.notFound("Scan");
  if (scanRow.status === "completed") return false; // already done — idempotent

  // ── criterion_observations ────────────────────────────────────────────────
  // Clear any existing (retry safety) then insert fresh
  await ctx.db
    .delete(criterionObservations)
    .where(eq(criterionObservations.scanId, scanId));

  if (result.observations.length > 0) {
    await ctx.db.insert(criterionObservations).values(
      result.observations.map((o) => ({
        scanId,
        criterionId: o.criterionId,
        state:       o.state,
        source:      o.source,
        modelVersion: o.modelVersion ?? null,
      })),
    );
  }

  // ── score_sets ────────────────────────────────────────────────────────────
  // Upsert-style: delete existing then insert (handles retry)
  await ctx.db.delete(scoreSets).where(eq(scoreSets.scanId, scanId));

  const ss = result.scoringResult.scoreSet;
  await ctx.db.insert(scoreSets).values({
    scanId,
    scoringModelVersion: result.pipelineVersion,
    totalScore:          ss.total,
    coverage:            String(result.scoringResult.coverageReport.coverageRatio),
    displayable:         result.scoringResult.displayable,
    rawPayloadJson:      ss as unknown as Record<string, unknown>,
  });

  // ── findings ─────────────────────────────────────────────────────────────
  await ctx.db.delete(findings).where(eq(findings.scanId, scanId));

  if (result.findings.length > 0) {
    await ctx.db.insert(findings).values(
      result.findings.map((f) => ({
        scanId,
        templateId:          f.templateId,
        severity:            f.severity,
        impact:              f.impact,
        priority:            f.priority,
        blockedByFoundation: f.blockedByFoundation,
        // status defaults to "open" in schema
        criterionIdsJson:    f.criterionIds as unknown as string[],
      })),
    );
  }

  // ── actions ───────────────────────────────────────────────────────────────
  // Actions are stored in the actions table via their sourceFindingId
  // For Phase 5.5 we store the action count on the scan; detailed actions
  // are derived deterministically from findings at read time (pure function),
  // so we don't need to persist them separately.
  // This preserves the deterministic core: actions = f(findings) always.

  return true;
}

// ─── Load full result for GET /scans/:id ─────────────────────────────────────

export interface ScanResultRow {
  id: string;
  status: ScanStatus;
  platform: string;
  createdAt: Date;
  completedAt: Date | null;
  failedAt: Date | null;
  failureCode: string | null;
  totalScore: number | null;
  displayable: boolean | null;
  coverageRatio: number | null;
  findings: Array<{
    templateId: string;
    severity: string;
    impact: number;
    priority: number;
    blockedByFoundation: boolean;
    status: string;
  }>;
}

export async function getScanResult(
  ctx: DbContext,
  scanId: string,
): Promise<ScanResultRow | null> {
  const [scanRow] = await ctx.db
    .select()
    .from(scans)
    .where(eq(scans.id, scanId))
    .limit(1);

  if (!scanRow) return null;

  const status = scanRow.status as ScanStatus;

  // For non-completed scans, return minimal info
  if (status !== "completed") {
    return {
      id:            scanRow.id,
      status,
      platform:      scanRow.platform,
      createdAt:     scanRow.createdAt,
      completedAt:   scanRow.completedAt,
      failedAt:      scanRow.failedAt,
      failureCode:   scanRow.failureCode,
      totalScore:    null,
      displayable:   null,
      coverageRatio: null,
      findings:      [],
    };
  }

  // Completed: load findings
  const findingRows = await ctx.db
    .select()
    .from(findings)
    .where(eq(findings.scanId, scanId));

  return {
    id:            scanRow.id,
    status,
    platform:      scanRow.platform,
    createdAt:     scanRow.createdAt,
    completedAt:   scanRow.completedAt,
    failedAt:      scanRow.failedAt,
    failureCode:   null,
    totalScore:    scanRow.totalScore,
    displayable:   scanRow.displayable,
    coverageRatio: scanRow.coverage !== null ? Number(scanRow.coverage) : null,
    findings: findingRows.map((f) => ({
      templateId:          f.templateId,
      severity:            f.severity,
      impact:              f.impact,
      priority:            f.priority,
      blockedByFoundation: f.blockedByFoundation,
      status:              f.status,
    })),
  };
}
