/**
 * User routes and auth-claim route.
 *
 * POST /users                  – create account (anonymous caller only in Phase 4.2)
 * GET  /users/me               – resolve own account
 * POST /auth/claim-anonymous   – merge anonymous session into authenticated user
 */

import type { FastifyInstance } from "fastify";
import type { DbContext } from "../../db/client.js";
import { AppError } from "../../errors/index.js";
import { isValidTokenShape } from "../auth/token.js";
import {
  resolveAnonSession,
  resolveUserSession,
  createUser,
} from "../auth/repository.js";
import { startUserSession } from "../auth/service.js";
import { getUserById, softDeleteUser } from "./service.js";
import { mergeAnonymousIntoUser } from "./merge.js";
import { anonIdentity, userIdentity } from "../auth/identity.js";

// ─── Schemas ─────────────────────────────────────────────────────────────────

const userSchema = {
  type: "object",
  required: ["id", "createdAt"],
  properties: {
    id:        { type: "string", format: "uuid" },
    createdAt: { type: "string", format: "date-time" },
  },
} as const;

const errorSchema = {
  type: "object",
  properties: { error: { type: "object", properties: { code: { type: "string" }, message: { type: "string" } } } },
} as const;

// ─── Route registration ───────────────────────────────────────────────────────

export async function registerUserRoutes(
  app: FastifyInstance,
  ctx: DbContext,
): Promise<void> {

  /**
   * POST /users
   * Creates a new user account and returns a user session token.
   * Phase 4.2: available to anonymous sessions (bootstraps a new registered account).
   * Phase 4.3: will also be called by Apple OAuth callback.
   */
  app.post(
    "/users",
    {
      schema: {
        operationId: "createUser",
        summary: "Create user account",
        response: {
          201: {
            type: "object",
            required: ["userId", "token", "expiresAt", "sessionId"],
            properties: {
              userId:    { type: "string", format: "uuid" },
              token:     { type: "string" },
              sessionId: { type: "string", format: "uuid" },
              expiresAt: { type: "string", format: "date-time" },
            },
          },
          401: errorSchema,
          500: errorSchema,
        },
      },
    },
    async (_req, reply) => {
      const user    = await createUser(ctx);
      const session = await startUserSession(ctx, user.id);
      return reply.status(201).send({
        userId:    user.id,
        token:     session.token,
        sessionId: session.sessionId,
        expiresAt: session.expiresAt.toISOString(),
      });
    },
  );

  /**
   * GET /users/me
   * Returns the current user. Requires a valid user session token.
   */
  app.get(
    "/users/me",
    {
      schema: {
        operationId: "getMe",
        summary: "Get current user",
        response: { 200: userSchema, 401: errorSchema, 403: errorSchema },
      },
    },
    async (req, reply) => {
      const identity = await resolveIdentityFromHeader(ctx, req.headers["authorization"]);
      if (!identity || identity.type !== "user") {
        throw AppError.unauthorized("A user session token is required");
      }
      const user = await getUserById(ctx, identity.userId);
      if (!user || user.deletedAt !== null) throw AppError.forbidden("Account not found or deactivated");
      return reply.status(200).send({
        id:        user.id,
        createdAt: user.createdAt.toISOString(),
      });
    },
  );

  /**
   * POST /auth/claim-anonymous
   * Merges an anonymous session into the authenticated user's account.
   * Body: { anonymousToken: string }
   * Requires: Authorization: Bearer <user-session-token>
   */
  app.post(
    "/auth/claim-anonymous",
    {
      schema: {
        operationId: "claimAnonymousSession",
        summary: "Merge anonymous data into user account",
        body: {
          type: "object",
          required: ["anonymousToken"],
          properties: { anonymousToken: { type: "string" } },
        },
        response: {
          200: {
            type: "object",
            required: ["profilesMigrated", "alreadyMerged"],
            properties: {
              profilesMigrated: { type: "number" },
              alreadyMerged:    { type: "boolean" },
            },
          },
          400: errorSchema, 401: errorSchema, 409: errorSchema,
        },
      },
    },
    async (req, reply) => {
      const identity = await resolveIdentityFromHeader(ctx, req.headers["authorization"]);
      if (!identity || identity.type !== "user") {
        throw AppError.unauthorized("A user session token is required");
      }

      const body = req.body as { anonymousToken?: unknown };
      const anonToken = body.anonymousToken;

      if (!isValidTokenShape(anonToken)) {
        throw AppError.validationError("anonymousToken is missing or malformed");
      }

      const anonSession = await resolveAnonSession(ctx, anonToken);
      if (!anonSession) {
        throw AppError.unauthorized("Anonymous session not found, expired, or already merged");
      }

      const result = await mergeAnonymousIntoUser(ctx, anonSession.id, identity.userId);
      return reply.status(200).send(result);
    },
  );
}

// ─── Identity resolution helper ───────────────────────────────────────────────

/**
 * Resolves the requesting identity from an Authorization header.
 * Returns null for missing/malformed headers (not an error — some routes are public).
 * Checks anonymous sessions first, then user sessions.
 */
export async function resolveIdentityFromHeader(
  ctx: DbContext,
  header: string | undefined,
) {
  if (!header) return null;
  const parts = header.split(" ");
  if (parts.length !== 2 || parts[0]?.toLowerCase() !== "bearer") return null;
  const token = parts[1];
  if (!token || !isValidTokenShape(token)) return null;

  // Try user session first (most common in authenticated context)
  const userSession = await resolveUserSession(ctx, token);
  if (userSession) return userIdentity(userSession.userId);

  // Fall back to anonymous session
  const anonSession = await resolveAnonSession(ctx, token);
  if (anonSession) return anonIdentity(anonSession.id);

  return null;
}
