/**
 * User service — account lifecycle.
 * No OAuth logic here; provider-specific auth is added in Phase 4.3+.
 */

import { eq, isNull, and } from "drizzle-orm";
import type { DbContext } from "../../db/client.js";
import { users } from "../../db/drizzle-schema.js";
import { AppError } from "../../errors/index.js";
import type { UserRow } from "../auth/repository.js";
import { createUser, getUserById } from "../auth/repository.js";

export { createUser, getUserById };

/**
 * Soft-deletes a user. Idempotent.
 * Soft-deleted users are invisible to all normal queries.
 */
export async function softDeleteUser(
  ctx: DbContext,
  userId: string,
): Promise<void> {
  const user = await getUserById(ctx, userId);
  if (!user) throw AppError.notFound("User");
  if (user.deletedAt !== null) return; // already deleted — idempotent

  await ctx.db
    .update(users)
    .set({ deletedAt: new Date(), updatedAt: new Date() })
    .where(eq(users.id, userId));
}

/**
 * Attaches an external provider subject to an existing user account.
 * Provider-neutral: accepts any (provider, subject) pair.
 * Phase 4.3 will use this for Apple Sign-In.
 *
 * For V1 we only have Apple, so appleSubject is the only column.
 * If the subject is already attached to a DIFFERENT user, throws CONFLICT.
 */
export async function attachAppleSubject(
  ctx: DbContext,
  userId: string,
  appleSubject: string,
): Promise<void> {
  // Check no other user owns this subject
  const [existing] = await ctx.db
    .select({ id: users.id })
    .from(users)
    .where(and(eq(users.appleSubject, appleSubject), isNull(users.deletedAt)))
    .limit(1);

  if (existing) {
    if (existing.id === userId) return; // already attached — idempotent
    throw AppError.conflict("Apple account already linked to a different user");
  }

  await ctx.db
    .update(users)
    .set({ appleSubject, updatedAt: new Date() })
    .where(eq(users.id, userId));
}

/**
 * Looks up a user by Apple subject (for OAuth callback).
 */
export async function getUserByAppleSubject(
  ctx: DbContext,
  appleSubject: string,
): Promise<UserRow | null> {
  const [row] = await ctx.db
    .select()
    .from(users)
    .where(and(eq(users.appleSubject, appleSubject), isNull(users.deletedAt)))
    .limit(1);
  return row ?? null;
}
