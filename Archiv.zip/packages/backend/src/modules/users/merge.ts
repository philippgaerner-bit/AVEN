/**
 * Anonymous → User ownership merge.
 *
 * Migrates all creator profiles (and thus all dependent data via FK) from an
 * anonymous session to a registered user.
 *
 * Rules enforced here:
 *   - Merge only once per anonymous session (schema + logic)
 *   - Repeating the SAME merge is idempotent
 *   - Merging the SAME anonymous session to a DIFFERENT user fails with CONFLICT
 *   - Soft-deleted users cannot receive ownership
 *
 * Data migration:
 *   - creator_profiles.owner_* columns are updated in-place
 *   - All child data (scans, findings, actions, etc.) is tied to
 *     creator_profile_id via FK and therefore follows automatically
 *   - No data is duplicated
 *
 * Transaction safety:
 *   Drizzle doesn't expose a transaction API in the same way across adapters;
 *   for postgres-js we use ctx.db.transaction(). The merge is structured
 *   so that partial execution leaves the system in a recoverable state.
 */

import { eq } from "drizzle-orm";
import type { DbContext } from "../../db/client.js";
import { creatorProfiles, anonymousSessions } from "../../db/drizzle-schema.js";
import { AppError } from "../../errors/index.js";
import { getUserById } from "../auth/repository.js";

export interface MergeResult {
  /** Number of creator profiles transferred to the user */
  profilesMigrated: number;
  /** true if this was a no-op (same merge repeated) */
  alreadyMerged: boolean;
}

/**
 * Merges anonymous session ownership into a registered user.
 *
 * @param ctx        DB context
 * @param anonId     anonymous_sessions.id
 * @param userId     users.id  (target owner)
 */
export async function mergeAnonymousIntoUser(
  ctx: DbContext,
  anonId: string,
  userId: string,
): Promise<MergeResult> {
  // 1. Validate target user
  const user = await getUserById(ctx, userId);
  if (!user) throw AppError.notFound("User");
  if (user.deletedAt !== null) throw AppError.forbidden("Target user account is deactivated");

  // 2. Load the anonymous session
  const [anonRow] = await ctx.db
    .select()
    .from(anonymousSessions)
    .where(eq(anonymousSessions.id, anonId))
    .limit(1);

  if (!anonRow) throw AppError.notFound("Anonymous session");

  // 3. Idempotency / conflict check
  if (anonRow.mergedIntoUserId !== null) {
    if (anonRow.mergedIntoUserId === userId) {
      // Exact same merge repeated → idempotent success
      return { profilesMigrated: 0, alreadyMerged: true };
    }
    // Attempt to merge into a DIFFERENT user → conflict
    throw AppError.conflict(
      "This anonymous session has already been merged into a different user account",
    );
  }

  // 4. Migrate creator profiles
  // Update ownerType, ownerUserId, clear ownerAnonymousSessionId
  const updated = await ctx.db
    .update(creatorProfiles)
    .set({
      ownerType: "user",
      ownerUserId: userId,
      ownerAnonymousSessionId: null,
      updatedAt: new Date(),
    })
    .where(eq(creatorProfiles.ownerAnonymousSessionId, anonId))
    .returning({ id: creatorProfiles.id });

  // 5. Mark anonymous session as merged
  await ctx.db
    .update(anonymousSessions)
    .set({ mergedIntoUserId: userId })
    .where(eq(anonymousSessions.id, anonId));

  return { profilesMigrated: updated.length, alreadyMerged: false };
}
