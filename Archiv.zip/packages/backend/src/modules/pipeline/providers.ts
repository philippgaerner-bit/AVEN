/**
 * Provider-neutral interfaces for the screenshot analysis pipeline.
 *
 * Three providers, three boundaries:
 *   ImageProcessor       — image normalization, quality, perceptual hash
 *   OCRProvider          — text extraction from image regions
 *   VisionObservationProvider — platform detection + criterion observations
 *
 * None of these providers set scores, priorities, or findings.
 * Their outputs are ALWAYS intermediate — the deterministic engine consumes them.
 */

import type {
  ImageMetadata,
  ImageQualityResult,
  DetectedPlatform,
  ExtractedRegion,
  ExtractedText,
  ProviderObservation,
} from "./types.js";

// ─── ImageProcessor ───────────────────────────────────────────────────────────

export interface ImageProcessor {
  readonly processorName: string;

  /** Normalize image (resize, rotate, convert) — returns updated metadata */
  normalizeImage(image: ImageMetadata): Promise<ImageMetadata>;

  /** Assess quality: dimensions, blur, perceptual hash */
  inspectQuality(image: ImageMetadata): Promise<ImageQualityResult>;

  /** Compute a DCT-based perceptual hash for deduplication */
  computePerceptualHash(image: ImageMetadata): Promise<string>;
}

// ─── OCRProvider ──────────────────────────────────────────────────────────────

export interface OCRProvider {
  readonly providerName: string;
  readonly modelVersion: string;

  /**
   * Extracts text from specified regions.
   * Returns one ExtractedText per region (empty text if nothing found).
   * Throws on unrecoverable error.
   */
  extractText(
    image: ImageMetadata,
    regions: ReadonlyArray<ExtractedRegion>,
  ): Promise<ReadonlyArray<ExtractedText>>;
}

// ─── VisionObservationProvider ────────────────────────────────────────────────

export interface VisionObservationProvider {
  readonly providerName: string;
  readonly modelVersion: string;

  /** Detects which platform the screenshot is from and its confidence */
  detectPlatform(image: ImageMetadata): Promise<DetectedPlatform>;

  /** Extracts bounding boxes for known profile regions */
  extractProfileRegions(
    image: ImageMetadata,
    platform: "tiktok" | "instagram",
  ): Promise<ReadonlyArray<ExtractedRegion>>;

  /**
   * Creates criterion observations from regions + extracted text.
   * MUST NOT set scores. Returns ONLY CriterionState values.
   * source must be "B" (OCR) or "C" (vision).
   */
  createCriterionObservations(
    platform: "tiktok" | "instagram",
    regions: ReadonlyArray<ExtractedRegion>,
    texts: ReadonlyArray<ExtractedText>,
  ): Promise<ReadonlyArray<ProviderObservation>>;
}

// ─── Stub implementations ─────────────────────────────────────────────────────

const STUB_HASH = "aabbccddeeff00112233445566778899";

export class StubImageProcessor implements ImageProcessor {
  readonly processorName = "stub-image-processor";

  constructor(
    private readonly opts: {
      qualityOk?: boolean;
      blurScore?: number;
      width?: number;
      height?: number;
      hash?: string;
    } = {},
  ) {}

  async normalizeImage(image: ImageMetadata): Promise<ImageMetadata> {
    return image; // passthrough
  }

  async inspectQuality(_image: ImageMetadata): Promise<ImageQualityResult> {
    const ok = this.opts.qualityOk ?? true;
    return {
      acceptable:        ok,
      widthPx:           this.opts.width  ?? 1080,
      heightPx:          this.opts.height ?? 1920,
      blurScore:         this.opts.blurScore ?? 0.1,
      perceptualHash:    this.opts.hash ?? STUB_HASH,
      ...(ok ? {} : { rejectionReason: "Image is too blurry" }),
    };
  }

  async computePerceptualHash(_image: ImageMetadata): Promise<string> {
    return this.opts.hash ?? STUB_HASH;
  }
}

export class StubOCRProvider implements OCRProvider {
  readonly providerName = "stub-ocr";
  readonly modelVersion = "stub-ocr-v1";

  constructor(private readonly opts: { fail?: boolean } = {}) {}

  async extractText(
    _image: ImageMetadata,
    regions: ReadonlyArray<ExtractedRegion>,
  ): Promise<ReadonlyArray<ExtractedText>> {
    if (this.opts.fail) throw new Error("StubOCR: simulated OCR failure");
    return regions.map((r) => ({
      regionType:  r.regionType,
      text:        r.regionType === "bio"          ? "Helping creators grow | Link below"
                 : r.regionType === "username"     ? "@testcreator"
                 : r.regionType === "display_name" ? "Test Creator"
                 : "",
      confidence: 0.95,
    }));
  }
}

export class StubVisionObservationProvider implements VisionObservationProvider {
  readonly providerName = "stub-vision";
  readonly modelVersion = "stub-vision-v1";

  constructor(
    private readonly opts: {
      platform?: "tiktok" | "instagram";
      confidence?: number;
      failPlatform?: boolean;
      failObservations?: boolean;
      observationState?: import("./types.js").ProviderObservation["state"];
    } = {},
  ) {}

  async detectPlatform(_image: ImageMetadata): Promise<DetectedPlatform> {
    if (this.opts.failPlatform) throw new Error("StubVision: simulated platform detection failure");
    return {
      platform:       this.opts.platform    ?? "tiktok",
      confidence:     this.opts.confidence  ?? 0.95,
      screenshotType: "profile",
    };
  }

  async extractProfileRegions(
    _image: ImageMetadata,
    _platform: "tiktok" | "instagram",
  ): Promise<ReadonlyArray<ExtractedRegion>> {
    return [
      { regionType: "bio",            boundingBox: { x: 0, y: 200, w: 1080, h: 120 } },
      { regionType: "username",       boundingBox: { x: 0, y: 100, w: 400,  h:  60 } },
      { regionType: "display_name",   boundingBox: { x: 0, y: 60,  w: 400,  h:  40 } },
      { regionType: "profile_picture",boundingBox: { x: 400, y: 60, w: 200, h: 200 } },
      { regionType: "feed_grid",      boundingBox: { x: 0, y: 400, w: 1080, h: 800 } },
    ];
  }

  async createCriterionObservations(
    _platform: "tiktok" | "instagram",
    _regions: ReadonlyArray<ExtractedRegion>,
    _texts: ReadonlyArray<ExtractedText>,
  ): Promise<ReadonlyArray<ProviderObservation>> {
    if (this.opts.failObservations) throw new Error("StubVision: simulated observation failure");

    const state = this.opts.observationState ?? "fulfilled";

    // Return a representative set of observations — source "C" (vision model)
    // Real provider would inspect text/regions to determine each criterion state
    return [
      { criterionId: "bio_target_audience",    state, source: "C", modelVersion: this.modelVersion },
      { criterionId: "bio_outcome",            state, source: "C", modelVersion: this.modelVersion },
      { criterionId: "bio_cta",               state, source: "C", modelVersion: this.modelVersion },
      { criterionId: "bio_first_line",         state, source: "C", modelVersion: this.modelVersion },
      { criterionId: "bio_no_filler",          state, source: "C", modelVersion: this.modelVersion },
      { criterionId: "content_hook",           state, source: "C", modelVersion: this.modelVersion },
      { criterionId: "content_cover",          state, source: "C", modelVersion: this.modelVersion },
      { criterionId: "content_recurring",      state, source: "C", modelVersion: this.modelVersion },
      { criterionId: "content_length",         state, source: "C", modelVersion: this.modelVersion },
      { criterionId: "content_text_position",  state, source: "C", modelVersion: this.modelVersion },
      { criterionId: "content_regularity",     state, source: "C", modelVersion: this.modelVersion },
      { criterionId: "feed_color_world",       state, source: "C", modelVersion: this.modelVersion },
      { criterionId: "feed_cover_pattern",     state, source: "C", modelVersion: this.modelVersion },
      { criterionId: "feed_topic",             state, source: "C", modelVersion: this.modelVersion },
      { criterionId: "feed_pinned",            state, source: "C", modelVersion: this.modelVersion },
      { criterionId: "brand_colors",           state, source: "C", modelVersion: this.modelVersion },
      { criterionId: "brand_font",             state, source: "C", modelVersion: this.modelVersion },
      { criterionId: "brand_theme",            state, source: "C", modelVersion: this.modelVersion },
      { criterionId: "brand_recognizable",     state, source: "C", modelVersion: this.modelVersion },
      { criterionId: "profile_pic_recognition",state, source: "C", modelVersion: this.modelVersion },
      { criterionId: "profile_pic_subject",    state, source: "C", modelVersion: this.modelVersion },
      { criterionId: "profile_pic_contrast",   state, source: "C", modelVersion: this.modelVersion },
      { criterionId: "profile_pic_color_fit",  state, source: "C", modelVersion: this.modelVersion },
      { criterionId: "username_pronounceable", state, source: "C", modelVersion: this.modelVersion },
      { criterionId: "username_clean",         state, source: "C", modelVersion: this.modelVersion },
      { criterionId: "name_field_topic",       state, source: "C", modelVersion: this.modelVersion },
      { criterionId: "username_name_match",    state, source: "C", modelVersion: this.modelVersion },
      { criterionId: "engagement_captions",    state, source: "C", modelVersion: this.modelVersion },
      { criterionId: "engagement_replies",     state, source: "C", modelVersion: this.modelVersion },
      { criterionId: "engagement_opinion",     state, source: "C", modelVersion: this.modelVersion },
      { criterionId: "engagement_cta_end",     state, source: "C", modelVersion: this.modelVersion },
    ];
  }
}
