/**
 * Provider factory — centralized provider selection.
 *
 * Rules:
 *  - "fake" → StubProvider (no network, safe for tests)
 *  - "disabled" → DisabledProvider (fails every call safely)
 *  - Unsupported value → ConfigError at startup (not at import time)
 *  - No network calls at module import
 *  - All provider outputs are validated before reaching scoring
 *  - Raw provider errors never leak to clients
 */

import type { AppConfig } from "../../config/index.js";
import { ConfigError } from "../../config/index.js";
import type {
  ImageProcessor,
  OCRProvider,
  VisionObservationProvider,
} from "./providers.js";
import {
  StubImageProcessor,
  StubOCRProvider,
  StubVisionObservationProvider,
} from "./providers.js";
import type {
  ImageMetadata,
  ExtractedRegion,
  ExtractedText,
  DetectedPlatform,
  ProviderObservation,
} from "./types.js";
import { ALL_CRITERION_IDS } from "@vyro/shared/scoring";
import { CRITERION_STATES } from "@vyro/shared/scoring";

// ─── Disabled provider (safe error on every call) ─────────────────────────────

class DisabledOCRProvider implements OCRProvider {
  readonly providerName = "disabled";
  readonly modelVersion = "disabled";
  async extractText(): Promise<never> {
    throw new Error("OCR provider is disabled in this environment");
  }
}

class DisabledVisionProvider implements VisionObservationProvider {
  readonly providerName = "disabled";
  readonly modelVersion = "disabled";
  async detectPlatform(): Promise<never> {
    throw new Error("Vision provider is disabled in this environment");
  }
  async extractProfileRegions(): Promise<never> {
    throw new Error("Vision provider is disabled in this environment");
  }
  async createCriterionObservations(): Promise<never> {
    throw new Error("Vision provider is disabled in this environment");
  }
}

// ─── Output validation wrapper ────────────────────────────────────────────────

const KNOWN_CRITERION_IDS = new Set<string>(ALL_CRITERION_IDS);
const VALID_STATES        = new Set<string>(CRITERION_STATES);

/**
 * Wraps a VisionObservationProvider to validate its output before
 * it reaches the scoring engine.
 *
 * Rejects observations with:
 *  - unknown criterionId
 *  - invalid state
 *  - duplicate criterionId
 *  - any extra scoring fields (score, priority, impact)
 */
class ValidatedVisionProvider implements VisionObservationProvider {
  constructor(private readonly inner: VisionObservationProvider) {}

  get providerName(): string { return this.inner.providerName; }
  get modelVersion(): string  { return this.inner.modelVersion; }

  async detectPlatform(image: ImageMetadata): Promise<DetectedPlatform> {
    return this.inner.detectPlatform(image);
  }

  async extractProfileRegions(
    image: ImageMetadata, platform: "tiktok" | "instagram",
  ): Promise<ReadonlyArray<ExtractedRegion>> {
    return this.inner.extractProfileRegions(image, platform);
  }

  async createCriterionObservations(
    platform: "tiktok" | "instagram",
    regions: ReadonlyArray<ExtractedRegion>,
    texts: ReadonlyArray<ExtractedText>,
  ): Promise<ReadonlyArray<ProviderObservation>> {
    const raw = await this.inner.createCriterionObservations(platform, regions, texts);
    return validateObservations(raw);
  }
}

export function validateObservations(
  obs: ReadonlyArray<ProviderObservation>,
): ReadonlyArray<ProviderObservation> {
  const seen = new Set<string>();

  for (const o of obs) {
    // Unknown criterion ID
    if (!KNOWN_CRITERION_IDS.has(o.criterionId)) {
      throw new Error(`Provider returned unknown criterionId: "${o.criterionId}"`);
    }
    // Invalid state
    if (!VALID_STATES.has(o.state)) {
      throw new Error(`Provider returned invalid state: "${o.state}" for "${o.criterionId}"`);
    }
    // Duplicate
    if (seen.has(o.criterionId)) {
      throw new Error(`Provider returned duplicate criterionId: "${o.criterionId}"`);
    }
    seen.add(o.criterionId);

    // No score injection — observation must not carry scoring fields
    const raw = o as unknown as Record<string, unknown>;
    if ("score" in raw || "priority" in raw || "impact" in raw || "total" in raw) {
      throw new Error(`Provider injected forbidden scoring field in observation for "${o.criterionId}"`);
    }
  }

  return obs;
}

// ─── Timeout + retry wrapper ──────────────────────────────────────────────────

export async function withTimeout<T>(
  fn: () => Promise<T>,
  timeoutMs: number,
  taskName: string,
): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(
      () => reject(new Error(`Provider timeout: ${taskName} exceeded ${timeoutMs}ms`)),
      timeoutMs,
    );
    fn().then(
      (v) => { clearTimeout(timer); resolve(v); },
      (e) => { clearTimeout(timer); reject(e); },
    );
  });
}

export async function withRetry<T>(
  fn: () => Promise<T>,
  maxRetries: number,
  taskName: string,
): Promise<T> {
  let lastErr: unknown;
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      return await fn();
    } catch (e) {
      lastErr = e;
      if (attempt < maxRetries) {
        // Simple exponential back-off: 100ms, 200ms, ...
        await new Promise((r) => setTimeout(r, 100 * (attempt + 1)));
      }
    }
  }
  throw new Error(`Provider failed after ${maxRetries + 1} attempts for ${taskName}: ${String(lastErr)}`);
}

// ─── OCR Adapter (HTTP-client ready) ─────────────────────────────────────────

/**
 * HTTP-ready OCR adapter boundary.
 * In production: implement with real HTTP client to provider API.
 * Phase 5.6: structure only — no real API calls.
 */
export class HttpOCRAdapter implements OCRProvider {
  readonly providerName: string;
  readonly modelVersion: string;

  constructor(
    private readonly config: {
      endpoint: string;
      apiKey: string;
      modelVersion: string;
      timeoutMs: number;
    },
  ) {
    this.providerName = "http-ocr";
    this.modelVersion = config.modelVersion;
  }

  async extractText(
    _image: ImageMetadata,
    _regions: ReadonlyArray<ExtractedRegion>,
  ): Promise<ReadonlyArray<ExtractedText>> {
    // Production implementation:
    //   const response = await fetch(this.config.endpoint, {
    //     method: "POST",
    //     headers: { Authorization: `Bearer ${this.config.apiKey}` },
    //     body: buildOCRRequest(_image, _regions),
    //     signal: AbortSignal.timeout(this.config.timeoutMs),
    //   });
    //   return parseOCRResponse(await response.json());
    throw new Error("HttpOCRAdapter: real provider not configured (Phase 5.7+)");
  }
}

/**
 * HTTP-ready Vision adapter boundary.
 * Same pattern as OCR adapter.
 */
export class HttpVisionAdapter implements VisionObservationProvider {
  readonly providerName: string;
  readonly modelVersion: string;

  constructor(
    private readonly config: {
      endpoint: string;
      apiKey: string;
      modelVersion: string;
      timeoutMs: number;
    },
  ) {
    this.providerName = "http-vision";
    this.modelVersion = config.modelVersion;
  }

  async detectPlatform(_image: ImageMetadata): Promise<DetectedPlatform> {
    throw new Error("HttpVisionAdapter: real provider not configured (Phase 5.7+)");
  }

  async extractProfileRegions(
    _image: ImageMetadata,
    _platform: "tiktok" | "instagram",
  ): Promise<ReadonlyArray<ExtractedRegion>> {
    throw new Error("HttpVisionAdapter: real provider not configured (Phase 5.7+)");
  }

  async createCriterionObservations(
    _platform: "tiktok" | "instagram",
    _regions: ReadonlyArray<ExtractedRegion>,
    _texts: ReadonlyArray<ExtractedText>,
  ): Promise<ReadonlyArray<ProviderObservation>> {
    throw new Error("HttpVisionAdapter: real provider not configured (Phase 5.7+)");
  }
}

// ─── Factory ──────────────────────────────────────────────────────────────────

export interface ProviderSet {
  imageProcessor: ImageProcessor;
  ocr:            OCRProvider;
  vision:         VisionObservationProvider;
}

/**
 * Creates providers from config.
 * Throws ConfigError for unsupported provider values.
 * No network calls here.
 */
export function createProviders(config: AppConfig): ProviderSet {
  const ocr = buildOCRProvider(config.ocrProvider);
  const vision = new ValidatedVisionProvider(buildVisionProvider(config.visionProvider));

  return {
    imageProcessor: new StubImageProcessor(), // Phase 5.7: real image processor
    ocr,
    vision,
  };
}

function buildOCRProvider(choice: string): OCRProvider {
  switch (choice) {
    case "fake":
      return new StubOCRProvider();
    case "disabled":
      return new DisabledOCRProvider();
    default:
      throw new ConfigError(
        `Unsupported OCR_PROVIDER: "${choice}". Supported: fake, disabled`,
      );
  }
}

function buildVisionProvider(choice: string): VisionObservationProvider {
  switch (choice) {
    case "fake":
      return new StubVisionObservationProvider();
    case "disabled":
      return new DisabledVisionProvider();
    default:
      throw new ConfigError(
        `Unsupported VISION_PROVIDER: "${choice}". Supported: fake, disabled`,
      );
  }
}
