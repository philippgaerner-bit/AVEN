/**
 * Screenshot Analysis Pipeline — types and stage definitions.
 *
 * Design rules:
 *  - AI/Vision providers ONLY produce criterion observations (source "B" or "C")
 *  - Scoring always runs deterministically from observations
 *  - Providers cannot set scores, priorities, or findings directly
 *  - All pipeline failures surface as PipelineFailure (no fake results)
 */

import type {
  CriterionState,
  ObservationSource,
  ScoringResult,
  ScoreSet,
} from "@vyro/shared/scoring";
import type { CriterionId } from "@vyro/shared/scoring";
import type { Finding } from "@vyro/shared/scoring";
import type { GrowthAction } from "../growth/actions.js";

// ─── Pipeline stages ──────────────────────────────────────────────────────────

export const PIPELINE_STAGES = [
  "ingest",
  "validateImage",
  "detectPlatform",
  "extractRegions",
  "extractText",
  "buildObservations",
  "calculateScore",
  "buildFindings",
  "buildActions",
] as const;

export type PipelineStage = (typeof PIPELINE_STAGES)[number];

// ─── Image metadata ───────────────────────────────────────────────────────────

export interface ImageMetadata {
  /** Opaque storage key (GCS path, local path, etc.) */
  readonly storageKey: string;
  readonly contentType: "image/jpeg" | "image/png" | "image/heic" | "image/webp";
  readonly byteSize: number;
  /** Raw bytes — only available in-process; never persisted */
  readonly bytes?: Uint8Array;
}

// ─── Image quality ────────────────────────────────────────────────────────────

export interface ImageQualityResult {
  readonly acceptable: boolean;
  readonly widthPx: number;
  readonly heightPx: number;
  /** Estimated blur score 0–1 (0 = clear, 1 = very blurry) */
  readonly blurScore: number;
  /** Perceptual hash for deduplication (DCT-based) */
  readonly perceptualHash: string;
  readonly rejectionReason?: string;
}

export const MIN_WIDTH_PX  = 320;
export const MIN_HEIGHT_PX = 480;
export const MAX_BLUR_SCORE = 0.7;

// ─── Detected platform ────────────────────────────────────────────────────────

export interface DetectedPlatform {
  readonly platform: "tiktok" | "instagram";
  /** Confidence 0–1 — pipeline fails if below threshold */
  readonly confidence: number;
  readonly screenshotType: "profile" | "feed" | "post" | "unknown";
}

export const MIN_PLATFORM_CONFIDENCE = 0.75;

// ─── Extracted regions ────────────────────────────────────────────────────────

export interface BoundingBox {
  readonly x: number; readonly y: number;
  readonly w: number; readonly h: number;
}

export interface ExtractedRegion {
  readonly regionType:
    | "bio"
    | "username"
    | "display_name"
    | "profile_picture"
    | "feed_grid"
    | "pinned_post"
    | "follower_count";
  readonly boundingBox: BoundingBox;
  /** Region bytes if extracted — never persisted */
  readonly bytes?: Uint8Array;
}

// ─── Extracted text ───────────────────────────────────────────────────────────

export interface ExtractedText {
  readonly regionType: ExtractedRegion["regionType"];
  readonly text: string;
  readonly confidence: number;
}

// ─── Criterion observations from providers ────────────────────────────────────

/**
 * A single criterion observation produced by a provider.
 * source "B" = OCR-derived; source "C" = Vision model-derived.
 * source "A" = manual/test (for stubs only).
 *
 * CONSTRAINT: Provider NEVER assigns a score — only a CriterionState.
 */
export interface ProviderObservation {
  readonly criterionId: CriterionId;
  readonly state: CriterionState;
  readonly source: ObservationSource;
  readonly modelVersion?: string;
}

// ─── Cache key ────────────────────────────────────────────────────────────────

/**
 * Stable cache key derived from the perceptual hash of the image.
 * Same image → same key → same pipeline result (idempotent).
 */
export interface PipelineCacheKey {
  readonly perceptualHash: string;
  readonly platform: "tiktok" | "instagram";
  readonly scoringModelVersion: string;
  readonly pipelineVersion: string;
}

export function buildCacheKey(
  hash: string,
  platform: "tiktok" | "instagram",
  scoringModelVersion: string,
  pipelineVersion: string,
): PipelineCacheKey {
  return { perceptualHash: hash, platform, scoringModelVersion, pipelineVersion };
}

export function cacheKeyString(key: PipelineCacheKey): string {
  return `${key.platform}:${key.scoringModelVersion}:${key.pipelineVersion}:${key.perceptualHash}`;
}

// ─── Pipeline result ──────────────────────────────────────────────────────────

export interface PipelineSuccess {
  readonly success: true;
  readonly cacheKey: PipelineCacheKey;
  readonly detectedPlatform: DetectedPlatform;
  readonly imageQuality: ImageQualityResult;
  readonly observations: ReadonlyArray<ProviderObservation>;
  readonly scoringResult: ScoringResult;
  readonly findings: ReadonlyArray<Finding>;
  readonly actions: ReadonlyArray<GrowthAction>;
  readonly completedStages: ReadonlyArray<PipelineStage>;
  readonly pipelineVersion: string;
}

export interface PipelineFailure {
  readonly success: false;
  readonly failedAtStage: PipelineStage;
  readonly reason:
    | "image_quality_insufficient"
    | "platform_not_detected"
    | "platform_confidence_low"
    | "ocr_failure"
    | "vision_failure"
    | "observation_validation_error"
    | "internal_error";
  readonly message: string;
  /** Stages that completed successfully before the failure */
  readonly completedStages: ReadonlyArray<PipelineStage>;
  /** Deterministic scoring was never reached, so no fake scores exist */
  readonly deterministicScoringUntouched: true;
}

export type PipelineResult = PipelineSuccess | PipelineFailure;

export function isPipelineSuccess(r: PipelineResult): r is PipelineSuccess {
  return r.success === true;
}

export function isPipelineFailure(r: PipelineResult): r is PipelineFailure {
  return r.success === false;
}
