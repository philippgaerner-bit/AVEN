/**
 * Screenshot Analysis Pipeline Orchestrator.
 *
 * Executes stages in order. Each stage:
 *   - may fail safely → PipelineFailure (no fake scores)
 *   - passes its output to the next stage
 *
 * The scoring step is ALWAYS the deterministic engine from @vyro/shared/scoring.
 * Providers can only influence observations; they never touch scores or findings.
 */

import {
  calculateScore,
  buildFindings,
  SCORING_MODEL_VERSION,
  ALL_CRITERION_IDS,
} from "@vyro/shared/scoring";
import type { CriterionObservation } from "@vyro/shared/scoring";

import { buildGrowthActions } from "../growth/actions.js";

import type {
  ImageMetadata,
  ProviderObservation,
  PipelineResult,
  PipelineSuccess,
  PipelineFailure,
  PipelineStage,
} from "./types.js";
import {
  MIN_WIDTH_PX, MIN_HEIGHT_PX, MAX_BLUR_SCORE,
  MIN_PLATFORM_CONFIDENCE,
  buildCacheKey,
} from "./types.js";

import type { ImageProcessor, OCRProvider, VisionObservationProvider } from "./providers.js";

// ─── Pipeline config ──────────────────────────────────────────────────────────

export const PIPELINE_VERSION = "v1.0.0" as const;

export interface PipelineProviders {
  readonly imageProcessor: ImageProcessor;
  readonly ocr:            OCRProvider;
  readonly vision:         VisionObservationProvider;
}

// ─── Orchestrator ─────────────────────────────────────────────────────────────

/**
 * Runs the complete analysis pipeline from image → scored result.
 *
 * Stage order: ingest → validateImage → detectPlatform → extractRegions
 *              → extractText → buildObservations → calculateScore
 *              → buildFindings → buildActions
 *
 * Any stage failure returns PipelineFailure with:
 *   - the stage that failed
 *   - which stages completed
 *   - deterministicScoringUntouched: true (no fake scores)
 */
export async function runAnalysisPipeline(
  image: ImageMetadata,
  creatorProfileId: string,
  providers: PipelineProviders,
): Promise<PipelineResult> {
  const completed: PipelineStage[] = [];

  function fail(
    stage: PipelineStage,
    reason: PipelineFailure["reason"],
    message: string,
  ): PipelineFailure {
    return {
      success:     false,
      failedAtStage: stage,
      reason,
      message,
      completedStages: [...completed],
      deterministicScoringUntouched: true,
    };
  }

  // ── Stage: ingest ────────────────────────────────────────────────────────────
  let normalizedImage: ImageMetadata;
  try {
    normalizedImage = await providers.imageProcessor.normalizeImage(image);
    completed.push("ingest");
  } catch (e) {
    return fail("ingest", "internal_error", `Image normalization failed: ${String(e)}`);
  }

  // ── Stage: validateImage ─────────────────────────────────────────────────────
  let quality;
  try {
    quality = await providers.imageProcessor.inspectQuality(normalizedImage);
    completed.push("validateImage");
  } catch (e) {
    return fail("validateImage", "internal_error", `Quality inspection failed: ${String(e)}`);
  }

  if (!quality.acceptable) {
    return fail("validateImage", "image_quality_insufficient",
      quality.rejectionReason ?? `Image quality insufficient (blur: ${quality.blurScore})`);
  }
  if (quality.widthPx < MIN_WIDTH_PX || quality.heightPx < MIN_HEIGHT_PX) {
    return fail("validateImage", "image_quality_insufficient",
      `Image too small: ${quality.widthPx}x${quality.heightPx} (min ${MIN_WIDTH_PX}x${MIN_HEIGHT_PX})`);
  }
  if (quality.blurScore > MAX_BLUR_SCORE) {
    return fail("validateImage", "image_quality_insufficient",
      `Image too blurry: blurScore=${quality.blurScore} (max ${MAX_BLUR_SCORE})`);
  }

  // ── Stage: detectPlatform ────────────────────────────────────────────────────
  let detected;
  try {
    detected = await providers.vision.detectPlatform(normalizedImage);
    completed.push("detectPlatform");
  } catch (e) {
    return fail("detectPlatform", "vision_failure", `Platform detection failed: ${String(e)}`);
  }

  if (!["tiktok", "instagram"].includes(detected.platform)) {
    return fail("detectPlatform", "platform_not_detected",
      `Unsupported platform detected: ${detected.platform}`);
  }
  if (detected.confidence < MIN_PLATFORM_CONFIDENCE) {
    return fail("detectPlatform", "platform_confidence_low",
      `Platform confidence too low: ${detected.confidence} < ${MIN_PLATFORM_CONFIDENCE}`);
  }

  const platform = detected.platform as "tiktok" | "instagram";

  // ── Stage: extractRegions ────────────────────────────────────────────────────
  let regions;
  try {
    regions = await providers.vision.extractProfileRegions(normalizedImage, platform);
    completed.push("extractRegions");
  } catch (e) {
    return fail("extractRegions", "vision_failure", `Region extraction failed: ${String(e)}`);
  }

  // ── Stage: extractText ───────────────────────────────────────────────────────
  let texts;
  try {
    texts = await providers.ocr.extractText(normalizedImage, regions);
    completed.push("extractText");
  } catch (e) {
    return fail("extractText", "ocr_failure", `OCR failed: ${String(e)}`);
  }

  // ── Stage: buildObservations ─────────────────────────────────────────────────
  let providerObs: ReadonlyArray<ProviderObservation>;
  try {
    providerObs = await providers.vision.createCriterionObservations(platform, regions, texts);
    completed.push("buildObservations");
  } catch (e) {
    return fail("buildObservations", "vision_failure", `Observation creation failed: ${String(e)}`);
  }

  // Validate: no unknown criterion IDs
  const knownIds = new Set<string>(ALL_CRITERION_IDS);
  const unknownIds = providerObs.filter((o) => !knownIds.has(o.criterionId));
  if (unknownIds.length > 0) {
    return fail("buildObservations", "observation_validation_error",
      `Provider returned unknown criterionIds: ${unknownIds.map((o) => o.criterionId).join(", ")}`);
  }

  // Build ObservationPackage — criteria missing from provider become "unavailable"
  const obsMap = new Map(providerObs.map((o) => [o.criterionId, o]));
  const observations: CriterionObservation[] = ALL_CRITERION_IDS.map((id) => {
    const prov = obsMap.get(id);
    return prov
      ? { id: prov.criterionId as import("@vyro/shared/scoring").CriterionId, state: prov.state, source: prov.source }
      : { id: id as import("@vyro/shared/scoring").CriterionId, state: "unavailable" as const, source: "A" as const };
  });

  // ── Stage: calculateScore ────────────────────────────────────────────────────
  let scoringResult;
  try {
    const pkg = {
      observations,
      modelVersions: {
        ocr:      providers.ocr.modelVersion,
        vision:   providers.vision.modelVersion,
        language: "none",
      },
      pipelineVersion: PIPELINE_VERSION,
      scoringModelVersion: SCORING_MODEL_VERSION,
    };
    scoringResult = calculateScore(pkg);
    completed.push("calculateScore");
  } catch (e) {
    return fail("calculateScore", "internal_error", `Scoring failed: ${String(e)}`);
  }

  // ── Stage: buildFindings ─────────────────────────────────────────────────────
  let findings;
  try {
    const pkg = {
      observations,
      modelVersions: { ocr: providers.ocr.modelVersion, vision: providers.vision.modelVersion, language: "none" },
      pipelineVersion: PIPELINE_VERSION,
      scoringModelVersion: SCORING_MODEL_VERSION,
    };
    findings = buildFindings(pkg, scoringResult);
    completed.push("buildFindings");
  } catch (e) {
    return fail("buildFindings", "internal_error", `Finding build failed: ${String(e)}`);
  }

  // ── Stage: buildActions ──────────────────────────────────────────────────────
  let actions;
  try {
    actions = buildGrowthActions(findings, creatorProfileId);
    completed.push("buildActions");
  } catch (e) {
    return fail("buildActions", "internal_error", `Action build failed: ${String(e)}`);
  }

  // ── Success ──────────────────────────────────────────────────────────────────
  const cacheKey = buildCacheKey(
    quality.perceptualHash, platform, SCORING_MODEL_VERSION, PIPELINE_VERSION,
  );

  const result: PipelineSuccess = {
    success:         true,
    cacheKey,
    detectedPlatform: detected,
    imageQuality:    quality,
    observations:    providerObs,
    scoringResult,
    findings,
    actions,
    completedStages: [...completed],
    pipelineVersion: PIPELINE_VERSION,
  };

  return result;
}
