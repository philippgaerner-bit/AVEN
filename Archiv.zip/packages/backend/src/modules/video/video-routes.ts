/**
 * Video render routes — Runway ML Gen-3 Alpha Turbo
 *
 * POST   /video/render           — submit job
 * GET    /video/render/status    — check if configured
 * GET    /video/render/:jobId    — poll job
 * DELETE /video/render/:jobId    — cancel job
 *
 * Required env vars:
 *   RUNWAY_API_KEY  — from https://app.runwayml.com (Settings → API)
 *   RUNWAY_API_URL  — defaults to https://api.runwayml.com/v1
 */

import type { FastifyInstance } from "fastify";
import type { AppConfig }       from "../../config/index.js";

const RUNWAY_BASE = process.env["RUNWAY_API_URL"] ?? "https://api.runwayml.com/v1";
const RUNWAY_KEY  = process.env["RUNWAY_API_KEY"] ?? "";

export async function registerVideoRoutes(
  app: FastifyInstance,
  _config: AppConfig,
): Promise<void> {

  const isConfigured = RUNWAY_KEY.length > 0;

  // ── Status ─────────────────────────────────────────────────────────────────

  app.get("/video/render/status", async (_req, reply) => {
    return reply.send({ configured: isConfigured, provider: "runway_gen3_alpha_turbo" });
  });

  // ── Submit ─────────────────────────────────────────────────────────────────

  app.post("/video/render", async (req, reply) => {
    if (!isConfigured) {
      return reply.status(503).send({
        error: "video_not_configured",
        message: "RUNWAY_API_KEY is not set.",
        configured: false,
      });
    }

    const body = req.body as {
      platform?: string;
      hook?: string;
      script?: string;
      style?: string;
      duration?: number;
      caption?: string;
    };

    const prompt   = buildRunwayPrompt(body);
    const duration = Math.min(Math.max(body.duration ?? 10, 5), 10);

    try {
      const res = await fetch(`${RUNWAY_BASE}/image_to_video`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${RUNWAY_KEY}`,
          "Content-Type": "application/json",
          "X-Runway-Version": "2024-11-06",
        },
        body: JSON.stringify({
          model:       "gen3a_turbo",
          prompt_text: prompt,
          ratio:       "768:1280",
          duration,
          watermark:   false,
        }),
      });

      if (!res.ok) {
        const text = await res.text();
        return reply.status(502).send({
          error: "runway_error",
          message: `Runway ML ${res.status}: ${text.slice(0, 200)}`,
        });
      }

      const data = await res.json() as { id?: string };
      return reply.status(201).send({ jobId: data.id ?? "", status: "queued" });
    } catch (e) {
      return reply.status(502).send({
        error: "network_error",
        message: e instanceof Error ? e.message : "unknown",
      });
    }
  });

  // ── Poll ───────────────────────────────────────────────────────────────────

  app.get("/video/render/:jobId", async (req, reply) => {
    if (!isConfigured) {
      return reply.status(503).send({ error: "video_not_configured", configured: false });
    }

    const { jobId } = req.params as { jobId: string };

    try {
      const res = await fetch(`${RUNWAY_BASE}/tasks/${jobId}`, {
        headers: {
          Authorization: `Bearer ${RUNWAY_KEY}`,
          "X-Runway-Version": "2024-11-06",
        },
      });

      if (!res.ok) {
        return reply.status(502).send({ status: "failed", error: `Runway ${res.status}` });
      }

      const data = await res.json() as {
        status?:   string;
        progress?: number;
        output?:   string[];
        failure?:  string;
      };

      switch (data.status) {
        case "PENDING":
        case "THROTTLED":
          return reply.send({ status: "queued",     progress: 0 });
        case "RUNNING":
          return reply.send({ status: "processing", progress: Math.round((data.progress ?? 0) * 100) });
        case "SUCCEEDED":
          return reply.send({ status: "completed",  videoURL: data.output?.[0] ?? "" });
        case "FAILED":
          return reply.send({ status: "failed",     error: data.failure ?? "Generation failed" });
        default:
          return reply.send({ status: "processing", progress: 5 });
      }
    } catch (e) {
      return reply.status(502).send({
        status: "failed",
        error: e instanceof Error ? e.message : "unknown",
      });
    }
  });

  // ── Cancel ─────────────────────────────────────────────────────────────────

  app.delete("/video/render/:jobId", async (req, reply) => {
    if (!isConfigured) return reply.status(204).send();
    const { jobId } = req.params as { jobId: string };
    try {
      await fetch(`${RUNWAY_BASE}/tasks/${jobId}/cancel`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${RUNWAY_KEY}`,
          "X-Runway-Version": "2024-11-06",
        },
      });
    } catch { /* best-effort */ }
    return reply.status(204).send();
  });
}

// ─── Prompt builder ───────────────────────────────────────────────────────────

function buildRunwayPrompt(body: {
  platform?: string;
  hook?:     string;
  style?:    string;
}): string {
  const style    = (body.style    ?? "viral").toLowerCase();
  const hook     = body.hook      ?? "";
  const platform = body.platform  ?? "TikTok";

  const styleDirection: Record<string, string> = {
    viral:        "fast-paced energetic trendy creator-style, jump cuts, vibrant lighting, high contrast",
    clean:        "minimal modern aesthetic, professional studio lighting, clean neutral tones",
    storytelling: "cinematic narrative, warm emotional tones, smooth transitions, shallow depth of field",
    educational:  "clear well-lit professional presenter, bold graphics, confident pacing",
    cinematic:    "cinematic wide shots, dramatic atmospheric lighting, film grain, moody color grade",
  };
  const direction = styleDirection[style] ?? styleDirection["viral"]!;

  return [
    `${platform} vertical 9:16 short-form video.`,
    `Style: ${direction}.`,
    hook ? `Visual concept based on: "${hook.slice(0, 90)}".` : "",
    "Dynamic modern short-form editing rhythm. Realistic human presenter or product close-ups.",
    "Professional cinematography, sharp focus, cinematic color grade. No text overlays.",
  ].filter(Boolean).join(" ");
}
