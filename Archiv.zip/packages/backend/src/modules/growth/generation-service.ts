/**
 * Generation service — orchestrates AI recommendation calls.
 *
 * Contract:
 *   - Accepts deterministic VYRO context (Finding, GrowthAction, observations)
 *   - Calls the provider, validates the structured response
 *   - Returns typed result OR GenerationFailure
 *   - Never mutates scores, findings, priorities, or actions
 *   - Provider errors → GenerationFailure (deterministic data unaffected)
 */

import type { Finding } from "@vyro/shared/scoring";
import type { GrowthAction } from "./actions.js";
import type { RecommendationAIProvider } from "./ai-provider.js";
import {
  buildExplainFindingPrompt,
  buildActionSuggestionPrompt,
  buildBioGenerationPrompt,
  buildHookGenerationPrompt,
  buildCaptionGenerationPrompt,
  buildContentIdeasPrompt,
} from "./ai-provider.js";
import {
  PROMPT_VERSIONS,
  isGenerationFailure,
  validateFindingExplanation,
  validateActionSuggestion,
  validateBioOptions,
  validateHookOptions,
  validateCaptionOptions,
  validateContentIdeas,
} from "./ai-types.js";
import type {
  CreatorContext, ObservationContext,
  FindingExplanation, ActionSuggestion,
  BioOptions, HookOptions, CaptionOptions, ContentIdeas,
  GenerationResult, GenerationFailure,
} from "./ai-types.js";

// ─── Failure factory ──────────────────────────────────────────────────────────

function failure(
  reason: GenerationFailure["reason"],
  message: string,
): GenerationFailure {
  return {
    failed: true,
    reason,
    message,
    deterministicCoreIntact: true,
  };
}

// ─── Safe call wrapper ────────────────────────────────────────────────────────

async function safeCall<T>(
  fn: () => Promise<unknown>,
  validator: (raw: unknown) => raw is T,
  taskName: string,
): Promise<GenerationResult<T>> {
  let raw: unknown;
  try {
    raw = await fn();
  } catch (err) {
    return failure("provider_error", `Provider error in ${taskName}: ${String(err)}`);
  }

  if (typeof raw === "string") {
    try { raw = JSON.parse(raw); } catch {
      return failure("invalid_output", `${taskName}: provider returned unparseable string`);
    }
  }

  if (!validator(raw)) {
    return failure("schema_mismatch", `${taskName}: provider response did not match expected schema`);
  }

  return raw;
}

// ─── Generation service ───────────────────────────────────────────────────────

export class GenerationService {
  constructor(private readonly provider: RecommendationAIProvider) {}

  async explainFinding(
    creator: CreatorContext,
    finding: Finding,
    observations: ReadonlyArray<ObservationContext>,
  ): Promise<GenerationResult<FindingExplanation>> {
    const req = {
      promptVersion: PROMPT_VERSIONS.EXPLAIN_FINDING,
      creator,
      finding: {
        templateId:   finding.templateId,
        title:        finding.title,
        severity:     finding.severity,
        observations,
      },
    };
    return safeCall(
      () => this.provider.explainFinding(req),
      validateFindingExplanation,
      "explainFinding",
    );
  }

  async generateActionSuggestion(
    creator: CreatorContext,
    action: GrowthAction,
    finding: Finding,
  ): Promise<GenerationResult<ActionSuggestion>> {
    const req = {
      promptVersion: PROMPT_VERSIONS.ACTION_SUGGESTION,
      creator,
      action: {
        actionType: action.actionType,
        category:   action.category,
        title:      action.title,
      },
      findingContext: {
        templateId: finding.templateId,
        title:      finding.title,
        severity:   finding.severity,
      },
    };
    return safeCall(
      () => this.provider.generateActionSuggestion(req),
      validateActionSuggestion,
      "generateActionSuggestion",
    );
  }

  async generateBioOptions(
    creator: CreatorContext,
    observations: ReadonlyArray<ObservationContext>,
  ): Promise<GenerationResult<BioOptions>> {
    const req = {
      promptVersion: PROMPT_VERSIONS.BIO_GENERATION,
      creator,
      currentBioObservations: observations,
    };
    return safeCall(
      () => this.provider.generateBioOptions(req),
      validateBioOptions,
      "generateBioOptions",
    );
  }

  async generateHookOptions(
    creator: CreatorContext,
    observations: ReadonlyArray<ObservationContext>,
  ): Promise<GenerationResult<HookOptions>> {
    const req = {
      promptVersion: PROMPT_VERSIONS.HOOK_GENERATION,
      creator,
      contentObservations: observations,
    };
    return safeCall(
      () => this.provider.generateHookOptions(req),
      validateHookOptions,
      "generateHookOptions",
    );
  }

  async generateCaptionOptions(
    creator: CreatorContext,
    observations: ReadonlyArray<ObservationContext>,
    topicHint?: string,
  ): Promise<GenerationResult<CaptionOptions>> {
    const req = {
      promptVersion: PROMPT_VERSIONS.CAPTION_GENERATION,
      creator,
      contentObservations: observations,
      ...(topicHint !== undefined ? { topicHint } : {}),
    };
    return safeCall(
      () => this.provider.generateCaptionOptions(req),
      validateCaptionOptions,
      "generateCaptionOptions",
    );
  }

  async generateContentIdeas(
    creator: CreatorContext,
    observations: ReadonlyArray<ObservationContext>,
  ): Promise<GenerationResult<ContentIdeas>> {
    const req = {
      promptVersion: PROMPT_VERSIONS.CONTENT_IDEAS_GENERATION,
      creator,
      contentObservations: observations,
    };
    return safeCall(
      () => this.provider.generateContentIdeas(req),
      validateContentIdeas,
      "generateContentIdeas",
    );
  }
}
