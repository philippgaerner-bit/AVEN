/**
 * Daily task selector and progress calculator.
 *
 * All functions are pure — no DB, no LLM, no randomness.
 * Same input always produces same output.
 */

import type { GrowthAction } from "./actions.js";
import type { ScoreSet, CategoryScore } from "@vyro/shared/scoring";

// ─── Daily task selector ──────────────────────────────────────────────────────

/**
 * Selects the single highest-priority eligible action for today's task.
 *
 * Rules (in order):
 *   1. Skip completed or dismissed actions
 *   2. Skip polish actions blocked by an open foundation issue
 *   3. Among eligible actions, return the one with the lowest priority number
 *      (priority 1 = highest)
 *   4. If multiple have the same priority, take the first by stable sort order
 *      (alphabetical actionType for determinism)
 *   5. Return null if no eligible action exists
 */
export function selectDailyTask(
  actions: ReadonlyArray<GrowthAction>,
): GrowthAction | null {
  const eligible = actions.filter(
    (a) => a.status === "open" && !a.blockedByFoundation,
  );

  if (eligible.length === 0) return null;

  // Deterministic sort: priority ASC, then actionType ASC
  const sorted = [...eligible].sort((a, b) => {
    if (a.priority !== b.priority) return a.priority - b.priority;
    return a.actionType.localeCompare(b.actionType);
  });

  return sorted[0] ?? null;
}

/**
 * Returns the top N eligible actions for an action plan.
 * Blocked polish actions are excluded.
 */
export function selectTopActions(
  actions: ReadonlyArray<GrowthAction>,
  limit = 3,
): ReadonlyArray<GrowthAction> {
  const eligible = actions.filter(
    (a) => a.status === "open" && !a.blockedByFoundation,
  );
  const sorted = [...eligible].sort((a, b) => {
    if (a.priority !== b.priority) return a.priority - b.priority;
    return a.actionType.localeCompare(b.actionType);
  });
  return sorted.slice(0, limit);
}

// ─── Progress calculation ─────────────────────────────────────────────────────

export type CategoryKey = keyof Omit<ScoreSet, "total">;

export interface ProgressReport {
  /** Change in total normalized score */
  readonly scoreDelta: number;
  /** Finding templateIds that were present before but are gone now */
  readonly resolvedFindingIds: ReadonlyArray<string>;
  /** Finding templateIds that are new since the previous state */
  readonly newFindingIds: ReadonlyArray<string>;
  /** Category keys where normalizedPoints improved */
  readonly improvedCategories: ReadonlyArray<CategoryKey>;
  /** Category keys where normalizedPoints worsened */
  readonly worsenedCategories: ReadonlyArray<CategoryKey>;
}

const CATEGORY_KEYS: ReadonlyArray<CategoryKey> = [
  "bio", "content", "feed", "brand", "profilePic", "username", "engagement",
];

/**
 * Compares two ScoreSet/Finding snapshots and returns a progress report.
 *
 * Pure function — no smoothing, no predictions.
 * Scores come directly from the deterministic ScoreSet.
 */
export function calculateProgress(
  previousScore: ScoreSet,
  currentScore: ScoreSet,
  previousFindingTemplateIds: ReadonlyArray<string>,
  currentFindingTemplateIds: ReadonlyArray<string>,
): ProgressReport {
  const scoreDelta = currentScore.total - previousScore.total;

  const prevSet = new Set(previousFindingTemplateIds);
  const currSet = new Set(currentFindingTemplateIds);

  const resolvedFindingIds = previousFindingTemplateIds.filter((id) => !currSet.has(id));
  const newFindingIds      = currentFindingTemplateIds.filter((id)  => !prevSet.has(id));

  const improvedCategories: CategoryKey[]  = [];
  const worsenedCategories: CategoryKey[] = [];

  for (const key of CATEGORY_KEYS) {
    const prev = (previousScore[key] as CategoryScore).normalizedPoints;
    const curr = (currentScore[key]  as CategoryScore).normalizedPoints;
    if (curr > prev) improvedCategories.push(key);
    else if (curr < prev) worsenedCategories.push(key);
  }

  return {
    scoreDelta,
    resolvedFindingIds,
    newFindingIds,
    improvedCategories,
    worsenedCategories,
  };
}
