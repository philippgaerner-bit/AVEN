/**
 * Growth action model and Finding→Action mapping.
 *
 * All mappings are deterministic — no LLM, no randomness.
 * expectedImpact comes directly from Finding.impact (lost points).
 *
 * Depends only on @vyro/shared scoring types — no DB, no HTTP.
 */

import type { Finding, FindingSeverity } from "@vyro/shared/scoring";

// ─── Action types ─────────────────────────────────────────────────────────────

/**
 * Specific action types derived from the 12 FindingTemplates.
 * These are more granular than the DB-level ActionType enum,
 * which stays stable for FK/migration purposes.
 */
export const GROWTH_ACTION_TYPES = [
  "optimize_bio_positioning",
  "add_bio_cta",
  "strengthen_bio_first_line",
  "improve_hooks",
  "clarify_covers",
  "build_content_structure",
  "improve_feed_consistency",
  "clarify_feed_topic",
  "strengthen_branding",
  "improve_profile_picture",
  "clarify_identity",
  "improve_engagement_structure",
] as const;

export type GrowthActionType = (typeof GROWTH_ACTION_TYPES)[number];

export const GROWTH_ACTION_CATEGORIES = [
  "bio",
  "content",
  "feed",
  "branding",
  "profile",
  "identity",
  "engagement",
] as const;

export type GrowthActionCategory = (typeof GROWTH_ACTION_CATEGORIES)[number];

// ─── Action status ────────────────────────────────────────────────────────────

export const GROWTH_ACTION_STATUSES = ["open", "completed", "dismissed"] as const;
export type GrowthActionStatus = (typeof GROWTH_ACTION_STATUSES)[number];

// ─── Growth action ────────────────────────────────────────────────────────────

export interface GrowthAction {
  readonly id: string;                    // "<profileId>:<templateId>" — stable, deterministic
  readonly sourceFindingId: string;       // Finding.templateId
  readonly creatorProfileId: string;
  readonly category: GrowthActionCategory;
  readonly title: string;
  readonly actionType: GrowthActionType;
  readonly expectedImpact: number;        // = Finding.impact (lost points)
  readonly priority: number;              // = Finding.priority (inherited from scoring)
  readonly severity: FindingSeverity;     // inherited
  readonly blockedByFoundation: boolean;  // inherited
  readonly status: GrowthActionStatus;
}

// ─── Finding→Action template mapping ─────────────────────────────────────────

interface ActionTemplate {
  readonly actionType: GrowthActionType;
  readonly category: GrowthActionCategory;
  readonly title: string;
}

/**
 * Fixed mapping from all 12 FindingTemplates to concrete action specs.
 * No LLM, no dynamic content — these are static product strings.
 */
export const FINDING_TO_ACTION: Readonly<Record<string, ActionTemplate>> = {
  bio_positioning_unclear: {
    actionType: "optimize_bio_positioning",
    category:   "bio",
    title:      "Make your bio instantly clear about who you help",
  },
  bio_cta_missing: {
    actionType: "add_bio_cta",
    category:   "bio",
    title:      "Add a clear next step to your bio",
  },
  bio_first_line_weak: {
    actionType: "strengthen_bio_first_line",
    category:   "bio",
    title:      "Strengthen the first line of your bio",
  },
  content_hook_weak: {
    actionType: "improve_hooks",
    category:   "content",
    title:      "Write stronger opening hooks for your content",
  },
  covers_unclear: {
    actionType: "clarify_covers",
    category:   "content",
    title:      "Make your covers communicate the topic faster",
  },
  content_structure_inconsistent: {
    actionType: "build_content_structure",
    category:   "content",
    title:      "Build a recognisable recurring content structure",
  },
  feed_inconsistent: {
    actionType: "improve_feed_consistency",
    category:   "feed",
    title:      "Create a more consistent visual look for your feed",
  },
  feed_topic_unclear: {
    actionType: "clarify_feed_topic",
    category:   "feed",
    title:      "Make your main topic visible at first glance",
  },
  branding_inconsistent: {
    actionType: "strengthen_branding",
    category:   "branding",
    title:      "Build a more recognisable visual brand",
  },
  profile_picture_weak: {
    actionType: "improve_profile_picture",
    category:   "profile",
    title:      "Make your profile picture more instantly recognisable",
  },
  identity_unclear: {
    actionType: "clarify_identity",
    category:   "identity",
    title:      "Align your username and name with your positioning",
  },
  engagement_structure_weak: {
    actionType: "improve_engagement_structure",
    category:   "engagement",
    title:      "Give your audience more reasons to interact",
  },
} as const;

// ─── Finding → GrowthAction conversion ───────────────────────────────────────

/**
 * Converts a Finding into a GrowthAction.
 * Pure function — deterministic, no DB, no LLM.
 *
 * Returns null if the finding has no known action template (defensive).
 */
export function findingToAction(
  finding: Finding,
  creatorProfileId: string,
): GrowthAction | null {
  const template = FINDING_TO_ACTION[finding.templateId];
  if (!template) return null;

  return {
    id:                `${creatorProfileId}:${finding.templateId}`,
    sourceFindingId:   finding.templateId,
    creatorProfileId,
    category:          template.category,
    title:             template.title,
    actionType:        template.actionType,
    expectedImpact:    finding.impact,
    priority:          finding.priority,
    severity:          finding.severity,
    blockedByFoundation: finding.blockedByFoundation,
    status:            "open",
  };
}

/**
 * Converts all findings for a profile into growth actions.
 * Filters out findings with no template mapping (none expected in V1).
 * Output order preserves finding priority order (already sorted by buildFindings).
 */
export function buildGrowthActions(
  findings: ReadonlyArray<Finding>,
  creatorProfileId: string,
): ReadonlyArray<GrowthAction> {
  const actions: GrowthAction[] = [];
  for (const f of findings) {
    const action = findingToAction(f, creatorProfileId);
    if (action) actions.push(action);
  }
  return actions;
}
