/**
 * AI Recommendation Layer — structured input/output types and prompt versions.
 *
 * Design rules enforced at this boundary:
 *   - AI never receives scores, priorities, or impact numbers as mutable targets
 *   - AI only receives observational context (what was found) + platform/niche
 *   - All structured outputs are validated before use
 *   - Prompt versions are constants — changes require explicit bumps
 */

import type { Finding, FindingSeverity } from "@vyro/shared/scoring";
import type { GrowthAction, GrowthActionType, GrowthActionCategory } from "./actions.js";

// ─── Prompt versions ──────────────────────────────────────────────────────────

export const PROMPT_VERSIONS = {
  EXPLAIN_FINDING:          "explain-finding-v1",
  ACTION_SUGGESTION:        "action-suggestion-v1",
  BIO_GENERATION:           "bio-generation-v1",
  HOOK_GENERATION:          "hook-generation-v1",
  CAPTION_GENERATION:       "caption-generation-v1",
  CONTENT_IDEAS_GENERATION: "content-ideas-generation-v1",
} as const;

export type PromptVersionKey = keyof typeof PROMPT_VERSIONS;
export type PromptVersion    = (typeof PROMPT_VERSIONS)[PromptVersionKey];

// ─── Safe context — what the AI is allowed to see ────────────────────────────

/** Platform context — never include tokens, private account data, or analytics */
export interface CreatorContext {
  readonly platform: "tiktok" | "instagram";
  readonly niche?: string;     // e.g. "fitness", "cooking" — optional, user-supplied
  readonly language?: string;  // ISO 639-1, default "en"
}

/**
 * The observable criteria states passed to the AI.
 * Scores and impact numbers are deliberately excluded.
 * AI may not reference or recalculate scores.
 */
export interface ObservationContext {
  readonly criterionId: string;
  readonly state: "fulfilled" | "partial" | "missing" | "unavailable";
}

// ─── Structured inputs ────────────────────────────────────────────────────────

export interface FindingExplanationRequest {
  readonly promptVersion: PromptVersion;
  readonly creator: CreatorContext;
  readonly finding: {
    readonly templateId: string;
    readonly title: string;          // the deterministic finding title
    readonly severity: FindingSeverity;
    readonly observations: ReadonlyArray<ObservationContext>;
  };
}

export interface ActionSuggestionRequest {
  readonly promptVersion: PromptVersion;
  readonly creator: CreatorContext;
  readonly action: {
    readonly actionType: GrowthActionType;
    readonly category: GrowthActionCategory;
    readonly title: string;
  };
  readonly findingContext: {
    readonly templateId: string;
    readonly title: string;
    readonly severity: FindingSeverity;
  };
}

export interface BioGenerationRequest {
  readonly promptVersion: PromptVersion;
  readonly creator: CreatorContext;
  readonly currentBioObservations: ReadonlyArray<ObservationContext>;
}

export interface HookGenerationRequest {
  readonly promptVersion: PromptVersion;
  readonly creator: CreatorContext;
  readonly contentObservations: ReadonlyArray<ObservationContext>;
}

export interface CaptionGenerationRequest {
  readonly promptVersion: PromptVersion;
  readonly creator: CreatorContext;
  readonly contentObservations: ReadonlyArray<ObservationContext>;
  readonly topicHint?: string; // optional user-supplied topic
}

export interface ContentIdeasRequest {
  readonly promptVersion: PromptVersion;
  readonly creator: CreatorContext;
  readonly contentObservations: ReadonlyArray<ObservationContext>;
}

// ─── Structured outputs ───────────────────────────────────────────────────────

export interface FindingExplanation {
  readonly promptVersion: PromptVersion;
  readonly headline:       string;
  readonly explanation:    string;
  readonly whyItMatters:  string;
  readonly recommendation: string;
}

export interface ActionSuggestion {
  readonly promptVersion:       PromptVersion;
  readonly title:               string;
  readonly steps:               ReadonlyArray<string>;
  readonly expectedOutcomeText: string;
}

export interface BioOptions {
  readonly promptVersion: PromptVersion;
  readonly options: readonly [string, string, string]; // exactly 3
}

export interface HookOptions {
  readonly promptVersion: PromptVersion;
  readonly options: readonly [string, string, string, string, string]; // exactly 5
}

export interface CaptionOptions {
  readonly promptVersion: PromptVersion;
  readonly options: readonly [string, string, string]; // exactly 3
}

export interface ContentIdeas {
  readonly promptVersion: PromptVersion;
  readonly ideas: readonly [string, string, string, string, string]; // exactly 5
}

// ─── Generation failure ───────────────────────────────────────────────────────

export interface GenerationFailure {
  readonly failed:  true;
  readonly reason:  "provider_error" | "invalid_output" | "schema_mismatch" | "timeout";
  readonly message: string;
  /** Scores/findings/actions are unaffected by generation failure */
  readonly deterministicCoreIntact: true;
}

export type GenerationResult<T> = T | GenerationFailure;

export function isGenerationFailure(r: unknown): r is GenerationFailure {
  return typeof r === "object" && r !== null && "failed" in r && (r as GenerationFailure).failed === true;
}

// ─── Output validation ────────────────────────────────────────────────────────

export function validateFindingExplanation(raw: unknown): raw is FindingExplanation {
  if (!raw || typeof raw !== "object") return false;
  const r = raw as Record<string, unknown>;
  return (
    typeof r["headline"]       === "string" && r["headline"].length       > 0 &&
    typeof r["explanation"]    === "string" && r["explanation"].length    > 0 &&
    typeof r["whyItMatters"]   === "string" && r["whyItMatters"].length   > 0 &&
    typeof r["recommendation"] === "string" && r["recommendation"].length > 0 &&
    typeof r["promptVersion"]  === "string"
  );
}

export function validateActionSuggestion(raw: unknown): raw is ActionSuggestion {
  if (!raw || typeof raw !== "object") return false;
  const r = raw as Record<string, unknown>;
  return (
    typeof r["title"]               === "string"  && r["title"].length > 0 &&
    Array.isArray(r["steps"])       && (r["steps"] as unknown[]).length > 0 &&
    (r["steps"] as unknown[]).every((s) => typeof s === "string" && (s as string).length > 0) &&
    typeof r["expectedOutcomeText"] === "string"  && r["expectedOutcomeText"].length > 0 &&
    typeof r["promptVersion"]       === "string"
  );
}

export function validateBioOptions(raw: unknown): raw is BioOptions {
  if (!raw || typeof raw !== "object") return false;
  const r = raw as Record<string, unknown>;
  return (
    Array.isArray(r["options"]) &&
    (r["options"] as unknown[]).length === 3 &&
    (r["options"] as unknown[]).every((s) => typeof s === "string" && (s as string).length > 0) &&
    typeof r["promptVersion"] === "string"
  );
}

export function validateHookOptions(raw: unknown): raw is HookOptions {
  if (!raw || typeof raw !== "object") return false;
  const r = raw as Record<string, unknown>;
  return (
    Array.isArray(r["options"]) &&
    (r["options"] as unknown[]).length === 5 &&
    (r["options"] as unknown[]).every((s) => typeof s === "string" && (s as string).length > 0) &&
    typeof r["promptVersion"] === "string"
  );
}

export function validateCaptionOptions(raw: unknown): raw is CaptionOptions {
  if (!raw || typeof raw !== "object") return false;
  const r = raw as Record<string, unknown>;
  return (
    Array.isArray(r["options"]) &&
    (r["options"] as unknown[]).length === 3 &&
    (r["options"] as unknown[]).every((s) => typeof s === "string" && (s as string).length > 0) &&
    typeof r["promptVersion"] === "string"
  );
}

export function validateContentIdeas(raw: unknown): raw is ContentIdeas {
  if (!raw || typeof raw !== "object") return false;
  const r = raw as Record<string, unknown>;
  return (
    Array.isArray(r["ideas"]) &&
    (r["ideas"] as unknown[]).length === 5 &&
    (r["ideas"] as unknown[]).every((s) => typeof s === "string" && (s as string).length > 0) &&
    typeof r["promptVersion"] === "string"
  );
}
