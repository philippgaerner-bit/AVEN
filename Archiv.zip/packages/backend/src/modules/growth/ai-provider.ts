/**
 * RecommendationAIProvider interface and prompt templates.
 *
 * Real providers (OpenAI, Anthropic, Gemini) implement this interface.
 * The generation service depends only on this interface — never on SDKs.
 *
 * Prompt templates are versioned constants. They include explicit safety
 * instructions preventing the AI from:
 *   - inventing or changing scores
 *   - changing priority or severity
 *   - making guaranteed growth claims
 */

import { PROMPT_VERSIONS } from "./ai-types.js";
import type {
  FindingExplanationRequest, FindingExplanation,
  ActionSuggestionRequest,  ActionSuggestion,
  BioGenerationRequest,     BioOptions,
  HookGenerationRequest,    HookOptions,
  CaptionGenerationRequest, CaptionOptions,
  ContentIdeasRequest,      ContentIdeas,
} from "./ai-types.js";

// ─── Provider interface ───────────────────────────────────────────────────────

export interface RecommendationAIProvider {
  readonly providerName: string;

  explainFinding(req: FindingExplanationRequest):   Promise<unknown>;
  generateActionSuggestion(req: ActionSuggestionRequest): Promise<unknown>;
  generateBioOptions(req: BioGenerationRequest):    Promise<unknown>;
  generateHookOptions(req: HookGenerationRequest):  Promise<unknown>;
  generateCaptionOptions(req: CaptionGenerationRequest): Promise<unknown>;
  generateContentIdeas(req: ContentIdeasRequest):   Promise<unknown>;
}

// ─── Prompt templates ─────────────────────────────────────────────────────────

/** Safety preamble injected into every prompt */
const SAFETY_PREAMBLE = `
CRITICAL RULES — MUST FOLLOW:
1. Never invent, modify, or recalculate any VYRO scores, category scores, or Creator Scores.
2. Never change finding priority, severity, or impact values.
3. Never claim guaranteed follower, view, or engagement growth numbers.
4. Only use the context provided. Do not infer unstated audience data.
5. Return ONLY valid JSON matching the exact schema specified. No markdown, no preamble.
`.trim();

export function buildExplainFindingPrompt(req: FindingExplanationRequest): string {
  const obsList = req.finding.observations
    .map((o) => `  - ${o.criterionId}: ${o.state}`)
    .join("\n");

  return `${SAFETY_PREAMBLE}

TASK: Explain a Creator Score finding to a social media creator.
Platform: ${req.creator.platform}
${req.creator.niche ? `Creator niche: ${req.creator.niche}` : ""}

Finding: "${req.finding.title}"
Severity: ${req.finding.severity}
Observed criteria:
${obsList}

Return JSON with this exact schema:
{
  "promptVersion": "${req.promptVersion}",
  "headline": "<short impactful headline, max 10 words>",
  "explanation": "<clear explanation of what was observed, 2-3 sentences>",
  "whyItMatters": "<why this affects creator growth, 1-2 sentences>",
  "recommendation": "<one concrete first step, 1 sentence>"
}`;
}

export function buildActionSuggestionPrompt(req: ActionSuggestionRequest): string {
  return `${SAFETY_PREAMBLE}

TASK: Provide concrete improvement steps for a creator action.
Platform: ${req.creator.platform}
${req.creator.niche ? `Creator niche: ${req.creator.niche}` : ""}

Action: "${req.action.title}"
Category: ${req.action.category}
Related finding: "${req.findingContext.title}"

Return JSON with this exact schema:
{
  "promptVersion": "${req.promptVersion}",
  "title": "<action title, concise>",
  "steps": ["<step 1>", "<step 2>", "<step 3>"],
  "expectedOutcomeText": "<what the creator should expect after completing this, no guaranteed numbers>"
}`;
}

export function buildBioGenerationPrompt(req: BioGenerationRequest): string {
  const obs = req.currentBioObservations
    .map((o) => `  - ${o.criterionId}: ${o.state}`)
    .join("\n");

  return `${SAFETY_PREAMBLE}

TASK: Generate 3 improved bio options for a social media creator.
Platform: ${req.creator.platform}
${req.creator.niche ? `Creator niche: ${req.creator.niche}` : ""}
Current bio criteria:
${obs}

Return JSON with this exact schema:
{
  "promptVersion": "${req.promptVersion}",
  "options": ["<bio option 1>", "<bio option 2>", "<bio option 3>"]
}
Each option must be under 150 characters. No follower count claims.`;
}

export function buildHookGenerationPrompt(req: HookGenerationRequest): string {
  return `${SAFETY_PREAMBLE}

TASK: Generate 5 strong content hook options for a social media creator.
Platform: ${req.creator.platform}
${req.creator.niche ? `Creator niche: ${req.creator.niche}` : ""}

Return JSON with this exact schema:
{
  "promptVersion": "${req.promptVersion}",
  "options": ["<hook 1>", "<hook 2>", "<hook 3>", "<hook 4>", "<hook 5>"]
}
Hooks should grab attention in the first 3 seconds. No guaranteed reach claims.`;
}

export function buildCaptionGenerationPrompt(req: CaptionGenerationRequest): string {
  return `${SAFETY_PREAMBLE}

TASK: Generate 3 caption options for a social media creator.
Platform: ${req.creator.platform}
${req.creator.niche ? `Creator niche: ${req.creator.niche}` : ""}
${req.topicHint ? `Topic: ${req.topicHint}` : ""}

Return JSON with this exact schema:
{
  "promptVersion": "${req.promptVersion}",
  "options": ["<caption 1>", "<caption 2>", "<caption 3>"]
}
Captions should encourage genuine engagement. No fake engagement bait.`;
}

export function buildContentIdeasPrompt(req: ContentIdeasRequest): string {
  return `${SAFETY_PREAMBLE}

TASK: Generate 5 content ideas for a social media creator.
Platform: ${req.creator.platform}
${req.creator.niche ? `Creator niche: ${req.creator.niche}` : ""}

Return JSON with this exact schema:
{
  "promptVersion": "${req.promptVersion}",
  "ideas": ["<idea 1>", "<idea 2>", "<idea 3>", "<idea 4>", "<idea 5>"]
}
Ideas should be concrete and actionable. No guaranteed viral claims.`;
}

// ─── Stub provider (for tests, no network) ───────────────────────────────────

/**
 * Returns deterministic valid responses for all methods.
 * Used in tests and development. Never calls a real API.
 */
export class StubRecommendationProvider implements RecommendationAIProvider {
  readonly providerName = "stub";

  private readonly _shouldFail: boolean;
  private readonly _returnMalformed: boolean;

  constructor(options: { fail?: boolean; malformed?: boolean } = {}) {
    this._shouldFail    = options.fail     ?? false;
    this._returnMalformed = options.malformed ?? false;
  }

  private _check(): void {
    if (this._shouldFail) throw new Error("StubProvider: simulated provider error");
  }

  private _malform<T>(valid: T): unknown {
    return this._returnMalformed ? { broken: true } : valid;
  }

  async explainFinding(req: FindingExplanationRequest): Promise<unknown> {
    this._check();
    return this._malform<FindingExplanation>({
      promptVersion:  req.promptVersion,
      headline:       "Your bio doesn't make your audience clear",
      explanation:    "Visitors can't immediately understand who you help and what they get.",
      whyItMatters:   "A clear bio converts profile visitors into followers.",
      recommendation: "Add who you help and one specific outcome to your first line.",
    });
  }

  async generateActionSuggestion(req: ActionSuggestionRequest): Promise<unknown> {
    this._check();
    return this._malform<ActionSuggestion>({
      promptVersion:       req.promptVersion,
      title:               req.action.title,
      steps:               ["Identify your target audience", "Write one clear outcome statement", "Add a CTA link"],
      expectedOutcomeText: "Your bio will communicate your value proposition more clearly.",
    });
  }

  async generateBioOptions(req: BioGenerationRequest): Promise<unknown> {
    this._check();
    return this._malform<BioOptions>({
      promptVersion: req.promptVersion,
      options: [
        "Helping [niche] creators grow | Free guide in bio 👇",
        "I teach [niche] skills | New video every week",
        "[Niche] tips for beginners | Start here →",
      ] as [string, string, string],
    });
  }

  async generateHookOptions(req: HookGenerationRequest): Promise<unknown> {
    this._check();
    return this._malform<HookOptions>({
      promptVersion: req.promptVersion,
      options: [
        "Stop scrolling if you want to learn this in 60 seconds",
        "I spent 3 years learning this so you don't have to",
        "The one mistake most beginners make (and how to fix it)",
        "Here's what nobody tells you about [topic]",
        "POV: You finally figured out [topic]",
      ] as [string, string, string, string, string],
    });
  }

  async generateCaptionOptions(req: CaptionGenerationRequest): Promise<unknown> {
    this._check();
    return this._malform<CaptionOptions>({
      promptVersion: req.promptVersion,
      options: [
        "Which approach works best for you? Drop a 1️⃣ or 2️⃣ below",
        "Save this for later and try it this week 📌",
        "What would you add? Tell me in the comments 👇",
      ] as [string, string, string],
    });
  }

  async generateContentIdeas(req: ContentIdeasRequest): Promise<unknown> {
    this._check();
    return this._malform<ContentIdeas>({
      promptVersion: req.promptVersion,
      ideas: [
        "A day-in-the-life video showing your workflow",
        "Top 3 mistakes beginners make in your niche",
        "A reaction to a common myth in your niche",
        "Step-by-step tutorial for one core skill",
        "Q&A answering your most asked DM questions",
      ] as [string, string, string, string, string],
    });
  }
}
