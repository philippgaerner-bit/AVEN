/**
 * VYRO Mobile API Client Contract — v1
 *
 * Defines:
 *   - Versioned API contract constant
 *   - Typed request/response models for all mobile-facing routes
 *   - Provider-neutral client interface (no HTTP client dependency)
 *   - Normalised client error type
 *
 * Rules:
 *   - Only client-safe fields (no internal IDs, stack traces, DB details)
 *   - Reuses backend types by reference where possible
 *   - No SwiftUI / StoreKit dependencies here
 */

// ─── Contract version ─────────────────────────────────────────────────────────

export const API_CONTRACT_VERSION = "v1" as const;
export type ApiContractVersion = typeof API_CONTRACT_VERSION;

// ─── Normalised client error ──────────────────────────────────────────────────

/**
 * Every error the client receives has this shape.
 * No stack trace, no internal DB details, no provider secrets.
 */
export interface ClientError {
  readonly code:       string;
  readonly message:    string;
  readonly httpStatus: number;
}

export function isClientError(e: unknown): e is ClientError {
  return (
    typeof e === "object" && e !== null &&
    typeof (e as ClientError).code       === "string" &&
    typeof (e as ClientError).message    === "string" &&
    typeof (e as ClientError).httpStatus === "number"
  );
}

// ─── Auth ─────────────────────────────────────────────────────────────────────

export interface CreateAnonymousSessionResponse {
  readonly token:     string;
  readonly sessionId: string;
  readonly expiresAt: string; // ISO 8601
}

export interface RotateSessionResponse {
  readonly token:     string;
  readonly sessionId: string;
  readonly expiresAt: string;
}

// logout → 204 no body

// ─── Users ────────────────────────────────────────────────────────────────────

export interface CreateUserResponse {
  readonly userId:    string;
  readonly token:     string;
  readonly sessionId: string;
  readonly expiresAt: string;
}

export interface GetMeResponse {
  readonly id:        string;
  readonly createdAt: string;
}

export interface ClaimAnonymousRequest {
  readonly anonymousToken: string;
}

export interface ClaimAnonymousResponse {
  readonly profilesMigrated: number;
  readonly alreadyMerged:    boolean;
}

// ─── Social accounts ──────────────────────────────────────────────────────────

export type SocialPlatform = "tiktok" | "instagram";

export interface SocialAccountSummary {
  readonly id:                string;
  readonly creatorProfileId:  string;
  readonly platform:          SocialPlatform;
  readonly providerAccountId: string;
  readonly displayName:       string | null;
  readonly username:          string | null;
  readonly connectedAt:       string;
}

export interface LinkSocialAccountRequest {
  readonly profileId:         string;
  readonly platform:          SocialPlatform;
  readonly providerAccountId: string;
  readonly displayName?:      string;
  readonly username?:         string;
}

// ─── Scans ────────────────────────────────────────────────────────────────────

export type ScanStatus = "accepted" | "processing" | "completed" | "failed";

export interface CreateScanResponse {
  readonly scanId:    string;
  readonly status:    ScanStatus;
  readonly profileId: string;
}

export interface FindingSummary {
  readonly templateId:          string;
  readonly severity:            "foundation" | "lever" | "polish";
  readonly impact:              number;
  readonly priority:            number;
  readonly blockedByFoundation: boolean;
  readonly status:              "open" | "completed" | "dismissed";
}

export interface GetScanResponse {
  readonly id:           string;
  readonly status:       ScanStatus;
  readonly platform:     SocialPlatform;
  readonly createdAt:    string;
  // Present only for completed scans:
  readonly totalScore?:    number | null;
  readonly displayable?:   boolean | null;
  readonly coverageRatio?: number | null;
  readonly findings?:      ReadonlyArray<FindingSummary>;
  // Present only for failed scans:
  readonly failureCode?:   string;
}

// ─── Billing ──────────────────────────────────────────────────────────────────

export type PlanId = "FREE" | "PRO" | "PRO_PLUS";

export interface FeatureAccess {
  readonly allowed:   boolean;
  readonly remaining: number | null;
}

export interface GetBillingStatusResponse {
  readonly plan:          PlanId;
  readonly active:        boolean;
  readonly features:      Record<string, FeatureAccess>;
  readonly creditBalance: number;
}

// ─── Provider-neutral client interface ────────────────────────────────────────

/**
 * Typed client interface for all mobile-facing VYRO API operations.
 * Implementations provide the actual HTTP transport.
 * Test implementations can be in-memory / stub.
 *
 * All methods return typed results; errors are thrown as ClientError.
 */
export interface VyroApiClient {
  // Auth
  createAnonymousSession():     Promise<CreateAnonymousSessionResponse>;
  rotateSession(token: string): Promise<RotateSessionResponse>;
  logout(token: string):        Promise<void>;

  // Users
  createUser():                             Promise<CreateUserResponse>;
  getCurrentUser(token: string):            Promise<GetMeResponse>;
  claimAnonymous(
    userToken: string,
    req: ClaimAnonymousRequest,
  ): Promise<ClaimAnonymousResponse>;

  // Social accounts
  listSocialAccounts(token: string, profileId: string): Promise<ReadonlyArray<SocialAccountSummary>>;
  linkSocialAccount(token: string, req: LinkSocialAccountRequest): Promise<SocialAccountSummary>;
  disconnectSocialAccount(token: string, accountId: string): Promise<void>;

  // Scans
  createScan(token: string, profileId: string, imageBytes: Uint8Array): Promise<CreateScanResponse>;
  getScan(token: string, scanId: string): Promise<GetScanResponse>;

  // Billing
  getBillingStatus(token: string): Promise<GetBillingStatusResponse>;
}

// ─── Stub client (for tests, no network) ─────────────────────────────────────

export type StubResponseMap = {
  createAnonymousSession?: CreateAnonymousSessionResponse;
  rotateSession?:          RotateSessionResponse;
  createUser?:             CreateUserResponse;
  getCurrentUser?:         GetMeResponse;
  claimAnonymous?:         ClaimAnonymousResponse;
  listSocialAccounts?:     ReadonlyArray<SocialAccountSummary>;
  linkSocialAccount?:      SocialAccountSummary;
  createScan?:             CreateScanResponse;
  getScan?:                GetScanResponse;
  getBillingStatus?:       GetBillingStatusResponse;
  error?:                  ClientError;
};

export class StubVyroApiClient implements VyroApiClient {
  constructor(private readonly responses: StubResponseMap = {}) {}

  private get<T>(key: keyof StubResponseMap, fallback: T): T {
    if (this.responses.error) throw this.responses.error;
    return (this.responses[key] as T | undefined) ?? fallback;
  }

  async createAnonymousSession(): Promise<CreateAnonymousSessionResponse> {
    return this.get("createAnonymousSession", {
      token: "stub-token-43chars-base64url-padded1",
      sessionId: "00000000-0000-0000-0000-000000000001",
      expiresAt: new Date(Date.now() + 90 * 86400000).toISOString(),
    });
  }

  async rotateSession(_token: string): Promise<RotateSessionResponse> {
    return this.get("rotateSession", {
      token: "rotated-token-43chars-base64url-pad1",
      sessionId: "00000000-0000-0000-0000-000000000002",
      expiresAt: new Date(Date.now() + 30 * 86400000).toISOString(),
    });
  }

  async logout(_token: string): Promise<void> {
    if (this.responses.error) throw this.responses.error;
  }

  async createUser(): Promise<CreateUserResponse> {
    return this.get("createUser", {
      userId: "00000000-0000-0000-0000-000000000003",
      token:  "user-token-43chars-base64url-padded1",
      sessionId: "00000000-0000-0000-0000-000000000004",
      expiresAt: new Date(Date.now() + 30 * 86400000).toISOString(),
    });
  }

  async getCurrentUser(_token: string): Promise<GetMeResponse> {
    return this.get("getCurrentUser", {
      id:        "00000000-0000-0000-0000-000000000003",
      createdAt: new Date().toISOString(),
    });
  }

  async claimAnonymous(_token: string, _req: ClaimAnonymousRequest): Promise<ClaimAnonymousResponse> {
    return this.get("claimAnonymous", { profilesMigrated: 1, alreadyMerged: false });
  }

  async listSocialAccounts(_token: string, _profileId: string): Promise<ReadonlyArray<SocialAccountSummary>> {
    return this.get("listSocialAccounts", []);
  }

  async linkSocialAccount(_token: string, req: LinkSocialAccountRequest): Promise<SocialAccountSummary> {
    return this.get("linkSocialAccount", {
      id: "00000000-0000-0000-0000-000000000010",
      creatorProfileId: req.profileId,
      platform: req.platform,
      providerAccountId: req.providerAccountId,
      displayName: req.displayName ?? null,
      username:    req.username    ?? null,
      connectedAt: new Date().toISOString(),
    });
  }

  async disconnectSocialAccount(_token: string, _id: string): Promise<void> {
    if (this.responses.error) throw this.responses.error;
  }

  async createScan(_token: string, profileId: string, _bytes: Uint8Array): Promise<CreateScanResponse> {
    return this.get("createScan", {
      scanId:    "00000000-0000-0000-0000-000000000020",
      status:    "accepted",
      profileId,
    });
  }

  async getScan(_token: string, scanId: string): Promise<GetScanResponse> {
    return this.get("getScan", {
      id: scanId, status: "completed", platform: "tiktok",
      createdAt: new Date().toISOString(),
      totalScore: 72, displayable: true, coverageRatio: 0.88,
      findings: [],
    });
  }

  async getBillingStatus(_token: string): Promise<GetBillingStatusResponse> {
    return this.get("getBillingStatus", {
      plan: "FREE", active: false,
      features: { scans: { allowed: true, remaining: 3 } },
      creditBalance: 0,
    });
  }
}
