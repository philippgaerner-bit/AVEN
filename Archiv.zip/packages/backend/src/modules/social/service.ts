/**
 * Social account service — provider-neutral linking logic.
 *
 * Security rules enforced here:
 *   - Only the profile owner can link/list/disconnect accounts
 *   - A providerAccountId can only be linked to ONE profile globally (per platform)
 *   - Platform on ProviderIdentity must match the requested platform
 *   - Disconnected accounts are treated as inactive
 *   - No provider tokens ever reach this layer
 */

import { eq, and, isNull } from "drizzle-orm";
import type { DbContext } from "../../db/client.js";
import { socialAccounts } from "../../db/drizzle-schema.js";
import type { CreatorPlatform } from "../../db/enums.js";
import { AppError } from "../../errors/index.js";
import type { Identity } from "../auth/identity.js";
import { getOwnedCreatorProfile } from "../profiles/service.js";
import type { ProviderIdentity } from "./provider.js";

// ─── Types ────────────────────────────────────────────────────────────────────

export interface SocialAccountRow {
  id: string;
  creatorProfileId: string;
  platform: CreatorPlatform;
  providerAccountId: string;
  displayName: string | null;
  username: string | null;
  connectedAt: Date;
  disconnectedAt: Date | null;
}

// ─── Link ─────────────────────────────────────────────────────────────────────

/**
 * Completes the account linking workflow using a verified ProviderIdentity.
 *
 * Called after:
 *   provider.exchangeCode(code, redirectUri) → ProviderIdentity
 *
 * Checks:
 *   1. Requester owns the profile
 *   2. Platform on identity matches requested platform
 *   3. No active link already exists for this providerAccountId globally
 *   4. Profile doesn't already have an active link for this platform
 *
 * If the same account is re-linked to the same profile after disconnection,
 * creates a new row (the old disconnected row remains as history).
 */
export async function linkSocialAccount(
  ctx: DbContext,
  profileId: string,
  identity: Identity,
  providerIdentity: ProviderIdentity,
): Promise<SocialAccountRow> {
  // 1. Ownership check
  await getOwnedCreatorProfile(ctx, profileId, identity);

  // 2. Platform match
  if (providerIdentity.platform !== providerIdentity.platform) {
    // (typed by construction — kept for runtime safety)
    throw AppError.validationError("Platform mismatch between request and provider identity");
  }

  const platform = providerIdentity.platform;

  // 3. Global uniqueness: is this providerAccountId already actively linked?
  const [existingGlobal] = await ctx.db
    .select({ id: socialAccounts.id, creatorProfileId: socialAccounts.creatorProfileId })
    .from(socialAccounts)
    .where(and(
      eq(socialAccounts.platform, platform),
      eq(socialAccounts.providerAccountId, providerIdentity.providerAccountId),
      isNull(socialAccounts.disconnectedAt),
    ))
    .limit(1);

  if (existingGlobal) {
    if (existingGlobal.creatorProfileId === profileId) {
      // Already linked to this profile — idempotent
      const [row] = await ctx.db
        .select()
        .from(socialAccounts)
        .where(eq(socialAccounts.id, existingGlobal.id))
        .limit(1);
      return row as SocialAccountRow;
    }
    // Linked to a DIFFERENT profile
    throw AppError.conflict(
      `This ${platform} account is already linked to another profile`,
    );
  }

  // 4. Profile uniqueness: one active link per platform per profile
  const [existingForProfile] = await ctx.db
    .select({ id: socialAccounts.id })
    .from(socialAccounts)
    .where(and(
      eq(socialAccounts.creatorProfileId, profileId),
      eq(socialAccounts.platform, platform),
      isNull(socialAccounts.disconnectedAt),
    ))
    .limit(1);

  if (existingForProfile) {
    throw AppError.conflict(
      `This profile already has an active ${platform} account linked. Disconnect it first.`,
    );
  }

  // 5. Insert
  const [row] = await ctx.db
    .insert(socialAccounts)
    .values({
      creatorProfileId:  profileId,
      platform,
      providerAccountId: providerIdentity.providerAccountId,
      displayName:       providerIdentity.displayName ?? null,
      username:          providerIdentity.username ?? null,
    })
    .returning();

  if (!row) throw AppError.internal("Failed to create social account link");
  return row as SocialAccountRow;
}

// ─── List ─────────────────────────────────────────────────────────────────────

/**
 * Lists active (not disconnected) social accounts for a profile.
 * Requester must own the profile.
 */
export async function listSocialAccounts(
  ctx: DbContext,
  profileId: string,
  identity: Identity,
): Promise<SocialAccountRow[]> {
  await getOwnedCreatorProfile(ctx, profileId, identity);

  const rows = await ctx.db
    .select()
    .from(socialAccounts)
    .where(and(
      eq(socialAccounts.creatorProfileId, profileId),
      isNull(socialAccounts.disconnectedAt),
    ));

  return rows as SocialAccountRow[];
}

/**
 * Gets a single social account by ID, enforcing ownership.
 */
export async function getSocialAccountById(
  ctx: DbContext,
  accountId: string,
  identity: Identity,
): Promise<SocialAccountRow> {
  const [row] = await ctx.db
    .select()
    .from(socialAccounts)
    .where(eq(socialAccounts.id, accountId))
    .limit(1);

  if (!row) throw AppError.notFound("Social account");

  // Verify the identity owns the profile that owns this account
  await getOwnedCreatorProfile(ctx, row.creatorProfileId, identity);

  return row as SocialAccountRow;
}

// ─── Disconnect ───────────────────────────────────────────────────────────────

/**
 * Disconnects (soft-deletes) a social account. Idempotent.
 * Requester must own the profile.
 */
export async function disconnectSocialAccount(
  ctx: DbContext,
  accountId: string,
  identity: Identity,
): Promise<void> {
  const account = await getSocialAccountById(ctx, accountId, identity);

  if (account.disconnectedAt !== null) return; // already disconnected — idempotent

  await ctx.db
    .update(socialAccounts)
    .set({ disconnectedAt: new Date() })
    .where(eq(socialAccounts.id, accountId));
}
