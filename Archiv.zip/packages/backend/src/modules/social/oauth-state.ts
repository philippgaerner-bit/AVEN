/**
 * OAuth state store — CSRF state token management.
 *
 * Generates and validates state tokens for OAuth flows.
 * In production: use Redis with TTL.
 * For development: in-process Map with expiry.
 *
 * Each state token:
 *   - is unique per authorization request
 *   - expires after 10 minutes
 *   - is consumed (deleted) on first use
 *   - carries the userId who initiated the flow
 */

import { randomBytes } from "node:crypto";

const STATE_TTL_MS = 10 * 60 * 1000; // 10 minutes

interface OAuthStateEntry {
  readonly userId:    string;
  readonly profileId: string;
  readonly platform:  string;
  readonly expiresAt: number;
}

// In-process store — replace with Redis in production
const store = new Map<string, OAuthStateEntry>();

export function generateOAuthState(
  userId:    string,
  profileId: string,
  platform:  string,
): string {
  const state = randomBytes(24).toString("base64url");
  store.set(state, {
    userId,
    profileId,
    platform,
    expiresAt: Date.now() + STATE_TTL_MS,
  });
  return state;
}

export function consumeOAuthState(state: string): OAuthStateEntry | null {
  const entry = store.get(state);
  store.delete(state); // always consume regardless of validity
  if (!entry) return null;
  if (Date.now() > entry.expiresAt) return null;
  return entry;
}

// Clean up expired entries periodically
setInterval(() => {
  const now = Date.now();
  for (const [key, entry] of store.entries()) {
    if (now > entry.expiresAt) store.delete(key);
  }
}, 60_000);
