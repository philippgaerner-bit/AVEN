/**
 * TikTok OAuth routes
 *
 * GET  /auth/tiktok/initiate  — generates auth URL, returns it to iOS client
 * GET  /auth/tiktok/callback  — receives code from TikTok, links account
 *
 * Security:
 *   - state token validated before exchanging code
 *   - client secret NEVER leaves the server
 *   - access tokens consumed here, never stored or returned
 *   - deep-link redirect to iOS app after completion
 */

import type { FastifyInstance } from "fastify";
import type { DbContext } from "../../db/client.js";
import type { AppConfig } from "../../config/index.js";
import { AppError } from "../../errors/index.js";
import { resolveIdentityFromHeader } from "../users/routes.js";
import { linkSocialAccount } from "../social/service.js";
import { TikTokProvider }    from "../social/tiktok-provider.js";
import { generateOAuthState, consumeOAuthState } from "../social/oauth-state.js";

// iOS deep-link scheme registered in AVEN app
const IOS_DEEP_LINK_SCHEME = "avengrowth";

export async function registerTikTokOAuthRoutes(
  app: FastifyInstance,
  ctx: DbContext,
  config: AppConfig,
): Promise<void> {

  // Determine if TikTok is configured
  const isConfigured =
    config.tiktokClientKey !== null &&
    config.tiktokClientSecret !== null;

  // Build provider (or null if not configured)
  const tiktokProvider = isConfigured
    ? new TikTokProvider({
        clientKey:    config.tiktokClientKey!,
        clientSecret: config.tiktokClientSecret!,
        redirectUri:  config.tiktokRedirectUri,
      })
    : null;

  /**
   * GET /auth/tiktok/initiate?profileId=<uuid>
   *
   * Returns:
   *   { authUrl, state, configured }
   *
   * iOS opens authUrl in ASWebAuthenticationSession.
   * configured=false means credentials are missing — iOS shows setup notice.
   */
  app.get(
    "/auth/tiktok/initiate",
    {
      schema: {
        operationId: "tiktokInitiate",
        summary:     "Start TikTok OAuth flow",
        querystring: { type: "object", properties: { profileId: { type: "string" } }, required: ["profileId"] },
        response: {
          200: {
            type: "object",
            properties: {
              configured: { type: "boolean" },
              authUrl:    { type: "string" },
              state:      { type: "string" },
              message:    { type: "string" },
            },
          },
        },
      },
    },
    async (req, reply) => {
      const identity = await resolveIdentityFromHeader(ctx, req.headers["authorization"]);
      if (!identity) throw AppError.unauthorized();

      const userId    = identity.type === "user" ? identity.userId : null;
      if (!userId) throw AppError.unauthorized("Anonymous sessions cannot link social accounts");

      const { profileId } = req.query as { profileId: string };

      if (!isConfigured || !tiktokProvider) {
        return reply.status(200).send({
          configured: false,
          authUrl:    "",
          state:      "",
          message:    "TikTok OAuth is not configured. Set TIKTOK_CLIENT_KEY and TIKTOK_CLIENT_SECRET environment variables.",
        });
      }

      const state  = generateOAuthState(userId, profileId, "tiktok");
      const authUrl = tiktokProvider.getAuthorizationUrl(state, config.tiktokRedirectUri);

      return reply.status(200).send({ configured: true, authUrl, state });
    },
  );

  /**
   * GET /auth/tiktok/callback?code=<code>&state=<state>
   *
   * Called by TikTok after user authorizes.
   * Exchanges code → ProviderIdentity → links account.
   * Redirects to iOS deep link: avengrowth://auth/tiktok/complete?success=true
   */
  app.get(
    "/auth/tiktok/callback",
    {
      schema: {
        operationId: "tiktokCallback",
        summary:     "TikTok OAuth callback",
        querystring: {
          type: "object",
          properties: {
            code:  { type: "string" },
            state: { type: "string" },
            error: { type: "string" },
            error_description: { type: "string" },
          },
        },
      },
    },
    async (req, reply) => {
      const { code, state, error } = req.query as {
        code?: string; state?: string; error?: string; error_description?: string;
      };

      // User cancelled
      if (error) {
        const deepLink = `${IOS_DEEP_LINK_SCHEME}://auth/tiktok/complete?success=false&error=${encodeURIComponent(error)}`;
        return reply.redirect(deepLink);
      }

      if (!code || !state) {
        const deepLink = `${IOS_DEEP_LINK_SCHEME}://auth/tiktok/complete?success=false&error=missing_params`;
        return reply.redirect(deepLink);
      }

      // Validate and consume state
      const stateEntry = consumeOAuthState(state);
      if (!stateEntry) {
        const deepLink = `${IOS_DEEP_LINK_SCHEME}://auth/tiktok/complete?success=false&error=invalid_state`;
        return reply.redirect(deepLink);
      }

      if (!tiktokProvider) {
        const deepLink = `${IOS_DEEP_LINK_SCHEME}://auth/tiktok/complete?success=false&error=not_configured`;
        return reply.redirect(deepLink);
      }

      try {
        // Exchange code for verified identity (access token consumed internally)
        const providerIdentity = await tiktokProvider.exchangeCode(code, state);

        // Build a server-side identity from the state entry
        const serverIdentity = {
          type:   "user" as const,
          userId: stateEntry.userId,
          sessionId: `oauth-${stateEntry.userId}`,
        };

        // Link the account
        const linked = await linkSocialAccount(
          ctx,
          stateEntry.profileId,
          serverIdentity,
          providerIdentity,
        );

        const deepLink = `${IOS_DEEP_LINK_SCHEME}://auth/tiktok/complete?success=true&accountId=${encodeURIComponent(linked.id)}&username=${encodeURIComponent(linked.username ?? linked.displayName ?? "")}`;
        return reply.redirect(deepLink);
      } catch (e) {
        const msg = e instanceof Error ? e.message.slice(0, 100) : "unknown_error";
        const deepLink = `${IOS_DEEP_LINK_SCHEME}://auth/tiktok/complete?success=false&error=${encodeURIComponent(msg)}`;
        return reply.redirect(deepLink);
      }
    },
  );

  /**
   * GET /auth/tiktok/status
   * Returns whether TikTok OAuth is configured.
   * iOS uses this at startup to show proper UI state.
   */
  app.get(
    "/auth/tiktok/status",
    {
      schema: {
        operationId: "tiktokStatus",
        response: {
          200: {
            type: "object",
            properties: {
              configured:  { type: "boolean" },
              redirectUri: { type: "string" },
            },
          },
        },
      },
    },
    async (_req, reply) => {
      return reply.status(200).send({
        configured:  isConfigured,
        redirectUri: config.tiktokRedirectUri,
      });
    },
  );
}
