/**
 * Social account HTTP routes.
 *
 * GET    /social/accounts              – list active linked accounts for a profile
 * DELETE /social/accounts/:id          – disconnect a linked account
 * POST   /social/accounts/link         – link an account via stub/test provider identity
 *
 * All routes require Authorization: Bearer <token> and a profileId query param.
 * The POST /link route accepts a pre-verified ProviderIdentity (Phase 4.3 test surface).
 * Real OAuth callbacks (Phase 4.4+) will call the same service layer.
 */

import type { FastifyInstance } from "fastify";
import type { DbContext } from "../../db/client.js";
import { AppError } from "../../errors/index.js";
import { resolveIdentityFromHeader } from "../users/routes.js";
import {
  linkSocialAccount,
  listSocialAccounts,
  disconnectSocialAccount,
} from "./service.js";
import type { ProviderIdentity } from "./provider.js";
import { CREATOR_PLATFORMS } from "../../db/enums.js";

const errorSchema = {
  type: "object",
  properties: {
    error: {
      type: "object",
      properties: { code: { type: "string" }, message: { type: "string" } },
    },
  },
} as const;

const socialAccountSchema = {
  type: "object",
  required: ["id", "platform", "username", "connectedAt"],
  properties: {
    id:                { type: "string", format: "uuid" },
    creatorProfileId:  { type: "string", format: "uuid" },
    platform:          { type: "string", enum: ["tiktok", "instagram"] as const },
    providerAccountId: { type: "string" },
    displayName:       { type: ["string", "null"] },
    username:          { type: ["string", "null"] },
    connectedAt:       { type: "string", format: "date-time" },
  },
} as const;

export async function registerSocialRoutes(
  app: FastifyInstance,
  ctx: DbContext,
): Promise<void> {
  /**
   * GET /social/accounts?profileId=<uuid>
   * Lists active social accounts for a profile owned by the caller.
   */
  app.get(
    "/social/accounts",
    {
      schema: {
        operationId: "listSocialAccounts",
        summary: "List linked social accounts",
        querystring: {
          type: "object",
          required: ["profileId"],
          properties: { profileId: { type: "string", format: "uuid" } },
        },
        response: {
          200: { type: "array", items: socialAccountSchema },
          401: errorSchema, 403: errorSchema,
        },
      },
    },
    async (req, reply) => {
      const identity = await requireIdentity(ctx, req.headers["authorization"]);
      const { profileId } = req.query as { profileId: string };
      const accounts = await listSocialAccounts(ctx, profileId, identity);
      return reply.status(200).send(
        accounts.map((a) => ({
          id:                a.id,
          creatorProfileId:  a.creatorProfileId,
          platform:          a.platform,
          providerAccountId: a.providerAccountId,
          displayName:       a.displayName,
          username:          a.username,
          connectedAt:       a.connectedAt.toISOString(),
        })),
      );
    },
  );

  /**
   * DELETE /social/accounts/:id
   * Disconnects a linked social account owned by the caller.
   */
  app.delete(
    "/social/accounts/:id",
    {
      schema: {
        operationId: "disconnectSocialAccount",
        summary: "Disconnect a linked social account",
        params: {
          type: "object",
          required: ["id"],
          properties: { id: { type: "string", format: "uuid" } },
        },
        response: { 204: { type: "null" }, 401: errorSchema, 403: errorSchema, 404: errorSchema },
      },
    },
    async (req, reply) => {
      const identity = await requireIdentity(ctx, req.headers["authorization"]);
      const { id } = req.params as { id: string };
      await disconnectSocialAccount(ctx, id, identity);
      return reply.status(204).send();
    },
  );

  /**
   * POST /social/accounts/link
   * Links a social account using a pre-verified ProviderIdentity.
   *
   * Phase 4.3: accepts a ProviderIdentity directly (no real OAuth).
   * Phase 4.4: will be replaced / supplemented by the OAuth callback route.
   *
   * Body:
   *   { profileId, platform, providerAccountId, displayName?, username? }
   */
  app.post(
    "/social/accounts/link",
    {
      schema: {
        operationId: "linkSocialAccount",
        summary: "Link a social account (provider-verified identity)",
        body: {
          type: "object",
          required: ["profileId", "platform", "providerAccountId"],
          properties: {
            profileId:         { type: "string", format: "uuid" },
            platform:          { type: "string", enum: ["tiktok", "instagram"] as const },
            providerAccountId: { type: "string", minLength: 1 },
            displayName:       { type: "string" },
            username:          { type: "string" },
          },
        },
        response: {
          201: socialAccountSchema,
          400: errorSchema, 401: errorSchema, 403: errorSchema, 409: errorSchema,
        },
      },
    },
    async (req, reply) => {
      const identity = await requireIdentity(ctx, req.headers["authorization"]);
      const body = req.body as {
        profileId: string;
        platform: "tiktok" | "instagram";
        providerAccountId: string;
        displayName?: string;
        username?: string;
      };

      if (!(CREATOR_PLATFORMS as readonly string[]).includes(body.platform)) {
        throw AppError.validationError(`Invalid platform: ${body.platform}`);
      }

      const providerIdentity: ProviderIdentity = {
        platform:          body.platform,
        providerAccountId: body.providerAccountId,
        displayName:       body.displayName,
        username:          body.username,
      };

      const account = await linkSocialAccount(ctx, body.profileId, identity, providerIdentity);

      return reply.status(201).send({
        id:                account.id,
        creatorProfileId:  account.creatorProfileId,
        platform:          account.platform,
        providerAccountId: account.providerAccountId,
        displayName:       account.displayName,
        username:          account.username,
        connectedAt:       account.connectedAt.toISOString(),
      });
    },
  );
}

// ─── Helper ───────────────────────────────────────────────────────────────────

async function requireIdentity(ctx: DbContext, header: string | undefined) {
  const identity = await resolveIdentityFromHeader(ctx, header);
  if (!identity) throw AppError.unauthorized("Authentication required");
  return identity;
}
