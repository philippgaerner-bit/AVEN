/**
 * TikTok OAuth provider — Login Kit v2
 *
 * Security:
 *   - Client secret NEVER leaves the backend
 *   - Access tokens are consumed here and NEVER returned to callers
 *   - Only ProviderIdentity (stable IDs + display info) crosses the boundary
 *   - State token is validated on every callback
 *   - PKCE code_verifier stored server-side (not in iOS app)
 */

import { createHash, randomBytes } from "node:crypto";
import type { SocialProvider, ProviderIdentity } from "./provider.js";

// ─── TikTok API endpoints ────────────────────────────────────────────────────

const TIKTOK_AUTH_URL      = "https://www.tiktok.com/v2/auth/authorize/";
const TIKTOK_TOKEN_URL     = "https://open.tiktokapis.com/v2/oauth/token/";
const TIKTOK_USERINFO_URL  = "https://open.tiktokapis.com/v2/user/info/";

// Scopes required for basic profile information
const TIKTOK_SCOPES = ["user.info.basic", "user.info.profile"].join(",");

// ─── PKCE helpers ────────────────────────────────────────────────────────────

function generateCodeVerifier(): string {
  return randomBytes(32).toString("base64url");
}

function deriveCodeChallenge(verifier: string): string {
  return createHash("sha256").update(verifier).digest("base64url");
}

// ─── TikTok provider ─────────────────────────────────────────────────────────

export interface TikTokProviderConfig {
  readonly clientKey:    string;   // from TikTok Developer Portal
  readonly clientSecret: string;   // NEVER sent to client
  readonly redirectUri:  string;   // must match Portal registration
}

export class TikTokProvider implements SocialProvider {
  readonly platform = "tiktok" as const;

  // In-process PKCE verifier store (per state token).
  // Production: use Redis with TTL instead.
  private readonly pendingVerifiers = new Map<string, string>();

  constructor(private readonly config: TikTokProviderConfig) {}

  getAuthorizationUrl(state: string, _redirectUri: string): string {
    const verifier  = generateCodeVerifier();
    const challenge = deriveCodeChallenge(verifier);

    // Store verifier keyed by state for later exchange
    this.pendingVerifiers.set(state, verifier);
    // Clean up old entries (simple TTL approximation)
    if (this.pendingVerifiers.size > 1000) {
      const firstKey = this.pendingVerifiers.keys().next().value;
      if (firstKey) this.pendingVerifiers.delete(firstKey);
    }

    const params = new URLSearchParams({
      client_key:            this.config.clientKey,
      scope:                 TIKTOK_SCOPES,
      response_type:         "code",
      redirect_uri:          this.config.redirectUri,
      state,
      code_challenge:        challenge,
      code_challenge_method: "S256",
    });

    return `${TIKTOK_AUTH_URL}?${params.toString()}`;
  }

  async exchangeCode(code: string, state: string): Promise<ProviderIdentity> {
    const verifier = this.pendingVerifiers.get(state);
    this.pendingVerifiers.delete(state); // consume once

    const body = new URLSearchParams({
      client_key:    this.config.clientKey,
      client_secret: this.config.clientSecret,
      code,
      grant_type:    "authorization_code",
      redirect_uri:  this.config.redirectUri,
      ...(verifier ? { code_verifier: verifier } : {}),
    });

    const tokenRes = await fetch(TIKTOK_TOKEN_URL, {
      method:  "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body:    body.toString(),
    });

    if (!tokenRes.ok) {
      const text = await tokenRes.text();
      throw new Error(`TikTok token exchange failed: ${tokenRes.status} — ${text.slice(0, 200)}`);
    }

    const tokenData = await tokenRes.json() as {
      data?: { access_token?: string; open_id?: string };
      error?: { code?: string; message?: string };
    };

    if (tokenData.error?.code || !tokenData.data?.access_token) {
      throw new Error(`TikTok token error: ${tokenData.error?.message ?? "unknown"}`);
    }

    const accessToken = tokenData.data.access_token;
    const openId      = tokenData.data.open_id ?? "";

    // Fetch basic user info
    const identity = await this.fetchUserInfo(accessToken, openId);

    // DO NOT store or return accessToken — consumed here
    return identity;
  }

  async getAccountIdentity(providerAccountId: string): Promise<ProviderIdentity> {
    // Without a stored refresh token we cannot re-fetch — return minimal identity
    // Production: store encrypted refresh token, re-fetch here
    return {
      platform:          "tiktok",
      providerAccountId,
      displayName:       undefined,
      username:          undefined,
    };
  }

  private async fetchUserInfo(accessToken: string, openId: string): Promise<ProviderIdentity> {
    const params = new URLSearchParams({
      fields: "open_id,display_name,avatar_url",
    });

    const infoRes = await fetch(`${TIKTOK_USERINFO_URL}?${params}`, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
    });

    if (!infoRes.ok) {
      // Fall back to open_id only if user info fails
      return { platform: "tiktok", providerAccountId: openId };
    }

    const infoData = await infoRes.json() as {
      data?: { user?: { open_id?: string; display_name?: string; avatar_url?: string } };
    };

    const user = infoData.data?.user;

    return {
      platform:          "tiktok",
      providerAccountId: user?.open_id ?? openId,
      displayName:       user?.display_name,
      username:          user?.display_name, // TikTok v2 doesn't expose @handle in basic scope
    };
  }
}
