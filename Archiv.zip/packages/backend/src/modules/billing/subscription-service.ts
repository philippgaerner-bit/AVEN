/**
 * Subscription service — processes subscription lifecycle events.
 *
 * Security:
 *  - Only the backend/provider event path can upgrade entitlements
 *  - Client cannot self-grant entitlements
 *  - Idempotency: repeated events with the same providerEventId are no-ops
 *  - Revoked/expired subscriptions remove access
 */

import { eq, and } from "drizzle-orm";
import type { DbContext } from "../../db/client.js";
import { subscriptions, idempotencyKeys } from "../../db/drizzle-schema.js";
import { AppError } from "../../errors/index.js";
import type { NormalisedSubscriptionEvent } from "./subscription-provider.js";
import { grantPlanEntitlements, revokePlanEntitlements } from "./entitlements.js";
import type { SubscriptionStatus } from "../../db/enums.js";

// ─── Status mapping ───────────────────────────────────────────────────────────

function eventTypeToStatus(eventType: NormalisedSubscriptionEvent["eventType"]): SubscriptionStatus {
  switch (eventType) {
    case "activated":    return "active";
    case "renewed":      return "active";
    case "paused":       return "past_due";
    case "billing_issue":return "past_due";
    case "expired":      return "expired";
    case "canceled":     return "canceled";
    case "revoked":      return "canceled";
  }
}

function isAccessGrantingEvent(eventType: NormalisedSubscriptionEvent["eventType"]): boolean {
  return eventType === "activated" || eventType === "renewed";
}

function isAccessRevokingEvent(eventType: NormalisedSubscriptionEvent["eventType"]): boolean {
  return eventType === "expired" || eventType === "canceled" || eventType === "revoked";
}

// ─── Process event ────────────────────────────────────────────────────────────

export interface ProcessEventResult {
  readonly processed:  boolean;
  readonly idempotent: boolean;
  readonly action:     "granted" | "revoked" | "updated" | "ignored" | "unknown_product";
  readonly plan:       string | null;
}

/**
 * Processes a normalised subscription event.
 *
 * Idempotency: uses idempotency_keys with providerEventId as the key.
 * Repeated delivery of the same event is a safe no-op.
 *
 * @param ctx     DB context
 * @param userId  Internal user who owns the subscription
 * @param event   Normalised event from the provider adapter
 */
export async function processSubscriptionEvent(
  ctx: DbContext,
  userId: string,
  event: NormalisedSubscriptionEvent,
): Promise<ProcessEventResult> {
  const ownerKey = `sub:${userId}`;

  // ── Idempotency check ────────────────────────────────────────────────────
  const [existing] = await ctx.db
    .select({ responseBodyJson: idempotencyKeys.responseBodyJson })
    .from(idempotencyKeys)
    .where(and(
      eq(idempotencyKeys.ownerKey, ownerKey),
      eq(idempotencyKeys.idempotencyKey, event.providerEventId),
    ))
    .limit(1);

  if (existing) {
    const prev = existing.responseBodyJson as ProcessEventResult;
    return { ...prev, idempotent: true };
  }

  let result: ProcessEventResult;

  // ── Unknown product ──────────────────────────────────────────────────────
  if (event.plan === null) {
    result = { processed: true, idempotent: false, action: "unknown_product", plan: null };
  } else if (isAccessGrantingEvent(event.eventType)) {
    // ── Grant access ────────────────────────────────────────────────────────
    await upsertSubscription(ctx, userId, event, eventTypeToStatus(event.eventType));
    await grantPlanEntitlements(ctx, userId, event.plan, "subscription", event.currentPeriodEnd);
    result = { processed: true, idempotent: false, action: "granted", plan: event.plan };

  } else if (isAccessRevokingEvent(event.eventType)) {
    // ── Revoke access ───────────────────────────────────────────────────────
    await upsertSubscription(ctx, userId, event, eventTypeToStatus(event.eventType));
    await revokePlanEntitlements(ctx, userId);
    result = { processed: true, idempotent: false, action: "revoked", plan: event.plan };

  } else {
    // billing_issue / paused — update subscription status, keep entitlements
    await upsertSubscription(ctx, userId, event, eventTypeToStatus(event.eventType));
    result = { processed: true, idempotent: false, action: "updated", plan: event.plan };
  }

  // ── Record idempotency key ───────────────────────────────────────────────
  const exp = new Date(event.occurredAt);
  exp.setDate(exp.getDate() + 30);

  await ctx.db
    .insert(idempotencyKeys)
    .values({
      ownerKey,
      idempotencyKey:     event.providerEventId,
      requestFingerprint: event.eventType,
      responseStatus:     200,
      responseBodyJson:   result as unknown as Record<string, unknown>,
      expiresAt:          exp,
    })
    .onConflictDoNothing();

  return result;
}

// ─── Upsert subscription row ──────────────────────────────────────────────────

async function upsertSubscription(
  ctx: DbContext,
  userId: string,
  event: NormalisedSubscriptionEvent,
  status: SubscriptionStatus,
): Promise<void> {
  // Only apple_iap, google_play, stripe are valid DB enum values
  const dbProvider = (["apple_iap","google_play","stripe"].includes(event.provider)
    ? event.provider
    : "apple_iap") as import("../../db/enums.js").SubscriptionProvider;

  await ctx.db
    .insert(subscriptions)
    .values({
      userId,
      provider:                dbProvider,
      providerCustomerId:      event.providerCustomerId,
      providerSubscriptionId:  event.providerSubscriptionId,
      status,
      currentPeriodEnd:        event.currentPeriodEnd,
      updatedAt:               new Date(),
    })
    .onConflictDoUpdate({
      target: [subscriptions.userId],  // one subscription per user in V1
      set: {
        status,
        currentPeriodEnd: event.currentPeriodEnd,
        providerSubscriptionId: event.providerSubscriptionId,
        providerCustomerId:     event.providerCustomerId,
        updatedAt:              new Date(),
      },
    });
}
