/**
 * Credit ledger — generic credit management for expensive features.
 *
 * Uses usage_counters table with featureKey="ai_video" (or other credit features).
 * Credits are separate from period-based usage limits.
 * periodKey for credits: "credits-<YYYY-MM>" — resets monthly.
 *
 * Rules:
 *  - No negative balance
 *  - Idempotent consumption via idempotency_keys table
 *  - grant/consume are separate operations
 *  - Balance is always ≥ 0
 */

import { eq, and, sql } from "drizzle-orm";
import type { DbContext } from "../../db/client.js";
import { usageCounters, idempotencyKeys } from "../../db/drizzle-schema.js";
import { AppError } from "../../errors/index.js";
import { buildPeriodKey } from "./plans.js";
import type { BillingFeature } from "./plans.js";

const CREDIT_PERIOD_PREFIX = "credits";

function creditPeriodKey(date: Date = new Date()): string {
  return `${CREDIT_PERIOD_PREFIX}-${buildPeriodKey("month", date)}`;
}

// ─── Balance ──────────────────────────────────────────────────────────────────

export async function getCreditBalance(
  ctx: DbContext,
  userId: string,
  feature: BillingFeature,
  date: Date = new Date(),
): Promise<number> {
  const periodKey = creditPeriodKey(date);
  const [row] = await ctx.db
    .select({ count: usageCounters.count })
    .from(usageCounters)
    .where(and(
      eq(usageCounters.ownerType, "user"),
      eq(usageCounters.ownerId, userId),
      eq(usageCounters.featureKey, feature as import("../../db/enums.js").FeatureKey),
      eq(usageCounters.periodKey, periodKey),
    ))
    .limit(1);
  return row?.count ?? 0;
}

// ─── Grant ────────────────────────────────────────────────────────────────────

export async function grantCredits(
  ctx: DbContext,
  userId: string,
  feature: BillingFeature,
  amount: number,
  date: Date = new Date(),
): Promise<number> {
  if (amount <= 0) throw AppError.validationError("Grant amount must be positive");

  const periodKey = creditPeriodKey(date);
  const fk = feature as import("../../db/enums.js").FeatureKey;

  // Upsert: increment count
  await ctx.db
    .insert(usageCounters)
    .values({ ownerType: "user", ownerId: userId, featureKey: fk, periodKey, count: amount })
    .onConflictDoUpdate({
      target: [usageCounters.ownerType, usageCounters.ownerId, usageCounters.featureKey, usageCounters.periodKey],
      set: {
        count: sql`${usageCounters.count} + ${amount}`,
        updatedAt: new Date(),
      },
    });

  return getCreditBalance(ctx, userId, feature, date);
}

// ─── Consume ──────────────────────────────────────────────────────────────────

export interface ConsumeResult {
  readonly consumed: boolean;
  readonly remaining: number;
  readonly idempotent: boolean; // true if this was a replay
}

export async function consumeCredits(
  ctx: DbContext,
  userId: string,
  feature: BillingFeature,
  amount: number,
  idempotencyKey: string,
  date: Date = new Date(),
): Promise<ConsumeResult> {
  if (amount <= 0) throw AppError.validationError("Consume amount must be positive");

  const ownerKey  = `credit:${userId}:${feature}`;
  const periodKey = creditPeriodKey(date);
  const fk = feature as import("../../db/enums.js").FeatureKey;

  // ── Idempotency check ────────────────────────────────────────────────────
  const [existing] = await ctx.db
    .select({ responseBodyJson: idempotencyKeys.responseBodyJson })
    .from(idempotencyKeys)
    .where(and(
      eq(idempotencyKeys.ownerKey, ownerKey),
      eq(idempotencyKeys.idempotencyKey, idempotencyKey),
    ))
    .limit(1);

  if (existing) {
    const prev = existing.responseBodyJson as { remaining: number } | null;
    return { consumed: true, remaining: prev?.remaining ?? 0, idempotent: true };
  }

  // ── Balance check ────────────────────────────────────────────────────────
  const balance = await getCreditBalance(ctx, userId, feature, date);
  if (balance < amount) {
    return { consumed: false, remaining: balance, idempotent: false };
  }

  // ── Deduct ───────────────────────────────────────────────────────────────
  await ctx.db
    .update(usageCounters)
    .set({
      count: sql`GREATEST(${usageCounters.count} - ${amount}, 0)`,
      updatedAt: new Date(),
    })
    .where(and(
      eq(usageCounters.ownerType, "user"),
      eq(usageCounters.ownerId, userId),
      eq(usageCounters.featureKey, fk),
      eq(usageCounters.periodKey, periodKey),
    ));

  const remaining = await getCreditBalance(ctx, userId, feature, date);

  // ── Record idempotency ───────────────────────────────────────────────────
  const exp = new Date(date);
  exp.setDate(exp.getDate() + 7); // keep idempotency key 7 days

  await ctx.db
    .insert(idempotencyKeys)
    .values({
      ownerKey,
      idempotencyKey,
      requestFingerprint: `consume:${amount}`,
      responseStatus:     200,
      responseBodyJson:   { remaining } as unknown as Record<string, unknown>,
      expiresAt:          exp,
    })
    .onConflictDoNothing();

  return { consumed: true, remaining, idempotent: false };
}
