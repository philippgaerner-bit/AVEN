/**
 * Billing routes — GET /billing/status and POST /billing/webhook
 */

import type { FastifyInstance } from "fastify";
import type { DbContext } from "../../db/client.js";
import { AppError } from "../../errors/index.js";
import { resolveIdentityFromHeader } from "../users/routes.js";
import { resolveUserPlan } from "./entitlements.js";
import { canUseFeature } from "./access.js";
import { getCreditBalance } from "./credits.js";
import { processSubscriptionEvent } from "./subscription-service.js";
import { createBillingProvider } from "./billing-provider.js";
import { DEFAULT_PRODUCT_MAP, resolveProductToPlan } from "./products.js";
import type { AppConfig } from "../../config/index.js";
import type { BillingFeature } from "./plans.js";
import { eq, and, isNull } from "drizzle-orm";
import { users } from "../../db/drizzle-schema.js";

const CHECKED_FEATURES: BillingFeature[] = [
  "scans", "bio_generation", "hook_generation", "caption_generation",
  "ai_recommendations", "ai_video", "full_insights", "growth_actions",
];

export async function registerBillingRoutes(
  app: FastifyInstance,
  ctx: DbContext,
  config?: Pick<AppConfig, "billingProvider" | "billingWebhookSecret">,
): Promise<void> {
  app.get(
    "/billing/status",
    {
      schema: {
        operationId: "getBillingStatus",
        summary: "Get current billing plan and entitlements",
        response: {
          200: {
            type: "object",
            properties: {
              plan:         { type: "string", enum: ["FREE", "PRO", "PRO_PLUS"] },
              active:       { type: "boolean" },
              features:     { type: "object" },
              creditBalance: { type: "number" },
            },
          },
        },
      },
    },
    async (req, reply) => {
      const identity = await resolveIdentityFromHeader(ctx, req.headers["authorization"]);
      if (!identity) throw AppError.unauthorized("Authentication required");

      // Anonymous users always get FREE
      const plan = identity.type === "user"
        ? await resolveUserPlan(ctx, identity.userId)
        : "FREE";

      // Build feature access summary
      const features: Record<string, { allowed: boolean; remaining?: number | null }> = {};
      for (const feature of CHECKED_FEATURES) {
        const r = await canUseFeature(ctx, identity, feature);
        features[feature] = {
          allowed:   r.allowed,
          remaining: r.remaining ?? r.creditsRemaining ?? null,
        };
      }

      // Credit balance for ai_video (user only)
      let creditBalance = 0;
      if (identity.type === "user") {
        creditBalance = await getCreditBalance(ctx, identity.userId, "ai_video");
      }

      return reply.status(200).send({
        plan,
        active: plan !== "FREE",
        features,
        creditBalance,
      });
    },
  );

  /**
   * POST /billing/webhook
   * Receives subscription lifecycle events from billing providers.
   *
   * Security:
   *   - Signature verified BEFORE any processing
   *   - Raw body never logged
   *   - Invalid signature → 401
   *   - Duplicate event → 200 (idempotent)
   *   - Unknown product → 200 (safe ignore)
   *   - No client-supplied plan upgrades accepted
   */
  app.post(
    "/billing/webhook",
    {
      config: { rawBody: true },
      schema: {
        operationId: "billingWebhook",
        summary: "Billing provider webhook endpoint",
        description: "Receives subscription events. Requires valid provider signature.",
        response: {
          200: { type: "object", properties: { received: { type: "boolean" } } },
          401: { type: "object", properties: { error: { type: "object" } } },
          400: { type: "object", properties: { error: { type: "object" } } },
        },
      },
    },
    async (req, reply) => {
      const provider = createBillingProvider(
        config?.billingProvider ?? "stub",
        config?.billingWebhookSecret ?? null,
      );

      // Raw body for signature verification
      const rawBody = (req as { rawBody?: Buffer }).rawBody ?? Buffer.from(JSON.stringify(req.body ?? {}));
      const headers = req.headers as Record<string, string>;

      // ── Signature verification (MUST come first) ──────────────────────────
      const sigValid = await provider.verifyWebhookSignature(rawBody, headers);
      if (!sigValid) {
        // Do not reveal why verification failed — prevents timing/info attacks
        throw AppError.unauthorized("Invalid webhook signature");
      }

      // ── Parse event ───────────────────────────────────────────────────────
      const event = await provider.parseSubscriptionEvent(rawBody, DEFAULT_PRODUCT_MAP);

      if (!event) {
        // Not a subscription event we handle — acknowledge and ignore
        return reply.status(200).send({ received: true });
      }

      // ── Resolve user from providerCustomerId ──────────────────────────────
      // In production: RevenueCat sends app_user_id which is our userId
      // For stub/test: we embed userId in providerCustomerId directly
      const userId = event.providerCustomerId.startsWith("user:")
        ? event.providerCustomerId.slice(5)
        : event.providerCustomerId;

      // Verify user exists before processing
      const [userRow] = await ctx.db
        .select({ id: users.id })
        .from(users)
        .where(and(eq(users.id, userId), isNull(users.deletedAt)))
        .limit(1);

      if (!userRow) {
        // Unknown user — safe to acknowledge (provider may retry; we can't process yet)
        return reply.status(200).send({ received: true });
      }

      // ── Process event (idempotent) ────────────────────────────────────────
      await processSubscriptionEvent(ctx, userRow.id, event);

      return reply.status(200).send({ received: true });
    },
  );
}
