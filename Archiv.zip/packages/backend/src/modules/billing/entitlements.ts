/**
 * Entitlement service — resolves a user's plan from the entitlements table.
 *
 * Rules:
 *  - entitlements table is the source of truth (not RevenueCat directly)
 *  - Expired or inactive entitlements are treated as FREE
 *  - Users with no entitlement row default to FREE
 *  - PRO_PLUS takes precedence over PRO
 */

import { eq, and, isNull, or } from "drizzle-orm";
import { gte } from "drizzle-orm";
import type { DbContext } from "../../db/client.js";
import { entitlements } from "../../db/drizzle-schema.js";
import type { PlanId } from "./plans.js";

// ─── Resolve effective plan ───────────────────────────────────────────────────

/**
 * Determines the user's current plan from active, non-expired entitlements.
 * Returns "FREE" if no qualifying entitlement exists.
 */
export async function resolveUserPlan(
  ctx: DbContext,
  userId: string,
  now: Date = new Date(),
): Promise<PlanId> {
  const rows = await ctx.db
    .select({ featureKey: entitlements.featureKey, active: entitlements.active, expiresAt: entitlements.expiresAt })
    .from(entitlements)
    .where(and(
      eq(entitlements.userId, userId),
      eq(entitlements.active, true),
      or(isNull(entitlements.expiresAt), gte(entitlements.expiresAt, now)),
    ));

  // Map entitlement feature keys to plan IDs
  // Convention: featureKey "full_insights" signals PRO, if a special "pro_plus" marker exists → PRO_PLUS
  // In V1: we use the featureKey values as plan signals. A "full_insights" active entitlement = PRO.
  // A future migration can add a dedicated plan entitlement row.
  // For now: detect plan tier from entitlement coverage.
  const activeKeys = new Set(rows.map((r) => r.featureKey));

  // PRO_PLUS: has ai_video AND full_insights (marker for highest tier)
  // PRO: has full_insights but limited ai_video credits
  // FREE: neither
  if (activeKeys.has("full_insights") && hasHighUsageLimits(rows)) {
    return "PRO_PLUS";
  }
  if (activeKeys.has("full_insights")) {
    return "PRO";
  }
  return "FREE";
}

// Helper: PRO_PLUS heuristic — future: replace with explicit plan entitlement
function hasHighUsageLimits(rows: Array<{ featureKey: string }>): boolean {
  // In V1, PRO_PLUS is indicated by having both full_insights and library_entries
  // This is a simple heuristic until we add explicit plan rows
  const keys = new Set(rows.map((r) => r.featureKey));
  return keys.has("full_insights") && keys.has("library_entries") && keys.has("scans");
}

// ─── Grant entitlements for a plan ───────────────────────────────────────────

/**
 * Grants all entitlements for a given plan to a user.
 * Called when a subscription is activated (Phase 6.2+).
 * Idempotent: uses upsert.
 */
export async function grantPlanEntitlements(
  ctx: DbContext,
  userId: string,
  plan: PlanId,
  source: "subscription" | "trial" | "manual",
  expiresAt: Date | null = null,
): Promise<void> {
  const PLAN_FEATURES: Record<PlanId, string[]> = {
    FREE: [],
    PRO: ["full_insights"],
    PRO_PLUS: ["full_insights", "library_entries", "scans"],
  };

  const features = PLAN_FEATURES[plan];
  for (const featureKey of features) {
    await ctx.db
      .insert(entitlements)
      .values({
        userId,
        featureKey: featureKey as import("../../db/enums.js").FeatureKey,
        active:    true,
        source,
        expiresAt,
        updatedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: [entitlements.userId, entitlements.featureKey],
        set:    { active: true, source, expiresAt, updatedAt: new Date() },
      });
  }
}

/**
 * Revokes all plan entitlements for a user (e.g. on subscription cancellation).
 */
export async function revokePlanEntitlements(
  ctx: DbContext,
  userId: string,
): Promise<void> {
  await ctx.db
    .update(entitlements)
    .set({ active: false, updatedAt: new Date() })
    .where(eq(entitlements.userId, userId));
}
