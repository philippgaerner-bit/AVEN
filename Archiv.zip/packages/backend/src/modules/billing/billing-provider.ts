/**
 * Billing provider interface and adapters.
 *
 * Every billing provider (RevenueCat, Apple, Stripe) implements BillingProvider.
 * The webhook route depends only on this interface — never on provider SDKs.
 *
 * Security contract:
 *   - verifyWebhookSignature MUST be called before any event processing
 *   - raw payload is never logged
 *   - secrets never appear in normalised events or error messages
 */

import { createHmac, timingSafeEqual } from "node:crypto";
import type { NormalisedSubscriptionEvent } from "./subscription-provider.js";
import type { ProductMap } from "./products.js";
import { resolveProductToPlan } from "./products.js";

// ─── Interface ────────────────────────────────────────────────────────────────

export interface BillingProvider {
  readonly providerName: string;

  /**
   * Verifies the webhook signature from provider headers.
   * MUST return false (not throw) for invalid signatures.
   * MUST use constant-time comparison.
   */
  verifyWebhookSignature(
    rawBody: Buffer | string,
    headers: Record<string, string>,
  ): Promise<boolean>;

  /**
   * Parses and normalises a verified raw webhook payload.
   * rawBody has already been verified by verifyWebhookSignature.
   * Returns null if the event type is not one we handle.
   * MUST NOT log rawBody or any secret values.
   */
  parseSubscriptionEvent(
    rawBody: Buffer | string,
    productMap: ProductMap,
  ): Promise<NormalisedSubscriptionEvent | null>;
}

// ─── Stub provider (tests, no network) ───────────────────────────────────────

export class StubBillingProvider implements BillingProvider {
  readonly providerName = "stub";

  constructor(
    private readonly opts: {
      signatureValid?: boolean;
      event?: NormalisedSubscriptionEvent | null;
    } = {},
  ) {}

  async verifyWebhookSignature(
    _rawBody: Buffer | string,
    headers: Record<string, string>,
  ): Promise<boolean> {
    // Stub: checks for a "x-stub-signature" header value of "valid"
    if (this.opts.signatureValid !== undefined) return this.opts.signatureValid;
    return headers["x-stub-signature"] === "valid";
  }

  async parseSubscriptionEvent(
    _rawBody: Buffer | string,
    _productMap: ProductMap,
  ): Promise<NormalisedSubscriptionEvent | null> {
    return this.opts.event ?? null;
  }
}

// ─── RevenueCat adapter boundary ─────────────────────────────────────────────

/**
 * Production-ready RevenueCat adapter.
 * Phase 6.3: structure only — no real SDK.
 * Phase 6.4+: plug in real RevenueCat webhook verification.
 *
 * RevenueCat webhook format reference:
 *   https://www.revenuecat.com/docs/webhooks
 *
 * Signature: RevenueCat sends "X-RevenueCat-Signature" header
 * containing HMAC-SHA256 of the raw body using the webhook secret.
 */
export class RevenueCatBillingProvider implements BillingProvider {
  readonly providerName = "revenuecat";

  constructor(private readonly webhookSecret: string) {
    if (!webhookSecret || webhookSecret.length < 8) {
      throw new Error("RevenueCat webhook secret is required and must be at least 8 characters");
    }
  }

  async verifyWebhookSignature(
    rawBody: Buffer | string,
    headers: Record<string, string>,
  ): Promise<boolean> {
    const sig = headers["x-revenuecat-signature"] ?? headers["X-RevenueCat-Signature"];
    if (!sig) return false;

    try {
      const body = typeof rawBody === "string" ? Buffer.from(rawBody, "utf8") : rawBody;
      const expected = createHmac("sha256", this.webhookSecret)
        .update(body)
        .digest("hex");
      const a = Buffer.from(sig,      "hex");
      const b = Buffer.from(expected, "hex");
      if (a.length !== b.length) return false;
      return timingSafeEqual(a, b);
    } catch {
      return false;
    }
  }

  async parseSubscriptionEvent(
    rawBody: Buffer | string,
    productMap: ProductMap,
  ): Promise<NormalisedSubscriptionEvent | null> {
    // Production implementation:
    //   const payload = JSON.parse(rawBody.toString("utf8")) as RevenueCatWebhookPayload;
    //   const event = payload.event;
    //   return mapRevenueCatEvent(event, productMap);
    //
    // For Phase 6.3: returns null (not configured)
    void rawBody;
    void productMap;
    return null;
  }
}

// ─── Factory ──────────────────────────────────────────────────────────────────

export function createBillingProvider(
  billingProvider: string,
  webhookSecret: string | null,
): BillingProvider {
  switch (billingProvider) {
    case "stub":
      return new StubBillingProvider(); // header-based: x-stub-signature: "valid" required
    case "disabled":
      return new StubBillingProvider({ signatureValid: false, event: null });
    case "revenuecat":
      if (!webhookSecret) {
        throw new Error("BILLING_WEBHOOK_SECRET is required when BILLING_PROVIDER=revenuecat");
      }
      return new RevenueCatBillingProvider(webhookSecret);
    default:
      throw new Error(`Unsupported BILLING_PROVIDER: "${billingProvider}". Supported: stub, disabled, revenuecat`);
  }
}
