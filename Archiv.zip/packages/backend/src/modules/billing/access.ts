/**
 * canUseFeature — backend-authoritative access control.
 *
 * Single entry point for all feature access decisions.
 * Never trusts client-side claims.
 */

import type { DbContext } from "../../db/client.js";
import type { Identity } from "../auth/identity.js";
import type { BillingFeature, PlanId } from "./plans.js";
import { PLAN_RULES, buildPeriodKey } from "./plans.js";
import { resolveUserPlan } from "./entitlements.js";
import { checkUsageLimit } from "./usage.js";
import { getCreditBalance } from "./credits.js";

// ─── Result ───────────────────────────────────────────────────────────────────

export type DenialReason =
  | "feature_not_in_plan"
  | "usage_limit_reached"
  | "insufficient_credits"
  | "anonymous_not_supported";

export interface AccessResult {
  readonly allowed: boolean;
  readonly plan: PlanId;
  readonly reason?: DenialReason;
  readonly remaining?: number | null;
  readonly creditsRemaining?: number;
}

// ─── canUseFeature ────────────────────────────────────────────────────────────

export async function canUseFeature(
  ctx: DbContext,
  identity: Identity,
  feature: BillingFeature,
  date: Date = new Date(),
): Promise<AccessResult> {
  // Anonymous users get FREE rules, no DB entitlement lookup
  const isAnon = identity.type === "anonymous";
  const plan: PlanId = isAnon ? "FREE" : await resolveUserPlan(ctx, identity.userId, date);
  const rule = PLAN_RULES[plan][feature];

  // Feature not in plan
  if (!rule.allowed) {
    return { allowed: false, plan, reason: "feature_not_in_plan" };
  }

  const ownerType = isAnon ? "anonymous" : "user";
  const ownerId   = isAnon ? identity.anonymousSessionId : identity.userId;

  // Credit-based feature (e.g. ai_video)
  if (rule.creditsPerPeriod !== undefined && !isAnon) {
    const balance = await getCreditBalance(ctx, ownerId, feature, date);
    if (balance <= 0) {
      return { allowed: false, plan, reason: "insufficient_credits", creditsRemaining: 0 };
    }
    return { allowed: true, plan, creditsRemaining: balance };
  }

  // Period limit check
  if (rule.limit) {
    const check = await checkUsageLimit(ctx, ownerType, ownerId, feature, rule.limit, date);
    if (!check.withinLimit) {
      return {
        allowed:   false,
        plan,
        reason:    "usage_limit_reached",
        remaining: 0,
      };
    }
    return { allowed: true, plan, remaining: check.remaining };
  }

  // Unlimited feature
  return { allowed: true, plan };
}
