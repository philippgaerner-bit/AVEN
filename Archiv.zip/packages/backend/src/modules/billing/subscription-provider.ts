/**
 * Subscription provider abstraction.
 *
 * Real providers (RevenueCat, Apple) implement SubscriptionEventProvider.
 * The subscription service depends only on this interface.
 *
 * Security: Raw provider payloads are never logged.
 * Signature verification is enforced at the provider adapter layer.
 */

import type { PlanId } from "./plans.js";

// ─── Normalised subscription event ───────────────────────────────────────────

export type SubscriptionEventType =
  | "activated"
  | "renewed"
  | "expired"
  | "canceled"
  | "revoked"        // refund / chargeback
  | "paused"
  | "billing_issue"; // past_due

export interface NormalisedSubscriptionEvent {
  readonly eventType:               SubscriptionEventType;
  readonly provider:                string;
  readonly providerCustomerId:      string;
  readonly providerSubscriptionId:  string;
  readonly productId:               string;
  /** Resolved internal plan — null = unknown product */
  readonly plan:                    PlanId | null;
  /** When the current paid period ends; null for terminal events */
  readonly currentPeriodEnd:        Date | null;
  /**
   * Idempotency key from the provider — ensures repeated delivery is safe.
   * Must be unique per event instance, not per event type.
   */
  readonly providerEventId:         string;
  readonly occurredAt:              Date;
}

// ─── Provider interface ───────────────────────────────────────────────────────

export interface SubscriptionEventProvider {
  readonly providerName: string;

  /**
   * Validates and normalises a raw provider webhook payload.
   * MUST verify provider signature before normalising.
   * MUST NOT log rawPayload.
   * Returns null if the payload is not a subscription event we handle.
   */
  normalise(rawPayload: unknown, headers: Record<string, string>): Promise<NormalisedSubscriptionEvent | null>;
}

// ─── Stub provider ────────────────────────────────────────────────────────────

/**
 * Stub for tests and development. Accepts pre-built events directly.
 * No signature verification needed (test context only).
 */
export class StubSubscriptionProvider implements SubscriptionEventProvider {
  readonly providerName = "stub";

  constructor(
    private readonly response: NormalisedSubscriptionEvent | null = null,
  ) {}

  async normalise(
    _rawPayload: unknown,
    _headers: Record<string, string>,
  ): Promise<NormalisedSubscriptionEvent | null> {
    return this.response;
  }
}
