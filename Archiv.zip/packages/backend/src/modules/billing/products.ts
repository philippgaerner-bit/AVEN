/**
 * Product mapping — maps provider product IDs to internal VYRO plans.
 *
 * Store product IDs are kept entirely outside plan business logic.
 * This mapping is the only place they appear in backend code.
 * Real IDs will come from config/env in production.
 */

import type { PlanId } from "./plans.js";
import type { SubscriptionProvider } from "../../db/enums.js";

// ─── Product map ──────────────────────────────────────────────────────────────

export type ProductMap = ReadonlyMap<string, PlanId>;

/**
 * Default V1 product mapping.
 * In production these come from environment config (not hardcoded).
 * Format: "<provider>:<productId>" → PlanId
 */
export const DEFAULT_PRODUCT_MAP: ProductMap = new Map<string, PlanId>([
  // Apple IAP (sandbox and production)
  ["apple_iap:com.vyro.pro.monthly",      "PRO"],
  ["apple_iap:com.vyro.pro.yearly",       "PRO"],
  ["apple_iap:com.vyro.proplus.monthly",  "PRO_PLUS"],
  ["apple_iap:com.vyro.proplus.yearly",   "PRO_PLUS"],
  // Stripe (web, Phase 6.3+)
  ["stripe:price_pro_monthly",            "PRO"],
  ["stripe:price_proplus_monthly",        "PRO_PLUS"],
  // Test/stub keys
  ["stub:pro",      "PRO"],
  ["stub:pro_plus", "PRO_PLUS"],
  ["stub:free",     "FREE"],
]);

/**
 * Resolves provider + productId to internal plan.
 * Returns null if the product is not recognised.
 */
export function resolveProductToPlan(
  provider: string,
  productId: string,
  map: ProductMap = DEFAULT_PRODUCT_MAP,
): PlanId | null {
  return map.get(`${provider}:${productId}`) ?? null;
}

/**
 * Validates a provider string.
 */
export function isKnownProvider(provider: string): provider is SubscriptionProvider {
  return ["apple_iap", "google_play", "stripe", "stub"].includes(provider);
}
