/**
 * Usage counter service — period-based usage limits.
 * Uses the existing usage_counters table and UNIQUE(ownerType, ownerId, featureKey, periodKey).
 */

import { eq, and, sql } from "drizzle-orm";
import type { DbContext } from "../../db/client.js";
import { usageCounters } from "../../db/drizzle-schema.js";
import type { FeatureKey, OwnerType } from "../../db/enums.js";
import type { BillingFeature } from "./plans.js";
import { buildPeriodKey } from "./plans.js";
import type { PeriodLimit } from "./plans.js";

// ─── Get usage ────────────────────────────────────────────────────────────────

export async function getUsageCount(
  ctx: DbContext,
  ownerType: OwnerType,
  ownerId: string,
  feature: BillingFeature,
  periodKey: string,
): Promise<number> {
  const [row] = await ctx.db
    .select({ count: usageCounters.count })
    .from(usageCounters)
    .where(and(
      eq(usageCounters.ownerType, ownerType),
      eq(usageCounters.ownerId, ownerId),
      eq(usageCounters.featureKey, feature as FeatureKey),
      eq(usageCounters.periodKey, periodKey),
    ))
    .limit(1);
  return row?.count ?? 0;
}

// ─── Increment usage ──────────────────────────────────────────────────────────

export async function incrementUsage(
  ctx: DbContext,
  ownerType: OwnerType,
  ownerId: string,
  feature: BillingFeature,
  periodKey: string,
  by = 1,
): Promise<number> {
  const fk = feature as FeatureKey;

  await ctx.db
    .insert(usageCounters)
    .values({ ownerType, ownerId, featureKey: fk, periodKey, count: by })
    .onConflictDoUpdate({
      target: [usageCounters.ownerType, usageCounters.ownerId, usageCounters.featureKey, usageCounters.periodKey],
      set: {
        count: sql`${usageCounters.count} + ${by}`,
        updatedAt: new Date(),
      },
    });

  return getUsageCount(ctx, ownerType, ownerId, feature, periodKey);
}

// ─── Check limit ──────────────────────────────────────────────────────────────

export interface LimitCheck {
  readonly withinLimit: boolean;
  readonly current: number;
  readonly max: number | null;
  readonly remaining: number | null;
}

export async function checkUsageLimit(
  ctx: DbContext,
  ownerType: OwnerType,
  ownerId: string,
  feature: BillingFeature,
  limit: PeriodLimit,
  date: Date = new Date(),
): Promise<LimitCheck> {
  const periodKey = buildPeriodKey(limit.period, date);
  const current   = await getUsageCount(ctx, ownerType, ownerId, feature, periodKey);

  if (limit.max === null) {
    return { withinLimit: true, current, max: null, remaining: null };
  }

  return {
    withinLimit: current < limit.max,
    current,
    max:         limit.max,
    remaining:   Math.max(0, limit.max - current),
  };
}
