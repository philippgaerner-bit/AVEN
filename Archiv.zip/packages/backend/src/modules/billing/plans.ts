/**
 * VYRO Plans — provider-neutral product definitions.
 * No store product IDs here. RevenueCat/StoreKit map their IDs to these plans externally.
 */

export const PLAN_IDS = ["FREE", "PRO", "PRO_PLUS"] as const;
export type PlanId = (typeof PLAN_IDS)[number];

export const PLAN_VERSION = "v1.0.0" as const;

// ─── Feature keys mirrored from enums (avoids circular import) ────────────────

export type BillingFeature =
  | "scans"
  | "bio_generation"
  | "hook_generation"
  | "caption_generation"
  | "hashtag_generation"
  | "content_idea_generation"
  | "library_entries"
  | "full_insights"
  | "ai_recommendations"
  | "ai_video"
  | "growth_actions";

// ─── Per-period limits (null = unlimited) ─────────────────────────────────────

export interface PeriodLimit {
  /** ISO period granularity used as periodKey prefix: "month" | "week" */
  readonly period: "month" | "week";
  readonly max: number | null;
}

export interface PlanFeatureRule {
  readonly allowed: boolean;
  readonly limit?: PeriodLimit;
  /** Credit pool for expensive features (e.g. ai_video) */
  readonly creditsPerPeriod?: number;
}

export type PlanRules = Readonly<Record<BillingFeature, PlanFeatureRule>>;

// ─── Plan definitions ─────────────────────────────────────────────────────────

const FREE_RULES: PlanRules = {
  scans:                    { allowed: true,  limit: { period: "month", max: 3 } },
  bio_generation:           { allowed: true,  limit: { period: "month", max: 5 } },
  hook_generation:          { allowed: true,  limit: { period: "month", max: 5 } },
  caption_generation:       { allowed: true,  limit: { period: "month", max: 5 } },
  hashtag_generation:       { allowed: true,  limit: { period: "month", max: 5 } },
  content_idea_generation:  { allowed: true,  limit: { period: "month", max: 5 } },
  library_entries:          { allowed: true,  limit: { period: "month", max: 10 } },
  full_insights:            { allowed: false },
  ai_recommendations:       { allowed: false },
  ai_video:                 { allowed: false },
  growth_actions:           { allowed: true,  limit: { period: "month", max: 3 } },
};

const PRO_RULES: PlanRules = {
  scans:                    { allowed: true,  limit: { period: "month", max: 30 } },
  bio_generation:           { allowed: true,  limit: { period: "month", max: 100 } },
  hook_generation:          { allowed: true,  limit: { period: "month", max: 100 } },
  caption_generation:       { allowed: true,  limit: { period: "month", max: 100 } },
  hashtag_generation:       { allowed: true,  limit: { period: "month", max: 100 } },
  content_idea_generation:  { allowed: true,  limit: { period: "month", max: 100 } },
  library_entries:          { allowed: true,  limit: { period: "month", max: 500 } },
  full_insights:            { allowed: true },
  ai_recommendations:       { allowed: true,  limit: { period: "month", max: 50 } },
  ai_video:                 { allowed: true,  creditsPerPeriod: 10 },
  growth_actions:           { allowed: true,  limit: { period: "month", max: null } },
};

const PRO_PLUS_RULES: PlanRules = {
  scans:                    { allowed: true,  limit: { period: "month", max: 200 } },
  bio_generation:           { allowed: true,  limit: { period: "month", max: null } },
  hook_generation:          { allowed: true,  limit: { period: "month", max: null } },
  caption_generation:       { allowed: true,  limit: { period: "month", max: null } },
  hashtag_generation:       { allowed: true,  limit: { period: "month", max: null } },
  content_idea_generation:  { allowed: true,  limit: { period: "month", max: null } },
  library_entries:          { allowed: true,  limit: { period: "month", max: null } },
  full_insights:            { allowed: true },
  ai_recommendations:       { allowed: true,  limit: { period: "month", max: null } },
  ai_video:                 { allowed: true,  creditsPerPeriod: 50 },
  growth_actions:           { allowed: true,  limit: { period: "month", max: null } },
};

export const PLAN_RULES: Readonly<Record<PlanId, PlanRules>> = {
  FREE:     FREE_RULES,
  PRO:      PRO_RULES,
  PRO_PLUS: PRO_PLUS_RULES,
};

// ─── Period key helpers ───────────────────────────────────────────────────────

/**
 * Generates the periodKey string for a given date.
 * "month" → "2025-01", "week" → "2025-W03"
 * Same date always produces same key (deterministic).
 */
export function buildPeriodKey(period: "month" | "week", date: Date = new Date()): string {
  if (period === "month") {
    const y = date.getUTCFullYear();
    const m = String(date.getUTCMonth() + 1).padStart(2, "0");
    return `${y}-${m}`;
  }
  // ISO week number
  const d = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
  return `${d.getUTCFullYear()}-W${String(weekNo).padStart(2, "0")}`;
}

/** Returns the PlanFeatureRule for a given plan + feature */
export function getPlanRule(plan: PlanId, feature: BillingFeature): PlanFeatureRule {
  return PLAN_RULES[plan][feature];
}
