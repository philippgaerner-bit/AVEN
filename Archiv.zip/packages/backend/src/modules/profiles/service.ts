/**
 * Creator profile service — ownership-aware operations.
 *
 * Every operation checks that the requesting identity owns the profile.
 * Anonymous and user identities are treated symmetrically.
 */

import { eq, and, isNull } from "drizzle-orm";
import type { DbContext } from "../../db/client.js";
import { creatorProfiles } from "../../db/drizzle-schema.js";
import { AppError } from "../../errors/index.js";
import type { Identity } from "../auth/identity.js";

// ─── Types ────────────────────────────────────────────────────────────────────

export interface CreatorProfileRow {
  id: string;
  ownerType: "user" | "anonymous";
  ownerUserId: string | null;
  ownerAnonymousSessionId: string | null;
  platform: "instagram" | "tiktok";
  createdAt: Date;
  updatedAt: Date;
}

// ─── Create ───────────────────────────────────────────────────────────────────

export async function createCreatorProfile(
  ctx: DbContext,
  identity: Identity,
  platform: "instagram" | "tiktok",
): Promise<CreatorProfileRow> {
  const values =
    identity.type === "anonymous"
      ? {
          ownerType: "anonymous" as const,
          ownerAnonymousSessionId: identity.anonymousSessionId,
          ownerUserId: null,
          platform,
        }
      : {
          ownerType: "user" as const,
          ownerUserId: identity.userId,
          ownerAnonymousSessionId: null,
          platform,
        };

  const [row] = await ctx.db
    .insert(creatorProfiles)
    .values(values)
    .returning();

  if (!row) throw AppError.internal("Failed to create creator profile");
  return row as CreatorProfileRow;
}

// ─── Read ─────────────────────────────────────────────────────────────────────

export async function getCreatorProfileById(
  ctx: DbContext,
  profileId: string,
): Promise<CreatorProfileRow | null> {
  const [row] = await ctx.db
    .select()
    .from(creatorProfiles)
    .where(eq(creatorProfiles.id, profileId))
    .limit(1);
  return (row as CreatorProfileRow) ?? null;
}

/**
 * Returns the profile only if the requesting identity owns it.
 * Throws FORBIDDEN if the profile exists but is owned by someone else.
 */
export async function getOwnedCreatorProfile(
  ctx: DbContext,
  profileId: string,
  identity: Identity,
): Promise<CreatorProfileRow> {
  const profile = await getCreatorProfileById(ctx, profileId);
  if (!profile) throw AppError.notFound("Creator profile");
  assertOwnership(profile, identity);
  return profile;
}

/**
 * Lists all profiles belonging to the requesting identity.
 */
export async function listCreatorProfiles(
  ctx: DbContext,
  identity: Identity,
): Promise<CreatorProfileRow[]> {
  const condition =
    identity.type === "anonymous"
      ? eq(creatorProfiles.ownerAnonymousSessionId, identity.anonymousSessionId)
      : eq(creatorProfiles.ownerUserId, identity.userId);

  const rows = await ctx.db
    .select()
    .from(creatorProfiles)
    .where(condition);

  return rows as CreatorProfileRow[];
}

// ─── Ownership check ──────────────────────────────────────────────────────────

/**
 * Asserts the identity owns the profile.
 * Throws FORBIDDEN if not.
 */
export function assertOwnership(
  profile: CreatorProfileRow,
  identity: Identity,
): void {
  if (identity.type === "anonymous") {
    if (profile.ownerAnonymousSessionId !== identity.anonymousSessionId) {
      throw AppError.forbidden("You do not own this profile");
    }
  } else {
    if (profile.ownerUserId !== identity.userId) {
      throw AppError.forbidden("You do not own this profile");
    }
  }
}
