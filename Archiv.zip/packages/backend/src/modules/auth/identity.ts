/**
 * Identity abstraction.
 *
 * Routes and services work with Identity objects, never with raw tokens.
 * Token validation happens at the route boundary; everything downstream
 * receives a typed identity.
 */

export type Identity =
  | { readonly type: "anonymous"; readonly anonymousSessionId: string }
  | { readonly type: "user"; readonly userId: string };

export function anonIdentity(anonymousSessionId: string): Identity {
  return { type: "anonymous", anonymousSessionId };
}

export function userIdentity(userId: string): Identity {
  return { type: "user", userId };
}

export function isAnonIdentity(
  identity: Identity,
): identity is { type: "anonymous"; anonymousSessionId: string } {
  return identity.type === "anonymous";
}

export function isUserIdentity(
  identity: Identity,
): identity is { type: "user"; userId: string } {
  return identity.type === "user";
}

/**
 * Extracts identity from an Authorization header value.
 * Validates token shape but does NOT hit the DB — caller must resolve session.
 */
export function identityLabel(identity: Identity): string {
  return identity.type === "anonymous"
    ? `anon:${identity.anonymousSessionId}`
    : `user:${identity.userId}`;
}
