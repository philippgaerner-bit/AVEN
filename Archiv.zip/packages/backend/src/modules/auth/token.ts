/**
 * Token utilities for anonymous and user sessions.
 *
 * Rules:
 *  - Tokens are opaque random bytes (URL-safe base64)
 *  - Only SHA-256 hashes are stored in the DB — never raw tokens
 *  - Constant-time comparison for hash verification
 *  - No external dependencies (Node crypto only)
 */

import { createHash, randomBytes, timingSafeEqual } from "node:crypto";

// ─── Constants ────────────────────────────────────────────────────────────────

/** Raw token length in bytes — yields 43-char base64url string */
export const TOKEN_BYTES = 32;

/** Session durations */
export const ANON_SESSION_TTL_DAYS  = 90;
export const USER_SESSION_TTL_DAYS  = 30;

// ─── Token generation ─────────────────────────────────────────────────────────

/**
 * Generates a cryptographically secure opaque token.
 * Returns URL-safe base64 (no padding).
 */
export function generateToken(): string {
  return randomBytes(TOKEN_BYTES).toString("base64url");
}

/**
 * Hashes a token with SHA-256.
 * This is what gets stored in the database.
 */
export function hashToken(token: string): string {
  return createHash("sha256").update(token, "utf8").digest("hex");
}

/**
 * Constant-time comparison of a candidate token against a stored hash.
 * Prevents timing attacks.
 */
export function verifyToken(candidate: string, storedHash: string): boolean {
  try {
    const candidateHash = hashToken(candidate);
    const a = Buffer.from(candidateHash, "hex");
    const b = Buffer.from(storedHash,   "hex");
    if (a.length !== b.length) return false;
    return timingSafeEqual(a, b);
  } catch {
    return false;
  }
}

/**
 * Generates a new token + its hash in one call.
 */
export function generateTokenPair(): { token: string; hash: string } {
  const token = generateToken();
  return { token, hash: hashToken(token) };
}

/** Returns a Date that is `days` from now */
export function expiresAt(days: number): Date {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d;
}

/** True if the given date is in the past */
export function isExpired(date: Date): boolean {
  return date < new Date();
}

/**
 * Basic structural validation of a token.
 * Tokens must be non-empty base64url strings of expected length.
 * Rejects obviously malformed inputs before any DB lookup.
 */
export function isValidTokenShape(token: unknown): token is string {
  if (typeof token !== "string" || token.length === 0) return false;
  // base64url character set + correct length range
  if (!/^[A-Za-z0-9_-]+$/.test(token)) return false;
  // A 32-byte random value encoded as base64url is always 43 chars
  return token.length === 43;
}
