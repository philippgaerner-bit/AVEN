/**
 * Auth repository — DB access for anonymous sessions and user sessions.
 *
 * Architecture:
 *  - Pure functions that take DbContext; no global state
 *  - No HTTP concerns
 *  - All queries go through Drizzle — no raw SQL
 *  - Tokens are NEVER stored or returned from this layer; only hashes
 */

import { eq, and, isNull } from "drizzle-orm";
import type { DbContext } from "../../db/client.js";
import {
  anonymousSessions,
  userSessions,
  users,
} from "../../db/drizzle-schema.js";
import {
  hashToken,
  verifyToken,
  expiresAt,
  isExpired,
  generateTokenPair,
  ANON_SESSION_TTL_DAYS,
  USER_SESSION_TTL_DAYS,
} from "./token.js";
import { AppError } from "../../errors/index.js";

// ─── Types ────────────────────────────────────────────────────────────────────

export interface AnonSessionRow {
  id: string;
  deviceSecretHash: string;
  createdAt: Date;
  lastSeenAt: Date;
  expiresAt: Date;
  mergedIntoUserId: string | null;
}

export interface UserSessionRow {
  id: string;
  userId: string;
  refreshTokenHash: string;
  tokenFamilyId: string;
  createdAt: Date;
  expiresAt: Date;
  revokedAt: Date | null;
  replacedBySessionId: string | null;
}

export interface UserRow {
  id: string;
  appleSubject: string | null;
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date | null;
}

// ─── Anonymous sessions ───────────────────────────────────────────────────────

/**
 * Creates a new anonymous session.
 * Returns the raw token (only time it is ever returned — caller must send it to client).
 * Stores only the hash.
 */
export async function createAnonSession(
  ctx: DbContext,
): Promise<{ sessionId: string; token: string; expiresAt: Date }> {
  const { token, hash } = generateTokenPair();
  const exp = expiresAt(ANON_SESSION_TTL_DAYS);

  const [row] = await ctx.db
    .insert(anonymousSessions)
    .values({
      deviceSecretHash: hash,
      expiresAt: exp,
    })
    .returning({ id: anonymousSessions.id });

  if (!row) throw AppError.internal("Failed to create anonymous session");

  return { sessionId: row.id, token, expiresAt: exp };
}

/**
 * Resolves an anonymous session by its raw token.
 * Returns null if:
 *   - token shape is invalid
 *   - no matching session
 *   - session is expired
 *   - session has been merged into a user
 *
 * Also updates lastSeenAt on success.
 */
export async function resolveAnonSession(
  ctx: DbContext,
  token: string,
): Promise<AnonSessionRow | null> {
  // Find candidate rows by checking all active sessions
  // (We can't index by hash without a full table scan in this MVP;
  // in production, add a unique index on device_secret_hash.)
  const rows = await ctx.db
    .select()
    .from(anonymousSessions)
    .where(and(
      isNull(anonymousSessions.mergedIntoUserId),
    ))
    .limit(1000); // reasonable upper bound for MVP

  for (const row of rows) {
    if (verifyToken(token, row.deviceSecretHash)) {
      if (isExpired(row.expiresAt)) return null;
      // Update lastSeenAt
      await ctx.db
        .update(anonymousSessions)
        .set({ lastSeenAt: new Date() })
        .where(eq(anonymousSessions.id, row.id));
      return row;
    }
  }
  return null;
}

/**
 * Resolves a session directly by ID (for internal use after token validation).
 */
export async function getAnonSessionById(
  ctx: DbContext,
  sessionId: string,
): Promise<AnonSessionRow | null> {
  const [row] = await ctx.db
    .select()
    .from(anonymousSessions)
    .where(eq(anonymousSessions.id, sessionId))
    .limit(1);
  return row ?? null;
}

/**
 * Revokes (expires) an anonymous session immediately.
 */
export async function revokeAnonSession(
  ctx: DbContext,
  sessionId: string,
): Promise<void> {
  await ctx.db
    .update(anonymousSessions)
    .set({ expiresAt: new Date(0) }) // epoch = effectively expired
    .where(eq(anonymousSessions.id, sessionId));
}

/**
 * Marks an anonymous session as merged into a registered user.
 * Can only be done once (enforced by the non-null check).
 */
export async function markAnonSessionMerged(
  ctx: DbContext,
  sessionId: string,
  userId: string,
): Promise<void> {
  const [row] = await ctx.db
    .select({ mergedIntoUserId: anonymousSessions.mergedIntoUserId })
    .from(anonymousSessions)
    .where(eq(anonymousSessions.id, sessionId))
    .limit(1);

  if (!row) throw AppError.notFound("Anonymous session");
  if (row.mergedIntoUserId !== null) {
    throw AppError.conflict("Anonymous session has already been merged into a user account");
  }

  await ctx.db
    .update(anonymousSessions)
    .set({ mergedIntoUserId: userId })
    .where(eq(anonymousSessions.id, sessionId));
}

// ─── Users ────────────────────────────────────────────────────────────────────

export async function createUser(ctx: DbContext): Promise<UserRow> {
  const [row] = await ctx.db
    .insert(users)
    .values({})
    .returning();
  if (!row) throw AppError.internal("Failed to create user");
  return row;
}

export async function getUserById(
  ctx: DbContext,
  userId: string,
): Promise<UserRow | null> {
  const [row] = await ctx.db
    .select()
    .from(users)
    .where(and(eq(users.id, userId), isNull(users.deletedAt)))
    .limit(1);
  return row ?? null;
}

// ─── User sessions ────────────────────────────────────────────────────────────

/**
 * Creates a new authenticated user session.
 * Returns the raw refresh token — caller must deliver it to client.
 */
export async function createUserSession(
  ctx: DbContext,
  userId: string,
  tokenFamilyId?: string,
): Promise<{ sessionId: string; token: string; expiresAt: Date }> {
  const { token, hash } = generateTokenPair();
  const exp = expiresAt(USER_SESSION_TTL_DAYS);
  const familyId = tokenFamilyId ?? generateTokenPair().token; // reuse token shape for UUID-like ID

  const [row] = await ctx.db
    .insert(userSessions)
    .values({
      userId,
      refreshTokenHash: hash,
      tokenFamilyId: familyId,
      expiresAt: exp,
    })
    .returning({ id: userSessions.id });

  if (!row) throw AppError.internal("Failed to create user session");

  return { sessionId: row.id, token, expiresAt: exp };
}

/**
 * Resolves a user session by raw token.
 * Returns null for invalid/expired/revoked sessions.
 * Does NOT update any timestamps (use rotateUserSession for that).
 */
export async function resolveUserSession(
  ctx: DbContext,
  token: string,
): Promise<UserSessionRow | null> {
  // Compute hash first so we query by hash column (faster in production with index)
  const hash = hashToken(token);

  const [row] = await ctx.db
    .select()
    .from(userSessions)
    .where(eq(userSessions.refreshTokenHash, hash))
    .limit(1);

  if (!row) return null;
  if (row.revokedAt !== null) return null;
  if (isExpired(row.expiresAt)) return null;

  return row;
}

/**
 * Rotates a user session: revokes the old one, creates a new one in the same family.
 * If the old token was already replaced (reuse attack), revokes the ENTIRE family.
 *
 * Returns new raw token on success.
 */
export async function rotateUserSession(
  ctx: DbContext,
  oldToken: string,
): Promise<{ sessionId: string; token: string; expiresAt: Date } | null> {
  const hash = hashToken(oldToken);

  const [oldRow] = await ctx.db
    .select()
    .from(userSessions)
    .where(eq(userSessions.refreshTokenHash, hash))
    .limit(1);

  if (!oldRow) return null;

  // Reuse detection: if this session was already replaced, revoke the whole family
  if (oldRow.replacedBySessionId !== null) {
    await revokeTokenFamily(ctx, oldRow.tokenFamilyId);
    return null;
  }

  if (oldRow.revokedAt !== null || isExpired(oldRow.expiresAt)) return null;

  // Create new session in same family
  const newSession = await createUserSession(ctx, oldRow.userId, oldRow.tokenFamilyId);

  // Mark old session as replaced
  await ctx.db
    .update(userSessions)
    .set({
      revokedAt: new Date(),
      replacedBySessionId: newSession.sessionId,
    })
    .where(eq(userSessions.id, oldRow.id));

  return newSession;
}

/**
 * Revokes all sessions in a token family (reuse-attack response).
 */
export async function revokeTokenFamily(
  ctx: DbContext,
  tokenFamilyId: string,
): Promise<void> {
  await ctx.db
    .update(userSessions)
    .set({ revokedAt: new Date() })
    .where(and(
      eq(userSessions.tokenFamilyId, tokenFamilyId),
      isNull(userSessions.revokedAt),
    ));
}

/**
 * Revokes a specific user session by ID.
 */
export async function revokeUserSessionById(
  ctx: DbContext,
  sessionId: string,
): Promise<void> {
  await ctx.db
    .update(userSessions)
    .set({ revokedAt: new Date() })
    .where(eq(userSessions.id, sessionId));
}
