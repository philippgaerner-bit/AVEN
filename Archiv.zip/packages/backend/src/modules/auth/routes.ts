/**
 * Auth HTTP routes.
 *
 * Token extraction from Authorization header: Bearer <token>
 * Tokens are NEVER written to logs or error responses.
 */

import type { FastifyInstance } from "fastify";
import type { DbContext } from "../../db/client.js";
import { AppError } from "../../errors/index.js";
import {
  startAnonSession,
  logoutAnonSession,
  rotateToken,
  logoutUserSession,
} from "./service.js";

// ─── Shared schemas ───────────────────────────────────────────────────────────

const tokenResponseSchema = {
  type: "object",
  required: ["token", "expiresAt", "sessionId"],
  properties: {
    token:     { type: "string", description: "Opaque session token — store securely" },
    sessionId: { type: "string", format: "uuid" },
    expiresAt: { type: "string", format: "date-time" },
  },
} as const;

const errorSchema = {
  type: "object",
  properties: {
    error: {
      type: "object",
      properties: {
        code:    { type: "string" },
        message: { type: "string" },
      },
    },
  },
} as const;

// ─── Route registration ───────────────────────────────────────────────────────

export async function registerAuthRoutes(
  app: FastifyInstance,
  ctx: DbContext,
): Promise<void> {
  /**
   * POST /auth/anonymous
   * Creates a new anonymous session. No credentials required.
   * The returned token must be sent as `Authorization: Bearer <token>` in subsequent requests.
   */
  app.post(
    "/auth/anonymous",
    {
      schema: {
        operationId: "createAnonymousSession",
        summary: "Create anonymous session",
        description:
          "Creates a new anonymous session without registration. " +
          "Returns a bearer token valid for 90 days.",
        response: {
          201: tokenResponseSchema,
          500: errorSchema,
        },
      },
    },
    async (_req, reply) => {
      const session = await startAnonSession(ctx);
      return reply.status(201).send({
        token:     session.token,
        sessionId: session.sessionId,
        expiresAt: session.expiresAt.toISOString(),
      });
    },
  );

  /**
   * POST /auth/session/rotate
   * Rotates a user refresh token. Invalidates the old token.
   * Requires: Authorization: Bearer <current_refresh_token>
   */
  app.post(
    "/auth/session/rotate",
    {
      schema: {
        operationId: "rotateSession",
        summary: "Rotate refresh token",
        description:
          "Issues a new refresh token and invalidates the current one. " +
          "If the current token was already replaced (replay attack), " +
          "the entire session family is revoked.",
        response: {
          200: tokenResponseSchema,
          401: errorSchema,
        },
      },
    },
    async (req, reply) => {
      const token = extractBearerToken(req.headers["authorization"]);
      const result = await rotateToken(ctx, token);
      return reply.status(200).send({
        token:     result.token,
        sessionId: result.sessionId,
        expiresAt: result.expiresAt.toISOString(),
      });
    },
  );

  /**
   * POST /auth/logout
   * Revokes the current session (anonymous or user).
   * Idempotent — succeeds even if the session was already revoked.
   */
  app.post(
    "/auth/logout",
    {
      schema: {
        operationId: "logout",
        summary: "Logout / revoke session",
        description:
          "Revokes the current session. Idempotent. " +
          "Works for both anonymous and authenticated sessions.",
        response: {
          204: { type: "null", description: "Session revoked" },
        },
      },
    },
    async (req, reply) => {
      const token = extractBearerToken(req.headers["authorization"]);
      // Try anonymous logout first; if that's a no-op, try user session
      await logoutAnonSession(ctx, token);
      await logoutUserSession(ctx, token);
      return reply.status(204).send();
    },
  );
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

/**
 * Extracts the bearer token from an Authorization header.
 * Returns the raw string (which may be malformed — service layer validates shape).
 * Never throws here — invalid inputs are handled by the service.
 */
function extractBearerToken(header: string | undefined): string | undefined {
  if (!header) return undefined;
  const parts = header.split(" ");
  if (parts.length !== 2 || parts[0]?.toLowerCase() !== "bearer") return undefined;
  return parts[1];
}
