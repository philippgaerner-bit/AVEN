/**
 * Auth service — orchestrates auth business logic.
 *
 * This layer owns:
 *   - input validation (token shape, required fields)
 *   - error mapping to AppError
 *   - idempotency boundary (future)
 *
 * It does NOT own HTTP or DB details.
 */

import type { DbContext } from "../../db/client.js";
import { AppError } from "../../errors/index.js";
import { isValidTokenShape } from "./token.js";
import {
  createAnonSession,
  resolveAnonSession,
  revokeAnonSession,
  createUserSession,
  resolveUserSession,
  rotateUserSession,
  revokeUserSessionById,
  getUserById,
} from "./repository.js";

// ─── Anonymous sessions ───────────────────────────────────────────────────────

export interface CreateAnonSessionResult {
  sessionId: string;
  /** Raw token — send to client exactly once, never log */
  token: string;
  expiresAt: Date;
}

export async function startAnonSession(
  ctx: DbContext,
): Promise<CreateAnonSessionResult> {
  return createAnonSession(ctx);
}

export async function validateAnonToken(
  ctx: DbContext,
  rawToken: unknown,
): Promise<{ sessionId: string }> {
  if (!isValidTokenShape(rawToken)) {
    throw AppError.unauthorized("Invalid or missing session token");
  }
  const session = await resolveAnonSession(ctx, rawToken);
  if (!session) {
    throw AppError.unauthorized("Session not found, expired, or already migrated");
  }
  return { sessionId: session.id };
}

export async function logoutAnonSession(
  ctx: DbContext,
  rawToken: unknown,
): Promise<void> {
  if (!isValidTokenShape(rawToken)) {
    // Treat invalid tokens as already-logged-out; don't reveal existence
    return;
  }
  const session = await resolveAnonSession(ctx, rawToken);
  if (!session) return; // idempotent
  await revokeAnonSession(ctx, session.id);
}

// ─── User sessions ────────────────────────────────────────────────────────────

export interface CreateUserSessionResult {
  sessionId: string;
  /** Raw refresh token — send to client exactly once, never log */
  token: string;
  expiresAt: Date;
  userId: string;
}

/**
 * Creates a session for an existing user (called after successful auth).
 * Phase 4.1: used internally. Phase 4.2 will call this after Apple OAuth.
 */
export async function startUserSession(
  ctx: DbContext,
  userId: string,
): Promise<CreateUserSessionResult> {
  const user = await getUserById(ctx, userId);
  if (!user) throw AppError.notFound("User");
  if (user.deletedAt !== null) throw AppError.forbidden("Account is deactivated");

  const session = await createUserSession(ctx, userId);
  return { ...session, userId };
}

export async function validateUserToken(
  ctx: DbContext,
  rawToken: unknown,
): Promise<{ sessionId: string; userId: string }> {
  if (!isValidTokenShape(rawToken)) {
    throw AppError.unauthorized("Invalid or missing session token");
  }
  const session = await resolveUserSession(ctx, rawToken);
  if (!session) {
    throw AppError.unauthorized("Session not found, expired, or revoked");
  }
  return { sessionId: session.id, userId: session.userId };
}

export async function rotateToken(
  ctx: DbContext,
  rawToken: unknown,
): Promise<CreateUserSessionResult> {
  if (!isValidTokenShape(rawToken)) {
    throw AppError.unauthorized("Invalid or missing session token");
  }
  const result = await rotateUserSession(ctx, rawToken);
  if (!result) {
    // Either reuse detected (family revoked) or session not found/expired
    throw AppError.unauthorized(
      "Session cannot be rotated. Please log in again.",
    );
  }
  // We need the userId — look it up from the new session
  const session = await resolveUserSession(ctx, result.token);
  if (!session) throw AppError.internal("Rotation produced invalid session");

  return { ...result, userId: session.userId };
}

export async function logoutUserSession(
  ctx: DbContext,
  rawToken: unknown,
): Promise<void> {
  if (!isValidTokenShape(rawToken)) return; // idempotent

  const session = await resolveUserSession(ctx, rawToken);
  if (!session) return; // already revoked / expired — idempotent
  await revokeUserSessionById(ctx, session.id);
}
