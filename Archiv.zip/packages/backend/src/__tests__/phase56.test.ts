/**
 * Phase 5.6 — Real Provider Integration Boundary Tests
 *
 *   A  Config — provider fields loaded correctly
 *   B  Provider factory — selection from config
 *   C  Output validation — malformed observations rejected
 *   D  Timeout and retry helpers
 *   E  Adapter boundaries (HTTP-ready, no network)
 *   F  No scoring injection via observations
 *   G  Existing pipeline still deterministic with fake providers
 */

import { describe, it } from "node:test";
import assert from "node:assert/strict";

import { loadConfig, ConfigError } from "../config/index.js";
import {
  createProviders,
  validateObservations,
  withTimeout,
  withRetry,
  HttpOCRAdapter,
  HttpVisionAdapter,
} from "../modules/pipeline/factory.js";
import {
  StubOCRProvider,
  StubVisionObservationProvider,
  StubImageProcessor,
} from "../modules/pipeline/providers.js";
import { runAnalysisPipeline, PIPELINE_VERSION } from "../modules/pipeline/orchestrator.js";
import { isPipelineSuccess } from "../modules/pipeline/types.js";
import { SCORING_MODEL_VERSION } from "@vyro/shared/scoring";
import type { ProviderObservation } from "../modules/pipeline/types.js";

// ─── Base test env ────────────────────────────────────────────────────────────

function baseEnv(): Record<string, string> {
  return {
    NODE_ENV: "test", PORT: "3000",
    DATABASE_URL: "postgresql://localhost/test",
    JWT_SECRET: "test-secret-minimum-32-chars-long!!",
    APPLE_CLIENT_ID: "com.test", GCS_BUCKET_NAME: "test-bucket",
  };
}

const FAKE_BYTES = new Uint8Array([0xff, 0xd8, 0xff, 0xe0]);

// ─── A: Config provider fields ────────────────────────────────────────────────

describe("A: Config — provider fields", () => {
  it("defaults to 'fake' in test environment", () => {
    const cfg = loadConfig(baseEnv());
    assert.equal(cfg.ocrProvider,              "fake");
    assert.equal(cfg.visionProvider,           "fake");
    assert.equal(cfg.recommendationAiProvider, "fake");
  });

  it("providerTimeoutMs defaults to 10000", () => {
    const cfg = loadConfig(baseEnv());
    assert.equal(cfg.providerTimeoutMs, 10000);
  });

  it("providerMaxRetries defaults to 2", () => {
    const cfg = loadConfig(baseEnv());
    assert.equal(cfg.providerMaxRetries, 2);
  });

  it("OCR_PROVIDER env var is picked up", () => {
    const cfg = loadConfig({ ...baseEnv(), OCR_PROVIDER: "disabled" });
    assert.equal(cfg.ocrProvider, "disabled");
  });

  it("VISION_PROVIDER env var is picked up", () => {
    const cfg = loadConfig({ ...baseEnv(), VISION_PROVIDER: "disabled" });
    assert.equal(cfg.visionProvider, "disabled");
  });

  it("PROVIDER_TIMEOUT_MS env var is picked up", () => {
    const cfg = loadConfig({ ...baseEnv(), PROVIDER_TIMEOUT_MS: "5000" });
    assert.equal(cfg.providerTimeoutMs, 5000);
  });

  it("PROVIDER_MAX_RETRIES env var is picked up", () => {
    const cfg = loadConfig({ ...baseEnv(), PROVIDER_MAX_RETRIES: "0" });
    assert.equal(cfg.providerMaxRetries, 0);
  });

  it("Provider settings don't leak in error messages (no secret values)", () => {
    // Provider config values are non-secret; but the API key is never in config struct
    const cfg = loadConfig(baseEnv());
    assert.ok(!JSON.stringify(cfg).includes("password"));
    assert.ok(!JSON.stringify(cfg).includes("apiKey"));
  });
});

// ─── B: Provider factory ─────────────────────────────────────────────────────

describe("B: Provider factory", () => {
  it("createProviders('fake') returns working stub providers", () => {
    const cfg = loadConfig(baseEnv());
    const providers = createProviders(cfg);
    assert.ok(providers.imageProcessor instanceof StubImageProcessor);
    assert.equal(typeof providers.ocr.extractText, "function");
    assert.equal(typeof providers.vision.detectPlatform, "function");
  });

  it("createProviders for 'disabled' OCR returns DisabledOCRProvider", async () => {
    const cfg = loadConfig({ ...baseEnv(), OCR_PROVIDER: "disabled" });
    const { ocr } = createProviders(cfg);
    assert.equal(ocr.providerName, "disabled");
    await assert.rejects(() => ocr.extractText({ storageKey:"k", contentType:"image/jpeg", byteSize:4 }, []));
  });

  it("createProviders for 'disabled' Vision returns DisabledVisionProvider", async () => {
    const cfg = loadConfig({ ...baseEnv(), VISION_PROVIDER: "disabled" });
    const { vision } = createProviders(cfg);
    assert.equal(vision.providerName, "disabled");
    await assert.rejects(() => vision.detectPlatform({ storageKey:"k", contentType:"image/jpeg", byteSize:4 }));
  });

  it("Unsupported OCR_PROVIDER throws ConfigError at startup", () => {
    const cfg = loadConfig({ ...baseEnv(), OCR_PROVIDER: "vendor-x" });
    assert.throws(() => createProviders(cfg), ConfigError);
  });

  it("Unsupported VISION_PROVIDER throws ConfigError at startup", () => {
    const cfg = loadConfig({ ...baseEnv(), VISION_PROVIDER: "vendor-y" });
    assert.throws(() => createProviders(cfg), ConfigError);
  });

  it("ConfigError message names the unsupported provider", () => {
    const cfg = loadConfig({ ...baseEnv(), OCR_PROVIDER: "my-bad-vendor" });
    try {
      createProviders(cfg);
      assert.fail("Should have thrown");
    } catch (e) {
      assert.ok(e instanceof ConfigError);
      assert.ok(e.message.includes("my-bad-vendor"), "Error must name the bad value");
    }
  });

  it("No network call on import (module import is safe)", async () => {
    // Importing factory module must not throw or make network requests
    const { createProviders: cp } = await import("../modules/pipeline/factory.js");
    assert.equal(typeof cp, "function");
  });
});

// ─── C: Output validation ─────────────────────────────────────────────────────

describe("C: Output validation — malformed observations", () => {
  const validObs: ProviderObservation = {
    criterionId: "bio_target_audience", state: "fulfilled", source: "C",
  };

  it("Valid observations pass through", () => {
    const result = validateObservations([validObs]);
    assert.equal(result.length, 1);
  });

  it("Unknown criterionId is rejected", () => {
    assert.throws(
      () => validateObservations([{ ...validObs, criterionId: "does_not_exist" }]),
      (e: unknown) => e instanceof Error && (e as Error).message.includes("unknown criterionId"),
    );
  });

  it("Invalid state is rejected", () => {
    assert.throws(
      () => validateObservations([{ ...validObs, state: "invented" as never }]),
      (e: unknown) => e instanceof Error && (e as Error).message.includes("invalid state"),
    );
  });

  it("Duplicate criterionId is rejected", () => {
    assert.throws(
      () => validateObservations([validObs, validObs]),
      (e: unknown) => e instanceof Error && (e as Error).message.includes("duplicate"),
    );
  });

  it("Observation with 'score' field is rejected", () => {
    const withScore = { ...validObs, score: 42 } as unknown as ProviderObservation;
    assert.throws(
      () => validateObservations([withScore]),
      (e: unknown) => e instanceof Error && (e as Error).message.includes("forbidden scoring field"),
    );
  });

  it("Observation with 'priority' field is rejected", () => {
    const withPriority = { ...validObs, priority: 1 } as unknown as ProviderObservation;
    assert.throws(
      () => validateObservations([withPriority]),
      (e: unknown) => e instanceof Error && (e as Error).message.includes("forbidden scoring field"),
    );
  });

  it("Observation with 'impact' field is rejected", () => {
    const withImpact = { ...validObs, impact: 5 } as unknown as ProviderObservation;
    assert.throws(
      () => validateObservations([withImpact]),
      (e: unknown) => e instanceof Error && (e as Error).message.includes("forbidden scoring field"),
    );
  });

  it("Empty observation list is valid", () => {
    const result = validateObservations([]);
    assert.equal(result.length, 0);
  });

  it("All 4 valid states are accepted", () => {
    const criterionIds = ["bio_target_audience", "bio_outcome", "bio_cta", "bio_first_line"];
    const states = ["fulfilled", "partial", "missing", "unavailable"] as const;
    const obs = criterionIds.map((id, i) => ({
      criterionId: id, state: states[i]!, source: "C" as const,
    }));
    const result = validateObservations(obs);
    assert.equal(result.length, 4);
  });
});

// ─── D: Timeout and retry ─────────────────────────────────────────────────────

describe("D: Timeout and retry helpers", () => {
  it("withTimeout resolves when fn completes in time", async () => {
    const result = await withTimeout(() => Promise.resolve(42), 1000, "test");
    assert.equal(result, 42);
  });

  it("withTimeout rejects after timeout", async () => {
    await assert.rejects(
      () => withTimeout(
        () => new Promise((r) => setTimeout(r, 200)),
        50, "slow-task",
      ),
      (e: unknown) => e instanceof Error && (e as Error).message.includes("timeout"),
    );
  });

  it("withTimeout error message includes task name", async () => {
    try {
      await withTimeout(() => new Promise((r) => setTimeout(r, 200)), 10, "my-provider-call");
    } catch (e) {
      assert.ok((e as Error).message.includes("my-provider-call"));
    }
  });

  it("withRetry succeeds on first attempt", async () => {
    let calls = 0;
    const result = await withRetry(() => { calls++; return Promise.resolve("ok"); }, 2, "test");
    assert.equal(result, "ok");
    assert.equal(calls, 1);
  });

  it("withRetry retries up to maxRetries times then throws", async () => {
    let calls = 0;
    await assert.rejects(
      () => withRetry(() => { calls++; return Promise.reject(new Error("fail")); }, 2, "test"),
    );
    assert.equal(calls, 3); // 1 initial + 2 retries
  });

  it("withRetry succeeds on second attempt", async () => {
    let calls = 0;
    const result = await withRetry(
      () => { calls++; if (calls < 2) throw new Error("not yet"); return Promise.resolve("done"); },
      2, "test",
    );
    assert.equal(result, "done");
    assert.equal(calls, 2);
  });

  it("withRetry(maxRetries=0) fails immediately with no retry", async () => {
    let calls = 0;
    await assert.rejects(
      () => withRetry(() => { calls++; return Promise.reject(new Error("fail")); }, 0, "test"),
    );
    assert.equal(calls, 1);
  });

  it("withRetry error message includes task name on exhaustion", async () => {
    try {
      await withRetry(() => Promise.reject(new Error("boom")), 1, "vision-call");
    } catch (e) {
      assert.ok((e as Error).message.includes("vision-call"));
    }
  });
});

// ─── E: Adapter boundaries ───────────────────────────────────────────────────

describe("E: HTTP adapter boundaries (no network)", () => {
  const ocrAdapter = new HttpOCRAdapter({
    endpoint: "https://ocr.provider.example/v1", apiKey: "test-key",
    modelVersion: "ocr-v1", timeoutMs: 5000,
  });

  const visionAdapter = new HttpVisionAdapter({
    endpoint: "https://vision.provider.example/v1", apiKey: "test-key",
    modelVersion: "vision-v1", timeoutMs: 5000,
  });

  it("HttpOCRAdapter is importable and has correct providerName", () => {
    assert.equal(ocrAdapter.providerName, "http-ocr");
    assert.equal(typeof ocrAdapter.extractText, "function");
  });

  it("HttpOCRAdapter.extractText throws (not configured) without making network call", async () => {
    await assert.rejects(() => ocrAdapter.extractText(
      { storageKey:"k", contentType:"image/jpeg", byteSize:4 }, [],
    ));
  });

  it("HttpVisionAdapter is importable and has correct providerName", () => {
    assert.equal(visionAdapter.providerName, "http-vision");
  });

  it("HttpVisionAdapter.detectPlatform throws (not configured)", async () => {
    await assert.rejects(() => visionAdapter.detectPlatform(
      { storageKey:"k", contentType:"image/jpeg", byteSize:4 },
    ));
  });

  it("HttpVisionAdapter.createCriterionObservations throws (not configured)", async () => {
    await assert.rejects(() => visionAdapter.createCriterionObservations("tiktok", [], []));
  });
});

// ─── F: No scoring injection via observations ─────────────────────────────────

describe("F: No scoring injection", () => {
  it("Provider observation cannot inject a total score", () => {
    const obs = {
      criterionId: "bio_target_audience", state: "fulfilled" as const, source: "C" as const,
      total: 100,  // attempt to inject
    } as unknown as ProviderObservation;
    assert.throws(() => validateObservations([obs]));
  });

  it("Scoring result total comes from calculateScore, not observation fields", async () => {
    const image = { storageKey:"k", contentType:"image/jpeg" as const, byteSize:4, bytes:FAKE_BYTES };
    const providers = {
      imageProcessor: new StubImageProcessor(),
      ocr: new StubOCRProvider(),
      vision: new StubVisionObservationProvider({ observationState: "fulfilled" }),
    };
    const result = await runAnalysisPipeline(image, "profile-1", providers);
    if (isPipelineSuccess(result)) {
      // Score 100 comes from the deterministic engine, not the provider
      assert.equal(result.scoringResult.scoreSet.total, 100);
      // Verify no observation has a score field
      for (const o of result.observations) {
        const raw = o as unknown as Record<string, unknown>;
        assert.ok(!("total" in raw));
        assert.ok(!("score" in raw));
      }
    }
  });
});

// ─── G: Existing pipeline remains deterministic with fake providers ────────────

describe("G: Pipeline determinism with factory-created providers", () => {
  it("Factory 'fake' providers produce same score as direct stub", async () => {
    const image = { storageKey:"k", contentType:"image/jpeg" as const, byteSize:4, bytes:FAKE_BYTES };

    const directProviders = {
      imageProcessor: new StubImageProcessor(),
      ocr: new StubOCRProvider(),
      vision: new StubVisionObservationProvider({ observationState: "fulfilled" }),
    };

    const cfg = loadConfig(baseEnv());
    const factoryProviders = createProviders(cfg);

    const r1 = await runAnalysisPipeline(image, "p", directProviders);
    const r2 = await runAnalysisPipeline(image, "p", factoryProviders);

    if (isPipelineSuccess(r1) && isPipelineSuccess(r2)) {
      assert.equal(r1.scoringResult.scoreSet.total, r2.scoringResult.scoreSet.total);
      assert.equal(r1.findings.length, r2.findings.length);
    }
  });

  it("ValidatedVisionProvider passes clean stub output unchanged", async () => {
    const cfg = loadConfig(baseEnv());
    const { vision } = createProviders(cfg);
    const obs = await vision.createCriterionObservations("tiktok", [], []);
    assert.equal(obs.length, 31);
    for (const o of obs) {
      assert.ok(o.criterionId.length > 0);
      assert.ok(["fulfilled","partial","missing","unavailable"].includes(o.state));
    }
  });

  it("Pipeline + factory providers: 10 identical runs produce same score", async () => {
    const image = { storageKey:"k", contentType:"image/jpeg" as const, byteSize:4, bytes:FAKE_BYTES };
    const cfg = loadConfig(baseEnv());
    const providers = createProviders(cfg);
    const scores: number[] = [];
    for (let i = 0; i < 10; i++) {
      const r = await runAnalysisPipeline(image, "p", providers);
      if (isPipelineSuccess(r)) scores.push(r.scoringResult.scoreSet.total);
    }
    assert.equal(scores.length, 10);
    assert.equal(new Set(scores).size, 1, "Score must be identical across 10 runs");
  });
});
