/**
 * Phase 4.1 Auth Tests
 *
 *   A  Token utilities (pure, no DB)
 *   B  Repository logic via in-memory fake DbContext
 *   C  Service layer
 *   D  HTTP routes via Fastify inject
 *   E  Security properties
 */

import { describe, it, before, after, beforeEach } from "node:test";
import assert from "node:assert/strict";

import {
  generateToken,
  generateTokenPair,
  hashToken,
  verifyToken,
  isValidTokenShape,
  isExpired,
  expiresAt,
  TOKEN_BYTES,
  ANON_SESSION_TTL_DAYS,
} from "../modules/auth/token.js";

import {
  createAnonSession,
  resolveAnonSession,
  revokeAnonSession,
  createUserSession,
  resolveUserSession,
  rotateUserSession,
  revokeUserSessionById,
  createUser,
  getUserById,
} from "../modules/auth/repository.js";

import {
  startAnonSession,
  validateAnonToken,
  logoutAnonSession,
  startUserSession,
  validateUserToken,
  rotateToken,
  logoutUserSession,
} from "../modules/auth/service.js";

import { AppError, formatErrorResponse } from "../errors/index.js";
import { loadConfig } from "../config/index.js";
import { createApp } from "../app.js";
import type { FastifyInstance } from "fastify";

// ─── In-memory fake DbContext ────────────────────────────────────────────────
// Tests that exercise repository or service logic need a DbContext.
// We use a real Drizzle-shaped in-memory store to avoid mocking internals.
// Since we have no local Postgres, we test logic that doesn't touch the DB
// directly (token utils, service validation), and use the HTTP tests
// to confirm route wiring with a NULL_DB_CONTEXT (which throws on any DB op).

// For repository/service tests that DO need a DB, we test the pure-function
// layer (token, validation) and the HTTP surface (Fastify inject).
// The repository itself is integration-tested (needs real PG) — excluded here.

// ─── A: Token utilities ──────────────────────────────────────────────────────

describe("A: Token utilities", () => {
  it("generateToken returns a 43-char base64url string", () => {
    const t = generateToken();
    assert.equal(typeof t, "string");
    assert.equal(t.length, 43, `Expected 43 chars, got ${t.length}`);
    assert.match(t, /^[A-Za-z0-9_-]+$/);
  });

  it("generateToken produces unique tokens", () => {
    const tokens = new Set(Array.from({ length: 100 }, () => generateToken()));
    assert.equal(tokens.size, 100, "Token collision detected");
  });

  it("hashToken returns a 64-char hex string", () => {
    const h = hashToken("any-input");
    assert.equal(typeof h, "string");
    assert.equal(h.length, 64);
    assert.match(h, /^[0-9a-f]+$/);
  });

  it("hashToken is deterministic", () => {
    assert.equal(hashToken("abc"), hashToken("abc"));
    assert.notEqual(hashToken("abc"), hashToken("ABC"));
  });

  it("generateTokenPair returns matching token and hash", () => {
    const { token, hash } = generateTokenPair();
    assert.equal(hash, hashToken(token));
    assert.equal(token.length, 43);
    assert.equal(hash.length, 64);
  });

  it("verifyToken: correct token passes", () => {
    const { token, hash } = generateTokenPair();
    assert.equal(verifyToken(token, hash), true);
  });

  it("verifyToken: wrong token fails", () => {
    const { hash } = generateTokenPair();
    const { token: other } = generateTokenPair();
    assert.equal(verifyToken(other, hash), false);
  });

  it("verifyToken: empty string fails safely", () => {
    const { hash } = generateTokenPair();
    assert.equal(verifyToken("", hash), false);
  });

  it("verifyToken: corrupted hash fails safely", () => {
    const { token } = generateTokenPair();
    assert.equal(verifyToken(token, "not-a-valid-hash"), false);
  });

  it("isValidTokenShape: valid token passes", () => {
    assert.equal(isValidTokenShape(generateToken()), true);
  });

  it("isValidTokenShape: rejects non-string", () => {
    assert.equal(isValidTokenShape(123),       false);
    assert.equal(isValidTokenShape(null),      false);
    assert.equal(isValidTokenShape(undefined), false);
    assert.equal(isValidTokenShape({}),        false);
  });

  it("isValidTokenShape: rejects empty string", () => {
    assert.equal(isValidTokenShape(""), false);
  });

  it("isValidTokenShape: rejects wrong length", () => {
    assert.equal(isValidTokenShape("abc"), false);
    assert.equal(isValidTokenShape("a".repeat(44)), false);
    assert.equal(isValidTokenShape("a".repeat(42)), false);
  });

  it("isValidTokenShape: rejects non-base64url characters", () => {
    // 43 chars but contains invalid char
    assert.equal(isValidTokenShape("a".repeat(42) + "!"), false);
    assert.equal(isValidTokenShape("a".repeat(42) + "+"), false);
    assert.equal(isValidTokenShape("a".repeat(42) + "/"), false);
  });

  it("expiresAt returns a future date", () => {
    const exp = expiresAt(30);
    assert.ok(exp > new Date());
  });

  it("isExpired: past date is expired", () => {
    assert.equal(isExpired(new Date(0)), true);
  });

  it("isExpired: future date is not expired", () => {
    assert.equal(isExpired(expiresAt(1)), false);
  });

  it("TOKEN_BYTES is 32", () => {
    assert.equal(TOKEN_BYTES, 32);
  });

  it("ANON_SESSION_TTL_DAYS is 90", () => {
    assert.equal(ANON_SESSION_TTL_DAYS, 90);
  });

  it("raw token is not stored in hash (hash is different from token)", () => {
    const { token, hash } = generateTokenPair();
    assert.notEqual(token, hash);
    // token is base64url, hash is hex — they can't be equal
    assert.ok(!hash.includes(token));
  });
});

// ─── B: Service validation (no DB) ───────────────────────────────────────────

describe("B: Service — input validation (no DB)", () => {
  // We test the validation layer of service functions without a real DB.
  // These throw AppError.unauthorized before any DB call.

  it("validateAnonToken rejects undefined", async () => {
    await assert.rejects(
      // NULL_DB_CONTEXT would throw if used — but validation fires first
      () => validateAnonToken({ db: null } as never, undefined),
      (e) => e instanceof AppError && e.code === "UNAUTHORIZED",
    );
  });

  it("validateAnonToken rejects empty string", async () => {
    await assert.rejects(
      () => validateAnonToken({ db: null } as never, ""),
      (e) => e instanceof AppError && e.code === "UNAUTHORIZED",
    );
  });

  it("validateAnonToken rejects short token", async () => {
    await assert.rejects(
      () => validateAnonToken({ db: null } as never, "tooshort"),
      (e) => e instanceof AppError && e.code === "UNAUTHORIZED",
    );
  });

  it("validateAnonToken rejects token with invalid chars", async () => {
    await assert.rejects(
      () => validateAnonToken({ db: null } as never, "a".repeat(42) + "/"),
      (e) => e instanceof AppError && e.code === "UNAUTHORIZED",
    );
  });

  it("validateUserToken rejects malformed token", async () => {
    await assert.rejects(
      () => validateUserToken({ db: null } as never, "bad"),
      (e) => e instanceof AppError && e.code === "UNAUTHORIZED",
    );
  });

  it("rotateToken rejects malformed token", async () => {
    await assert.rejects(
      () => rotateToken({ db: null } as never, "bad"),
      (e) => e instanceof AppError && e.code === "UNAUTHORIZED",
    );
  });

  it("logoutAnonSession with invalid token is idempotent (no throw)", async () => {
    // Invalid token shape → early return, no DB access
    await assert.doesNotReject(
      () => logoutAnonSession({ db: null } as never, undefined),
    );
    await assert.doesNotReject(
      () => logoutAnonSession({ db: null } as never, "bad"),
    );
  });

  it("logoutUserSession with invalid token is idempotent (no throw)", async () => {
    await assert.doesNotReject(
      () => logoutUserSession({ db: null } as never, undefined),
    );
  });
});

// ─── C: Security properties ───────────────────────────────────────────────────

describe("C: Security properties", () => {
  it("hashToken output does not contain the raw token", () => {
    const token = generateToken();
    const hash  = hashToken(token);
    assert.ok(!hash.includes(token), "Hash must not contain raw token");
  });

  it("Two different tokens never produce the same hash", () => {
    const pairs = Array.from({ length: 50 }, generateTokenPair);
    const hashes = new Set(pairs.map((p) => p.hash));
    assert.equal(hashes.size, 50, "Hash collision detected");
  });

  it("verifyToken is constant-time safe for mismatched lengths", () => {
    // Should return false, not throw, for hashes of wrong length
    assert.equal(verifyToken("a".repeat(43), ""), false);
    assert.equal(verifyToken("a".repeat(43), "x"), false);
    assert.equal(verifyToken("a".repeat(43), "ff".repeat(100)), false);
  });

  it("Generated tokens are URL-safe (no + / = characters)", () => {
    for (let i = 0; i < 200; i++) {
      const t = generateToken();
      assert.ok(!/[+/=]/.test(t), `Token contains URL-unsafe char: ${t}`);
    }
  });

  it("Token shape validation prevents SQL-injection-shaped inputs", () => {
    const injections = [
      "' OR 1=1 --",
      "admin'--",
      "1; DROP TABLE users;",
      "<script>alert(1)</script>",
    ];
    for (const s of injections) {
      assert.equal(isValidTokenShape(s), false, `Should reject: ${s}`);
    }
  });
});

// ─── D: HTTP routes via Fastify inject ───────────────────────────────────────
// We test route wiring and error handling with NULL_DB_CONTEXT.
// Routes that need DB will 500 (expected with null DB) — we verify the
// error format. Route-level validation and non-DB paths are fully tested.

describe("D: HTTP routes (Fastify inject, NULL_DB_CONTEXT)", () => {
  let app: FastifyInstance;

  const cfg = loadConfig({
    NODE_ENV: "test", PORT: "3002",
    DATABASE_URL: "postgresql://localhost:5432/test",
    JWT_SECRET: "test-secret-minimum-32-chars-long!!",
    APPLE_CLIENT_ID: "com.vyro.test",
    GCS_BUCKET_NAME: "vyro-test",
  });

  before(async () => {
    // NULL_DB_CONTEXT — auth routes exist but DB calls throw
    app = await createApp(cfg);
  });
  after(async () => { await app.close(); });

  it("POST /auth/anonymous exists and returns JSON", async () => {
    const res = await app.inject({ method: "POST", url: "/auth/anonymous" });
    // With NULL_DB_CONTEXT the DB insert throws → 500, but route exists
    assert.notEqual(res.statusCode, 404, "Route /auth/anonymous must exist");
    // Check error format
    if (res.statusCode >= 400) {
      const body = res.json<{ error: { code: string } }>();
      assert.ok(body.error?.code, "Error response must have code field");
    }
  });

  it("POST /auth/session/rotate without token → 401", async () => {
    const res = await app.inject({
      method: "POST",
      url: "/auth/session/rotate",
      headers: {}, // no Authorization
    });
    assert.equal(res.statusCode, 401);
    const body = res.json<{ error: { code: string } }>();
    assert.equal(body.error.code, "UNAUTHORIZED");
  });

  it("POST /auth/session/rotate with malformed token → 401", async () => {
    const res = await app.inject({
      method: "POST",
      url: "/auth/session/rotate",
      headers: { authorization: "Bearer tooshort" },
    });
    assert.equal(res.statusCode, 401);
    const body = res.json<{ error: { code: string } }>();
    assert.equal(body.error.code, "UNAUTHORIZED");
  });

  it("POST /auth/logout without token → 204 (idempotent)", async () => {
    const res = await app.inject({ method: "POST", url: "/auth/logout" });
    assert.equal(res.statusCode, 204);
  });

  it("POST /auth/logout with malformed token → 204 (idempotent)", async () => {
    const res = await app.inject({
      method: "POST",
      url: "/auth/logout",
      headers: { authorization: "Bearer bad" },
    });
    assert.equal(res.statusCode, 204);
  });

  it("POST /auth/logout with well-formed but unknown token → 204 (idempotent)", async () => {
    const token = generateToken();
    const res = await app.inject({
      method: "POST",
      url: "/auth/logout",
      headers: { authorization: `Bearer ${token}` },
    });
    // logoutAnonSession and logoutUserSession both try to resolve session —
    // NULL_DB_CONTEXT throws on any DB call.
    // This verifies the route is wired, 204 or 500 both acceptable here.
    assert.ok(res.statusCode === 204 || res.statusCode === 500);
  });

  it("Token is not echoed back in error responses", async () => {
    const token = generateToken();
    const res = await app.inject({
      method: "POST",
      url: "/auth/session/rotate",
      headers: { authorization: `Bearer ${token}` },
    });
    // Token (43 chars) must not appear in response body
    assert.ok(!res.body.includes(token), "Token must not appear in error response");
  });

  it("GET /health still works after auth routes registered", async () => {
    const res = await app.inject({ method: "GET", url: "/health" });
    assert.equal(res.statusCode, 200);
    assert.equal(res.json<{ status: string }>().status, "ok");
  });

  it("OpenAPI document includes auth routes", async () => {
    const doc = app.swagger() as {
      paths: Record<string, unknown>;
      openapi: string;
    };
    assert.ok(doc.paths?.["/auth/anonymous"],      "/auth/anonymous missing from OpenAPI");
    assert.ok(doc.paths?.["/auth/session/rotate"], "/auth/session/rotate missing from OpenAPI");
    assert.ok(doc.paths?.["/auth/logout"],         "/auth/logout missing from OpenAPI");
  });

  it("Auth routes use correct HTTP methods", async () => {
    // GET on POST-only route → 404
    const res = await app.inject({ method: "GET", url: "/auth/anonymous" });
    assert.ok(res.statusCode === 404 || res.statusCode === 405);
  });

  it("Error response never contains Authorization header value", async () => {
    const token = generateToken();
    const res = await app.inject({
      method: "POST",
      url: "/auth/session/rotate",
      headers: { authorization: `Bearer ${token}` },
    });
    // Neither the raw token nor the word "Bearer" should leak into response
    assert.ok(!res.body.includes(token));
  });
});

// ─── E: AppError integration ──────────────────────────────────────────────────

describe("E: AppError integration", () => {
  it("UNAUTHORIZED AppError is expose=true with status 401", () => {
    const e = AppError.unauthorized();
    assert.equal(e.expose, true);
    assert.equal(e.httpStatus, 401);
    assert.equal(e.code, "UNAUTHORIZED");
  });

  it("CONFLICT AppError is expose=true with status 409", () => {
    const e = AppError.conflict("already merged");
    assert.equal(e.expose, true);
    assert.equal(e.httpStatus, 409);
  });

  it("Internal AppError does not expose DB details", () => {
    const e = AppError.internal("DB error: password=secret at 10.0.0.1");
    assert.equal(e.expose, false);
    const { body } = formatErrorResponse(e);
    assert.ok(!body.error.message.includes("secret"));
    assert.ok(!body.error.message.includes("10.0.0.1"));
  });
});
