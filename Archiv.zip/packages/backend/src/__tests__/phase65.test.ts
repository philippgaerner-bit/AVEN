/**
 * Phase 6.5 — iOS ViewModel Logic Tests (TypeScript mirror)
 *
 * The HomeViewModel mapping functions are pure functions.
 * Since Swift toolchain unavailable on Linux, we verify the same logic
 * in TypeScript, which is semantically identical to the Swift implementation.
 * Any change to the Swift ViewModel must be mirrored here.
 *
 *   A  formatCount — number → display string
 *   B  formatChange — percentage → display string
 *   C  scoreStatus — score → status label
 *   D  mapActions — ordering + blocked filtering
 *   E  Navigation state
 *   F  API contract alignment
 */

import { describe, it } from "node:test";
import assert from "node:assert/strict";

// ─── Mirrors of HomeViewModel pure functions ──────────────────────────────────
// Keep in sync with HomeViewModel.swift

function formatCount(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000)     return `${(n / 1_000).toFixed(1)}K`;
  return `${n}`;
}

function formatChange(pct: number): string {
  const sign = pct >= 0 ? "+" : "";
  return `${sign}${pct.toFixed(1)}%`;
}

function scoreStatus(total: number): string {
  if (total >= 80) return "Stark";
  if (total >= 60) return "Gut";
  if (total >= 40) return "Verbesserbar";
  return "Kritisch";
}

interface ActionData {
  id: string; title: string; category: string;
  impact: number; priority: number; severity: string; isBlocked: boolean;
}

function mapActions(raw: ActionData[]): ActionData[] {
  return raw
    .filter((a) => !a.isBlocked || a.severity !== "polish")
    .sort((a, b) => a.priority - b.priority);
}

function impactLabel(impact: number): string {
  return `+${impact} pts`;
}

// AppTab enum
const APP_TABS = ["home", "analytics", "create", "actionPlan", "profile"] as const;
type AppTab = typeof APP_TABS[number];

// ─── A: formatCount ───────────────────────────────────────────────────────────

describe("A: formatCount", () => {
  it("< 1K → raw number", () => { assert.equal(formatCount(999), "999"); });
  it("1K → '1.0K'",       () => { assert.equal(formatCount(1000), "1.0K"); });
  it("24800 → '24.8K'",   () => { assert.equal(formatCount(24800), "24.8K"); });
  it("1M → '1.0M'",       () => { assert.equal(formatCount(1_000_000), "1.0M"); });
  it("1.5M → '1.5M'",     () => { assert.equal(formatCount(1_500_000), "1.5M"); });
  it("0 → '0'",           () => { assert.equal(formatCount(0), "0"); });
});

// ─── B: formatChange ─────────────────────────────────────────────────────────

describe("B: formatChange", () => {
  it("positive → '+X.Y%'",  () => { assert.equal(formatChange(3.2),  "+3.2%"); });
  it("negative → '-X.Y%'",  () => { assert.equal(formatChange(-1.4), "-1.4%"); });
  it("zero → '+0.0%'",      () => { assert.equal(formatChange(0),    "+0.0%"); });
  it("large positive",       () => { assert.equal(formatChange(12.7), "+12.7%"); });
});

// ─── C: scoreStatus ───────────────────────────────────────────────────────────

describe("C: scoreStatus", () => {
  it("100 → 'Stark'",        () => assert.equal(scoreStatus(100), "Stark"));
  it("80 → 'Stark'",         () => assert.equal(scoreStatus(80),  "Stark"));
  it("79 → 'Gut'",           () => assert.equal(scoreStatus(79),  "Gut"));
  it("60 → 'Gut'",           () => assert.equal(scoreStatus(60),  "Gut"));
  it("59 → 'Verbesserbar'",  () => assert.equal(scoreStatus(59),  "Verbesserbar"));
  it("40 → 'Verbesserbar'",  () => assert.equal(scoreStatus(40),  "Verbesserbar"));
  it("39 → 'Kritisch'",      () => assert.equal(scoreStatus(39),  "Kritisch"));
  it("0 → 'Kritisch'",       () => assert.equal(scoreStatus(0),   "Kritisch"));
  it("68 → 'Gut' (stub data)", () => assert.equal(scoreStatus(68), "Gut"));
});

// ─── D: mapActions ────────────────────────────────────────────────────────────

describe("D: mapActions — ordering and filtering", () => {
  const actions: ActionData[] = [
    { id:"a3", title:"Feed",        category:"feed",    impact:3, priority:3, severity:"polish",     isBlocked:true  },
    { id:"a1", title:"Bio",         category:"bio",     impact:6, priority:1, severity:"foundation", isBlocked:false },
    { id:"a2", title:"Hooks",       category:"content", impact:4, priority:2, severity:"lever",      isBlocked:false },
    { id:"a4", title:"Branding",    category:"brand",   impact:2, priority:4, severity:"polish",     isBlocked:false },
  ];

  it("Sorts by priority ascending", () => {
    const r = mapActions(actions);
    const priorities = r.map((a) => a.priority);
    assert.deepEqual(priorities, [...priorities].sort((a,b) => a-b));
  });

  it("Blocked polish actions are excluded", () => {
    const r = mapActions(actions);
    assert.ok(!r.some((a) => a.isBlocked && a.severity === "polish"),
      "Blocked polish must be filtered out");
  });

  it("Non-blocked polish actions are included", () => {
    const r = mapActions(actions);
    assert.ok(r.some((a) => a.id === "a4"), "Non-blocked polish (a4) must be included");
  });

  it("Foundation actions come first", () => {
    const r = mapActions(actions);
    assert.equal(r[0]!.severity, "foundation");
  });

  it("impactLabel formats correctly", () => {
    assert.equal(impactLabel(6), "+6 pts");
    assert.equal(impactLabel(3), "+3 pts");
  });

  it("Empty action list → empty result", () => {
    assert.deepEqual(mapActions([]), []);
  });

  it("All blocked polish → empty result", () => {
    const all = [
      { id:"x", title:"t", category:"c", impact:1, priority:1, severity:"polish", isBlocked:true },
    ];
    assert.equal(mapActions(all).length, 0);
  });
});

// ─── E: Navigation state ─────────────────────────────────────────────────────

describe("E: Navigation tab state", () => {
  it("5 tabs defined", () => {
    assert.equal(APP_TABS.length, 5);
  });

  it("Tab IDs are correct", () => {
    assert.deepEqual([...APP_TABS], ["home","analytics","create","actionPlan","profile"]);
  });

  it("Default tab is home", () => {
    let selected: AppTab = "home";
    assert.equal(selected, "home");
  });

  it("Tab selection is type-safe (invalid tab is a type error)", () => {
    const validTabs: AppTab[] = ["home","analytics","create","actionPlan","profile"];
    assert.equal(validTabs.length, 5);
  });
});

// ─── F: API contract alignment ────────────────────────────────────────────────

describe("F: API contract alignment", () => {
  it("SocialPlatform values match backend CREATOR_PLATFORMS", async () => {
    const { CREATOR_PLATFORMS } = await import("../db/enums.js");
    const swiftPlatforms = ["tiktok", "instagram"]; // from HomeDomain.swift SocialPlatform enum
    for (const p of swiftPlatforms) {
      assert.ok((CREATOR_PLATFORMS as readonly string[]).includes(p),
        `iOS platform '${p}' not in backend CREATOR_PLATFORMS`);
    }
  });

  it("Scan status values match backend ScanStatus enum", async () => {
    const { SCAN_STATUSES } = await import("../db/enums.js");
    const swiftStatuses = ["accepted","processing","completed","failed"]; // from GetScanResponse
    for (const s of swiftStatuses) {
      assert.ok((SCAN_STATUSES as readonly string[]).includes(s),
        `iOS status '${s}' not in backend SCAN_STATUSES`);
    }
  });

  it("Plan IDs match billing plans", async () => {
    const { PLAN_IDS } = await import("../modules/billing/plans.js");
    const swiftPlans = ["FREE","PRO","PRO_PLUS"]; // from PlanId in HomeDomain
    for (const p of swiftPlans) {
      assert.ok((PLAN_IDS as readonly string[]).includes(p),
        `iOS plan '${p}' not in backend PLAN_IDS`);
    }
  });

  it("FindingSeverity values match scoring engine", async () => {
    const { FINDING_TEMPLATES } = await import("@vyro/shared/scoring");
    const severities = new Set(FINDING_TEMPLATES.map((t) => t.severity));
    const swiftSeverities = ["foundation","lever","polish"];
    for (const s of swiftSeverities) {
      assert.ok(severities.has(s as "foundation" | "lever" | "polish"),
        `iOS severity '${s}' not in scoring engine`);
    }
  });

  it("API_CONTRACT_VERSION is 'v1'", async () => {
    const { API_CONTRACT_VERSION } = await import("../modules/client-contract/index.js");
    assert.equal(API_CONTRACT_VERSION, "v1");
  });
});
