/**
 * Phase 5.4 — Upload, Storage & Job Foundation Tests
 *
 *   A  Upload validation
 *   B  AssetStorage (InMemoryAssetStorage)
 *   C  AnalysisJobQueue (InMemoryJobQueue)
 *   D  Scan status transitions
 *   E  Upload service (with null DB — validates validation layer)
 *   F  HTTP routes (Fastify inject)
 *   G  Security properties
 */

import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";

import {
  validateUpload,
  SUPPORTED_CONTENT_TYPES,
  DEFAULT_MAX_BYTES,
  ASSET_RETENTION_HOURS,
  isValidTransition,
} from "../modules/scans/service.js";

import {
  InMemoryAssetStorage,
  buildStorageKey,
  contentTypeToExt,
} from "../modules/scans/storage.js";

import {
  InMemoryJobQueue,
} from "../modules/scans/queue.js";

import { loadConfig } from "../config/index.js";
import { createApp } from "../app.js";
import type { FastifyInstance } from "fastify";
import { generateToken } from "../modules/auth/token.js";
import { AppError } from "../errors/index.js";

// ─── A: Upload validation ─────────────────────────────────────────────────────

describe("A: Upload validation", () => {
  const TINY_JPEG = new Uint8Array([0xff, 0xd8, 0xff, 0xe0]); // JPEG magic bytes

  it("Valid JPEG passes", () => {
    const r = validateUpload(TINY_JPEG, "image/jpeg");
    assert.equal(r.valid, true);
    assert.equal(r.contentType, "image/jpeg");
  });

  it("Valid PNG passes", () => {
    const r = validateUpload(TINY_JPEG, "image/png");
    assert.equal(r.valid, true);
    assert.equal(r.contentType, "image/png");
  });

  it("Valid WebP passes", () => {
    const r = validateUpload(TINY_JPEG, "image/webp");
    assert.equal(r.valid, true);
  });

  it("HEIC is rejected (not in supported list for upload)", () => {
    const r = validateUpload(TINY_JPEG, "image/heic");
    assert.equal(r.valid, false);
    assert.ok(r.rejectionReason?.includes("Unsupported"));
  });

  it("Empty file is rejected", () => {
    const r = validateUpload(new Uint8Array(0), "image/jpeg");
    assert.equal(r.valid, false);
    assert.ok(r.rejectionReason?.includes("Empty"));
  });

  it("Oversize file is rejected", () => {
    const big = new Uint8Array(DEFAULT_MAX_BYTES + 1);
    const r = validateUpload(big, "image/jpeg");
    assert.equal(r.valid, false);
    assert.ok(r.rejectionReason?.includes("too large"));
  });

  it("Configurable max size works", () => {
    const bytes = new Uint8Array(1000);
    assert.equal(validateUpload(bytes, "image/jpeg", 500).valid,  false);
    assert.equal(validateUpload(bytes, "image/jpeg", 2000).valid, true);
  });

  it("Unknown content type is rejected", () => {
    const r = validateUpload(TINY_JPEG, "application/pdf");
    assert.equal(r.valid, false);
    assert.ok(r.rejectionReason?.includes("Unsupported content type"));
  });

  it("text/html is rejected", () => {
    assert.equal(validateUpload(TINY_JPEG, "text/html").valid, false);
  });

  it("SUPPORTED_CONTENT_TYPES contains jpeg, png, webp", () => {
    assert.ok((SUPPORTED_CONTENT_TYPES as readonly string[]).includes("image/jpeg"));
    assert.ok((SUPPORTED_CONTENT_TYPES as readonly string[]).includes("image/png"));
    assert.ok((SUPPORTED_CONTENT_TYPES as readonly string[]).includes("image/webp"));
  });

  it("ASSET_RETENTION_HOURS is 24", () => {
    assert.equal(ASSET_RETENTION_HOURS, 24);
  });

  it("DEFAULT_MAX_BYTES is 10 MB", () => {
    assert.equal(DEFAULT_MAX_BYTES, 10 * 1024 * 1024);
  });
});

// ─── B: AssetStorage ─────────────────────────────────────────────────────────

describe("B: InMemoryAssetStorage", () => {
  it("put then get returns same bytes", async () => {
    const s = new InMemoryAssetStorage();
    const bytes = new Uint8Array([1, 2, 3]);
    await s.put("key/a.jpg", bytes, "image/jpeg");
    const back = await s.get("key/a.jpg");
    assert.ok(back !== null);
    assert.deepEqual([...back], [1, 2, 3]);
  });

  it("get on missing key returns null", async () => {
    const s = new InMemoryAssetStorage();
    assert.equal(await s.get("nonexistent"), null);
  });

  it("exists returns true for stored key", async () => {
    const s = new InMemoryAssetStorage();
    await s.put("k", new Uint8Array([42]), "image/jpeg");
    assert.equal(await s.exists("k"), true);
  });

  it("exists returns false for missing key", async () => {
    const s = new InMemoryAssetStorage();
    assert.equal(await s.exists("missing"), false);
  });

  it("delete removes key", async () => {
    const s = new InMemoryAssetStorage();
    await s.put("k", new Uint8Array([1]), "image/jpeg");
    await s.delete("k");
    assert.equal(await s.exists("k"), false);
    assert.equal(await s.get("k"), null);
  });

  it("delete on missing key is idempotent (no throw)", async () => {
    const s = new InMemoryAssetStorage();
    await assert.doesNotReject(() => s.delete("nonexistent"));
  });

  it("size tracks number of stored objects", async () => {
    const s = new InMemoryAssetStorage();
    assert.equal(s.size, 0);
    await s.put("a", new Uint8Array([1]), "image/jpeg");
    await s.put("b", new Uint8Array([2]), "image/png");
    assert.equal(s.size, 2);
    await s.delete("a");
    assert.equal(s.size, 1);
  });

  it("buildStorageKey never contains user-supplied filename", () => {
    const key = buildStorageKey("scan-1", "asset-1", "jpg");
    assert.ok(key.startsWith("uploads/scan-1/asset-1.jpg"));
    assert.ok(!key.includes(".."));
    assert.ok(!key.includes("//"));
  });

  it("contentTypeToExt maps correctly", () => {
    assert.equal(contentTypeToExt("image/jpeg"), "jpg");
    assert.equal(contentTypeToExt("image/png"),  "png");
    assert.equal(contentTypeToExt("image/webp"), "webp");
    assert.equal(contentTypeToExt("image/heic"), null);
    assert.equal(contentTypeToExt("text/html"),  null);
  });
});

// ─── C: AnalysisJobQueue ──────────────────────────────────────────────────────

describe("C: InMemoryJobQueue", () => {
  const baseJob = {
    scanId:           "scan-1",
    creatorProfileId: "profile-1",
    storageKey:       "uploads/scan-1/asset-1.jpg",
    platform:         "tiktok" as const,
    pipelineVersion:  "v1.0.0",
  };

  it("enqueueScan returns jobId", async () => {
    const q = new InMemoryJobQueue();
    const { jobId } = await q.enqueueScan(baseJob);
    assert.ok(typeof jobId === "string" && jobId.length > 0);
  });

  it("queuedCount increments on enqueue", async () => {
    const q = new InMemoryJobQueue();
    await q.enqueueScan(baseJob);
    await q.enqueueScan({ ...baseJob, scanId: "scan-2" });
    assert.equal(await q.queuedCount(), 2);
  });

  it("deduplication: same key → deduplicated=true, no duplicate job", async () => {
    const q = new InMemoryJobQueue();
    const r1 = await q.enqueueScan({ ...baseJob, deduplicationKey: "dk-1" });
    const r2 = await q.enqueueScan({ ...baseJob, deduplicationKey: "dk-1" });
    assert.equal(r1.deduplicated, false);
    assert.equal(r2.deduplicated, true);
    assert.equal(await q.queuedCount(), 1);
  });

  it("different deduplication keys → different jobs", async () => {
    const q = new InMemoryJobQueue();
    const r1 = await q.enqueueScan({ ...baseJob, deduplicationKey: "dk-A" });
    const r2 = await q.enqueueScan({ ...baseJob, scanId: "scan-2", deduplicationKey: "dk-B" });
    assert.equal(r1.deduplicated, false);
    assert.equal(r2.deduplicated, false);
    assert.equal(await q.queuedCount(), 2);
  });

  it("no deduplicationKey → always enqueues", async () => {
    const q = new InMemoryJobQueue();
    await q.enqueueScan(baseJob);
    await q.enqueueScan({ ...baseJob, scanId: "scan-2" });
    assert.equal(await q.queuedCount(), 2);
  });

  it("clear resets queue", async () => {
    const q = new InMemoryJobQueue();
    await q.enqueueScan(baseJob);
    q.clear();
    assert.equal(await q.queuedCount(), 0);
  });

  it("allJobs returns enqueued job payloads", async () => {
    const q = new InMemoryJobQueue();
    await q.enqueueScan(baseJob);
    const jobs = q.allJobs();
    assert.equal(jobs.length, 1);
    assert.equal(jobs[0]!.scanId, "scan-1");
  });
});

// ─── D: Scan status transitions ───────────────────────────────────────────────

describe("D: Scan status transitions", () => {
  it("accepted → processing: valid", () => {
    assert.equal(isValidTransition("accepted", "processing"), true);
  });

  it("accepted → failed: valid", () => {
    assert.equal(isValidTransition("accepted", "failed"), true);
  });

  it("processing → completed: valid", () => {
    assert.equal(isValidTransition("processing", "completed"), true);
  });

  it("processing → failed: valid", () => {
    assert.equal(isValidTransition("processing", "failed"), true);
  });

  it("completed → anything: invalid (terminal)", () => {
    assert.equal(isValidTransition("completed", "processing"), false);
    assert.equal(isValidTransition("completed", "failed"),     false);
    assert.equal(isValidTransition("completed", "accepted"),   false);
  });

  it("failed → anything: invalid (terminal)", () => {
    assert.equal(isValidTransition("failed", "completed"),  false);
    assert.equal(isValidTransition("failed", "processing"), false);
    assert.equal(isValidTransition("failed", "accepted"),   false);
  });

  it("accepted → completed: invalid (must go through processing)", () => {
    assert.equal(isValidTransition("accepted", "completed"), false);
  });

  it("processing → accepted: invalid (no going back)", () => {
    assert.equal(isValidTransition("processing", "accepted"), false);
  });
});

// ─── E: Upload service validation layer (no DB) ───────────────────────────────

describe("E: Upload service validation (no DB)", () => {
  const nullCtx = { db: null } as never;

  it("ingestUpload with empty bytes → throws VALIDATION_ERROR before DB", async () => {
    const { ingestUpload } = await import("../modules/scans/service.js");
    const s = new InMemoryAssetStorage();
    const q = new InMemoryJobQueue();
    await assert.rejects(
      () => ingestUpload(nullCtx, s, q, {
        ownerKey: "user-1", creatorProfileId: "p-1", platform: "tiktok",
        bytes: new Uint8Array(0), contentType: "image/jpeg", idempotencyKey: "key-1",
      }),
      (e: { code?: string }) => e.code === "VALIDATION_ERROR",
    );
  });

  it("ingestUpload with bad content type → throws VALIDATION_ERROR before DB", async () => {
    const { ingestUpload } = await import("../modules/scans/service.js");
    const s = new InMemoryAssetStorage();
    const q = new InMemoryJobQueue();
    await assert.rejects(
      () => ingestUpload(nullCtx, s, q, {
        ownerKey: "user-1", creatorProfileId: "p-1", platform: "tiktok",
        bytes: new Uint8Array([1,2,3]), contentType: "image/gif", idempotencyKey: "key-2",
      }),
      (e: { code?: string }) => e.code === "VALIDATION_ERROR",
    );
  });

  it("Storage is not written to if validation fails", async () => {
    const { ingestUpload } = await import("../modules/scans/service.js");
    const s = new InMemoryAssetStorage();
    const q = new InMemoryJobQueue();
    await ingestUpload(nullCtx, s, q, {
      ownerKey: "u", creatorProfileId: "p", platform: "tiktok",
      bytes: new Uint8Array(0), contentType: "image/jpeg", idempotencyKey: "k",
    }).catch(() => {});
    assert.equal(s.size, 0, "Storage must be untouched when validation fails");
  });
});

// ─── F: HTTP routes ───────────────────────────────────────────────────────────

describe("F: HTTP routes (Fastify inject)", () => {
  let app: FastifyInstance;
  const storage = new InMemoryAssetStorage();
  const queue   = new InMemoryJobQueue();

  const cfg = loadConfig({
    NODE_ENV: "test", PORT: "3020",
    DATABASE_URL: "postgresql://localhost:5432/test",
    JWT_SECRET: "test-secret-minimum-32-chars-long!!",
    APPLE_CLIENT_ID: "com.vyro.test",
    GCS_BUCKET_NAME: "vyro-test",
  });

  before(async () => { app = await createApp(cfg, undefined, storage, queue); });
  after(async () => { await app.close(); });

  it("POST /scans without auth → 401", async () => {
    const res = await app.inject({ method: "POST", url: "/scans" });
    assert.equal(res.statusCode, 401);
  });

  it("POST /scans without Idempotency-Key → 401 or 400", async () => {
    const token = generateToken();
    const res = await app.inject({
      method: "POST", url: "/scans",
      headers: { authorization: `Bearer ${token}`, "content-type": "image/jpeg" },
      payload: Buffer.from([0xff, 0xd8]),
    });
    assert.ok([400, 401, 500].includes(res.statusCode));
  });

  it("POST /scans without X-Creator-Profile-Id → 400 or 401", async () => {
    const token = generateToken();
    const res = await app.inject({
      method: "POST", url: "/scans",
      headers: {
        authorization: `Bearer ${token}`,
        "content-type": "image/jpeg",
        "idempotency-key": "test-key-1",
        "x-platform": "tiktok",
      },
      payload: Buffer.from([0xff, 0xd8]),
    });
    assert.ok([400, 401, 500].includes(res.statusCode));
  });

  it("POST /scans exists (not 404)", async () => {
    const res = await app.inject({ method: "POST", url: "/scans" });
    assert.notEqual(res.statusCode, 404);
  });

  it("GET /scans/:id without auth → 401", async () => {
    const res = await app.inject({ method: "GET", url: "/scans/00000000-0000-0000-0000-000000000001" });
    assert.equal(res.statusCode, 401);
  });

  it("GET /scans/:id with unknown-but-valid token → 401 or 500 (no DB)", async () => {
    const token = generateToken();
    const res = await app.inject({
      method: "GET", url: "/scans/00000000-0000-0000-0000-000000000001",
      headers: { authorization: `Bearer ${token}` },
    });
    assert.ok([401, 500].includes(res.statusCode));
  });

  it("GET /health still works after scan routes registered", async () => {
    const res = await app.inject({ method: "GET", url: "/health" });
    assert.equal(res.statusCode, 200);
  });

  it("OpenAPI includes /scans and /scans/{id}", async () => {
    const doc = app.swagger() as { paths: Record<string, unknown> };
    assert.ok(doc.paths?.["/scans"],       "/scans missing from OpenAPI");
    assert.ok(doc.paths?.["/scans/{id}"],  "/scans/{id} missing from OpenAPI");
  });
});

// ─── G: Security properties ───────────────────────────────────────────────────

describe("G: Security properties", () => {
  it("storageKey never contains user-supplied filename", () => {
    const key = buildStorageKey("scan-abc", "asset-xyz", "jpg");
    assert.ok(!key.includes("../"));
    assert.ok(!key.includes("userfile.jpg"));
    assert.match(key, /^uploads\/[^/]+\/[^/]+\.(jpg|png|webp)$/);
  });

  it("Storage returns null (not bytes) for deleted asset", async () => {
    const s = new InMemoryAssetStorage();
    await s.put("k", new Uint8Array([1,2,3]), "image/jpeg");
    await s.delete("k");
    assert.equal(await s.get("k"), null);
  });

  it("Raw image bytes are not exposed via error messages", () => {
    const bytes = new Uint8Array([0xff, 0xd8, 0xff]); // JPEG header
    const r = validateUpload(bytes, "image/gif"); // force rejection
    const msg = r.rejectionReason ?? "";
    // Rejection message must not embed byte content
    assert.ok(!msg.includes("255"), "Raw byte values must not appear in error");
  });

  it("Duplicate idempotencyKey with same ownerKey is safe (InMemoryJobQueue dedup)", async () => {
    const q = new InMemoryJobQueue();
    const job = {
      scanId: "s1", creatorProfileId: "p1", storageKey: "k",
      platform: "tiktok" as const, pipelineVersion: "v1.0.0",
      deduplicationKey: "owner-1:s1",
    };
    const r1 = await q.enqueueScan(job);
    const r2 = await q.enqueueScan(job);
    assert.equal(r1.deduplicated, false);
    assert.equal(r2.deduplicated, true);
    assert.equal(await q.queuedCount(), 1);
  });

  it("JPEG, PNG, WebP are the only accepted types (no SVG, GIF, PDF)", () => {
    const rejected = ["image/gif", "image/svg+xml", "application/pdf", "text/plain", "image/tiff"];
    for (const ct of rejected) {
      const r = validateUpload(new Uint8Array([1,2,3]), ct);
      assert.equal(r.valid, false, `${ct} should be rejected`);
    }
  });

  it("AppError.FORBIDDEN for ownership violation is not a 500", () => {
    const e = AppError.forbidden("You do not own this scan");
    assert.equal(e.httpStatus, 403);
    assert.equal(e.expose, true); // shows safe message
  });
});
