/**
 * Phase 6.4 — Mobile Client Contract Tests
 *
 *   A  API contract version and types
 *   B  Client error normalisation
 *   C  StubVyroApiClient — all methods
 *   D  Scan and billing response contracts
 *   E  OpenAPI — all required mobile routes
 *   F  No internal fields leaked
 */

import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";

import {
  API_CONTRACT_VERSION,
  StubVyroApiClient,
  isClientError,
  type ClientError,
  type CreateAnonymousSessionResponse,
  type GetScanResponse,
  type GetBillingStatusResponse,
  type FindingSummary,
  type PlanId,
} from "../modules/client-contract/index.js";

import { formatErrorResponse, AppError } from "../errors/index.js";
import { loadConfig } from "../config/index.js";
import { createApp } from "../app.js";
import { generateToken } from "../modules/auth/token.js";
import type { FastifyInstance } from "fastify";

// ─── A: Contract version and types ───────────────────────────────────────────

describe("A: API contract version and types", () => {
  it("API_CONTRACT_VERSION is 'v1'", () => {
    assert.equal(API_CONTRACT_VERSION, "v1");
  });

  it("isClientError: valid error passes", () => {
    const e: ClientError = { code: "NOT_FOUND", message: "Not found", httpStatus: 404 };
    assert.equal(isClientError(e), true);
  });

  it("isClientError: null fails", () => {
    assert.equal(isClientError(null), false);
  });

  it("isClientError: missing code fails", () => {
    assert.equal(isClientError({ message: "x", httpStatus: 400 }), false);
  });

  it("isClientError: missing httpStatus fails", () => {
    assert.equal(isClientError({ code: "X", message: "x" }), false);
  });

  it("ClientError has no stack, no internal detail fields", () => {
    const e: ClientError = { code: "INTERNAL_ERROR", message: "Something went wrong", httpStatus: 500 };
    const keys = Object.keys(e);
    assert.ok(!keys.includes("stack"));
    assert.ok(!keys.includes("detail"));
    assert.ok(!keys.includes("cause"));
    assert.ok(!keys.includes("internal"));
  });
});

// ─── B: Client error normalisation ───────────────────────────────────────────

describe("B: Error normalisation", () => {
  it("AppError.notFound → 404, expose=true, message safe for client", () => {
    const { statusCode, body } = formatErrorResponse(AppError.notFound("Scan"));
    assert.equal(statusCode, 404);
    assert.equal(body.error.code, "NOT_FOUND");
    assert.ok(body.error.message.length > 0);
    assert.ok(!body.error.message.includes("SELECT"));
  });

  it("AppError.internal → 500, expose=false, generic message", () => {
    const { statusCode, body } = formatErrorResponse(AppError.internal("DB error at 10.0.0.1"));
    assert.equal(statusCode, 500);
    assert.equal(body.error.code, "INTERNAL_ERROR");
    assert.ok(!body.error.message.includes("10.0.0.1"));
    assert.ok(!body.error.message.includes("DB error"));
  });

  it("AppError.unauthorized → 401", () => {
    const { statusCode, body } = formatErrorResponse(AppError.unauthorized());
    assert.equal(statusCode, 401);
    assert.equal(body.error.code, "UNAUTHORIZED");
  });

  it("AppError.forbidden → 403, message is safe", () => {
    const { statusCode, body } = formatErrorResponse(AppError.forbidden("You do not own this"));
    assert.equal(statusCode, 403);
    assert.ok(!body.error.message.includes("query"));
  });

  it("AppError.conflict → 409", () => {
    const { statusCode } = formatErrorResponse(AppError.conflict("Already exists"));
    assert.equal(statusCode, 409);
  });

  it("Unknown error → 500 with generic message", () => {
    const { statusCode, body } = formatErrorResponse(new Error("internal-db-details"));
    assert.equal(statusCode, 500);
    assert.ok(!body.error.message.includes("internal-db-details"));
  });

  it("Error body always has error.code and error.message", () => {
    for (const err of [
      AppError.notFound("X"), AppError.internal("y"), AppError.unauthorized(),
      AppError.forbidden("z"), new Error("w"),
    ]) {
      const { body } = formatErrorResponse(err);
      assert.ok(typeof body.error.code    === "string" && body.error.code.length    > 0);
      assert.ok(typeof body.error.message === "string" && body.error.message.length > 0);
    }
  });
});

// ─── C: StubVyroApiClient ────────────────────────────────────────────────────

describe("C: StubVyroApiClient — all methods", () => {
  const client = new StubVyroApiClient();

  it("createAnonymousSession returns token + sessionId + expiresAt", async () => {
    const r = await client.createAnonymousSession();
    assert.ok(typeof r.token     === "string" && r.token.length     > 0);
    assert.ok(typeof r.sessionId === "string" && r.sessionId.length > 0);
    assert.ok(typeof r.expiresAt === "string");
    assert.ok(!isNaN(new Date(r.expiresAt).getTime()), "expiresAt must be valid ISO date");
  });

  it("rotateSession returns new token", async () => {
    const r = await client.rotateSession("old-token");
    assert.ok(r.token !== "old-token");
  });

  it("logout resolves without throwing", async () => {
    await assert.doesNotReject(() => client.logout("token"));
  });

  it("createUser returns userId + token", async () => {
    const r = await client.createUser();
    assert.ok(typeof r.userId    === "string");
    assert.ok(typeof r.token     === "string");
    assert.ok(typeof r.sessionId === "string");
  });

  it("getCurrentUser returns id + createdAt", async () => {
    const r = await client.getCurrentUser("token");
    assert.ok(typeof r.id        === "string");
    assert.ok(typeof r.createdAt === "string");
  });

  it("claimAnonymous returns profilesMigrated", async () => {
    const r = await client.claimAnonymous("token", { anonymousToken: "anon-token" });
    assert.ok(typeof r.profilesMigrated === "number");
    assert.ok(typeof r.alreadyMerged    === "boolean");
  });

  it("listSocialAccounts returns array", async () => {
    const r = await client.listSocialAccounts("token", "profile-id");
    assert.ok(Array.isArray(r));
  });

  it("linkSocialAccount returns SocialAccountSummary with all fields", async () => {
    const r = await client.linkSocialAccount("token", {
      profileId: "p1", platform: "tiktok", providerAccountId: "tt-123",
    });
    assert.ok(typeof r.id               === "string");
    assert.ok(typeof r.creatorProfileId === "string");
    assert.equal(r.platform, "tiktok");
    assert.equal(r.providerAccountId, "tt-123");
    assert.ok(typeof r.connectedAt === "string");
  });

  it("linkSocialAccount platform matches request", async () => {
    const r = await client.linkSocialAccount("token", {
      profileId: "p1", platform: "instagram", providerAccountId: "ig-456",
    });
    assert.equal(r.platform, "instagram");
  });

  it("disconnectSocialAccount resolves", async () => {
    await assert.doesNotReject(() => client.disconnectSocialAccount("token", "acc-id"));
  });

  it("createScan returns scanId + status='accepted'", async () => {
    const r = await client.createScan("token", "profile-1", new Uint8Array([0xff, 0xd8]));
    assert.ok(typeof r.scanId === "string");
    assert.equal(r.status, "accepted");
  });

  it("getScan returns completed result with score fields", async () => {
    const r = await client.getScan("token", "scan-id");
    assert.equal(r.status, "completed");
    assert.ok(typeof r.totalScore    === "number");
    assert.ok(typeof r.displayable   === "boolean");
    assert.ok(typeof r.coverageRatio === "number");
    assert.ok(Array.isArray(r.findings));
  });

  it("getBillingStatus returns plan + features + creditBalance", async () => {
    const r = await client.getBillingStatus("token");
    assert.ok(["FREE","PRO","PRO_PLUS"].includes(r.plan));
    assert.ok(typeof r.active         === "boolean");
    assert.ok(typeof r.features       === "object");
    assert.ok(typeof r.creditBalance  === "number");
  });

  it("Error propagation: stub with error throws ClientError on any call", async () => {
    const err: ClientError = { code: "UNAUTHORIZED", message: "No auth", httpStatus: 401 };
    const errClient = new StubVyroApiClient({ error: err });
    await assert.rejects(() => errClient.createAnonymousSession(), (e) => isClientError(e));
    await assert.rejects(() => errClient.getCurrentUser("t"),      (e) => isClientError(e));
    await assert.rejects(() => errClient.getScan("t", "id"),       (e) => isClientError(e));
  });
});

// ─── D: Scan and billing response contracts ───────────────────────────────────

describe("D: Response contract shapes", () => {
  it("GetScanResponse: all optional fields absent for 'accepted' scan", async () => {
    const client = new StubVyroApiClient({
      getScan: { id: "s1", status: "accepted", platform: "tiktok", createdAt: new Date().toISOString() },
    });
    const r = await client.getScan("t", "s1");
    assert.equal(r.status, "accepted");
    assert.equal(r.totalScore,    undefined);
    assert.equal(r.displayable,   undefined);
    assert.equal(r.coverageRatio, undefined);
    assert.equal(r.findings,      undefined);
  });

  it("GetScanResponse: 'failed' scan has failureCode, no score", async () => {
    const client = new StubVyroApiClient({
      getScan: { id:"s2", status:"failed", platform:"instagram", createdAt:new Date().toISOString(), failureCode:"ocr_failure" },
    });
    const r = await client.getScan("t", "s2");
    assert.equal(r.status, "failed");
    assert.equal(r.failureCode, "ocr_failure");
    assert.equal(r.totalScore, undefined);
  });

  it("FindingSummary has all required fields", () => {
    const f: FindingSummary = {
      templateId: "bio_cta_missing", severity: "lever", impact: 3,
      priority: 2, blockedByFoundation: false, status: "open",
    };
    assert.ok(f.templateId.length > 0);
    assert.ok(["foundation","lever","polish"].includes(f.severity));
    assert.ok(typeof f.impact === "number");
    assert.ok(typeof f.priority === "number");
    assert.ok(typeof f.blockedByFoundation === "boolean");
  });

  it("GetBillingStatusResponse: FREE plan has active=false", async () => {
    const client = new StubVyroApiClient();
    const r = await client.getBillingStatus("t");
    assert.equal(r.plan, "FREE");
    assert.equal(r.active, false);
    assert.equal(r.creditBalance, 0);
  });

  it("PlanId type accepts only FREE/PRO/PRO_PLUS", () => {
    const plans: PlanId[] = ["FREE", "PRO", "PRO_PLUS"];
    assert.equal(plans.length, 3);
  });

  it("Dates in responses are ISO 8601 strings", async () => {
    const client = new StubVyroApiClient();
    const session = await client.createAnonymousSession();
    const user    = await client.getCurrentUser("t");
    const scan    = await client.getScan("t", "s");
    for (const d of [session.expiresAt, user.createdAt, scan.createdAt]) {
      assert.ok(!isNaN(new Date(d).getTime()), `Not a valid ISO date: ${d}`);
    }
  });
});

// ─── E: OpenAPI — all required mobile routes ──────────────────────────────────

describe("E: OpenAPI coverage for mobile routes", () => {
  let app: FastifyInstance;

  const cfg = loadConfig({
    NODE_ENV:"test", PORT:"3050",
    DATABASE_URL:"postgresql://localhost/t",
    JWT_SECRET:"secret-32-chars-minimum-length!!",
    APPLE_CLIENT_ID:"x", GCS_BUCKET_NAME:"x",
  });

  before(async () => { app = await createApp(cfg); });
  after(async () => { await app.close(); });

  const REQUIRED_MOBILE_ROUTES: Array<[string, string]> = [
    ["/auth/anonymous",       "post"],
    ["/auth/session/rotate",  "post"],
    ["/auth/logout",          "post"],
    ["/users",                "post"],
    ["/users/me",             "get"],
    ["/auth/claim-anonymous", "post"],
    ["/social/accounts",      "get"],
    ["/social/accounts/{id}", "delete"],
    ["/social/accounts/link", "post"],
    ["/scans",                "post"],
    ["/scans/{id}",           "get"],
    ["/billing/status",       "get"],
  ];

  for (const [path, method] of REQUIRED_MOBILE_ROUTES) {
    it(`OpenAPI: ${method.toUpperCase()} ${path} exists`, async () => {
      const doc = app.swagger() as { paths: Record<string, Record<string, unknown>> };
      assert.ok(doc.paths?.[path] !== undefined,              `Path missing: ${path}`);
      assert.ok(doc.paths[path]?.[method] !== undefined,     `Method ${method} missing: ${path}`);
    });
  }

  it("OpenAPI version is 3.1.0", async () => {
    const doc = app.swagger() as { openapi: string };
    assert.equal(doc.openapi, "3.1.0");
  });

  it("GET /health still works", async () => {
    const res = await app.inject({ method: "GET", url: "/health" });
    assert.equal(res.statusCode, 200);
  });

  it("Unauthenticated GET /users/me → 401 (not 500)", async () => {
    const res = await app.inject({ method: "GET", url: "/users/me" });
    assert.equal(res.statusCode, 401);
  });

  it("POST /auth/anonymous → route exists and returns JSON", async () => {
    const res = await app.inject({ method: "POST", url: "/auth/anonymous" });
    assert.notEqual(res.statusCode, 404);
    if (res.statusCode < 400) {
      const body = res.json<{ token: string }>();
      assert.ok(typeof body.token === "string");
    }
  });
});

// ─── F: No internal fields leaked ────────────────────────────────────────────

describe("F: No internal fields leaked", () => {
  let app: FastifyInstance;

  const cfg = loadConfig({
    NODE_ENV:"test", PORT:"3051",
    DATABASE_URL:"postgresql://localhost/t",
    JWT_SECRET:"secret-32-chars-minimum-length!!",
    APPLE_CLIENT_ID:"x", GCS_BUCKET_NAME:"x",
  });

  before(async () => { app = await createApp(cfg); });
  after(async () => { await app.close(); });

  it("GET /scans/:id error response has no stack trace", async () => {
    const token = generateToken();
    const res = await app.inject({
      method: "GET", url: "/scans/bad-id",
      headers: { authorization: `Bearer ${token}` },
    });
    assert.ok(!res.body.includes(" at "),       "Stack trace leaked");
    assert.ok(!res.body.includes("node:"),      "Node internal path leaked");
    assert.ok(!res.body.includes("TypeError"),  "Error class leaked");
  });

  it("Token never appears in any error response", async () => {
    const token = generateToken();
    const urls = ["/users/me", "/scans/x", "/billing/status"];
    for (const url of urls) {
      const res = await app.inject({
        method: "GET", url,
        headers: { authorization: `Bearer ${token}` },
      });
      assert.ok(!res.body.includes(token), `Token leaked in response to ${url}`);
    }
  });

  it("DB error details never appear in 5xx response", async () => {
    const res = await app.inject({ method: "GET", url: "/users/me" });
    assert.ok(!res.body.includes("ECONNREFUSED"));
    assert.ok(!res.body.includes("postgres"));
    assert.ok(!res.body.includes("password"));
  });

  it("All error responses have error.code and error.message at root", async () => {
    const res = await app.inject({ method: "GET", url: "/users/me" });
    if (res.statusCode >= 400) {
      const body = res.json<{ error: { code: string; message: string } }>();
      assert.ok(typeof body.error?.code    === "string");
      assert.ok(typeof body.error?.message === "string");
    }
  });

  it("StubVyroApiClient: no internal secret fields in any response", async () => {
    const client = new StubVyroApiClient();
    const session = await client.createAnonymousSession();
    const billing = await client.getBillingStatus("t");
    for (const obj of [session, billing]) {
      const json = JSON.stringify(obj);
      assert.ok(!json.includes("apiKey"),       "apiKey in response");
      assert.ok(!json.includes("webhookSecret"),"webhookSecret in response");
      assert.ok(!json.includes("jwtSecret"),    "jwtSecret in response");
    }
  });
});
