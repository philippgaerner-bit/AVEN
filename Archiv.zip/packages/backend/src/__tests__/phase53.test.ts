/**
 * Phase 5.3 — Screenshot Analysis Pipeline Tests
 *
 *   A  Types and cache key utilities
 *   B  Provider stubs
 *   C  Pipeline — success flows (TikTok and Instagram)
 *   D  Pipeline — failure modes
 *   E  Deterministic scoring protection
 *   F  Cache foundation
 */

import { describe, it } from "node:test";
import assert from "node:assert/strict";

import {
  PIPELINE_STAGES,
  buildCacheKey,
  cacheKeyString,
  isPipelineSuccess,
  isPipelineFailure,
  MIN_PLATFORM_CONFIDENCE,
  MIN_WIDTH_PX,
  MIN_HEIGHT_PX,
  MAX_BLUR_SCORE,
} from "../modules/pipeline/types.js";

import {
  StubImageProcessor,
  StubOCRProvider,
  StubVisionObservationProvider,
} from "../modules/pipeline/providers.js";

import { runAnalysisPipeline, PIPELINE_VERSION } from "../modules/pipeline/orchestrator.js";
import { SCORING_MODEL_VERSION } from "@vyro/shared/scoring";
import type { ImageMetadata } from "../modules/pipeline/types.js";

// ─── Helpers ──────────────────────────────────────────────────────────────────

const PROFILE_ID = "profile-test-pipeline";

const STUB_IMAGE: ImageMetadata = {
  storageKey:  "test/screenshot.jpg",
  contentType: "image/jpeg",
  byteSize:    204800,
};

function makeProviders(overrides: {
  qualityOk?: boolean;
  blurScore?: number;
  width?: number;
  height?: number;
  hash?: string;
  platform?: "tiktok" | "instagram";
  platformConfidence?: number;
  failPlatform?: boolean;
  failOCR?: boolean;
  failObservations?: boolean;
  observationState?: "fulfilled" | "missing" | "partial" | "unavailable";
} = {}) {
  return {
    imageProcessor: new StubImageProcessor({
      qualityOk: overrides.qualityOk,
      blurScore:  overrides.blurScore,
      width:      overrides.width,
      height:     overrides.height,
      hash:       overrides.hash,
    }),
    ocr:    new StubOCRProvider({ fail: overrides.failOCR }),
    vision: new StubVisionObservationProvider({
      platform:         overrides.platform,
      confidence:       overrides.platformConfidence,
      failPlatform:     overrides.failPlatform,
      failObservations: overrides.failObservations,
      observationState: overrides.observationState,
    }),
  };
}

// ─── A: Types and constants ───────────────────────────────────────────────────

describe("A: Pipeline types and constants", () => {
  it("PIPELINE_STAGES has exactly 9 stages in correct order", () => {
    assert.equal(PIPELINE_STAGES.length, 9);
    assert.equal(PIPELINE_STAGES[0], "ingest");
    assert.equal(PIPELINE_STAGES[8], "buildActions");
  });

  it("PIPELINE_VERSION matches semver pattern", () => {
    assert.match(PIPELINE_VERSION, /^v\d+\.\d+\.\d+$/);
  });

  it("buildCacheKey produces stable key", () => {
    const key = buildCacheKey("hash123", "tiktok", "v1.0.0", "v1.0.0");
    assert.equal(key.perceptualHash, "hash123");
    assert.equal(key.platform, "tiktok");
  });

  it("cacheKeyString is deterministic", () => {
    const key = buildCacheKey("hash123", "tiktok", "v1.0.0", "v1.0.0");
    assert.equal(cacheKeyString(key), cacheKeyString(key));
  });

  it("cacheKeyString differs for different hashes", () => {
    const a = cacheKeyString(buildCacheKey("hash-A", "tiktok", "v1.0.0", "v1.0.0"));
    const b = cacheKeyString(buildCacheKey("hash-B", "tiktok", "v1.0.0", "v1.0.0"));
    assert.notEqual(a, b);
  });

  it("cacheKeyString differs for different platforms", () => {
    const a = cacheKeyString(buildCacheKey("hash", "tiktok",    "v1.0.0", "v1.0.0"));
    const b = cacheKeyString(buildCacheKey("hash", "instagram", "v1.0.0", "v1.0.0"));
    assert.notEqual(a, b);
  });

  it("cacheKeyString differs for different scoring model versions", () => {
    const a = cacheKeyString(buildCacheKey("hash", "tiktok", "v1.0.0", "v1.0.0"));
    const b = cacheKeyString(buildCacheKey("hash", "tiktok", "v2.0.0", "v1.0.0"));
    assert.notEqual(a, b);
  });

  it("MIN_PLATFORM_CONFIDENCE, MIN_WIDTH_PX, MIN_HEIGHT_PX, MAX_BLUR_SCORE defined", () => {
    assert.ok(MIN_PLATFORM_CONFIDENCE > 0 && MIN_PLATFORM_CONFIDENCE < 1);
    assert.ok(MIN_WIDTH_PX > 0);
    assert.ok(MIN_HEIGHT_PX > 0);
    assert.ok(MAX_BLUR_SCORE > 0 && MAX_BLUR_SCORE < 1);
  });
});

// ─── B: Provider stubs ────────────────────────────────────────────────────────

describe("B: Provider stubs", () => {
  it("StubImageProcessor.inspectQuality returns acceptable result by default", async () => {
    const proc = new StubImageProcessor();
    const q = await proc.inspectQuality(STUB_IMAGE);
    assert.equal(q.acceptable, true);
    assert.ok(q.widthPx >= MIN_WIDTH_PX);
    assert.ok(q.heightPx >= MIN_HEIGHT_PX);
    assert.ok(q.blurScore <= MAX_BLUR_SCORE);
    assert.ok(q.perceptualHash.length > 0);
  });

  it("StubImageProcessor can simulate bad quality", async () => {
    const proc = new StubImageProcessor({ qualityOk: false, blurScore: 0.9 });
    const q = await proc.inspectQuality(STUB_IMAGE);
    assert.equal(q.acceptable, false);
    assert.ok(q.rejectionReason !== undefined);
  });

  it("StubOCRProvider returns text for known region types", async () => {
    const ocr = new StubOCRProvider();
    const regions = [
      { regionType: "bio" as const,      boundingBox: { x:0, y:0, w:100, h:50 } },
      { regionType: "username" as const, boundingBox: { x:0, y:0, w:100, h:30 } },
    ];
    const texts = await ocr.extractText(STUB_IMAGE, regions);
    assert.equal(texts.length, 2);
    assert.ok(texts[0]!.text.length > 0);
  });

  it("StubOCRProvider fail mode throws", async () => {
    const ocr = new StubOCRProvider({ fail: true });
    await assert.rejects(() => ocr.extractText(STUB_IMAGE, []));
  });

  it("StubVisionObservationProvider detects tiktok by default", async () => {
    const v = new StubVisionObservationProvider();
    const d = await v.detectPlatform(STUB_IMAGE);
    assert.equal(d.platform, "tiktok");
    assert.ok(d.confidence >= MIN_PLATFORM_CONFIDENCE);
  });

  it("StubVisionObservationProvider can simulate instagram", async () => {
    const v = new StubVisionObservationProvider({ platform: "instagram" });
    const d = await v.detectPlatform(STUB_IMAGE);
    assert.equal(d.platform, "instagram");
  });

  it("StubVisionObservationProvider returns 31 observations", async () => {
    const v = new StubVisionObservationProvider();
    const regions = await v.extractProfileRegions(STUB_IMAGE, "tiktok");
    const texts   = [];
    const obs = await v.createCriterionObservations("tiktok", regions, texts);
    assert.equal(obs.length, 31);
  });

  it("StubVisionObservationProvider observations use source C", async () => {
    const v = new StubVisionObservationProvider();
    const obs = await v.createCriterionObservations("tiktok", [], []);
    for (const o of obs) assert.equal(o.source, "C");
  });

  it("Provider observations never contain score values", async () => {
    const v = new StubVisionObservationProvider();
    const obs = await v.createCriterionObservations("tiktok", [], []);
    for (const o of obs) {
      assert.ok(!("score" in o), "Observation must not contain a score");
      assert.ok(!("impact" in o), "Observation must not contain impact");
    }
  });
});

// ─── C: Pipeline success flows ────────────────────────────────────────────────

describe("C: Pipeline success flows", () => {
  it("TikTok profile screenshot → PipelineSuccess", async () => {
    const result = await runAnalysisPipeline(STUB_IMAGE, PROFILE_ID, makeProviders());
    assert.equal(isPipelineSuccess(result), true, `Expected success, got: ${JSON.stringify(result)}`);
  });

  it("Instagram profile screenshot → PipelineSuccess", async () => {
    const result = await runAnalysisPipeline(
      STUB_IMAGE, PROFILE_ID, makeProviders({ platform: "instagram" }),
    );
    assert.equal(isPipelineSuccess(result), true);
    if (isPipelineSuccess(result)) assert.equal(result.detectedPlatform.platform, "instagram");
  });

  it("PipelineSuccess has all 9 completed stages", async () => {
    const result = await runAnalysisPipeline(STUB_IMAGE, PROFILE_ID, makeProviders());
    if (isPipelineSuccess(result)) {
      assert.equal(result.completedStages.length, 9);
      for (const stage of PIPELINE_STAGES) {
        assert.ok(result.completedStages.includes(stage), `Stage missing: ${stage}`);
      }
    }
  });

  it("PipelineSuccess contains scoringResult", async () => {
    const result = await runAnalysisPipeline(STUB_IMAGE, PROFILE_ID, makeProviders());
    if (isPipelineSuccess(result)) {
      assert.ok(result.scoringResult !== undefined);
      const ss = result.scoringResult.scoreSet;
      assert.ok(ss.total >= 0 && ss.total <= 100);
    }
  });

  it("PipelineSuccess contains findings array", async () => {
    const result = await runAnalysisPipeline(STUB_IMAGE, PROFILE_ID, makeProviders());
    if (isPipelineSuccess(result)) {
      assert.ok(Array.isArray(result.findings));
    }
  });

  it("PipelineSuccess contains actions array", async () => {
    const result = await runAnalysisPipeline(STUB_IMAGE, PROFILE_ID, makeProviders());
    if (isPipelineSuccess(result)) {
      assert.ok(Array.isArray(result.actions));
    }
  });

  it("PipelineSuccess.cacheKey has correct platform", async () => {
    const result = await runAnalysisPipeline(
      STUB_IMAGE, PROFILE_ID, makeProviders({ platform: "instagram" }),
    );
    if (isPipelineSuccess(result)) {
      assert.equal(result.cacheKey.platform, "instagram");
    }
  });

  it("All fulfilled obs → score 100 and 0 findings", async () => {
    const result = await runAnalysisPipeline(
      STUB_IMAGE, PROFILE_ID, makeProviders({ observationState: "fulfilled" }),
    );
    if (isPipelineSuccess(result)) {
      assert.equal(result.scoringResult.scoreSet.total, 100);
      assert.equal(result.findings.length, 0);
      assert.equal(result.actions.length, 0);
    }
  });

  it("All missing obs → score 0 and 12 findings/actions", async () => {
    const result = await runAnalysisPipeline(
      STUB_IMAGE, PROFILE_ID, makeProviders({ observationState: "missing" }),
    );
    if (isPipelineSuccess(result)) {
      assert.equal(result.scoringResult.scoreSet.total, 0);
      assert.equal(result.findings.length, 12);
      assert.equal(result.actions.length, 12);
    }
  });
});

// ─── D: Failure modes ─────────────────────────────────────────────────────────

describe("D: Pipeline failure modes", () => {
  it("Bad image quality → PipelineFailure at validateImage", async () => {
    const result = await runAnalysisPipeline(
      STUB_IMAGE, PROFILE_ID, makeProviders({ qualityOk: false }),
    );
    assert.equal(isPipelineFailure(result), true);
    if (isPipelineFailure(result)) {
      assert.equal(result.failedAtStage, "validateImage");
      assert.equal(result.reason, "image_quality_insufficient");
      assert.equal(result.deterministicScoringUntouched, true);
    }
  });

  it("Image too small → failure at validateImage", async () => {
    const result = await runAnalysisPipeline(
      STUB_IMAGE, PROFILE_ID, makeProviders({ width: 100, height: 100 }),
    );
    assert.equal(isPipelineFailure(result), true);
    if (isPipelineFailure(result)) assert.equal(result.failedAtStage, "validateImage");
  });

  it("High blur score → failure at validateImage", async () => {
    const result = await runAnalysisPipeline(
      STUB_IMAGE, PROFILE_ID, makeProviders({ blurScore: 0.95, qualityOk: false }),
    );
    assert.equal(isPipelineFailure(result), true);
  });

  it("Platform detection failure → PipelineFailure at detectPlatform", async () => {
    const result = await runAnalysisPipeline(
      STUB_IMAGE, PROFILE_ID, makeProviders({ failPlatform: true }),
    );
    assert.equal(isPipelineFailure(result), true);
    if (isPipelineFailure(result)) {
      assert.equal(result.failedAtStage, "detectPlatform");
      assert.equal(result.reason, "vision_failure");
    }
  });

  it("Low platform confidence → failure at detectPlatform", async () => {
    const result = await runAnalysisPipeline(
      STUB_IMAGE, PROFILE_ID, makeProviders({ platformConfidence: 0.3 }),
    );
    assert.equal(isPipelineFailure(result), true);
    if (isPipelineFailure(result)) {
      assert.equal(result.failedAtStage, "detectPlatform");
      assert.equal(result.reason, "platform_confidence_low");
    }
  });

  it("OCR failure → PipelineFailure at extractText", async () => {
    const result = await runAnalysisPipeline(
      STUB_IMAGE, PROFILE_ID, makeProviders({ failOCR: true }),
    );
    assert.equal(isPipelineFailure(result), true);
    if (isPipelineFailure(result)) {
      assert.equal(result.failedAtStage, "extractText");
      assert.equal(result.reason, "ocr_failure");
    }
  });

  it("Vision observation failure → PipelineFailure at buildObservations", async () => {
    const result = await runAnalysisPipeline(
      STUB_IMAGE, PROFILE_ID, makeProviders({ failObservations: true }),
    );
    assert.equal(isPipelineFailure(result), true);
    if (isPipelineFailure(result)) {
      assert.equal(result.failedAtStage, "buildObservations");
    }
  });

  it("All failures set deterministicScoringUntouched = true", async () => {
    const failCases = [
      makeProviders({ qualityOk: false }),
      makeProviders({ failPlatform: true }),
      makeProviders({ failOCR: true }),
      makeProviders({ failObservations: true }),
    ];
    for (const providers of failCases) {
      const r = await runAnalysisPipeline(STUB_IMAGE, PROFILE_ID, providers);
      if (isPipelineFailure(r)) {
        assert.equal(r.deterministicScoringUntouched, true);
      }
    }
  });

  it("completedStages is never empty on failure after ingest", async () => {
    const result = await runAnalysisPipeline(
      STUB_IMAGE, PROFILE_ID, makeProviders({ failPlatform: true }),
    );
    if (isPipelineFailure(result)) {
      // ingest + validateImage completed before detectPlatform
      assert.ok(result.completedStages.includes("ingest"));
    }
  });
});

// ─── E: Deterministic scoring protection ─────────────────────────────────────

describe("E: Deterministic scoring protection", () => {
  it("Same stub providers → same score every run", async () => {
    const providers = makeProviders({ observationState: "fulfilled" });
    const r1 = await runAnalysisPipeline(STUB_IMAGE, PROFILE_ID, providers);
    const r2 = await runAnalysisPipeline(STUB_IMAGE, PROFILE_ID, providers);
    if (isPipelineSuccess(r1) && isPipelineSuccess(r2)) {
      assert.equal(r1.scoringResult.scoreSet.total, r2.scoringResult.scoreSet.total);
    }
  });

  it("Provider cannot inject a score — score comes from calculateScore only", async () => {
    const result = await runAnalysisPipeline(STUB_IMAGE, PROFILE_ID, makeProviders());
    if (isPipelineSuccess(result)) {
      // Verify the score is a valid normalized 0–100 integer
      const total = result.scoringResult.scoreSet.total;
      assert.ok(Number.isInteger(total), "Score must be integer");
      assert.ok(total >= 0 && total <= 100, "Score must be 0–100");
    }
  });

  it("Provider observations never include a score field", async () => {
    const result = await runAnalysisPipeline(STUB_IMAGE, PROFILE_ID, makeProviders());
    if (isPipelineSuccess(result)) {
      for (const obs of result.observations) {
        assert.ok(!("score" in obs));
        assert.ok(!("total" in obs));
        assert.ok(!("impact" in obs));
      }
    }
  });

  it("Finding impact comes from deterministic scoring, not provider", async () => {
    const result = await runAnalysisPipeline(
      STUB_IMAGE, PROFILE_ID, makeProviders({ observationState: "missing" }),
    );
    if (isPipelineSuccess(result)) {
      for (const finding of result.findings) {
        assert.ok(finding.impact > 0, "impact must come from scoring engine");
        assert.ok(finding.priority > 0, "priority must come from scoring engine");
      }
    }
  });

  it("Different observation states produce different scores (scoring is responsive)", async () => {
    const r100 = await runAnalysisPipeline(STUB_IMAGE, PROFILE_ID, makeProviders({ observationState: "fulfilled" }));
    const r0   = await runAnalysisPipeline(STUB_IMAGE, PROFILE_ID, makeProviders({ observationState: "missing" }));
    if (isPipelineSuccess(r100) && isPipelineSuccess(r0)) {
      assert.ok(r100.scoringResult.scoreSet.total > r0.scoringResult.scoreSet.total);
    }
  });

  it("pipelineVersion is set in result", async () => {
    const result = await runAnalysisPipeline(STUB_IMAGE, PROFILE_ID, makeProviders());
    if (isPipelineSuccess(result)) {
      assert.equal(result.pipelineVersion, PIPELINE_VERSION);
    }
  });
});

// ─── F: Cache foundation ──────────────────────────────────────────────────────

describe("F: Cache foundation", () => {
  it("Same image (same perceptual hash) produces same cache key", async () => {
    const providers = makeProviders({ hash: "fixed-hash-abc" });
    const r1 = await runAnalysisPipeline(STUB_IMAGE, PROFILE_ID, providers);
    const r2 = await runAnalysisPipeline(STUB_IMAGE, PROFILE_ID, providers);
    if (isPipelineSuccess(r1) && isPipelineSuccess(r2)) {
      assert.equal(cacheKeyString(r1.cacheKey), cacheKeyString(r2.cacheKey));
    }
  });

  it("Different perceptual hash → different cache key", async () => {
    const r1 = await runAnalysisPipeline(STUB_IMAGE, PROFILE_ID, makeProviders({ hash: "hash-A" }));
    const r2 = await runAnalysisPipeline(STUB_IMAGE, PROFILE_ID, makeProviders({ hash: "hash-B" }));
    if (isPipelineSuccess(r1) && isPipelineSuccess(r2)) {
      assert.notEqual(cacheKeyString(r1.cacheKey), cacheKeyString(r2.cacheKey));
    }
  });

  it("Cache key includes scoringModelVersion for cache invalidation on model change", async () => {
    const result = await runAnalysisPipeline(STUB_IMAGE, PROFILE_ID, makeProviders());
    if (isPipelineSuccess(result)) {
      assert.equal(result.cacheKey.scoringModelVersion, SCORING_MODEL_VERSION);
      assert.ok(cacheKeyString(result.cacheKey).includes(SCORING_MODEL_VERSION));
    }
  });

  it("Cache key includes pipelineVersion", async () => {
    const result = await runAnalysisPipeline(STUB_IMAGE, PROFILE_ID, makeProviders());
    if (isPipelineSuccess(result)) {
      assert.equal(result.cacheKey.pipelineVersion, PIPELINE_VERSION);
    }
  });

  it("isPipelineSuccess and isPipelineFailure are mutually exclusive", async () => {
    const r1 = await runAnalysisPipeline(STUB_IMAGE, PROFILE_ID, makeProviders());
    const r2 = await runAnalysisPipeline(STUB_IMAGE, PROFILE_ID, makeProviders({ failOCR: true }));
    assert.equal(isPipelineSuccess(r1) && isPipelineFailure(r1), false);
    assert.equal(isPipelineSuccess(r2) && isPipelineFailure(r2), false);
    assert.equal(isPipelineSuccess(r1) || isPipelineFailure(r1), true);
    assert.equal(isPipelineSuccess(r2) || isPipelineFailure(r2), true);
  });
});
