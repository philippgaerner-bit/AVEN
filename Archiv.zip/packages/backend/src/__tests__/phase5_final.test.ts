/**
 * Phase 5 Final — Integration & Regression Verification
 *
 * Verifies all Phase 5 sub-phases work correctly together:
 *   A  End-to-end scan flow (in-process, fake providers)
 *   B  Deterministic core protection across the full stack
 *   C  Growth engine integration
 *   D  Provider layer integration
 *   E  Persistence wiring
 *   F  OpenAPI completeness
 *   G  Security and isolation
 */

import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";

// ── Core scoring ───────────────────────────────────────────────────────────
import {
  calculateScore, buildFindings, SCORING_MODEL_VERSION,
  ALL_CRITERION_IDS, FINDING_TEMPLATES,
} from "@vyro/shared/scoring";
import type { ObservationPackage } from "@vyro/shared/scoring";

// ── Growth engine ──────────────────────────────────────────────────────────
import { buildGrowthActions, FINDING_TO_ACTION, GROWTH_ACTION_TYPES } from "../modules/growth/actions.js";
import { selectDailyTask, selectTopActions, calculateProgress } from "../modules/growth/planner.js";
import { GenerationService } from "../modules/growth/generation-service.js";
import { StubRecommendationProvider } from "../modules/growth/ai-provider.js";
import { isGenerationFailure, PROMPT_VERSIONS } from "../modules/growth/ai-types.js";

// ── Pipeline ───────────────────────────────────────────────────────────────
import { runAnalysisPipeline, PIPELINE_VERSION } from "../modules/pipeline/orchestrator.js";
import { isPipelineSuccess, isPipelineFailure, buildCacheKey, cacheKeyString } from "../modules/pipeline/types.js";
import {
  StubImageProcessor, StubOCRProvider, StubVisionObservationProvider,
} from "../modules/pipeline/providers.js";
import { createProviders, validateObservations, withTimeout, withRetry } from "../modules/pipeline/factory.js";

// ── Upload/storage/queue ───────────────────────────────────────────────────
import { InMemoryAssetStorage } from "../modules/scans/storage.js";
import { InMemoryJobQueue } from "../modules/scans/queue.js";
import { validateUpload, isValidTransition, ASSET_RETENTION_HOURS } from "../modules/scans/service.js";
import { processAnalysisJob } from "../modules/scans/worker.js";

// ── App/config/http ────────────────────────────────────────────────────────
import { loadConfig } from "../config/index.js";
import { createApp } from "../app.js";
import { AppError, formatErrorResponse } from "../errors/index.js";
import { generateToken } from "../modules/auth/token.js";
import type { FastifyInstance } from "fastify";
import type { AnalysisJob } from "../modules/scans/queue.js";

// ─── Constants ────────────────────────────────────────────────────────────────

const FAKE_BYTES = new Uint8Array([0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10]);
const PROFILE_ID = "profile-phase5-final";
const SCAN_ID    = "scan-phase5-final";

function allFulfilledPkg(): ObservationPackage {
  return {
    observations: ALL_CRITERION_IDS.map((id) => ({ id, state: "fulfilled" as const, source: "A" as const })),
    modelVersions: { ocr: "v1" }, pipelineVersion: PIPELINE_VERSION,
    scoringModelVersion: SCORING_MODEL_VERSION,
  };
}
function allMissingPkg(): ObservationPackage {
  return {
    observations: ALL_CRITERION_IDS.map((id) => ({ id, state: "missing" as const, source: "A" as const })),
    modelVersions: { ocr: "v1" }, pipelineVersion: PIPELINE_VERSION,
    scoringModelVersion: SCORING_MODEL_VERSION,
  };
}
function fakeProviders(state: "fulfilled" | "missing" = "fulfilled") {
  return {
    imageProcessor: new StubImageProcessor(),
    ocr:    new StubOCRProvider(),
    vision: new StubVisionObservationProvider({ observationState: state }),
  };
}

// ═══════════════════════════════════════════════════════════════════════════
//  A — End-to-end scan flow (in-process)
// ═══════════════════════════════════════════════════════════════════════════

describe("A: End-to-end scan flow", () => {
  it("Upload validation → pipeline → observations → score → findings → actions", async () => {
    // Step 1: validate upload
    const validation = validateUpload(FAKE_BYTES, "image/jpeg");
    assert.equal(validation.valid, true);

    // Step 2: storage
    const storage = new InMemoryAssetStorage();
    await storage.put("scans/test/img.jpg", FAKE_BYTES, "image/jpeg");
    assert.ok(await storage.exists("scans/test/img.jpg"));

    // Step 3: enqueue
    const queue = new InMemoryJobQueue();
    const { jobId } = await queue.enqueueScan({
      scanId: SCAN_ID, creatorProfileId: PROFILE_ID,
      storageKey: "scans/test/img.jpg", platform: "tiktok",
      pipelineVersion: PIPELINE_VERSION,
    });
    assert.ok(jobId.length > 0);

    // Step 4: pipeline runs (with fulfilled stub → score 100)
    const imageMetadata = {
      storageKey: "scans/test/img.jpg", contentType: "image/jpeg" as const,
      byteSize: FAKE_BYTES.byteLength, bytes: FAKE_BYTES,
    };
    const pipelineResult = await runAnalysisPipeline(imageMetadata, PROFILE_ID, fakeProviders("fulfilled"));
    assert.equal(isPipelineSuccess(pipelineResult), true);

    if (isPipelineSuccess(pipelineResult)) {
      // Step 5: score is deterministic
      assert.equal(pipelineResult.scoringResult.scoreSet.total, 100);
      assert.equal(pipelineResult.findings.length, 0);
      assert.equal(pipelineResult.actions.length, 0);

      // Step 6: cache key is stable
      const key = pipelineResult.cacheKey;
      assert.equal(key.platform, "tiktok");
      assert.equal(key.scoringModelVersion, SCORING_MODEL_VERSION);
    }
  });

  it("Full flow with missing obs → score 0, 12 findings, 12 actions, daily task", async () => {
    const image = { storageKey:"k", contentType:"image/jpeg" as const, byteSize:4, bytes:FAKE_BYTES };
    const result = await runAnalysisPipeline(image, PROFILE_ID, fakeProviders("missing"));
    assert.equal(isPipelineSuccess(result), true);

    if (isPipelineSuccess(result)) {
      assert.equal(result.scoringResult.scoreSet.total, 0);
      assert.equal(result.findings.length, 12);
      assert.equal(result.actions.length, 12);

      // Growth engine integration
      const daily = selectDailyTask(result.actions);
      assert.ok(daily !== null);
      assert.equal(daily.severity, "foundation");

      const top3 = selectTopActions(result.actions, 3);
      assert.equal(top3.length, 3);
      for (const a of top3) assert.equal(a.blockedByFoundation, false);
    }
  });

  it("Worker with null DB fails safely — no corrupt state", async () => {
    const storage = new InMemoryAssetStorage();
    await storage.put("k", FAKE_BYTES, "image/jpeg");
    const job: AnalysisJob = {
      scanId: "s-safe", creatorProfileId: "p",
      storageKey: "k", platform: "tiktok", pipelineVersion: PIPELINE_VERSION,
    };
    const result = await processAnalysisJob(job, { db: null } as never, storage, fakeProviders());
    assert.equal(result.success, false);
    assert.equal(result.skipped, false);
    // Asset still accessible (worker didn't delete on failure)
    assert.ok(await storage.exists("k"));
  });

  it("Idempotency: same scan job enqueued twice → second is deduplicated", async () => {
    const queue = new InMemoryJobQueue();
    const job: AnalysisJob = { scanId:"s1", creatorProfileId:"p", storageKey:"k", platform:"tiktok", pipelineVersion: PIPELINE_VERSION, deduplicationKey:"dk-idem" };
    const r1 = await queue.enqueueScan(job);
    const r2 = await queue.enqueueScan({ ...job, scanId: "s2" });
    assert.equal(r1.deduplicated, false);
    assert.equal(r2.deduplicated, true);
  });

  it("Asset retention is ≤ 24h (GDPR/privacy rule)", () => {
    assert.ok(ASSET_RETENTION_HOURS <= 24);
    assert.ok(ASSET_RETENTION_HOURS > 0);
  });

  it("Scan status transitions are safe and terminal states are locked", () => {
    assert.equal(isValidTransition("accepted",   "processing"), true);
    assert.equal(isValidTransition("processing", "completed"),  true);
    assert.equal(isValidTransition("processing", "failed"),     true);
    assert.equal(isValidTransition("completed",  "processing"), false); // cannot reprocess
    assert.equal(isValidTransition("failed",     "processing"), false); // cannot retry without re-accept
    assert.equal(isValidTransition("completed",  "failed"),     false);
  });
});

// ═══════════════════════════════════════════════════════════════════════════
//  B — Deterministic core protection
// ═══════════════════════════════════════════════════════════════════════════

describe("B: Deterministic core protection", () => {
  it("Provider observations CANNOT override scores", async () => {
    const image = { storageKey:"k", contentType:"image/jpeg" as const, byteSize:4, bytes:FAKE_BYTES };

    // With fulfilled observations → score 100
    const r100 = await runAnalysisPipeline(image, "p", fakeProviders("fulfilled"));
    // With missing observations → score 0
    const r0   = await runAnalysisPipeline(image, "p", fakeProviders("missing"));

    if (isPipelineSuccess(r100) && isPipelineSuccess(r0)) {
      assert.equal(r100.scoringResult.scoreSet.total, 100);
      assert.equal(r0.scoringResult.scoreSet.total, 0);
      // Scores differ only because observations differ — not because providers injected them
      for (const o of r100.observations) {
        const raw = o as unknown as Record<string, unknown>;
        assert.ok(!("total" in raw) && !("score" in raw));
      }
    }
  });

  it("Scoring engine output is not affected by AI generation failures", async () => {
    const pkg = allMissingPkg();
    const sr  = calculateScore(pkg);
    const scoreBeforeAI = sr.scoreSet.total;

    const failingSvc = new GenerationService(new StubRecommendationProvider({ fail: true }));
    const findings = buildFindings(pkg, sr);
    if (findings.length > 0) {
      await failingSvc.explainFinding({ platform: "tiktok" }, findings[0]!, []);
    }

    // Score must be unchanged
    assert.equal(sr.scoreSet.total, scoreBeforeAI);
  });

  it("100 runs produce identical score/findings/actions (determinism)", async () => {
    const image = { storageKey:"k", contentType:"image/jpeg" as const, byteSize:4, bytes:FAKE_BYTES };
    const providers = fakeProviders("missing");
    const first = await runAnalysisPipeline(image, "p", providers);
    if (!isPipelineSuccess(first)) return;

    const refScore    = first.scoringResult.scoreSet.total;
    const refFindings = first.findings.length;
    const refCacheKey = cacheKeyString(first.cacheKey);

    for (let i = 0; i < 99; i++) {
      const r = await runAnalysisPipeline(image, "p", providers);
      if (isPipelineSuccess(r)) {
        assert.equal(r.scoringResult.scoreSet.total, refScore,    `Score changed at run ${i}`);
        assert.equal(r.findings.length,              refFindings, `Findings changed at run ${i}`);
        assert.equal(cacheKeyString(r.cacheKey),     refCacheKey, `CacheKey changed at run ${i}`);
      }
    }
  });

  it("Finding severity, priority and impact come only from scoring engine", () => {
    const pkg     = allMissingPkg();
    const sr      = calculateScore(pkg);
    const findings = buildFindings(pkg, sr);
    const actions  = buildGrowthActions(findings, "p");

    for (const [i, action] of actions.entries()) {
      const finding = findings.find((f) => f.templateId === action.sourceFindingId)!;
      assert.equal(action.priority,       finding.priority,  `Priority mismatch at ${i}`);
      assert.equal(action.severity,       finding.severity,  `Severity mismatch at ${i}`);
      assert.equal(action.expectedImpact, finding.impact,    `Impact mismatch at ${i}`);
    }
  });
});

// ═══════════════════════════════════════════════════════════════════════════
//  C — Growth engine integration
// ═══════════════════════════════════════════════════════════════════════════

describe("C: Growth engine integration", () => {
  it("All 12 FindingTemplates have action mappings", () => {
    for (const tmpl of FINDING_TEMPLATES) {
      assert.ok(
        FINDING_TO_ACTION[tmpl.templateId] !== undefined,
        `No mapping for: ${tmpl.templateId}`,
      );
    }
  });

  it("All 12 growth action types are used", () => {
    const usedTypes = new Set(Object.values(FINDING_TO_ACTION).map((a) => a.actionType));
    for (const t of GROWTH_ACTION_TYPES) {
      assert.ok(usedTypes.has(t), `Unused action type: ${t}`);
    }
  });

  it("Daily task selector: foundation before lever, lever before polish", () => {
    const pkg     = allMissingPkg();
    const sr      = calculateScore(pkg);
    const findings = buildFindings(pkg, sr);
    const actions  = buildGrowthActions(findings, "p");

    const daily = selectDailyTask(actions);
    assert.ok(daily !== null);
    assert.equal(daily.severity, "foundation");
    assert.equal(daily.blockedByFoundation, false);
  });

  it("selectTopActions(3) returns no blocked polish", () => {
    const pkg     = allMissingPkg();
    const sr      = calculateScore(pkg);
    const findings = buildFindings(pkg, sr);
    const actions  = buildGrowthActions(findings, "p");
    const top = selectTopActions(actions, 3);
    assert.equal(top.length, 3);
    for (const a of top) assert.equal(a.blockedByFoundation, false);
  });

  it("Progress comparison: fulfilled→missing = -100 delta", () => {
    const sr100 = calculateScore(allFulfilledPkg());
    const sr0   = calculateScore(allMissingPkg());
    const report = calculateProgress(sr100.scoreSet, sr0.scoreSet, [], []);
    assert.equal(report.scoreDelta, -100);
    assert.ok(report.worsenedCategories.includes("bio"));
  });

  it("AI recommendation fallback: provider error → GenerationFailure, scores unchanged", async () => {
    const pkg     = allMissingPkg();
    const sr      = calculateScore(pkg);
    const scoreSnapshot = sr.scoreSet.total;

    const svc = new GenerationService(new StubRecommendationProvider({ fail: true }));
    const findings = buildFindings(pkg, sr);
    const r = await svc.explainFinding({ platform: "tiktok" }, findings[0]!, []);
    assert.equal(isGenerationFailure(r), true);
    if (isGenerationFailure(r)) assert.equal(r.deterministicCoreIntact, true);
    assert.equal(sr.scoreSet.total, scoreSnapshot);
  });

  it("AI generation success returns structured output with promptVersion", async () => {
    const svc = new GenerationService(new StubRecommendationProvider());
    const pkg     = allMissingPkg();
    const sr      = calculateScore(pkg);
    const findings = buildFindings(pkg, sr);
    const r = await svc.generateBioOptions({ platform: "instagram" }, []);
    assert.equal(isGenerationFailure(r), false);
    if (!isGenerationFailure(r)) {
      assert.equal(r.options.length, 3);
      assert.equal(r.promptVersion, PROMPT_VERSIONS.BIO_GENERATION);
    }
  });
});

// ═══════════════════════════════════════════════════════════════════════════
//  D — Provider layer integration
// ═══════════════════════════════════════════════════════════════════════════

describe("D: Provider layer integration", () => {
  it("createProviders('fake') works without network", () => {
    const cfg = loadConfig({ NODE_ENV:"test", PORT:"3000",
      DATABASE_URL:"postgresql://localhost/t", JWT_SECRET:"secret-32-chars-minimum-length!!",
      APPLE_CLIENT_ID:"x", GCS_BUCKET_NAME:"x" });
    const { imageProcessor, ocr, vision } = createProviders(cfg);
    assert.equal(typeof imageProcessor.inspectQuality, "function");
    assert.equal(typeof ocr.extractText, "function");
    assert.equal(typeof vision.detectPlatform, "function");
  });

  it("ValidatedVisionProvider rejects unknown criterionId injection", () => {
    assert.throws(
      () => validateObservations([{ criterionId: "fake_criterion", state: "fulfilled", source: "C" as const }]),
      (e: unknown) => e instanceof Error && (e as Error).message.includes("unknown criterionId"),
    );
  });

  it("ValidatedVisionProvider rejects score injection via observation", () => {
    const obs = { criterionId: "bio_target_audience", state: "fulfilled" as const, source: "C" as const, score: 100 };
    assert.throws(() => validateObservations([obs as never]));
  });

  it("withTimeout enforces time bound", async () => {
    await assert.rejects(
      () => withTimeout(() => new Promise((r) => setTimeout(r, 500)), 20, "slow"),
      (e: unknown) => (e as Error).message.includes("timeout"),
    );
  });

  it("withRetry(0) gives exactly 1 attempt", async () => {
    let calls = 0;
    await assert.rejects(() => withRetry(() => { calls++; return Promise.reject(new Error("x")); }, 0, "t"));
    assert.equal(calls, 1);
  });

  it("Pipeline failure → deterministicScoringUntouched", async () => {
    const image = { storageKey:"k", contentType:"image/jpeg" as const, byteSize:4, bytes:FAKE_BYTES };
    const result = await runAnalysisPipeline(image, "p", {
      imageProcessor: new StubImageProcessor(),
      ocr:    new StubOCRProvider({ fail: true }),
      vision: new StubVisionObservationProvider(),
    });
    assert.equal(isPipelineFailure(result), true);
    if (isPipelineFailure(result)) assert.equal(result.deterministicScoringUntouched, true);
  });

  it("Disabled OCR provider fails at call time, not import time", async () => {
    const cfg = loadConfig({ NODE_ENV:"test", PORT:"3000",
      DATABASE_URL:"postgresql://localhost/t", JWT_SECRET:"secret-32-chars-minimum-length!!",
      APPLE_CLIENT_ID:"x", GCS_BUCKET_NAME:"x", OCR_PROVIDER:"disabled" });
    const { ocr } = createProviders(cfg);
    await assert.rejects(() => ocr.extractText({ storageKey:"k", contentType:"image/jpeg", byteSize:1 }, []));
  });
});

// ═══════════════════════════════════════════════════════════════════════════
//  E — Persistence wiring
// ═══════════════════════════════════════════════════════════════════════════

describe("E: Persistence wiring", () => {
  it("InMemoryAssetStorage put/get/delete cycle", async () => {
    const s = new InMemoryAssetStorage();
    await s.put("key", FAKE_BYTES, "image/jpeg");
    const got = await s.get("key");
    assert.ok(got !== null && got.length === FAKE_BYTES.length);
    await s.delete("key");
    assert.equal(await s.get("key"), null);
  });

  it("delete non-existent key is safe", async () => {
    const s = new InMemoryAssetStorage();
    await assert.doesNotReject(() => s.delete("no-such-key"));
  });

  it("ASSET_RETENTION_HOURS ≤ 24 enforces screenshot deletion policy", () => {
    assert.ok(ASSET_RETENTION_HOURS <= 24);
  });

  it("isValidTransition prevents double-completion", () => {
    assert.equal(isValidTransition("completed", "completed"),  false);
    assert.equal(isValidTransition("completed", "processing"), false);
    assert.equal(isValidTransition("completed", "accepted"),   false);
  });

  it("Upload validation rejects HEIC (not in supported list)", () => {
    const r = validateUpload(FAKE_BYTES, "image/heic");
    assert.equal(r.valid, false);
  });

  it("Upload validation accepts JPEG, PNG, WebP", () => {
    for (const ct of ["image/jpeg", "image/png", "image/webp"] as const) {
      const r = validateUpload(FAKE_BYTES, ct);
      assert.equal(r.valid, true, `${ct} should be accepted`);
    }
  });
});

// ═══════════════════════════════════════════════════════════════════════════
//  F — OpenAPI completeness
// ═══════════════════════════════════════════════════════════════════════════

describe("F: OpenAPI completeness", () => {
  let app: FastifyInstance;

  const cfg = loadConfig({ NODE_ENV:"test", PORT:"3099",
    DATABASE_URL:"postgresql://localhost/t", JWT_SECRET:"secret-32-chars-minimum-length!!",
    APPLE_CLIENT_ID:"x", GCS_BUCKET_NAME:"x" });

  before(async () => { app = await createApp(cfg); });
  after(async () => { await app.close(); });

  it("OpenAPI 3.1.0 document is generated", async () => {
    const doc = app.swagger() as { openapi: string };
    assert.equal(doc.openapi, "3.1.0");
  });

  it("All 12 Phase 4+5 routes present in OpenAPI", async () => {
    const doc  = app.swagger() as { paths: Record<string, unknown> };
    const required = [
      "/health",
      "/auth/anonymous", "/auth/session/rotate", "/auth/logout",
      "/users", "/users/me", "/auth/claim-anonymous",
      "/social/accounts", "/social/accounts/{id}", "/social/accounts/link",
      "/scans", "/scans/{id}",
    ];
    for (const path of required) {
      assert.ok(doc.paths?.[path] !== undefined, `Missing from OpenAPI: ${path}`);
    }
  });

  it("GET /health still returns 200 after all routes registered", async () => {
    const res = await app.inject({ method: "GET", url: "/health" });
    assert.equal(res.statusCode, 200);
    assert.equal(res.json<{ status: string }>().status, "ok");
  });

  it("/scans has POST, /scans/{id} has GET", async () => {
    const doc = app.swagger() as { paths: Record<string, Record<string, unknown>> };
    assert.ok(doc.paths["/scans"]?.["post"] !== undefined);
    assert.ok(doc.paths["/scans/{id}"]?.["get"] !== undefined);
  });
});

// ═══════════════════════════════════════════════════════════════════════════
//  G — Security
// ═══════════════════════════════════════════════════════════════════════════

describe("G: Security", () => {
  let app: FastifyInstance;

  const cfg = loadConfig({ NODE_ENV:"test", PORT:"3098",
    DATABASE_URL:"postgresql://localhost/t", JWT_SECRET:"secret-32-chars-minimum-length!!",
    APPLE_CLIENT_ID:"x", GCS_BUCKET_NAME:"x" });

  before(async () => { app = await createApp(cfg); });
  after(async () => { await app.close(); });

  it("GET /scans/:id without token → 401, not 500", async () => {
    const res = await app.inject({ method: "GET", url: "/scans/any-id" });
    assert.equal(res.statusCode, 401);
  });

  it("POST /scans without token → 401", async () => {
    const res = await app.inject({ method: "POST", url: "/scans", payload: FAKE_BYTES });
    assert.equal(res.statusCode, 401);
  });

  it("Token value never appears in error response body", async () => {
    const token = generateToken();
    const res = await app.inject({
      method: "GET", url: "/scans/any-id",
      headers: { authorization: `Bearer ${token}` },
    });
    assert.ok(!res.body.includes(token), "Token must not appear in response");
  });

  it("DB error details do not appear in response body", async () => {
    const token = generateToken();
    const res = await app.inject({
      method: "GET", url: "/scans/any-id",
      headers: { authorization: `Bearer ${token}` },
    });
    assert.ok(!res.body.includes("ECONNREFUSED"));
    assert.ok(!res.body.includes("postgres"));
    assert.ok(!res.body.includes("password"));
  });

  it("FORBIDDEN AppError → 403, expose=true (safe message)", () => {
    const e = AppError.forbidden("You do not own this scan");
    assert.equal(e.httpStatus, 403);
    assert.equal(e.expose, true);
    assert.ok(!e.message.includes("token"));
  });

  it("INTERNAL AppError → expose=false, 500", () => {
    const e = AppError.internal("DB at 10.0.0.1");
    assert.equal(e.expose, false);
    assert.equal(e.httpStatus, 500);
    const { body } = formatErrorResponse(e);
    assert.ok(!body.error.message.includes("10.0.0.1"), "Internal details must not leak");
  });

  it("Raw screenshot bytes never logged (storage API has no console.log)", async () => {
    // Structural check: InMemoryAssetStorage returns exact bytes, no transformation
    const s = new InMemoryAssetStorage();
    await s.put("secret", FAKE_BYTES, "image/jpeg");
    const got = await s.get("secret");
    assert.ok(got !== null);
    // Verify exact bytes returned (no encoding or logging transformation)
    assert.equal(got.length, FAKE_BYTES.length);
    for (let i = 0; i < FAKE_BYTES.length; i++) {
      assert.equal(got[i], FAKE_BYTES[i]);
    }
  });

  it("Provider error messages are capped and sanitized in worker", async () => {
    const storage = new InMemoryAssetStorage();
    const result = await processAnalysisJob(
      { scanId:"s", creatorProfileId:"p", storageKey:"missing-key", platform:"tiktok", pipelineVersion: PIPELINE_VERSION },
      { db: null } as never, storage, fakeProviders(),
    );
    assert.equal(result.success, false);
    if (result.failureReason) {
      assert.ok(!result.failureReason.includes("password"));
      assert.ok(result.failureReason.length < 1000, "Failure reason must be bounded");
    }
  });
});
