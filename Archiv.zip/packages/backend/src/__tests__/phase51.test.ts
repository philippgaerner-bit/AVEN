/**
 * Phase 5.1 — Growth Engine Core Tests
 *
 *   A  Finding→Action mappings (all 12 templates)
 *   B  Priority and blocking rules
 *   C  Daily task selector
 *   D  Progress calculation
 *   E  Determinism
 */

import { describe, it } from "node:test";
import assert from "node:assert/strict";

import {
  calculateScore,
  buildFindings,
  selectTopFindings,
  FINDING_TEMPLATES,
  SCORING_MODEL_VERSION,
  ALL_CRITERION_IDS,
} from "@vyro/shared/scoring";
import type { ObservationPackage, Finding } from "@vyro/shared/scoring";

import {
  FINDING_TO_ACTION,
  GROWTH_ACTION_TYPES,
  buildGrowthActions,
  findingToAction,
  type GrowthAction,
} from "../modules/growth/actions.js";

import {
  selectDailyTask,
  selectTopActions,
  calculateProgress,
} from "../modules/growth/planner.js";

// ─── Helpers ──────────────────────────────────────────────────────────────────

function makePkg(
  overrides: Partial<Record<string, "fulfilled" | "partial" | "missing" | "unavailable">> = {},
): ObservationPackage {
  return {
    observations: ALL_CRITERION_IDS.map((id) => ({
      id,
      state: (overrides[id] ?? "fulfilled") as "fulfilled" | "partial" | "missing" | "unavailable",
      source: "A" as const,
    })),
    modelVersions: { ocr: "test-v1" },
    pipelineVersion: "v1.0.0",
    scoringModelVersion: SCORING_MODEL_VERSION,
  };
}

function allMissingPkg(): ObservationPackage {
  return makePkg(
    Object.fromEntries(ALL_CRITERION_IDS.map((id) => [id, "missing"])) as Record<string, "missing">,
  );
}

function getFindings(overrides?: Partial<Record<string, "fulfilled" | "partial" | "missing" | "unavailable">>): ReadonlyArray<Finding> {
  const pkg = overrides ? makePkg(overrides) : allMissingPkg();
  const sr  = calculateScore(pkg);
  return buildFindings(pkg, sr);
}

function makeAction(overrides: Partial<GrowthAction> = {}): GrowthAction {
  return {
    id: "profile:bio_cta_missing",
    sourceFindingId: "bio_cta_missing",
    creatorProfileId: "profile-1",
    category: "bio",
    title: "Add a clear next step to your bio",
    actionType: "add_bio_cta",
    expectedImpact: 3,
    priority: 2,
    severity: "lever",
    blockedByFoundation: false,
    status: "open",
    ...overrides,
  };
}

const PROFILE_ID = "profile-test-1";

// ─── A: Finding→Action mappings ───────────────────────────────────────────────

describe("A: Finding→Action mappings (all 12 templates)", () => {
  it("FINDING_TO_ACTION covers all 12 FindingTemplates", () => {
    for (const tmpl of FINDING_TEMPLATES) {
      assert.ok(
        FINDING_TO_ACTION[tmpl.templateId] !== undefined,
        `No action mapping for: ${tmpl.templateId}`,
      );
    }
    assert.equal(Object.keys(FINDING_TO_ACTION).length, 12);
  });

  it("All 12 action types are in GROWTH_ACTION_TYPES", () => {
    const types = new Set(GROWTH_ACTION_TYPES);
    for (const [, action] of Object.entries(FINDING_TO_ACTION)) {
      assert.ok(types.has(action.actionType), `Unknown actionType: ${action.actionType}`);
    }
  });

  it("bio_positioning_unclear → optimize_bio_positioning", () => {
    assert.equal(FINDING_TO_ACTION["bio_positioning_unclear"]?.actionType, "optimize_bio_positioning");
    assert.equal(FINDING_TO_ACTION["bio_positioning_unclear"]?.category, "bio");
  });

  it("bio_cta_missing → add_bio_cta", () => {
    assert.equal(FINDING_TO_ACTION["bio_cta_missing"]?.actionType, "add_bio_cta");
  });

  it("bio_first_line_weak → strengthen_bio_first_line", () => {
    assert.equal(FINDING_TO_ACTION["bio_first_line_weak"]?.actionType, "strengthen_bio_first_line");
  });

  it("content_hook_weak → improve_hooks", () => {
    assert.equal(FINDING_TO_ACTION["content_hook_weak"]?.actionType, "improve_hooks");
  });

  it("covers_unclear → clarify_covers", () => {
    assert.equal(FINDING_TO_ACTION["covers_unclear"]?.actionType, "clarify_covers");
  });

  it("content_structure_inconsistent → build_content_structure", () => {
    assert.equal(FINDING_TO_ACTION["content_structure_inconsistent"]?.actionType, "build_content_structure");
  });

  it("feed_inconsistent → improve_feed_consistency", () => {
    assert.equal(FINDING_TO_ACTION["feed_inconsistent"]?.actionType, "improve_feed_consistency");
    assert.equal(FINDING_TO_ACTION["feed_inconsistent"]?.category, "feed");
  });

  it("feed_topic_unclear → clarify_feed_topic", () => {
    assert.equal(FINDING_TO_ACTION["feed_topic_unclear"]?.actionType, "clarify_feed_topic");
  });

  it("branding_inconsistent → strengthen_branding", () => {
    assert.equal(FINDING_TO_ACTION["branding_inconsistent"]?.actionType, "strengthen_branding");
    assert.equal(FINDING_TO_ACTION["branding_inconsistent"]?.category, "branding");
  });

  it("profile_picture_weak → improve_profile_picture", () => {
    assert.equal(FINDING_TO_ACTION["profile_picture_weak"]?.actionType, "improve_profile_picture");
  });

  it("identity_unclear → clarify_identity", () => {
    assert.equal(FINDING_TO_ACTION["identity_unclear"]?.actionType, "clarify_identity");
  });

  it("engagement_structure_weak → improve_engagement_structure", () => {
    assert.equal(FINDING_TO_ACTION["engagement_structure_weak"]?.actionType, "improve_engagement_structure");
    assert.equal(FINDING_TO_ACTION["engagement_structure_weak"]?.category, "engagement");
  });

  it("findingToAction returns correct expectedImpact from finding.impact", () => {
    const findings = getFindings({ bio_cta: "missing" });
    const f = findings.find((f) => f.templateId === "bio_cta_missing");
    assert.ok(f, "bio_cta_missing finding not found");
    const action = findingToAction(f, PROFILE_ID);
    assert.ok(action !== null);
    assert.equal(action.expectedImpact, f.impact);
    assert.equal(action.expectedImpact, 3); // bio_cta maxPoints = 3
  });

  it("findingToAction returns null for unknown templateId", () => {
    const fakeFinding = { templateId: "does_not_exist", impact: 5, priority: 1, severity: "lever", blockedByFoundation: false } as Finding;
    assert.equal(findingToAction(fakeFinding, PROFILE_ID), null);
  });

  it("buildGrowthActions: all 12 findings → 12 actions when all missing", () => {
    const findings = getFindings();
    assert.equal(findings.length, 12);
    const actions = buildGrowthActions(findings, PROFILE_ID);
    assert.equal(actions.length, 12);
  });

  it("buildGrowthActions: action IDs are deterministic", () => {
    const findings = getFindings();
    const a1 = buildGrowthActions(findings, PROFILE_ID);
    const a2 = buildGrowthActions(findings, PROFILE_ID);
    for (let i = 0; i < a1.length; i++) {
      assert.equal(a1[i]!.id, a2[i]!.id);
    }
  });

  it("buildGrowthActions: action titles are non-empty strings", () => {
    const actions = buildGrowthActions(getFindings(), PROFILE_ID);
    for (const a of actions) {
      assert.ok(a.title.length > 0, `Empty title for ${a.sourceFindingId}`);
    }
  });
});

// ─── B: Priority and blocking ──────────────────────────────────────────────────

describe("B: Priority and blocking rules", () => {
  it("Actions inherit priority from findings", () => {
    const findings = getFindings();
    const actions = buildGrowthActions(findings, PROFILE_ID);
    // All finding priorities are 1-based and match action priorities
    for (const action of actions) {
      const f = findings.find((f) => f.templateId === action.sourceFindingId);
      assert.ok(f, `No finding for ${action.sourceFindingId}`);
      assert.equal(action.priority, f.priority);
    }
  });

  it("Foundation actions come before lever, lever before polish", () => {
    const actions = buildGrowthActions(getFindings(), PROFILE_ID);
    const SEVERITY_ORDER: Record<string, number> = { foundation: 0, lever: 1, polish: 2 };
    let prevOrder = -1;
    for (const a of actions) {
      const ord = SEVERITY_ORDER[a.severity] ?? 99;
      assert.ok(ord >= prevOrder, `${a.severity} after ${actions[actions.indexOf(a) - 1]?.severity}`);
      prevOrder = ord;
    }
  });

  it("Polish actions blocked when foundation issues exist", () => {
    const findings = getFindings();
    const hasFoundation = findings.some((f) => f.severity === "foundation");
    assert.ok(hasFoundation, "Need foundation findings for this test");
    const actions = buildGrowthActions(findings, PROFILE_ID);
    const polish = actions.filter((a) => a.severity === "polish");
    assert.ok(polish.length > 0, "Need polish actions");
    for (const p of polish) {
      assert.equal(p.blockedByFoundation, true);
    }
  });

  it("Polish actions not blocked when no foundation issues exist", () => {
    // Only feed_inconsistent (polish) and branding_inconsistent (polish) missing
    const findings = getFindings({
      feed_color_world: "missing", feed_cover_pattern: "missing",
      brand_colors: "missing", brand_font: "missing", brand_theme: "missing", brand_recognizable: "missing",
    });
    const hasFoundation = findings.some((f) => f.severity === "foundation");
    assert.equal(hasFoundation, false, "No foundation findings expected");
    const actions = buildGrowthActions(findings, PROFILE_ID);
    for (const a of actions) {
      assert.equal(a.blockedByFoundation, false);
    }
  });
});

// ─── C: Daily task selector ────────────────────────────────────────────────────

describe("C: Daily task selector", () => {
  it("Returns null for empty action list", () => {
    assert.equal(selectDailyTask([]), null);
  });

  it("Returns null when all actions are completed", () => {
    const actions = [
      makeAction({ status: "completed" }),
      makeAction({ id: "p:b", status: "completed", sourceFindingId: "bio_cta_missing" }),
    ];
    assert.equal(selectDailyTask(actions), null);
  });

  it("Returns null when all actions are dismissed", () => {
    assert.equal(selectDailyTask([makeAction({ status: "dismissed" })]), null);
  });

  it("Returns null when all open actions are blocked polish", () => {
    const blocked = makeAction({ severity: "polish", blockedByFoundation: true });
    assert.equal(selectDailyTask([blocked]), null);
  });

  it("Selects highest-priority (lowest number) open action", () => {
    const a1 = makeAction({ priority: 3 });
    const a2 = makeAction({ id: "p:b", priority: 1, sourceFindingId: "content_hook_weak", actionType: "improve_hooks" });
    const a3 = makeAction({ id: "p:c", priority: 2, sourceFindingId: "bio_cta_missing", actionType: "add_bio_cta" });
    const result = selectDailyTask([a1, a3, a2]);
    assert.equal(result?.priority, 1);
    assert.equal(result?.sourceFindingId, "content_hook_weak");
  });

  it("Skips blocked polish in favor of eligible lever", () => {
    const blocked = makeAction({ priority: 1, severity: "polish", blockedByFoundation: true });
    const lever   = makeAction({ id: "p:b", priority: 2, severity: "lever", blockedByFoundation: false });
    const result  = selectDailyTask([blocked, lever]);
    assert.equal(result?.severity, "lever");
  });

  it("Uses alphabetical actionType as tiebreaker for equal priority", () => {
    const a = makeAction({ priority: 1, actionType: "improve_hooks",         id: "p:a", sourceFindingId: "content_hook_weak" });
    const b = makeAction({ priority: 1, actionType: "add_bio_cta",           id: "p:b", sourceFindingId: "bio_cta_missing" });
    const c = makeAction({ priority: 1, actionType: "clarify_feed_topic",    id: "p:c", sourceFindingId: "feed_topic_unclear" });
    const result = selectDailyTask([a, c, b]);
    assert.equal(result?.actionType, "add_bio_cta"); // alphabetically first
  });

  it("selectTopActions excludes blocked polish, returns ≤ limit", () => {
    const actions = buildGrowthActions(getFindings(), PROFILE_ID);
    const top = selectTopActions(actions, 3);
    assert.ok(top.length <= 3);
    for (const a of top) {
      assert.equal(a.blockedByFoundation, false);
      assert.equal(a.status, "open");
    }
  });

  it("selectDailyTask with real findings — returns foundation action first", () => {
    const actions = buildGrowthActions(getFindings(), PROFILE_ID);
    const daily = selectDailyTask(actions);
    assert.ok(daily !== null);
    assert.equal(daily.severity, "foundation");
  });

  it("Daily task never comes from completed actions (real findings)", () => {
    const actions = buildGrowthActions(getFindings(), PROFILE_ID).map((a) =>
      a.severity === "foundation" ? { ...a, status: "completed" as const } : a,
    );
    const daily = selectDailyTask(actions);
    if (daily) assert.notEqual(daily.status, "completed");
  });
});

// ─── D: Progress calculation ───────────────────────────────────────────────────

describe("D: Progress calculation", () => {
  // Build real ScoreSets from the engine
  const pkg100 = makePkg();
  const pkg0   = allMissingPkg();
  const sr100  = calculateScore(pkg100);
  const sr0    = calculateScore(pkg0);

  it("scoreDelta is positive when score improves", () => {
    const report = calculateProgress(sr0.scoreSet, sr100.scoreSet, [], []);
    assert.ok(report.scoreDelta > 0);
    assert.equal(report.scoreDelta, 100); // 100 - 0 = 100
  });

  it("scoreDelta is negative when score worsens", () => {
    const report = calculateProgress(sr100.scoreSet, sr0.scoreSet, [], []);
    assert.ok(report.scoreDelta < 0);
    assert.equal(report.scoreDelta, -100);
  });

  it("scoreDelta is 0 when score unchanged", () => {
    const report = calculateProgress(sr100.scoreSet, sr100.scoreSet, [], []);
    assert.equal(report.scoreDelta, 0);
  });

  it("resolvedFindingIds: previous findings not in current", () => {
    const report = calculateProgress(
      sr0.scoreSet, sr100.scoreSet,
      ["bio_cta_missing", "content_hook_weak"],
      ["content_hook_weak"],
    );
    assert.deepEqual(report.resolvedFindingIds, ["bio_cta_missing"]);
  });

  it("newFindingIds: current findings not in previous", () => {
    const report = calculateProgress(
      sr100.scoreSet, sr0.scoreSet,
      ["content_hook_weak"],
      ["content_hook_weak", "feed_topic_unclear"],
    );
    assert.deepEqual(report.newFindingIds, ["feed_topic_unclear"]);
  });

  it("improvedCategories: normalizedPoints increased", () => {
    // sr0 has 0 in all categories, sr100 has full scores
    const report = calculateProgress(sr0.scoreSet, sr100.scoreSet, [], []);
    assert.ok(report.improvedCategories.includes("bio"));
    assert.ok(report.improvedCategories.includes("content"));
    assert.equal(report.worsenedCategories.length, 0);
  });

  it("worsenedCategories: normalizedPoints decreased", () => {
    const report = calculateProgress(sr100.scoreSet, sr0.scoreSet, [], []);
    assert.ok(report.worsenedCategories.includes("bio"));
    assert.equal(report.improvedCategories.length, 0);
  });

  it("No improvement or regression when scores identical", () => {
    const report = calculateProgress(sr100.scoreSet, sr100.scoreSet, ["x"], ["x"]);
    assert.equal(report.improvedCategories.length, 0);
    assert.equal(report.worsenedCategories.length, 0);
    assert.equal(report.resolvedFindingIds.length, 0);
    assert.equal(report.newFindingIds.length, 0);
  });

  it("Empty finding lists produce empty resolved/new arrays", () => {
    const report = calculateProgress(sr0.scoreSet, sr100.scoreSet, [], []);
    assert.deepEqual(report.resolvedFindingIds, []);
    assert.deepEqual(report.newFindingIds, []);
  });
});

// ─── E: Determinism ───────────────────────────────────────────────────────────

describe("E: Determinism", () => {
  it("buildGrowthActions: 10 repeated calls yield identical output", () => {
    const findings = getFindings();
    const first = buildGrowthActions(findings, PROFILE_ID);
    for (let i = 0; i < 9; i++) {
      const run = buildGrowthActions(findings, PROFILE_ID);
      assert.equal(run.length, first.length);
      for (let j = 0; j < run.length; j++) {
        assert.equal(run[j]!.id,           first[j]!.id);
        assert.equal(run[j]!.priority,     first[j]!.priority);
        assert.equal(run[j]!.expectedImpact, first[j]!.expectedImpact);
      }
    }
  });

  it("selectDailyTask: 10 repeated calls yield identical result", () => {
    const actions = buildGrowthActions(getFindings(), PROFILE_ID);
    const first = selectDailyTask(actions);
    for (let i = 0; i < 9; i++) {
      const run = selectDailyTask([...actions]);
      assert.equal(run?.id, first?.id);
    }
  });

  it("calculateProgress: 10 repeated calls yield identical deltas", () => {
    const pkg = allMissingPkg();
    const sr  = calculateScore(pkg);
    const base = calculateScore(makePkg());
    const first = calculateProgress(base.scoreSet, sr.scoreSet, ["x"], ["y"]);
    for (let i = 0; i < 9; i++) {
      const run = calculateProgress(base.scoreSet, sr.scoreSet, ["x"], ["y"]);
      assert.equal(run.scoreDelta, first.scoreDelta);
      assert.deepEqual(run.resolvedFindingIds, first.resolvedFindingIds);
      assert.deepEqual(run.newFindingIds, first.newFindingIds);
    }
  });

  it("Actions expectedImpact = finding.impact (no invented scores)", () => {
    const findings = getFindings();
    const actions  = buildGrowthActions(findings, PROFILE_ID);
    for (const action of actions) {
      const f = findings.find((f) => f.templateId === action.sourceFindingId);
      assert.ok(f, `Missing finding for ${action.sourceFindingId}`);
      assert.equal(action.expectedImpact, f.impact, `Impact mismatch for ${action.sourceFindingId}`);
    }
  });
});
