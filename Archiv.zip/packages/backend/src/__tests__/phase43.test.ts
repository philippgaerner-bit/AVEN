/**
 * Phase 4.3 Tests — Social Account Foundation
 *
 *   A  Provider abstraction (StubSocialProvider)
 *   B  Service logic — ownership, duplicates, platform (in-memory via service unit tests)
 *   C  HTTP routes (Fastify inject, NULL_DB_CONTEXT)
 *   D  Security properties
 */

import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";

import { StubSocialProvider, type ProviderIdentity } from "../modules/social/provider.js";
import { AppError } from "../errors/index.js";
import { anonIdentity, userIdentity } from "../modules/auth/identity.js";
import { assertOwnership, type CreatorProfileRow } from "../modules/profiles/service.js";
import { generateToken } from "../modules/auth/token.js";
import { loadConfig } from "../config/index.js";
import { createApp } from "../app.js";
import type { FastifyInstance } from "fastify";
import {
  linkSocialAccount,
  listSocialAccounts,
  disconnectSocialAccount,
  getSocialAccountById,
} from "../modules/social/service.js";
import { CREATOR_PLATFORMS } from "../db/enums.js";

// ─── A: Provider abstraction ──────────────────────────────────────────────────

describe("A: StubSocialProvider", () => {
  const tiktokIdentity: ProviderIdentity = {
    platform:          "tiktok",
    providerAccountId: "tiktok-user-123",
    displayName:       "Test Creator",
    username:          "@testcreator",
  };

  const instagramIdentity: ProviderIdentity = {
    platform:          "instagram",
    providerAccountId: "ig-user-456",
    displayName:       "IG Creator",
    username:          "igcreator",
  };

  it("StubSocialProvider.platform matches the identity platform", () => {
    const p = new StubSocialProvider(tiktokIdentity);
    assert.equal(p.platform, "tiktok");
  });

  it("getAuthorizationUrl returns a non-empty URL", () => {
    const p = new StubSocialProvider(tiktokIdentity);
    const url = p.getAuthorizationUrl("csrf-state", "https://example.com/callback");
    assert.ok(typeof url === "string" && url.length > 0);
    assert.ok(url.includes("csrf-state"), "State must be included in URL");
  });

  it("getAuthorizationUrl does NOT include real credentials", () => {
    const p = new StubSocialProvider(tiktokIdentity);
    const url = p.getAuthorizationUrl("state", "https://redirect.example");
    assert.ok(!url.includes("client_secret"), "Must not expose secrets");
    assert.ok(!url.includes("access_token"),  "Must not expose tokens");
  });

  it("exchangeCode returns the pre-baked identity", async () => {
    const p = new StubSocialProvider(tiktokIdentity);
    const id = await p.exchangeCode("any-code", "https://redirect.example");
    assert.equal(id.platform,          "tiktok");
    assert.equal(id.providerAccountId, "tiktok-user-123");
    assert.equal(id.displayName,       "Test Creator");
  });

  it("exchangeCode does NOT return access tokens", async () => {
    const p = new StubSocialProvider(tiktokIdentity);
    const id = await p.exchangeCode("code", "redirect") as Record<string, unknown>;
    assert.ok(!("accessToken"  in id), "Must not return access token");
    assert.ok(!("refreshToken" in id), "Must not return refresh token");
  });

  it("getAccountIdentity returns stable identity", async () => {
    const p = new StubSocialProvider(instagramIdentity);
    const id = await p.getAccountIdentity("ig-user-456");
    assert.equal(id.platform, "instagram");
    assert.equal(id.providerAccountId, "ig-user-456");
  });

  it("TikTok and Instagram providers have distinct platforms", () => {
    const tt = new StubSocialProvider(tiktokIdentity);
    const ig = new StubSocialProvider(instagramIdentity);
    assert.notEqual(tt.platform, ig.platform);
  });

  it("ProviderIdentity has no token fields", () => {
    const id = tiktokIdentity as Record<string, unknown>;
    assert.ok(!("accessToken"  in id));
    assert.ok(!("refreshToken" in id));
    assert.ok(!("clientSecret" in id));
  });
});

// ─── B: Service logic (no DB — pure unit tests) ───────────────────────────────

describe("B: Social service logic (ownership and validation)", () => {
  // We test the ownership layer (assertOwnership) which is already unit-tested,
  // and we verify service functions are importable and typed.
  // Full integration tests (with DB) are left for the integration test phase.

  it("linkSocialAccount is importable and async", () => {
    assert.equal(typeof linkSocialAccount, "function");
  });

  it("listSocialAccounts is importable and async", () => {
    assert.equal(typeof listSocialAccounts, "function");
  });

  it("disconnectSocialAccount is importable and async", () => {
    assert.equal(typeof disconnectSocialAccount, "function");
  });

  it("getSocialAccountById is importable", () => {
    assert.equal(typeof getSocialAccountById, "function");
  });

  // Profile ownership check (reuses existing assertOwnership)
  it("anon identity cannot access another anon's social accounts", () => {
    const profile: CreatorProfileRow = {
      id: "profile-1", ownerType: "anonymous",
      ownerAnonymousSessionId: "sess-abc", ownerUserId: null,
      platform: "tiktok", createdAt: new Date(), updatedAt: new Date(),
    };
    assert.throws(
      () => assertOwnership(profile, anonIdentity("sess-xyz")),
      (e: unknown) => e instanceof AppError && e.code === "FORBIDDEN",
    );
  });

  it("user identity cannot access another user's social accounts", () => {
    const profile: CreatorProfileRow = {
      id: "profile-2", ownerType: "user",
      ownerUserId: "user-A", ownerAnonymousSessionId: null,
      platform: "instagram", createdAt: new Date(), updatedAt: new Date(),
    };
    assert.throws(
      () => assertOwnership(profile, userIdentity("user-B")),
      (e: unknown) => e instanceof AppError && e.code === "FORBIDDEN",
    );
  });

  it("linkSocialAccount with null DB throws (DB required)", async () => {
    await assert.rejects(
      () => linkSocialAccount(
        { db: null } as never,
        "profile-id",
        userIdentity("user-id"),
        { platform: "tiktok", providerAccountId: "tt-123" },
      ),
      (e: unknown) => e instanceof Error,
    );
  });

  it("CONFLICT AppError has correct shape for duplicate link scenario", () => {
    const e = AppError.conflict("This tiktok account is already linked to another profile");
    assert.equal(e.code, "CONFLICT");
    assert.equal(e.httpStatus, 409);
    assert.equal(e.expose, true);
    // Must not leak internal IDs
    assert.ok(!e.message.includes("profile-id-secret"));
  });

  it("CONFLICT for same-profile already-linked scenario", () => {
    const e = AppError.conflict("This profile already has an active tiktok account linked. Disconnect it first.");
    assert.equal(e.code, "CONFLICT");
    assert.equal(e.httpStatus, 409);
  });
});

// ─── C: HTTP routes ───────────────────────────────────────────────────────────

describe("C: HTTP routes (Fastify inject, NULL_DB_CONTEXT)", () => {
  let app: FastifyInstance;

  const cfg = loadConfig({
    NODE_ENV: "test", PORT: "3004",
    DATABASE_URL: "postgresql://localhost:5432/test",
    JWT_SECRET: "test-secret-minimum-32-chars-long!!",
    APPLE_CLIENT_ID: "com.vyro.test",
    GCS_BUCKET_NAME: "vyro-test",
  });

  before(async () => { app = await createApp(cfg); });
  after(async () => { await app.close(); });

  // GET /social/accounts
  it("GET /social/accounts without auth → 401", async () => {
    const res = await app.inject({
      method: "GET", url: "/social/accounts?profileId=00000000-0000-0000-0000-000000000001",
    });
    assert.equal(res.statusCode, 401);
    assert.equal(res.json<{ error: { code: string } }>().error.code, "UNAUTHORIZED");
  });

  it("GET /social/accounts with malformed token → 401", async () => {
    const res = await app.inject({
      method: "GET", url: "/social/accounts?profileId=00000000-0000-0000-0000-000000000001",
      headers: { authorization: "Bearer bad" },
    });
    assert.equal(res.statusCode, 401);
  });

  it("GET /social/accounts missing profileId → 400", async () => {
    const token = generateToken();
    const res = await app.inject({
      method: "GET", url: "/social/accounts",
      headers: { authorization: `Bearer ${token}` },
    });
    assert.equal(res.statusCode, 400);
  });

  it("GET /social/accounts route exists", async () => {
    const res = await app.inject({ method: "GET", url: "/social/accounts" });
    assert.notEqual(res.statusCode, 404, "Route must exist");
  });

  // DELETE /social/accounts/:id
  it("DELETE /social/accounts/:id without auth → 401", async () => {
    const res = await app.inject({
      method: "DELETE",
      url: "/social/accounts/00000000-0000-0000-0000-000000000001",
    });
    assert.equal(res.statusCode, 401);
  });

  it("DELETE /social/accounts/:id with well-formed token (no DB) → 401 or 500", async () => {
    const token = generateToken();
    const res = await app.inject({
      method: "DELETE",
      url: "/social/accounts/00000000-0000-0000-0000-000000000001",
      headers: { authorization: `Bearer ${token}` },
    });
    assert.ok([401, 500].includes(res.statusCode));
  });

  // POST /social/accounts/link
  it("POST /social/accounts/link without auth → 401", async () => {
    const res = await app.inject({
      method: "POST", url: "/social/accounts/link",
      payload: { profileId: "00000000-0000-0000-0000-000000000001", platform: "tiktok", providerAccountId: "tt-123" },
    });
    assert.equal(res.statusCode, 401);
  });

  it("POST /social/accounts/link with invalid platform → 400", async () => {
    const token = generateToken();
    const res = await app.inject({
      method: "POST", url: "/social/accounts/link",
      headers: { authorization: `Bearer ${token}` },
      payload: { profileId: "00000000-0000-0000-0000-000000000001", platform: "snapchat", providerAccountId: "sn-123" },
    });
    // 400 (schema validation) before auth check in some Fastify versions, or 401
    assert.ok([400, 401].includes(res.statusCode));
  });

  it("POST /social/accounts/link missing providerAccountId → 400", async () => {
    const token = generateToken();
    const res = await app.inject({
      method: "POST", url: "/social/accounts/link",
      headers: { authorization: `Bearer ${token}` },
      payload: { profileId: "00000000-0000-0000-0000-000000000001", platform: "tiktok" },
    });
    assert.ok([400, 401].includes(res.statusCode));
  });

  it("POST /social/accounts/link route exists", async () => {
    const res = await app.inject({ method: "POST", url: "/social/accounts/link" });
    assert.notEqual(res.statusCode, 404);
  });

  // Response never leaks provider tokens
  it("Error responses from social routes contain no token values", async () => {
    const token = generateToken();
    const res = await app.inject({
      method: "GET",
      url: "/social/accounts?profileId=00000000-0000-0000-0000-000000000001",
      headers: { authorization: `Bearer ${token}` },
    });
    assert.ok(!res.body.includes(token), "Token must not appear in response body");
  });

  // OpenAPI
  it("OpenAPI document includes all three social routes", async () => {
    const doc = app.swagger() as { paths: Record<string, unknown> };
    assert.ok(doc.paths?.["/social/accounts"],        "/social/accounts missing");
    assert.ok(doc.paths?.["/social/accounts/{id}"],   "/social/accounts/:id missing");
    assert.ok(doc.paths?.["/social/accounts/link"],   "/social/accounts/link missing");
  });

  // Existing routes unaffected
  it("GET /health still 200 after social routes registered", async () => {
    const res = await app.inject({ method: "GET", url: "/health" });
    assert.equal(res.statusCode, 200);
    assert.equal(res.json<{ status: string }>().status, "ok");
  });
});

// ─── D: Security properties ───────────────────────────────────────────────────

describe("D: Security properties", () => {
  it("ProviderIdentity struct has no access token field", () => {
    const id: ProviderIdentity = {
      platform: "tiktok",
      providerAccountId: "tt-456",
    };
    const keys = Object.keys(id);
    assert.ok(!keys.includes("accessToken"),  "accessToken must not be in ProviderIdentity");
    assert.ok(!keys.includes("refreshToken"), "refreshToken must not be in ProviderIdentity");
    assert.ok(!keys.includes("clientSecret"), "clientSecret must not be in ProviderIdentity");
  });

  it("StubSocialProvider exchangeCode result has no token fields", async () => {
    const stub = new StubSocialProvider({
      platform: "instagram",
      providerAccountId: "ig-789",
    });
    const result = await stub.exchangeCode("code", "redirect") as Record<string, unknown>;
    assert.ok(!("accessToken"  in result));
    assert.ok(!("refreshToken" in result));
  });

  it("CONFLICT error for cross-profile claim does not reveal real profile ID", () => {
    const e = AppError.conflict("This tiktok account is already linked to another profile");
    assert.ok(!e.message.includes("profile-id-of-real-owner"),
      "Real profile ID must not be in error message");
  });

  it("TikTok and Instagram are the only supported platforms", () => {
    assert.deepEqual([...CREATOR_PLATFORMS].sort(), ["instagram", "tiktok"]);
    assert.equal(CREATOR_PLATFORMS.length, 2);
  });

  it("Social route 401 response body contains no auth header value", async () => {
    // Verified already in suite C, but explicit security assertion here
    const token = generateToken();
    const cfg = loadConfig({
      NODE_ENV: "test", PORT: "3005",
      DATABASE_URL: "postgresql://localhost:5432/test",
      JWT_SECRET: "test-secret-minimum-32-chars-long!!",
      APPLE_CLIENT_ID: "com.vyro.test",
      GCS_BUCKET_NAME: "vyro-test",
    });
    const app2 = await createApp(cfg);
    try {
      const res = await app2.inject({
        method: "GET", url: "/social/accounts?profileId=00000000-0000-0000-0000-000000000001",
        headers: { authorization: `Bearer ${token}` },
      });
      assert.ok(!res.body.includes(token));
    } finally {
      await app2.close();
    }
  });

  it("disconnected accounts have disconnectedAt set (inactive check)", () => {
    // Structural check: SocialAccountRow shape includes disconnectedAt
    // This is validated by TypeScript at compile time; runtime check here:
    const mockAccount = {
      id: "acc-1", creatorProfileId: "prof-1", platform: "tiktok" as const,
      providerAccountId: "tt-xyz", displayName: null, username: null,
      connectedAt: new Date(), disconnectedAt: new Date(),
    };
    assert.ok(mockAccount.disconnectedAt instanceof Date, "disconnectedAt must be a Date");
    assert.ok(mockAccount.disconnectedAt <= new Date(), "disconnectedAt should be in the past");
  });
});
