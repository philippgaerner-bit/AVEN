/**
 * Phase 6.3 — Billing Provider Integration Boundary Tests
 *
 *   A  Config — billing provider fields
 *   B  BillingProvider interface + stubs
 *   C  RevenueCat adapter (no network)
 *   D  createBillingProvider factory
 *   E  Webhook route (Fastify inject)
 *   F  Security
 */

import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";
import { createHmac } from "node:crypto";

import { loadConfig } from "../config/index.js";
import {
  StubBillingProvider, RevenueCatBillingProvider, createBillingProvider,
} from "../modules/billing/billing-provider.js";
import { DEFAULT_PRODUCT_MAP } from "../modules/billing/products.js";
import type { NormalisedSubscriptionEvent } from "../modules/billing/subscription-provider.js";
import { createApp } from "../app.js";
import { generateToken } from "../modules/auth/token.js";
import type { FastifyInstance } from "fastify";

// ─── Helpers ──────────────────────────────────────────────────────────────────

function baseEnv(): Record<string, string> {
  return {
    NODE_ENV: "test", PORT: "3040",
    DATABASE_URL: "postgresql://localhost/t",
    JWT_SECRET: "secret-32-chars-minimum-length!!",
    APPLE_CLIENT_ID: "x", GCS_BUCKET_NAME: "x",
  };
}

function makeEvent(overrides: Partial<NormalisedSubscriptionEvent> = {}): NormalisedSubscriptionEvent {
  return {
    eventType:              "activated",
    provider:               "stub",
    providerCustomerId:     "user:test-user-1",
    providerSubscriptionId: "sub-abc",
    productId:              "pro",
    plan:                   "PRO",
    currentPeriodEnd:       new Date(Date.now() + 30 * 86400000),
    providerEventId:        `evt-${Math.random().toString(36).slice(2)}`,
    occurredAt:             new Date(),
    ...overrides,
  };
}

const FAKE_SECRET = "test-webhook-secret-abc";

function hmacSig(body: string, secret: string): string {
  return createHmac("sha256", secret).update(body, "utf8").digest("hex");
}

// ─── A: Config ────────────────────────────────────────────────────────────────

describe("A: Billing config", () => {
  it("billingProvider defaults to 'stub' in test", () => {
    assert.equal(loadConfig(baseEnv()).billingProvider, "stub");
  });

  it("billingWebhookSecret defaults to null when not set", () => {
    assert.equal(loadConfig(baseEnv()).billingWebhookSecret, null);
  });

  it("BILLING_PROVIDER env var is picked up", () => {
    const cfg = loadConfig({ ...baseEnv(), BILLING_PROVIDER: "disabled" });
    assert.equal(cfg.billingProvider, "disabled");
  });

  it("BILLING_WEBHOOK_SECRET env var is picked up", () => {
    const cfg = loadConfig({ ...baseEnv(), BILLING_WEBHOOK_SECRET: "my-secret" });
    assert.equal(cfg.billingWebhookSecret, "my-secret");
  });

  it("billingWebhookSecret is never in config JSON as a nested sub-field of another secret", () => {
    const cfg = loadConfig({ ...baseEnv(), BILLING_WEBHOOK_SECRET: "super-secret" });
    // The value is in config, but the *key* is clearly named
    assert.equal(cfg.billingWebhookSecret, "super-secret");
    // Verify it doesn't bleed into other fields
    assert.ok(!String(cfg.jwtSecret).includes("super-secret"));
  });
});

// ─── B: BillingProvider interface + stubs ─────────────────────────────────────

describe("B: StubBillingProvider", () => {
  it("Signature valid when header present", async () => {
    const p = new StubBillingProvider();
    assert.equal(await p.verifyWebhookSignature("body", { "x-stub-signature": "valid" }), true);
  });

  it("Signature invalid when header missing", async () => {
    const p = new StubBillingProvider();
    assert.equal(await p.verifyWebhookSignature("body", {}), false);
  });

  it("Signature can be forced via options", async () => {
    const valid   = new StubBillingProvider({ signatureValid: true });
    const invalid = new StubBillingProvider({ signatureValid: false });
    assert.equal(await valid.verifyWebhookSignature("b", {}),   true);
    assert.equal(await invalid.verifyWebhookSignature("b", {}), false);
  });

  it("parseSubscriptionEvent returns configured event", async () => {
    const event = makeEvent();
    const p = new StubBillingProvider({ signatureValid: true, event });
    const r = await p.parseSubscriptionEvent("body", DEFAULT_PRODUCT_MAP);
    assert.deepEqual(r, event);
  });

  it("parseSubscriptionEvent returns null when not configured", async () => {
    const p = new StubBillingProvider({ signatureValid: true, event: null });
    const r = await p.parseSubscriptionEvent("body", DEFAULT_PRODUCT_MAP);
    assert.equal(r, null);
  });

  it("NormalisedSubscriptionEvent has no secret fields", () => {
    const e = makeEvent();
    const keys = Object.keys(e);
    assert.ok(!keys.includes("secret"));
    assert.ok(!keys.includes("apiKey"));
    assert.ok(!keys.includes("webhookSecret"));
  });
});

// ─── C: RevenueCat adapter ────────────────────────────────────────────────────

describe("C: RevenueCatBillingProvider", () => {
  const rc = new RevenueCatBillingProvider(FAKE_SECRET);

  it("Instantiates with a valid secret", () => {
    assert.equal(rc.providerName, "revenuecat");
  });

  it("Throws on empty secret", () => {
    assert.throws(() => new RevenueCatBillingProvider(""));
  });

  it("Throws on too-short secret", () => {
    assert.throws(() => new RevenueCatBillingProvider("short"));
  });

  it("Verifies valid HMAC-SHA256 signature", async () => {
    const body = '{"event":{"type":"INITIAL_PURCHASE"}}';
    const sig  = hmacSig(body, FAKE_SECRET);
    const valid = await rc.verifyWebhookSignature(
      Buffer.from(body), { "x-revenuecat-signature": sig },
    );
    assert.equal(valid, true);
  });

  it("Rejects invalid signature", async () => {
    const body = "some-body";
    const valid = await rc.verifyWebhookSignature(
      Buffer.from(body), { "x-revenuecat-signature": "deadbeef" },
    );
    assert.equal(valid, false);
  });

  it("Rejects missing signature header", async () => {
    assert.equal(await rc.verifyWebhookSignature(Buffer.from("body"), {}), false);
  });

  it("Uses constant-time comparison (does not throw on wrong-length hex)", async () => {
    const result = await rc.verifyWebhookSignature(Buffer.from("x"), { "x-revenuecat-signature": "nothex!!" });
    assert.equal(result, false);
  });

  it("parseSubscriptionEvent returns null (not yet configured)", async () => {
    const r = await rc.parseSubscriptionEvent(Buffer.from("{}"), DEFAULT_PRODUCT_MAP);
    assert.equal(r, null);
  });

  it("Secret never appears in parsed event output", async () => {
    const r = await rc.parseSubscriptionEvent(Buffer.from('{"secret":"' + FAKE_SECRET + '"}'), DEFAULT_PRODUCT_MAP);
    // Returns null, so definitely doesn't contain secret
    assert.equal(r, null);
  });
});

// ─── D: createBillingProvider factory ────────────────────────────────────────

describe("D: createBillingProvider factory", () => {
  it("'stub' → StubBillingProvider", () => {
    const p = createBillingProvider("stub", null);
    assert.equal(p.providerName, "stub");
  });

  it("'disabled' → StubBillingProvider (always rejects signature)", async () => {
    const p = createBillingProvider("disabled", null);
    assert.equal(await p.verifyWebhookSignature("body", { "x-stub-signature": "valid" }), false);
  });

  it("'revenuecat' with secret → RevenueCatBillingProvider", () => {
    const p = createBillingProvider("revenuecat", "a-valid-long-secret!!");
    assert.equal(p.providerName, "revenuecat");
  });

  it("'revenuecat' without secret → throws", () => {
    assert.throws(() => createBillingProvider("revenuecat", null));
  });

  it("Unknown provider → throws with provider name in message", () => {
    try {
      createBillingProvider("unknown-vendor", null);
      assert.fail("Should throw");
    } catch (e) {
      assert.ok((e as Error).message.includes("unknown-vendor"));
    }
  });
});

// ─── E: Webhook route (Fastify inject) ───────────────────────────────────────

describe("E: POST /billing/webhook", () => {
  let app: FastifyInstance;

  const cfg = loadConfig({ ...baseEnv(), PORT: "3041" });

  before(async () => { app = await createApp(cfg); });
  after(async () => { await app.close(); });

  it("POST /billing/webhook route exists (not 404)", async () => {
    const res = await app.inject({ method: "POST", url: "/billing/webhook", payload: {} });
    assert.notEqual(res.statusCode, 404);
  });

  it("Valid stub signature → 200 (no event, just acknowledged)", async () => {
    const res = await app.inject({
      method: "POST", url: "/billing/webhook",
      headers: { "x-stub-signature": "valid", "content-type": "application/json" },
      payload: {},
    });
    assert.equal(res.statusCode, 200);
    assert.equal(res.json<{ received: boolean }>().received, true);
  });

  it("Invalid signature → 401", async () => {
    const res = await app.inject({
      method: "POST", url: "/billing/webhook",
      headers: { "x-stub-signature": "wrong", "content-type": "application/json" },
      payload: {},
    });
    assert.equal(res.statusCode, 401);
  });

  it("Missing signature header → 401", async () => {
    const res = await app.inject({
      method: "POST", url: "/billing/webhook",
      headers: { "content-type": "application/json" },
      payload: {},
    });
    assert.equal(res.statusCode, 401);
  });

  it("401 response body does not reveal signature details", async () => {
    const res = await app.inject({
      method: "POST", url: "/billing/webhook",
      headers: { "x-stub-signature": "bad" },
      payload: {},
    });
    assert.ok(!res.body.includes("HMAC"));
    assert.ok(!res.body.includes("secret"));
    assert.ok(!res.body.includes("signature algorithm"));
  });

  it("OpenAPI includes /billing/webhook and /billing/status", async () => {
    const doc = app.swagger() as { paths: Record<string, unknown> };
    assert.ok(doc.paths?.["/billing/webhook"] !== undefined, "/billing/webhook missing");
    assert.ok(doc.paths?.["/billing/status"]  !== undefined, "/billing/status missing");
  });

  it("GET /billing/status still returns 401 without auth", async () => {
    const res = await app.inject({ method: "GET", url: "/billing/status" });
    assert.equal(res.statusCode, 401);
  });
});

// ─── F: Security ──────────────────────────────────────────────────────────────

describe("F: Security", () => {
  it("RevenueCat signature verification is constant-time (timingSafeEqual)", async () => {
    // Verified by code: uses timingSafeEqual internally
    const rc = new RevenueCatBillingProvider(FAKE_SECRET);
    // Attacker trying a similar-but-wrong signature
    const body = "payload";
    const correctSig = hmacSig(body, FAKE_SECRET);
    const almostSig  = correctSig.slice(0, -2) + "ff";
    assert.equal(await rc.verifyWebhookSignature(Buffer.from(body), { "x-revenuecat-signature": almostSig }), false);
  });

  it("StubBillingProvider never leaks secret in event output", async () => {
    const p = new StubBillingProvider({ signatureValid: true, event: makeEvent() });
    const r = await p.parseSubscriptionEvent("secret=mysecret", DEFAULT_PRODUCT_MAP);
    assert.ok(r !== null);
    const json = JSON.stringify(r);
    assert.ok(!json.includes("mysecret"));
  });

  it("'disabled' provider rejects all signatures regardless of header", async () => {
    const p = createBillingProvider("disabled", null);
    assert.equal(await p.verifyWebhookSignature("body", { "x-stub-signature": "valid" }), false);
    assert.equal(await p.verifyWebhookSignature("body", { "x-revenuecat-signature": "any" }), false);
  });

  it("Client cannot spoof plan via webhook without valid signature", async () => {
    const cfg = loadConfig(baseEnv());
    const app2 = await createApp(cfg);
    try {
      const res = await app2.inject({
        method: "POST", url: "/billing/webhook",
        headers: { "content-type": "application/json" },
        payload: { plan: "PRO_PLUS", userId: "attacker" },
      });
      assert.equal(res.statusCode, 401);
    } finally {
      await app2.close();
    }
  });

  it("createBillingProvider config is validated at startup (unsupported throws)", () => {
    assert.throws(() => createBillingProvider("evil-vendor", null));
  });

  it("RevenueCat constructor validates secret strength", () => {
    assert.throws(() => new RevenueCatBillingProvider("weak"));
    assert.doesNotThrow(() => new RevenueCatBillingProvider("a-sufficiently-long-secret!"));
  });
});
