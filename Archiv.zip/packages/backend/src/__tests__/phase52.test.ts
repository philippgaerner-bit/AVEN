/**
 * Phase 5.2 — AI Recommendation Layer Tests
 *
 *   A  Provider abstraction and stub
 *   B  Structured output validation
 *   C  Generation service (success paths)
 *   D  Fallback on provider error
 *   E  Fallback on malformed output
 *   F  Deterministic core protection
 *   G  Prompt versioning
 */

import { describe, it } from "node:test";
import assert from "node:assert/strict";

import {
  PROMPT_VERSIONS,
  isGenerationFailure,
  validateFindingExplanation,
  validateActionSuggestion,
  validateBioOptions,
  validateHookOptions,
  validateCaptionOptions,
  validateContentIdeas,
} from "../modules/growth/ai-types.js";

import {
  StubRecommendationProvider,
  buildExplainFindingPrompt,
  buildActionSuggestionPrompt,
  buildBioGenerationPrompt,
  buildHookGenerationPrompt,
  buildCaptionGenerationPrompt,
  buildContentIdeasPrompt,
} from "../modules/growth/ai-provider.js";

import { GenerationService } from "../modules/growth/generation-service.js";

import {
  calculateScore, buildFindings, SCORING_MODEL_VERSION, ALL_CRITERION_IDS,
} from "@vyro/shared/scoring";
import type { ObservationPackage, Finding } from "@vyro/shared/scoring";
import { buildGrowthActions } from "../modules/growth/actions.js";

// ─── Helpers ──────────────────────────────────────────────────────────────────

const CREATOR = { platform: "tiktok" as const, niche: "fitness" };
const PROFILE  = "profile-test";

function allMissingPkg(): ObservationPackage {
  return {
    observations: ALL_CRITERION_IDS.map((id) => ({ id, state: "missing" as const, source: "A" as const })),
    modelVersions: { ocr: "v1" }, pipelineVersion: "v1.0.0",
    scoringModelVersion: SCORING_MODEL_VERSION,
  };
}

const pkg      = allMissingPkg();
const sr       = calculateScore(pkg);
const findings = buildFindings(pkg, sr);
const actions  = buildGrowthActions(findings, PROFILE);

const sampleFinding  = findings[0]!;
const sampleAction   = actions[0]!;
const sampleObs      = sampleFinding.criterionIds.map((id) => ({ criterionId: id, state: "missing" as const }));

function makeService(opts: { fail?: boolean; malformed?: boolean } = {}): GenerationService {
  return new GenerationService(new StubRecommendationProvider(opts));
}

// ─── A: Provider abstraction ─────────────────────────────────────────────────

describe("A: Provider abstraction", () => {
  it("StubRecommendationProvider implements all 6 methods", () => {
    const p = new StubRecommendationProvider();
    assert.equal(typeof p.explainFinding,          "function");
    assert.equal(typeof p.generateActionSuggestion,"function");
    assert.equal(typeof p.generateBioOptions,      "function");
    assert.equal(typeof p.generateHookOptions,     "function");
    assert.equal(typeof p.generateCaptionOptions,  "function");
    assert.equal(typeof p.generateContentIdeas,    "function");
  });

  it("providerName is set", () => {
    assert.equal(new StubRecommendationProvider().providerName, "stub");
  });

  it("Stub returns object (not string) by default", async () => {
    const p = new StubRecommendationProvider();
    const r = await p.explainFinding({
      promptVersion: PROMPT_VERSIONS.EXPLAIN_FINDING,
      creator: CREATOR,
      finding: { templateId: sampleFinding.templateId, title: sampleFinding.title, severity: sampleFinding.severity, observations: sampleObs },
    });
    assert.equal(typeof r, "object");
  });

  it("Stub fail mode throws", async () => {
    const p = new StubRecommendationProvider({ fail: true });
    await assert.rejects(() => p.explainFinding({
      promptVersion: PROMPT_VERSIONS.EXPLAIN_FINDING,
      creator: CREATOR,
      finding: { templateId: "x", title: "x", severity: "lever", observations: [] },
    }));
  });
});

// ─── B: Structured output validation ─────────────────────────────────────────

describe("B: Structured output validation", () => {
  it("validateFindingExplanation: valid object passes", () => {
    assert.equal(validateFindingExplanation({
      promptVersion: "explain-finding-v1",
      headline: "Test", explanation: "Exp", whyItMatters: "Why", recommendation: "Rec",
    }), true);
  });

  it("validateFindingExplanation: missing field fails", () => {
    assert.equal(validateFindingExplanation({ headline: "h", explanation: "e", whyItMatters: "w" }), false);
  });

  it("validateFindingExplanation: empty string field fails", () => {
    assert.equal(validateFindingExplanation({
      promptVersion: "v", headline: "", explanation: "e", whyItMatters: "w", recommendation: "r",
    }), false);
  });

  it("validateActionSuggestion: valid passes", () => {
    assert.equal(validateActionSuggestion({
      promptVersion: "action-suggestion-v1",
      title: "Do this", steps: ["Step 1", "Step 2"], expectedOutcomeText: "Better results",
    }), true);
  });

  it("validateActionSuggestion: empty steps array fails", () => {
    assert.equal(validateActionSuggestion({
      promptVersion: "v", title: "t", steps: [], expectedOutcomeText: "x",
    }), false);
  });

  it("validateActionSuggestion: non-string step fails", () => {
    assert.equal(validateActionSuggestion({
      promptVersion: "v", title: "t", steps: [1, 2], expectedOutcomeText: "x",
    }), false);
  });

  it("validateBioOptions: exactly 3 options passes", () => {
    assert.equal(validateBioOptions({
      promptVersion: "v", options: ["a", "b", "c"],
    }), true);
  });

  it("validateBioOptions: 2 options fails", () => {
    assert.equal(validateBioOptions({ promptVersion: "v", options: ["a", "b"] }), false);
  });

  it("validateBioOptions: 4 options fails", () => {
    assert.equal(validateBioOptions({ promptVersion: "v", options: ["a","b","c","d"] }), false);
  });

  it("validateHookOptions: exactly 5 options passes", () => {
    assert.equal(validateHookOptions({
      promptVersion: "v", options: ["a","b","c","d","e"],
    }), true);
  });

  it("validateHookOptions: 4 options fails", () => {
    assert.equal(validateHookOptions({ promptVersion: "v", options: ["a","b","c","d"] }), false);
  });

  it("validateCaptionOptions: exactly 3 passes", () => {
    assert.equal(validateCaptionOptions({ promptVersion: "v", options: ["a","b","c"] }), true);
  });

  it("validateContentIdeas: exactly 5 passes", () => {
    assert.equal(validateContentIdeas({ promptVersion: "v", ideas: ["a","b","c","d","e"] }), true);
  });

  it("validateContentIdeas: 4 ideas fails", () => {
    assert.equal(validateContentIdeas({ promptVersion: "v", ideas: ["a","b","c","d"] }), false);
  });

  it("null → all validators return false", () => {
    for (const v of [validateFindingExplanation, validateActionSuggestion, validateBioOptions,
                     validateHookOptions, validateCaptionOptions, validateContentIdeas]) {
      assert.equal(v(null), false);
      assert.equal(v(undefined), false);
      assert.equal(v("string"), false);
      assert.equal(v(42), false);
    }
  });
});

// ─── C: Generation service — success ────────────────────────────────────────

describe("C: Generation service — success paths", () => {
  const svc = makeService();

  it("explainFinding returns FindingExplanation", async () => {
    const r = await svc.explainFinding(CREATOR, sampleFinding, sampleObs);
    assert.equal(isGenerationFailure(r), false);
    if (!isGenerationFailure(r)) {
      assert.ok(r.headline.length > 0);
      assert.ok(r.explanation.length > 0);
      assert.ok(r.whyItMatters.length > 0);
      assert.ok(r.recommendation.length > 0);
      assert.equal(r.promptVersion, PROMPT_VERSIONS.EXPLAIN_FINDING);
    }
  });

  it("generateActionSuggestion returns ActionSuggestion", async () => {
    const finding = findings.find((f) => f.templateId === sampleAction.sourceFindingId)!;
    const r = await svc.generateActionSuggestion(CREATOR, sampleAction, finding);
    assert.equal(isGenerationFailure(r), false);
    if (!isGenerationFailure(r)) {
      assert.ok(r.title.length > 0);
      assert.ok(r.steps.length > 0);
      assert.ok(r.expectedOutcomeText.length > 0);
      assert.equal(r.promptVersion, PROMPT_VERSIONS.ACTION_SUGGESTION);
    }
  });

  it("generateBioOptions returns exactly 3 options", async () => {
    const r = await svc.generateBioOptions(CREATOR, sampleObs);
    assert.equal(isGenerationFailure(r), false);
    if (!isGenerationFailure(r)) {
      assert.equal(r.options.length, 3);
      assert.equal(r.promptVersion, PROMPT_VERSIONS.BIO_GENERATION);
    }
  });

  it("generateHookOptions returns exactly 5 options", async () => {
    const r = await svc.generateHookOptions(CREATOR, sampleObs);
    assert.equal(isGenerationFailure(r), false);
    if (!isGenerationFailure(r)) {
      assert.equal(r.options.length, 5);
    }
  });

  it("generateCaptionOptions returns exactly 3 options", async () => {
    const r = await svc.generateCaptionOptions(CREATOR, sampleObs);
    assert.equal(isGenerationFailure(r), false);
    if (!isGenerationFailure(r)) assert.equal(r.options.length, 3);
  });

  it("generateCaptionOptions with topicHint works", async () => {
    const r = await svc.generateCaptionOptions(CREATOR, sampleObs, "morning routines");
    assert.equal(isGenerationFailure(r), false);
  });

  it("generateContentIdeas returns exactly 5 ideas", async () => {
    const r = await svc.generateContentIdeas(CREATOR, sampleObs);
    assert.equal(isGenerationFailure(r), false);
    if (!isGenerationFailure(r)) assert.equal(r.ideas.length, 5);
  });

  it("deterministicCoreIntact not present on success result", async () => {
    const r = await svc.explainFinding(CREATOR, sampleFinding, sampleObs);
    assert.ok(!("deterministicCoreIntact" in (r as object)));
  });
});

// ─── D: Fallback on provider error ───────────────────────────────────────────

describe("D: Fallback on provider error", () => {
  const failSvc = makeService({ fail: true });

  it("explainFinding → GenerationFailure on provider error", async () => {
    const r = await failSvc.explainFinding(CREATOR, sampleFinding, sampleObs);
    assert.equal(isGenerationFailure(r), true);
    if (isGenerationFailure(r)) {
      assert.equal(r.failed, true);
      assert.equal(r.reason, "provider_error");
      assert.equal(r.deterministicCoreIntact, true);
    }
  });

  it("generateBioOptions → GenerationFailure on provider error", async () => {
    const r = await failSvc.generateBioOptions(CREATOR, sampleObs);
    assert.equal(isGenerationFailure(r), true);
  });

  it("generateHookOptions → GenerationFailure on provider error", async () => {
    const r = await failSvc.generateHookOptions(CREATOR, sampleObs);
    assert.equal(isGenerationFailure(r), true);
  });

  it("generateCaptionOptions → GenerationFailure on provider error", async () => {
    const r = await failSvc.generateCaptionOptions(CREATOR, sampleObs);
    assert.equal(isGenerationFailure(r), true);
  });

  it("generateContentIdeas → GenerationFailure on provider error", async () => {
    const r = await failSvc.generateContentIdeas(CREATOR, sampleObs);
    assert.equal(isGenerationFailure(r), true);
  });

  it("generateActionSuggestion → GenerationFailure on provider error", async () => {
    const f = findings[0]!;
    const r = await failSvc.generateActionSuggestion(CREATOR, sampleAction, f);
    assert.equal(isGenerationFailure(r), true);
    if (isGenerationFailure(r)) assert.equal(r.deterministicCoreIntact, true);
  });

  it("GenerationFailure.message contains useful info (not empty)", async () => {
    const r = await failSvc.explainFinding(CREATOR, sampleFinding, sampleObs);
    if (isGenerationFailure(r)) {
      assert.ok(r.message.length > 0);
    }
  });
});

// ─── E: Fallback on malformed output ─────────────────────────────────────────

describe("E: Fallback on malformed output", () => {
  const malformedSvc = makeService({ malformed: true });

  it("explainFinding: malformed response → GenerationFailure with schema_mismatch", async () => {
    const r = await malformedSvc.explainFinding(CREATOR, sampleFinding, sampleObs);
    assert.equal(isGenerationFailure(r), true);
    if (isGenerationFailure(r)) assert.equal(r.reason, "schema_mismatch");
  });

  it("generateBioOptions: malformed → GenerationFailure", async () => {
    const r = await malformedSvc.generateBioOptions(CREATOR, sampleObs);
    assert.equal(isGenerationFailure(r), true);
  });

  it("generateHookOptions: malformed → GenerationFailure", async () => {
    const r = await malformedSvc.generateHookOptions(CREATOR, sampleObs);
    assert.equal(isGenerationFailure(r), true);
  });

  it("generateCaptionOptions: malformed → GenerationFailure", async () => {
    const r = await malformedSvc.generateCaptionOptions(CREATOR, sampleObs);
    assert.equal(isGenerationFailure(r), true);
  });

  it("generateContentIdeas: malformed → GenerationFailure", async () => {
    const r = await malformedSvc.generateContentIdeas(CREATOR, sampleObs);
    assert.equal(isGenerationFailure(r), true);
  });

  it("deterministicCoreIntact = true on schema_mismatch", async () => {
    const r = await malformedSvc.explainFinding(CREATOR, sampleFinding, sampleObs);
    if (isGenerationFailure(r)) assert.equal(r.deterministicCoreIntact, true);
  });
});

// ─── F: Deterministic core protection ────────────────────────────────────────

describe("F: Deterministic core protection", () => {
  it("Generation failure does not mutate findings", async () => {
    const beforeTemplateId = sampleFinding.templateId;
    const beforeImpact     = sampleFinding.impact;
    const beforePriority   = sampleFinding.priority;

    await makeService({ fail: true }).explainFinding(CREATOR, sampleFinding, sampleObs);

    assert.equal(sampleFinding.templateId, beforeTemplateId);
    assert.equal(sampleFinding.impact,     beforeImpact);
    assert.equal(sampleFinding.priority,   beforePriority);
  });

  it("Generation failure does not mutate GrowthActions", async () => {
    const beforeType     = sampleAction.actionType;
    const beforePriority = sampleAction.priority;
    const beforeImpact   = sampleAction.expectedImpact;

    const f = findings.find((f) => f.templateId === sampleAction.sourceFindingId)!;
    await makeService({ fail: true }).generateActionSuggestion(CREATOR, sampleAction, f);

    assert.equal(sampleAction.actionType,      beforeType);
    assert.equal(sampleAction.priority,        beforePriority);
    assert.equal(sampleAction.expectedImpact,  beforeImpact);
  });

  it("Scores are unchanged after generation", async () => {
    const beforeTotal = sr.scoreSet.total;
    await makeService().explainFinding(CREATOR, sampleFinding, sampleObs);
    assert.equal(sr.scoreSet.total, beforeTotal);
  });

  it("GenerationFailure never propagates to actions list", async () => {
    // Actions are produced by deterministic buildGrowthActions — AI layer is separate
    const actionsAfter = buildGrowthActions(findings, PROFILE);
    assert.equal(actionsAfter.length, actions.length);
    for (let i = 0; i < actions.length; i++) {
      assert.equal(actionsAfter[i]!.priority,       actions[i]!.priority);
      assert.equal(actionsAfter[i]!.expectedImpact, actions[i]!.expectedImpact);
    }
  });

  it("Provider output never contains score values", async () => {
    const r = await makeService().explainFinding(CREATOR, sampleFinding, sampleObs);
    if (!isGenerationFailure(r)) {
      // Output should not contain the actual total score or category score numbers
      // (they are not passed to the provider)
      const text = JSON.stringify(r);
      assert.ok(!text.includes(`"total":${sr.scoreSet.total}`));
    }
  });

  it("isGenerationFailure correctly discriminates", () => {
    assert.equal(isGenerationFailure({ failed: true, reason: "provider_error", message: "x", deterministicCoreIntact: true }), true);
    assert.equal(isGenerationFailure({ headline: "h", explanation: "e" }), false);
    assert.equal(isGenerationFailure(null), false);
    assert.equal(isGenerationFailure("string"), false);
  });
});

// ─── G: Prompt versioning ─────────────────────────────────────────────────────

describe("G: Prompt versioning", () => {
  it("All 6 PROMPT_VERSIONS are defined and non-empty", () => {
    for (const [key, val] of Object.entries(PROMPT_VERSIONS)) {
      assert.ok(typeof val === "string" && val.length > 0, `${key} is empty`);
    }
    assert.equal(Object.keys(PROMPT_VERSIONS).length, 6);
  });

  it("PROMPT_VERSIONS contain version suffix (v1)", () => {
    for (const val of Object.values(PROMPT_VERSIONS)) {
      assert.ok(val.includes("v1"), `${val} has no version suffix`);
    }
  });

  it("Prompt builder includes safety preamble content", () => {
    const prompt = buildExplainFindingPrompt({
      promptVersion: PROMPT_VERSIONS.EXPLAIN_FINDING,
      creator: CREATOR,
      finding: { templateId: "bio_cta_missing", title: "Test", severity: "lever", observations: [] },
    });
    assert.ok(prompt.includes("Never invent"), "Safety rule missing");
    assert.ok(prompt.includes("guaranteed"), "Growth claim rule missing");
    assert.ok(prompt.includes("JSON"), "JSON instruction missing");
  });

  it("Prompt builder includes promptVersion in output schema", () => {
    const prompt = buildBioGenerationPrompt({
      promptVersion: PROMPT_VERSIONS.BIO_GENERATION,
      creator: CREATOR,
      currentBioObservations: [],
    });
    assert.ok(prompt.includes("promptVersion"), "promptVersion missing from schema");
    assert.ok(prompt.includes(PROMPT_VERSIONS.BIO_GENERATION));
  });

  it("Each prompt builder includes creator platform", () => {
    const builders = [
      buildExplainFindingPrompt({ promptVersion: PROMPT_VERSIONS.EXPLAIN_FINDING, creator: CREATOR, finding: { templateId: "x", title: "x", severity: "lever", observations: [] } }),
      buildBioGenerationPrompt({ promptVersion: PROMPT_VERSIONS.BIO_GENERATION, creator: CREATOR, currentBioObservations: [] }),
      buildHookGenerationPrompt({ promptVersion: PROMPT_VERSIONS.HOOK_GENERATION, creator: CREATOR, contentObservations: [] }),
      buildCaptionGenerationPrompt({ promptVersion: PROMPT_VERSIONS.CAPTION_GENERATION, creator: CREATOR, contentObservations: [] }),
      buildContentIdeasPrompt({ promptVersion: PROMPT_VERSIONS.CONTENT_IDEAS_GENERATION, creator: CREATOR, contentObservations: [] }),
    ];
    for (const prompt of builders) {
      assert.ok(prompt.includes("tiktok"), `Platform missing from prompt`);
    }
  });

  it("promptVersion from stub response matches request version", async () => {
    const svc = makeService();
    const r = await svc.generateBioOptions(CREATOR, sampleObs);
    if (!isGenerationFailure(r)) {
      assert.equal(r.promptVersion, PROMPT_VERSIONS.BIO_GENERATION);
    }
  });
});
