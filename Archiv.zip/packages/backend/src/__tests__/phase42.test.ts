/**
 * Phase 4.2 Tests
 *
 *   A  Identity abstraction
 *   B  User service (validation layer, no DB)
 *   C  Merge service (validation layer, no DB)
 *   D  Creator profile ownership logic
 *   E  HTTP routes (Fastify inject, NULL_DB_CONTEXT)
 *   F  Security properties
 */

import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";

import {
  anonIdentity, userIdentity,
  isAnonIdentity, isUserIdentity,
  identityLabel,
} from "../modules/auth/identity.js";

import {
  assertOwnership,
  type CreatorProfileRow,
} from "../modules/profiles/service.js";

import { AppError } from "../errors/index.js";
import { generateToken } from "../modules/auth/token.js";
import { loadConfig } from "../config/index.js";
import { createApp } from "../app.js";
import type { FastifyInstance } from "fastify";
import { softDeleteUser, attachAppleSubject, getUserByAppleSubject } from "../modules/users/service.js";
import { mergeAnonymousIntoUser } from "../modules/users/merge.js";
import { resolveIdentityFromHeader } from "../modules/users/routes.js";

// ─── A: Identity abstraction ─────────────────────────────────────────────────

describe("A: Identity abstraction", () => {
  it("anonIdentity creates anonymous identity", () => {
    const id = anonIdentity("sess-123");
    assert.equal(id.type, "anonymous");
    assert.equal(id.anonymousSessionId, "sess-123");
  });

  it("userIdentity creates user identity", () => {
    const id = userIdentity("user-456");
    assert.equal(id.type, "user");
    assert.equal(id.userId, "user-456");
  });

  it("isAnonIdentity discriminates correctly", () => {
    assert.equal(isAnonIdentity(anonIdentity("x")), true);
    assert.equal(isAnonIdentity(userIdentity("x")), false);
  });

  it("isUserIdentity discriminates correctly", () => {
    assert.equal(isUserIdentity(userIdentity("x")), true);
    assert.equal(isUserIdentity(anonIdentity("x")), false);
  });

  it("identityLabel does not contain sensitive data", () => {
    const label = identityLabel(anonIdentity("sess-abc"));
    assert.ok(label.includes("anon"));
    assert.ok(!label.includes("token"));
  });

  it("identityLabel differs for user vs anon", () => {
    const a = identityLabel(anonIdentity("same-id"));
    const u = identityLabel(userIdentity("same-id"));
    assert.notEqual(a, u);
  });
});

// ─── B: User service validation (no DB) ──────────────────────────────────────

describe("B: User service — validation (no DB)", () => {
  const nullCtx = { db: null } as never;

  it("softDeleteUser throws when DB is null", async () => {
    await assert.rejects(
      () => softDeleteUser(nullCtx, "any-id"),
      (e: unknown) => e instanceof Error,
    );
  });

  it("attachAppleSubject is importable and typed", () => {
    assert.equal(typeof attachAppleSubject, "function");
  });

  it("getUserByAppleSubject is importable and typed", () => {
    assert.equal(typeof getUserByAppleSubject, "function");
  });
});

// ─── C: Merge service validation (no DB) ─────────────────────────────────────

describe("C: Merge service — validation (no DB)", () => {
  const nullCtx = { db: null } as never;

  it("mergeAnonymousIntoUser is importable and async", () => {
    assert.equal(typeof mergeAnonymousIntoUser, "function");
    const result = mergeAnonymousIntoUser(nullCtx, "anon-id", "user-id");
    assert.ok(result instanceof Promise);
    result.catch(() => {}); // swallow expected DB error
  });
});

// ─── D: Creator profile ownership ────────────────────────────────────────────

describe("D: Creator profile ownership (assertOwnership)", () => {
  function makeProfile(overrides: Partial<CreatorProfileRow>): CreatorProfileRow {
    return {
      id: "profile-1",
      ownerType: "anonymous",
      ownerUserId: null,
      ownerAnonymousSessionId: "sess-abc",
      platform: "tiktok",
      createdAt: new Date(),
      updatedAt: new Date(),
      ...overrides,
    };
  }

  it("anon identity owns anon profile with matching session ID", () => {
    assert.doesNotThrow(() =>
      assertOwnership(makeProfile({ ownerAnonymousSessionId: "sess-abc" }), anonIdentity("sess-abc")),
    );
  });

  it("anon identity cannot access another anon's profile", () => {
    assert.throws(
      () => assertOwnership(makeProfile({ ownerAnonymousSessionId: "sess-abc" }), anonIdentity("sess-xyz")),
      (e: unknown) => e instanceof AppError && e.code === "FORBIDDEN",
    );
  });

  it("user identity owns user profile with matching user ID", () => {
    const profile = makeProfile({
      ownerType: "user",
      ownerUserId: "user-123",
      ownerAnonymousSessionId: null,
    });
    assert.doesNotThrow(() => assertOwnership(profile, userIdentity("user-123")));
  });

  it("user identity cannot access another user's profile", () => {
    const profile = makeProfile({
      ownerType: "user",
      ownerUserId: "user-123",
      ownerAnonymousSessionId: null,
    });
    assert.throws(
      () => assertOwnership(profile, userIdentity("user-999")),
      (e: unknown) => e instanceof AppError && e.code === "FORBIDDEN",
    );
  });

  it("user identity cannot access anon profile", () => {
    const anonProfile = makeProfile({ ownerAnonymousSessionId: "sess-abc" });
    assert.throws(
      () => assertOwnership(anonProfile, userIdentity("user-123")),
      (e: unknown) => e instanceof AppError && e.code === "FORBIDDEN",
    );
  });

  it("anon identity cannot access user profile", () => {
    const userProfile = makeProfile({
      ownerType: "user",
      ownerUserId: "user-123",
      ownerAnonymousSessionId: null,
    });
    assert.throws(
      () => assertOwnership(userProfile, anonIdentity("sess-abc")),
      (e: unknown) => e instanceof AppError && e.code === "FORBIDDEN",
    );
  });

  it("ownership check uses exact string equality (no partial match)", () => {
    assert.throws(
      () => assertOwnership(
        makeProfile({ ownerAnonymousSessionId: "sess-abc" }),
        anonIdentity("sess-ab"), // prefix
      ),
      (e: unknown) => e instanceof AppError && e.code === "FORBIDDEN",
    );
  });

  it("ownership check is case-sensitive", () => {
    assert.throws(
      () => assertOwnership(
        makeProfile({ ownerAnonymousSessionId: "Sess-ABC" }),
        anonIdentity("sess-abc"),
      ),
      (e: unknown) => e instanceof AppError && e.code === "FORBIDDEN",
    );
  });
});

// ─── E: HTTP routes ──────────────────────────────────────────────────────────

describe("E: HTTP routes (Fastify inject, NULL_DB_CONTEXT)", () => {
  let app: FastifyInstance;

  const cfg = loadConfig({
    NODE_ENV: "test", PORT: "3003",
    DATABASE_URL: "postgresql://localhost:5432/test",
    JWT_SECRET: "test-secret-minimum-32-chars-long!!",
    APPLE_CLIENT_ID: "com.vyro.test",
    GCS_BUCKET_NAME: "vyro-test",
  });

  before(async () => { app = await createApp(cfg); });
  after(async () => { await app.close(); });

  // POST /users
  it("POST /users exists", async () => {
    const res = await app.inject({ method: "POST", url: "/users" });
    assert.notEqual(res.statusCode, 404, "Route /users must exist");
  });

  it("POST /users returns JSON with error format on DB failure", async () => {
    const res = await app.inject({ method: "POST", url: "/users" });
    if (res.statusCode >= 400) {
      const body = res.json<{ error: { code: string } }>();
      assert.ok(body.error?.code, "Must have error.code");
    }
  });

  // GET /users/me
  it("GET /users/me without token → 401", async () => {
    const res = await app.inject({ method: "GET", url: "/users/me" });
    assert.equal(res.statusCode, 401);
    assert.equal(res.json<{ error: { code: string } }>().error.code, "UNAUTHORIZED");
  });

  it("GET /users/me with malformed token → 401", async () => {
    const res = await app.inject({
      method: "GET", url: "/users/me",
      headers: { authorization: "Bearer tooshort" },
    });
    assert.equal(res.statusCode, 401);
  });

  it("GET /users/me with well-formed but unknown token → 401", async () => {
    const token = generateToken();
    const res = await app.inject({
      method: "GET", url: "/users/me",
      headers: { authorization: `Bearer ${token}` },
    });
    // NULL_DB_CONTEXT may throw 500 on DB lookup, or 401 if validation fires first
    assert.ok(res.statusCode === 401 || res.statusCode === 500,
      `Expected 401 or 500, got ${res.statusCode}`);
  });

  // POST /auth/claim-anonymous
  it("POST /auth/claim-anonymous without auth → 401", async () => {
    const res = await app.inject({
      method: "POST", url: "/auth/claim-anonymous",
      payload: { anonymousToken: generateToken() },
    });
    assert.equal(res.statusCode, 401);
  });

  it("POST /auth/claim-anonymous with anon Bearer token → 401 (user token required)", async () => {
    // Anon tokens pass shape check but resolve to null with NULL_DB_CONTEXT
    const token = generateToken();
    const res = await app.inject({
      method: "POST", url: "/auth/claim-anonymous",
      headers: { authorization: `Bearer ${token}` },
      payload: { anonymousToken: generateToken() },
    });
    // Either 401 (auth failed) or 500 (null DB); 401 is correct
    assert.ok(res.statusCode === 401 || res.statusCode === 500);
  });

  it("POST /auth/claim-anonymous with missing body → 400 or 401", async () => {
    const token = generateToken();
    const res = await app.inject({
      method: "POST", url: "/auth/claim-anonymous",
      headers: { authorization: `Bearer ${token}` },
      payload: {},
    });
    // Missing anonymousToken → validation error (400) or auth failed (401/500)
    assert.ok([400, 401, 500].includes(res.statusCode));
  });

  it("POST /auth/claim-anonymous with malformed anonymousToken → 400 or 401", async () => {
    const token = generateToken();
    const res = await app.inject({
      method: "POST", url: "/auth/claim-anonymous",
      headers: { authorization: `Bearer ${token}` },
      payload: { anonymousToken: "bad" },
    });
    assert.ok([400, 401, 500].includes(res.statusCode));
  });

  // OpenAPI
  it("OpenAPI document includes user and claim routes", async () => {
    const doc = app.swagger() as { paths: Record<string, unknown> };
    assert.ok(doc.paths?.["/users"],                  "/users missing from OpenAPI");
    assert.ok(doc.paths?.["/users/me"],               "/users/me missing from OpenAPI");
    assert.ok(doc.paths?.["/auth/claim-anonymous"],   "/auth/claim-anonymous missing from OpenAPI");
  });

  // Existing routes still work
  it("GET /health still 200 after user routes registered", async () => {
    const res = await app.inject({ method: "GET", url: "/health" });
    assert.equal(res.statusCode, 200);
  });
});

// ─── F: Security properties ───────────────────────────────────────────────────

describe("F: Security properties", () => {
  it("AppError.FORBIDDEN is expose=true (safe client message)", () => {
    const e = AppError.forbidden("You do not own this profile");
    assert.equal(e.expose, true);
    assert.equal(e.httpStatus, 403);
    assert.equal(e.code, "FORBIDDEN");
  });

  it("AppError.CONFLICT is expose=true", () => {
    const e = AppError.conflict("Already merged");
    assert.equal(e.expose, true);
    assert.equal(e.httpStatus, 409);
  });

  it("ownership error message does not reveal target owner ID", () => {
    // assertOwnership should throw FORBIDDEN without leaking the owner's session/user ID
    const profile: CreatorProfileRow = {
      id: "p1", ownerType: "anonymous", ownerAnonymousSessionId: "secret-session-id",
      ownerUserId: null, platform: "tiktok", createdAt: new Date(), updatedAt: new Date(),
    };
    let caught: AppError | null = null;
    try { assertOwnership(profile, anonIdentity("attacker-session")); }
    catch (e) { caught = e as AppError; }
    assert.ok(caught);
    // The error message must not reveal the real owner's session ID
    assert.ok(!caught.message.includes("secret-session-id"), "Owner ID leaked in error message");
  });

  it("merge conflict error does not reveal target user ID", () => {
    // The CONFLICT AppError from mergeAnonymousIntoUser should not embed userId
    const e = AppError.conflict(
      "This anonymous session has already been merged into a different user account",
    );
    assert.ok(!e.message.includes("user-id-secret"));
  });

  it("resolveIdentityFromHeader is available", () => {
    assert.equal(typeof resolveIdentityFromHeader, "function");
  });

  it("assertOwnership uses exact ID comparison (not substring)", () => {
    const profile: CreatorProfileRow = {
      id: "p1", ownerType: "user", ownerUserId: "user-12345",
      ownerAnonymousSessionId: null, platform: "instagram",
      createdAt: new Date(), updatedAt: new Date(),
    };
    // "user-1234" is a prefix of "user-12345" — must still fail
    assert.throws(
      () => assertOwnership(profile, userIdentity("user-1234")),
      (e: unknown) => e instanceof AppError && e.code === "FORBIDDEN",
    );
  });

  it("identity type cannot be confused by forging the discriminant", () => {
    // Ensure type narrowing works — anon identity cannot be treated as user
    const id = anonIdentity("sess-xyz");
    assert.equal(id.type, "anonymous");
    // @ts-expect-error — userId not available on anon identity at compile time
    // At runtime it should be undefined
    assert.equal((id as { userId?: string }).userId, undefined);
  });
});
