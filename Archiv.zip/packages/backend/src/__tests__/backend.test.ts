/**
 * Backend-Tests — Phase 3 vollständig.
 *
 *   A  Konfiguration
 *   B  Fehlersystem
 *   C  Schema-Enums und Constraints
 *   D  Fastify HTTP-Endpoints
 *   E  Drizzle-Schema (20 Tabellen, Unique Constraints)
 */

import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";

import { loadConfig, type AppConfig, ConfigError } from "../config/index.js";
import {
  AppError, formatErrorResponse,
  ERROR_CODES, ERROR_HTTP_STATUS,
} from "../errors/index.js";
import {
  CREATOR_PLATFORMS, SCAN_STATUSES, DB_CRITERION_STATES,
  DB_OBSERVATION_SOURCES, DB_FINDING_SEVERITIES, DB_FINDING_STATUSES,
  OWNER_TYPES, GENERATED_ITEM_TYPES, SUBSCRIPTION_STATUSES,
  FEATURE_KEYS, AUDIT_EVENT_TYPES, AUDIT_ACTOR_TYPES,
  ENTITLEMENT_SOURCES, MODEL_TASK_TYPES,
} from "../db/enums.js";
import { createApp } from "../app.js";
import { ALL_CRITERION_IDS } from "@vyro/shared/scoring";
import type {
  DbUser, DbAnonymousSession, DbUserSession, DbCreatorProfile,
  DbScan, DbUploadedAsset, DbCriterionObservation, DbScoreSet,
  DbFinding, DbAction, DbDailyTask, DbGeneratedItem,
  DbLibraryEntry, DbSubscription, DbEntitlement, DbUsageCounter,
  DbIdempotencyKey, DbAuditEvent, DbModelVersion, DbPipelineVersion,
} from "../db/schema.js";
import {
  users, anonymousSessions, userSessions, creatorProfiles,
  scans, uploadedAssets, criterionObservations, scoreSets,
  findings, actions, dailyTasks, generatedItems,
  libraryEntries, subscriptions, entitlements, usageCounters,
  idempotencyKeys, auditEvents, modelVersions, pipelineVersions,
  schema,
} from "../db/drizzle-schema.js";

// ─── Helpers ─────────────────────────────────────────────────────────────────

function testEnv(): Record<string, string> {
  return {
    NODE_ENV:       "test",
    PORT:           "3001",
    DATABASE_URL:   "postgresql://localhost:5432/vyro_test",
    JWT_SECRET:     "test-secret-32-zeichen-minimum!!!!!",
    APPLE_CLIENT_ID: "com.vyro.test",
    GCS_BUCKET_NAME: "vyro-test",
  };
}

function testConfig(): AppConfig { return loadConfig(testEnv()); }

// ═══════════════════════════════════════════════════════════════════════════
//  A — Konfiguration
// ═══════════════════════════════════════════════════════════════════════════

describe("A: Konfiguration", () => {
  it("gültige Config wird geladen", () => {
    const c = testConfig();
    assert.equal(c.nodeEnv, "test");
    assert.equal(c.port, 3001);
    assert.equal(c.isTest, true);
  });
  it("fehlendes JWT_SECRET → ConfigError", () => {
    const e = testEnv(); delete e["JWT_SECRET"];
    assert.throws(() => loadConfig(e), ConfigError);
  });
  it("JWT_SECRET < 32 Zeichen → ConfigError", () => {
    assert.throws(() => loadConfig({ ...testEnv(), JWT_SECRET: "kurz" }), ConfigError);
  });
  it("fehlende DATABASE_URL → ConfigError", () => {
    const e = testEnv(); delete e["DATABASE_URL"];
    assert.throws(() => loadConfig(e), ConfigError);
  });
  it("PORT 0 → ConfigError", () => {
    assert.throws(() => loadConfig({ ...testEnv(), PORT: "0" }), ConfigError);
  });
  it("ungültiger NODE_ENV → ConfigError", () => {
    assert.throws(() => loadConfig({ ...testEnv(), NODE_ENV: "xyz" }), ConfigError);
  });
  it("alle vier gültigen NODE_ENV-Werte akzeptiert", () => {
    for (const e of ["development","test","staging","production"] as const) {
      assert.equal(loadConfig({ ...testEnv(), NODE_ENV: e }).nodeEnv, e);
    }
  });
  it("redisUrl null wenn nicht gesetzt", () => {
    const e = testEnv(); delete e["REDIS_URL"];
    assert.equal(loadConfig(e).redisUrl, null);
  });
  it("isProduction false in test", () => {
    assert.equal(testConfig().isProduction, false);
  });
});

// ═══════════════════════════════════════════════════════════════════════════
//  B — Fehlersystem
// ═══════════════════════════════════════════════════════════════════════════

describe("B: Fehlersystem", () => {
  it("alle ERROR_CODES haben HTTP-Status", () => {
    for (const code of Object.values(ERROR_CODES)) {
      const s = ERROR_HTTP_STATUS[code];
      assert.ok(s >= 100 && s < 600);
    }
  });
  it("VALIDATION_ERROR→400, UNAUTHORIZED→401, NOT_FOUND→404, RATE_LIMITED→429, INTERNAL→500", () => {
    assert.equal(ERROR_HTTP_STATUS["VALIDATION_ERROR"], 400);
    assert.equal(ERROR_HTTP_STATUS["UNAUTHORIZED"],     401);
    assert.equal(ERROR_HTTP_STATUS["NOT_FOUND"],        404);
    assert.equal(ERROR_HTTP_STATUS["RATE_LIMITED"],     429);
    assert.equal(ERROR_HTTP_STATUS["INTERNAL_ERROR"],   500);
  });
  it("AppError.validationError → expose true, 400", () => {
    const e = AppError.validationError("Feld fehlt");
    assert.equal(e.expose, true);
    assert.equal(e.httpStatus, 400);
  });
  it("AppError.internal → expose false", () => {
    assert.equal(AppError.internal("db fehler").expose, false);
  });
  it("exponierbarer Fehler → code+message im Response", () => {
    const { statusCode, body } = formatErrorResponse(AppError.notFound("Scan"));
    assert.equal(statusCode, 404);
    assert.equal(body.error.code, "NOT_FOUND");
  });
  it("interner Fehler → generische Antwort, keine Details", () => {
    const { statusCode, body } = formatErrorResponse(AppError.internal("db-ip: 10.0.0.1"));
    assert.equal(statusCode, 500);
    assert.ok(!body.error.message.includes("10.0.0.1"));
  });
  it("unbekannter Fehler → generische 500-Antwort", () => {
    const { statusCode } = formatErrorResponse(new Error("xyz"));
    assert.equal(statusCode, 500);
  });
  it("null → 500", () => {
    assert.equal(formatErrorResponse(null).statusCode, 500);
  });
});

// ═══════════════════════════════════════════════════════════════════════════
//  C — Schema-Enums
// ═══════════════════════════════════════════════════════════════════════════

describe("C: Schema-Enums", () => {
  it("CREATOR_PLATFORMS: instagram + tiktok", () => {
    assert.equal(CREATOR_PLATFORMS.length, 2);
    assert.ok((CREATOR_PLATFORMS as readonly string[]).includes("instagram"));
    assert.ok((CREATOR_PLATFORMS as readonly string[]).includes("tiktok"));
  });
  it("DB_CRITERION_STATES: fulfilled partial missing unavailable", () => {
    assert.equal(DB_CRITERION_STATES.length, 4);
  });
  it("DB_FINDING_SEVERITIES: foundation lever polish", () => {
    assert.deepEqual([...DB_FINDING_SEVERITIES].sort(), ["foundation","lever","polish"]);
  });
  it("FEATURE_KEYS enthält full_insights", () => {
    assert.ok((FEATURE_KEYS as readonly string[]).includes("full_insights"));
  });
  it("AUDIT_EVENT_TYPES enthält DSGVO-Pflicht-Events", () => {
    assert.ok((AUDIT_EVENT_TYPES as readonly string[]).includes("account_deleted"));
    assert.ok((AUDIT_EVENT_TYPES as readonly string[]).includes("data_deletion_completed"));
  });
  it("ENTITLEMENT_SOURCES enthält kein 'revenuecat'", () => {
    assert.ok(!(ENTITLEMENT_SOURCES as readonly string[]).includes("revenuecat"));
  });
  it("MODEL_TASK_TYPES enthält ocr, vision_observe, language_observe, language_generate", () => {
    for (const t of ["ocr","vision_observe","language_observe","language_generate"]) {
      assert.ok((MODEL_TASK_TYPES as readonly string[]).includes(t), `Fehlt: ${t}`);
    }
  });
  it("Enums ohne Duplikate", () => {
    for (const [name, arr] of [
      ["CREATOR_PLATFORMS", CREATOR_PLATFORMS],
      ["SCAN_STATUSES", SCAN_STATUSES],
      ["DB_CRITERION_STATES", DB_CRITERION_STATES],
      ["FEATURE_KEYS", FEATURE_KEYS],
    ] as const) {
      assert.equal(new Set(arr).size, arr.length, `Duplikat in ${name}`);
    }
  });
});

// ═══════════════════════════════════════════════════════════════════════════
//  D — Fastify HTTP-Endpoints
// ═══════════════════════════════════════════════════════════════════════════

describe("D: Fastify HTTP-Endpoints", () => {
  let app: Awaited<ReturnType<typeof createApp>>;

  before(async () => { app = await createApp(testConfig()); });
  after(async () => { await app.close(); });

  it("GET /health → 200", async () => {
    const res = await app.inject({ method: "GET", url: "/health" });
    assert.equal(res.statusCode, 200);
  });

  it("GET /health → exakter Body", async () => {
    const res = await app.inject({ method: "GET", url: "/health" });
    const body = res.json<{ status: string; service: string; version: string }>();
    assert.equal(body.status,  "ok");
    assert.equal(body.service, "vyro-api");
    assert.equal(body.version, "0.1.0");
  });

  it("GET /health → Content-Type: application/json", async () => {
    const res = await app.inject({ method: "GET", url: "/health" });
    assert.ok(res.headers["content-type"]?.includes("application/json"));
  });

  it("GET /health → KEIN nodeEnv-Feld (exakter Body)", async () => {
    const res  = await app.inject({ method: "GET", url: "/health" });
    const body = res.json<Record<string, unknown>>();
    assert.ok(!("nodeEnv" in body), "nodeEnv darf nicht im /health-Body stehen");
  });

  it("GET /unbekannt → 404 mit Fehlerformat", async () => {
    const res  = await app.inject({ method: "GET", url: "/unbekannt" });
    const body = res.json<{ error: { code: string } }>();
    assert.equal(res.statusCode, 404);
    assert.equal(body.error.code, "NOT_FOUND");
  });

  it("interner Fehler → kein Stacktrace im Body", async () => {
    const res = await app.inject({ method: "GET", url: "/_test/internal-error" });
    assert.equal(res.statusCode, 500);
    assert.ok(!res.body.includes(" at "),   "Stacktrace im Response");
    assert.ok(!res.body.includes("Error:"), "Fehlerklasse im Response");
    assert.ok(!res.body.includes("simulierter"), "Interne Details im Response");
    const body = res.json<{ error: { code: string } }>();
    assert.equal(body.error.code, "INTERNAL_ERROR");
  });

  it("AppError → code + message exponiert", async () => {
    const res  = await app.inject({ method: "GET", url: "/_test/app-error" });
    const body = res.json<{ error: { code: string; message: string } }>();
    assert.equal(res.statusCode, 404);
    assert.equal(body.error.code, "NOT_FOUND");
    assert.ok(body.error.message.length > 0);
  });

  it("OpenAPI-Dokument enthält /health", async () => {
    const res = await app.inject({ method: "GET", url: "/documentation/json" });
    if (res.statusCode === 404) {
      // Kein UI-Plugin → Dokument über API abrufen
      const doc = app.swagger();
      assert.ok(doc.paths?.["/health"] !== undefined, "/health fehlt in OpenAPI");
    } else {
      const doc = res.json<{ paths: Record<string, unknown> }>();
      assert.ok(doc.paths?.["/health"] !== undefined, "/health fehlt in OpenAPI");
    }
  });

  it("OpenAPI-Dokument ist programmatisch erzeugbar", async () => {
    const doc = app.swagger();
    assert.ok(typeof doc === "object");
    assert.equal((doc as { openapi: string }).openapi, "3.1.0");
    assert.ok((doc as { info: { title: string } }).info.title.length > 0);
  });
});

// ═══════════════════════════════════════════════════════════════════════════
//  E — Drizzle-Schema (20 Tabellen, Constraints)
// ═══════════════════════════════════════════════════════════════════════════

describe("E: Drizzle-Schema", () => {
  it("exakt 21 Tabellen im Schema-Export", () => {
    assert.equal(Object.keys(schema).length, 21);
  });

  it("alle 21 erwarteten Tabellennamen vorhanden", () => {
    const expected = [
      "users","anonymousSessions","userSessions","creatorProfiles",
      "scans","uploadedAssets","criterionObservations","scoreSets",
      "findings","actions","dailyTasks","generatedItems",
      "libraryEntries","subscriptions","entitlements","usageCounters",
      "idempotencyKeys","auditEvents","modelVersions","pipelineVersions",
      "socialAccounts",
    ];
    for (const name of expected) {
      assert.ok(name in schema, `Tabelle fehlt: ${name}`);
    }
  });

  // ── Column-level introspection using Drizzle's direct property access ──────
  // Drizzle 0.45 exposes column metadata as plain properties (not via symbols).
  // JSON.stringify(table) throws due to circular refs — use col["prop"] instead.

  function col(c: { notNull?: boolean; columnType?: string; primary?: boolean; name?: string }): typeof c {
    return c;
  }

  it("UNIQUE(scanId, criterionId) in criterion_observations — index name in ExtraConfig", () => {
    // Unique index is declared via uniqueIndex(...).on(t.scanId, t.criterionId).
    // Verify the columns that form the constraint exist and have correct SQL names.
    assert.equal(criterionObservations.scanId["name"], "scan_id");
    assert.equal(criterionObservations.criterionId["name"], "criterion_id");
    // ExtraConfigBuilder symbol confirms the uniqueIndex was wired up
    const syms = Object.getOwnPropertySymbols(criterionObservations);
    const hasExtraConfig = syms.some(s => String(s).includes("ExtraConfigBuilder"));
    assert.ok(hasExtraConfig, "criterion_observations has no ExtraConfigBuilder (no uniqueIndex defined)");
  });

  it("UNIQUE(scanId) in score_sets — ExtraConfigBuilder present", () => {
    assert.equal(scoreSets.scanId["name"], "scan_id");
    const syms = Object.getOwnPropertySymbols(scoreSets);
    const hasExtraConfig = syms.some(s => String(s).includes("ExtraConfigBuilder"));
    assert.ok(hasExtraConfig, "score_sets has no ExtraConfigBuilder (no uniqueIndex defined)");
  });

  it("UNIQUE(userId, featureKey) in entitlements — ExtraConfigBuilder present", () => {
    assert.equal(entitlements.userId["name"], "user_id");
    assert.equal(entitlements.featureKey["name"], "feature_key");
    const syms = Object.getOwnPropertySymbols(entitlements);
    const hasExtraConfig = syms.some(s => String(s).includes("ExtraConfigBuilder"));
    assert.ok(hasExtraConfig, "entitlements has no ExtraConfigBuilder (no uniqueIndex defined)");
  });

  it("UNIQUE(ownerType, ownerId, featureKey, periodKey) in usage_counters — ExtraConfigBuilder present", () => {
    assert.equal(usageCounters.ownerType["name"], "owner_type");
    assert.equal(usageCounters.ownerId["name"],   "owner_id");
    assert.equal(usageCounters.featureKey["name"],"feature_key");
    assert.equal(usageCounters.periodKey["name"], "period_key");
    const syms = Object.getOwnPropertySymbols(usageCounters);
    const hasExtraConfig = syms.some(s => String(s).includes("ExtraConfigBuilder"));
    assert.ok(hasExtraConfig, "usage_counters has no ExtraConfigBuilder (no uniqueIndex defined)");
  });

  it("UNIQUE(ownerKey, idempotencyKey) in idempotency_keys — ExtraConfigBuilder present", () => {
    assert.equal(idempotencyKeys.ownerKey["name"],       "owner_key");
    assert.equal(idempotencyKeys.idempotencyKey["name"], "idempotency_key");
    const syms = Object.getOwnPropertySymbols(idempotencyKeys);
    const hasExtraConfig = syms.some(s => String(s).includes("ExtraConfigBuilder"));
    assert.ok(hasExtraConfig, "idempotency_keys has no ExtraConfigBuilder (no uniqueIndex defined)");
  });

  it("expiresAt in uploaded_assets ist NOT NULL", () => {
    const c = col(uploadedAssets.expiresAt);
    assert.ok(c !== undefined, "expiresAt-Spalte fehlt in uploaded_assets");
    assert.equal(c.notNull, true, "uploaded_assets.expiresAt muss NOT NULL sein");
    assert.equal(c.columnType, "PgTimestamp");
  });

  it("KEINE Punkte-Spalte in criterion_observations", () => {
    const cols = Object.keys(criterionObservations);
    assert.ok(!cols.includes("points"), "Punkte-Spalte in criterion_observations gefunden");
    assert.ok(!cols.includes("score"),  "Score-Spalte in criterion_observations gefunden");
  });

  it("criterion_observations.criterionId ist PgText (kompatibel mit 31 CriterionIds)", () => {
    assert.equal(ALL_CRITERION_IDS.length, 31);
    const c = col(criterionObservations.criterionId);
    assert.ok(c !== undefined);
    assert.equal(c.columnType, "PgText", "criterionId muss TEXT sein, nicht enum");
  });

  it("creator_profiles hat ownerUserId UND ownerAnonymousSessionId als nullable FKs", () => {
    assert.ok("ownerUserId"             in creatorProfiles, "ownerUserId fehlt");
    assert.ok("ownerAnonymousSessionId" in creatorProfiles, "ownerAnonymousSessionId fehlt");
    assert.ok("ownerType"               in creatorProfiles, "ownerType fehlt");
    // Both FK columns are nullable (notNull === false / undefined)
    assert.ok(!creatorProfiles.ownerUserId["notNull"],            "ownerUserId soll nullable sein");
    assert.ok(!creatorProfiles.ownerAnonymousSessionId["notNull"],"ownerAnonymousSessionId soll nullable sein");
  });

  it("uploaded_assets.expiresAt ist PgTimestamp with time zone", () => {
    assert.ok("expiresAt" in uploadedAssets);
    assert.equal(col(uploadedAssets.expiresAt).columnType, "PgTimestamp");
  });

  it("idempotency_keys.expiresAt ist NOT NULL", () => {
    assert.ok("expiresAt" in idempotencyKeys);
    assert.equal(col(idempotencyKeys.expiresAt).notNull, true, "idempotency_keys.expiresAt muss NOT NULL sein");
  });

  it("pipelineVersions.version ist PgText und Primary Key", () => {
    const c = col(pipelineVersions.version);
    assert.equal(c.columnType, "PgText",  "version muss TEXT sein, nicht uuid");
    assert.equal(c.primary,    true,      "version muss Primary Key sein");
  });

  it("score_sets.rawPayloadJson ist PgJsonb", () => {
    assert.equal(col(scoreSets.rawPayloadJson).columnType, "PgJsonb");
  });

  it("audit_events.metadataJson ist PgJsonb", () => {
    assert.ok("metadataJson" in auditEvents);
    assert.equal(col(auditEvents.metadataJson).columnType, "PgJsonb");
  });

  it("TypeScript-Interfaces stimmen mit Drizzle-Schema überein: DbUser", () => {
    const mock: DbUser = {
      id: "uuid", appleSubject: null, createdAt: new Date(),
      updatedAt: new Date(), deletedAt: null,
    };
    assert.equal(mock.appleSubject, null);
  });

  it("TypeScript-Interfaces: DbCriterionObservation hat kein points-Feld", () => {
    const obs: DbCriterionObservation = {
      id: "u", scanId: "s", criterionId: "bio_outcome",
      state: "fulfilled", source: "A", modelVersion: null, createdAt: new Date(),
    };
    assert.ok(!("points" in obs));
    assert.ok(!("score"  in obs));
  });

  it("Creator-Owner-Invariante: Validierungsfunktion korrekt", () => {
    function valid(p: DbCreatorProfile): boolean {
      if (p.ownerType === "user")
        return p.ownerUserId !== null && p.ownerAnonymousSessionId === null;
      if (p.ownerType === "anonymous")
        return p.ownerAnonymousSessionId !== null && p.ownerUserId === null;
      return false;
    }
    const base = { id:"u", platform:"tiktok" as const, createdAt: new Date(), updatedAt: new Date() };
    assert.equal(valid({ ...base, ownerType:"user",      ownerUserId:"id", ownerAnonymousSessionId:null }), true);
    assert.equal(valid({ ...base, ownerType:"anonymous", ownerUserId:null, ownerAnonymousSessionId:"sid" }), true);
    assert.equal(valid({ ...base, ownerType:"user",      ownerUserId:null, ownerAnonymousSessionId:null }), false);
    assert.equal(valid({ ...base, ownerType:"user",      ownerUserId:"id", ownerAnonymousSessionId:"sid" }), false);
  });
});

// Typ-Imports für Vollständigkeits-Check (TypeScript prüft alle 20)
void [
  users, anonymousSessions, userSessions, creatorProfiles,
  scans, uploadedAssets, criterionObservations, scoreSets,
  findings, actions, dailyTasks, generatedItems,
  libraryEntries, subscriptions, entitlements, usageCounters,
  idempotencyKeys, auditEvents, modelVersions, pipelineVersions,
] satisfies unknown[];
