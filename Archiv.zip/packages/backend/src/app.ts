/**
 * Fastify App Factory.
 *
 * Verantwortung:
 *   - Plugins registrieren (Swagger/OpenAPI)
 *   - Zentrales Error Handling
 *   - Routes registrieren
 *   - Testbar ohne listen()
 */

import Fastify, { type FastifyInstance } from "fastify";
import swagger from "@fastify/swagger";
import type { AppConfig } from "./config/index.js";
import { AppError, formatErrorResponse } from "./errors/index.js";
import { registerAuthRoutes } from "./modules/auth/routes.js";
import { registerUserRoutes } from "./modules/users/routes.js";
import { registerSocialRoutes } from "./modules/social/routes.js";
import { registerTikTokOAuthRoutes } from "./modules/social/tiktok-routes.js";
import { registerVideoRoutes }       from "./modules/video/video-routes.js";
import { registerScanRoutes } from "./modules/scans/routes.js";
import { registerBillingRoutes } from "./modules/billing/routes.js";
import { InMemoryAssetStorage } from "./modules/scans/storage.js";
import { InMemoryJobQueue } from "./modules/scans/queue.js";
import type { AssetStorage } from "./modules/scans/storage.js";
import type { AnalysisJobQueue } from "./modules/scans/queue.js";
import type { DbContext } from "./db/client.js";
import { NULL_DB_CONTEXT } from "./db/client.js";

// ─── App Factory ─────────────────────────────────────────────────────────────

export async function createApp(
  config: AppConfig,
  ctx: DbContext = NULL_DB_CONTEXT,
  storage: AssetStorage = new InMemoryAssetStorage(),
  queue: AnalysisJobQueue = new InMemoryJobQueue(),
): Promise<FastifyInstance> {
  const app = Fastify({
    logger: config.isDevelopment
      ? { level: "info" }
      : config.isTest
        ? false
        : { level: "warn" },
  });

  // ── OpenAPI / Swagger ────────────────────────────────────────────────────
  await app.register(swagger, {
    openapi: {
      openapi: "3.1.0",
      info: {
        title: "VYRO API",
        description: "Creator Score & Coaching API",
        version: "0.1.0",
      },
      servers: [{ url: "http://localhost:" + config.port }],
    },
  });

  // ── Zentraler Error Handler ──────────────────────────────────────────────
  app.setErrorHandler((err, _req, reply) => {
    const { statusCode, body } = formatErrorResponse(err);

    if ((err as { validation?: unknown }).validation) {
      return reply.status(400).send({
        error: { code: "VALIDATION_ERROR", message: "Ungültige Anfrageparameter." },
      });
    }

    return reply.status(statusCode).send(body);
  });

  // ── 404 Handler ──────────────────────────────────────────────────────────
  app.setNotFoundHandler((_req, reply) => {
    reply.status(404).send({
      error: { code: "NOT_FOUND", message: "Dieser Endpoint existiert nicht." },
    });
  });

  // ── Routes ───────────────────────────────────────────────────────────────
  await registerRoutes(app);
  await registerAuthRoutes(app, ctx);
  await registerUserRoutes(app, ctx);
  await registerSocialRoutes(app, ctx);
  await registerTikTokOAuthRoutes(app, ctx, config);
  await registerVideoRoutes(app, config);
  await registerScanRoutes(app, ctx, storage, queue);
  await registerBillingRoutes(app, ctx, config);
  await app.ready();
  return app;
}

// ─── Routes ──────────────────────────────────────────────────────────────────

async function registerRoutes(app: FastifyInstance): Promise<void> {
  app.get(
    "/health",
    {
      schema: {
        operationId: "getHealth",
        summary: "Health check",
        response: {
          200: {
            type: "object",
            required: ["status", "service", "version"],
            properties: {
              status: { type: "string", enum: ["ok"] },
              service: { type: "string" },
              version: { type: "string" },
            },
          },
        },
      },
    },
    async (_req, reply) => {
      return reply.status(200).send({ status: "ok", service: "vyro-api", version: "0.1.0" });
    }
  );

  // Test-Hilfsrouten – versteckt aus OpenAPI
  app.get("/_test/internal-error", { schema: { hide: true } }, async () => {
    throw AppError.internal("simulierter Fehler", new Error("db timeout"));
  });

  app.get("/_test/app-error", { schema: { hide: true } }, async () => {
    throw AppError.notFound("TestRessource");
  });
}
