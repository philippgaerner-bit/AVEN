/**
 * Datenbankverbindung — createDb() erzeugt einen typisierten Drizzle-Client.
 * Keine Verbindung beim Modulimport.
 */

import { drizzle, type PostgresJsDatabase } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import { schema } from "./drizzle-schema.js";

export type DbClient = PostgresJsDatabase<typeof schema>;

export interface DbContext {
  readonly db: DbClient;
}

/**
 * Erzeugt einen Drizzle-Client ohne sofortige Verbindung.
 * Die eigentliche TCP-Verbindung erfolgt beim ersten Query.
 */
export function createDb(databaseUrl: string): DbContext {
  const sql = postgres(databaseUrl, {
    max: 10,
    idle_timeout: 20,
    connect_timeout: 10,
    ssl: databaseUrl.includes("sslmode=require") ? "require" : false,
  });
  const db = drizzle(sql, { schema });
  return { db };
}

/** Für Unit-Tests: kein echter DB-Client */
export const NULL_DB_CONTEXT = { db: null } as unknown as DbContext;
