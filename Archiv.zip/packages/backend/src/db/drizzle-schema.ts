/**
 * Drizzle PostgreSQL Schema — exakt 20 Tabellen des V1-Datenmodells.
 *
 * Regeln:
 *   - UUID Primary Keys
 *   - timestamptz für alle Zeitstempel
 *   - JSONB für strukturierte Payloads
 *   - Keine Punkte-Spalte in criterion_observations
 *   - expiresAt NOT NULL in uploaded_assets und idempotency_keys
 */

import {
  pgTable, pgEnum, uuid, text, boolean, integer,
  timestamp, jsonb, uniqueIndex, index, numeric,
} from "drizzle-orm/pg-core";

// ─── Enums ───────────────────────────────────────────────────────────────────

export const creatorPlatformEnum = pgEnum("creator_platform", ["instagram", "tiktok"]);
export const scanStatusEnum      = pgEnum("scan_status",       ["accepted", "processing", "completed", "failed"]);
export const criterionStateEnum  = pgEnum("criterion_state",   ["fulfilled", "partial", "missing", "unavailable"]);
export const observationSrcEnum  = pgEnum("observation_source",["A", "B", "C"]);
export const findingSeverityEnum = pgEnum("finding_severity",  ["foundation", "lever", "polish"]);
export const findingStatusEnum   = pgEnum("finding_status",    ["open", "completed", "dismissed"]);
export const ownerTypeEnum       = pgEnum("owner_type",        ["user", "anonymous"]);
export const actionTypeEnum      = pgEnum("action_type",       ["fix_bio","fix_content","fix_feed","fix_branding","fix_profile_pic","fix_username","fix_engagement","rescan"]);
export const actionStatusEnum    = pgEnum("action_status",     ["pending", "completed", "dismissed"]);
export const dailyTaskStatusEnum = pgEnum("daily_task_status", ["pending", "completed", "skipped"]);
export const genItemTypeEnum     = pgEnum("generated_item_type",["bio","hook","caption","hashtags","content_idea"]);
export const subStatusEnum       = pgEnum("subscription_status",["trialing","active","past_due","canceled","expired"]);
export const subProviderEnum     = pgEnum("subscription_provider",["apple_iap","google_play","stripe"]);
export const entSourceEnum       = pgEnum("entitlement_source", ["subscription","trial","manual"]);
export const featureKeyEnum      = pgEnum("feature_key",       ["scans","bio_generation","hook_generation","caption_generation","hashtag_generation","content_idea_generation","library_entries","full_insights"]);
export const auditEventTypeEnum  = pgEnum("audit_event_type",  ["account_created","account_merged","account_deleted","session_created","session_revoked","subscription_activated","subscription_changed","entitlement_granted","entitlement_revoked","admin_viewed_user","data_export_requested","data_deletion_completed"]);
export const auditActorTypeEnum  = pgEnum("audit_actor_type",  ["user","admin","system"]);
export const modelTaskTypeEnum   = pgEnum("model_task_type",   ["ocr","vision_observe","language_observe","language_generate","transcription"]);
export const uploadContentEnum   = pgEnum("upload_content_type",["image/jpeg","image/png","image/heic","image/webp"]);

// ─── 1. users ────────────────────────────────────────────────────────────────

export const users = pgTable("users", {
  id:           uuid("id").primaryKey().defaultRandom(),
  appleSubject: text("apple_subject"),
  createdAt:    timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt:    timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  deletedAt:    timestamp("deleted_at", { withTimezone: true }),
}, (t) => [
  uniqueIndex("users_apple_subject_idx").on(t.appleSubject),
]);

// ─── 2. anonymous_sessions ───────────────────────────────────────────────────

export const anonymousSessions = pgTable("anonymous_sessions", {
  id:                  uuid("id").primaryKey().defaultRandom(),
  deviceSecretHash:    text("device_secret_hash").notNull(),
  createdAt:           timestamp("created_at",  { withTimezone: true }).notNull().defaultNow(),
  lastSeenAt:          timestamp("last_seen_at", { withTimezone: true }).notNull().defaultNow(),
  expiresAt:           timestamp("expires_at",   { withTimezone: true }).notNull(),
  mergedIntoUserId:    uuid("merged_into_user_id").references(() => users.id),
}, (t) => [
  index("anon_sessions_expires_idx").on(t.expiresAt),
]);

// ─── 3. user_sessions ────────────────────────────────────────────────────────

export const userSessions = pgTable("user_sessions", {
  id:                   uuid("id").primaryKey().defaultRandom(),
  userId:               uuid("user_id").notNull().references(() => users.id),
  refreshTokenHash:     text("refresh_token_hash").notNull(),
  tokenFamilyId:        uuid("token_family_id").notNull(),
  createdAt:            timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  expiresAt:            timestamp("expires_at",  { withTimezone: true }).notNull(),
  revokedAt:            timestamp("revoked_at",  { withTimezone: true }),
  replacedBySessionId:  uuid("replaced_by_session_id"),
}, (t) => [
  index("user_sessions_user_idx").on(t.userId),
  index("user_sessions_expires_idx").on(t.expiresAt),
]);

// ─── 4. creator_profiles ─────────────────────────────────────────────────────

export const creatorProfiles = pgTable("creator_profiles", {
  id:                       uuid("id").primaryKey().defaultRandom(),
  ownerType:                ownerTypeEnum("owner_type").notNull(),
  ownerUserId:              uuid("owner_user_id").references(() => users.id),
  ownerAnonymousSessionId:  uuid("owner_anonymous_session_id").references(() => anonymousSessions.id),
  platform:                 creatorPlatformEnum("platform").notNull(),
  createdAt:                timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt:                timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("creator_profiles_user_idx").on(t.ownerUserId),
  index("creator_profiles_anon_idx").on(t.ownerAnonymousSessionId),
]);

// ─── 5. scans ────────────────────────────────────────────────────────────────

export const scans = pgTable("scans", {
  id:                   uuid("id").primaryKey().defaultRandom(),
  creatorProfileId:     uuid("creator_profile_id").notNull().references(() => creatorProfiles.id),
  status:               scanStatusEnum("status").notNull().default("accepted"),
  platform:             creatorPlatformEnum("platform").notNull(),
  scoringModelVersion:  text("scoring_model_version"),
  pipelineVersion:      text("pipeline_version"),
  coverage:             numeric("coverage", { precision: 4, scale: 3 }),
  displayable:          boolean("displayable"),
  totalScore:           integer("total_score"),
  createdAt:            timestamp("created_at",   { withTimezone: true }).notNull().defaultNow(),
  completedAt:          timestamp("completed_at", { withTimezone: true }),
  failedAt:             timestamp("failed_at",    { withTimezone: true }),
  failureCode:          text("failure_code"),
}, (t) => [
  index("scans_profile_created_idx").on(t.creatorProfileId, t.createdAt),
]);

// ─── 6. uploaded_assets ──────────────────────────────────────────────────────

export const uploadedAssets = pgTable("uploaded_assets", {
  id:              uuid("id").primaryKey().defaultRandom(),
  scanId:          uuid("scan_id").notNull().references(() => scans.id),
  storageKey:      text("storage_key").notNull(),
  contentType:     uploadContentEnum("content_type").notNull(),
  byteSize:        integer("byte_size").notNull(),
  perceptualHash:  text("perceptual_hash"),
  createdAt:       timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  expiresAt:       timestamp("expires_at", { withTimezone: true }).notNull(),   // NOT NULL — 24h-Pflicht
  deletedAt:       timestamp("deleted_at", { withTimezone: true }),
}, (t) => [
  index("uploaded_assets_expires_idx").on(t.expiresAt),
  index("uploaded_assets_scan_idx").on(t.scanId),
]);

// ─── 7. criterion_observations ───────────────────────────────────────────────
// KEINE Punkte-Spalte — Punkte entstehen deterministisch im Bewertungskern

export const criterionObservations = pgTable("criterion_observations", {
  id:            uuid("id").primaryKey().defaultRandom(),
  scanId:        uuid("scan_id").notNull().references(() => scans.id),
  criterionId:   text("criterion_id").notNull(),
  state:         criterionStateEnum("state").notNull(),
  source:        observationSrcEnum("source").notNull(),
  modelVersion:  text("model_version"),
  createdAt:     timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  uniqueIndex("criterion_obs_unique_idx").on(t.scanId, t.criterionId),  // UNIQUE(scanId, criterionId)
]);

// ─── 8. score_sets ───────────────────────────────────────────────────────────

export const scoreSets = pgTable("score_sets", {
  id:                   uuid("id").primaryKey().defaultRandom(),
  scanId:               uuid("scan_id").notNull().references(() => scans.id),
  scoringModelVersion:  text("scoring_model_version").notNull(),
  totalScore:           integer("total_score").notNull(),
  coverage:             numeric("coverage", { precision: 4, scale: 3 }).notNull(),
  displayable:          boolean("displayable").notNull(),
  rawPayloadJson:       jsonb("raw_payload_json").notNull(),
  createdAt:            timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  uniqueIndex("score_sets_scan_unique_idx").on(t.scanId),  // UNIQUE(scanId)
]);

// ─── 9. findings ─────────────────────────────────────────────────────────────

export const findings = pgTable("findings", {
  id:                  uuid("id").primaryKey().defaultRandom(),
  scanId:              uuid("scan_id").notNull().references(() => scans.id),
  templateId:          text("template_id").notNull(),
  severity:            findingSeverityEnum("severity").notNull(),
  impact:              integer("impact").notNull(),
  priority:            integer("priority").notNull(),
  blockedByFoundation: boolean("blocked_by_foundation").notNull().default(false),
  status:              findingStatusEnum("finding_status").notNull().default("open"),
  criterionIdsJson:    jsonb("criterion_ids_json"),
  createdAt:           timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("findings_scan_idx").on(t.scanId),
]);

// ─── 10. actions ─────────────────────────────────────────────────────────────

export const actions = pgTable("actions", {
  id:               uuid("id").primaryKey().defaultRandom(),
  creatorProfileId: uuid("creator_profile_id").notNull().references(() => creatorProfiles.id),
  sourceFindingId:  uuid("source_finding_id").references(() => findings.id),
  type:             actionTypeEnum("type").notNull(),
  status:           actionStatusEnum("action_status").notNull().default("pending"),
  createdAt:        timestamp("created_at",   { withTimezone: true }).notNull().defaultNow(),
  completedAt:      timestamp("completed_at", { withTimezone: true }),
});

// ─── 11. daily_tasks ─────────────────────────────────────────────────────────

export const dailyTasks = pgTable("daily_tasks", {
  id:               uuid("id").primaryKey().defaultRandom(),
  creatorProfileId: uuid("creator_profile_id").notNull().references(() => creatorProfiles.id),
  actionId:         uuid("action_id").notNull().references(() => actions.id),
  assignedDate:     text("assigned_date").notNull(),   // "YYYY-MM-DD"
  status:           dailyTaskStatusEnum("status").notNull().default("pending"),
  createdAt:        timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("daily_tasks_profile_date_idx").on(t.creatorProfileId, t.assignedDate),
]);

// ─── 12. generated_items ─────────────────────────────────────────────────────

export const generatedItems = pgTable("generated_items", {
  id:               uuid("id").primaryKey().defaultRandom(),
  creatorProfileId: uuid("creator_profile_id").notNull().references(() => creatorProfiles.id),
  type:             genItemTypeEnum("type").notNull(),
  content:          text("content").notNull(),
  modelVersion:     text("model_version").notNull(),
  promptVersion:    text("prompt_version").notNull(),
  createdAt:        timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

// ─── 13. library_entries ─────────────────────────────────────────────────────

export const libraryEntries = pgTable("library_entries", {
  id:               uuid("id").primaryKey().defaultRandom(),
  creatorProfileId: uuid("creator_profile_id").notNull().references(() => creatorProfiles.id),
  generatedItemId:  uuid("generated_item_id").notNull().references(() => generatedItems.id),
  createdAt:        timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

// ─── 14. subscriptions ───────────────────────────────────────────────────────

export const subscriptions = pgTable("subscriptions", {
  id:                       uuid("id").primaryKey().defaultRandom(),
  userId:                   uuid("user_id").notNull().references(() => users.id),
  provider:                 subProviderEnum("provider").notNull(),
  providerCustomerId:       text("provider_customer_id"),
  providerSubscriptionId:   text("provider_subscription_id"),
  status:                   subStatusEnum("status").notNull(),
  currentPeriodEnd:         timestamp("current_period_end", { withTimezone: true }),
  createdAt:                timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt:                timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

// ─── 15. entitlements ────────────────────────────────────────────────────────

export const entitlements = pgTable("entitlements", {
  id:         uuid("id").primaryKey().defaultRandom(),
  userId:     uuid("user_id").notNull().references(() => users.id),
  featureKey: featureKeyEnum("feature_key").notNull(),
  active:     boolean("active").notNull().default(false),
  source:     entSourceEnum("source").notNull(),
  expiresAt:  timestamp("expires_at", { withTimezone: true }),
  updatedAt:  timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  uniqueIndex("entitlements_user_feature_idx").on(t.userId, t.featureKey),  // UNIQUE(userId, featureKey)
]);

// ─── 16. usage_counters ──────────────────────────────────────────────────────

export const usageCounters = pgTable("usage_counters", {
  id:         uuid("id").primaryKey().defaultRandom(),
  ownerType:  ownerTypeEnum("owner_type").notNull(),
  ownerId:    text("owner_id").notNull(),
  featureKey: featureKeyEnum("feature_key").notNull(),
  periodKey:  text("period_key").notNull(),
  count:      integer("count").notNull().default(0),
  updatedAt:  timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  uniqueIndex("usage_counters_unique_idx").on(t.ownerType, t.ownerId, t.featureKey, t.periodKey),  // UNIQUE
]);

// ─── 17. idempotency_keys ────────────────────────────────────────────────────

export const idempotencyKeys = pgTable("idempotency_keys", {
  id:                uuid("id").primaryKey().defaultRandom(),
  ownerKey:          text("owner_key").notNull(),
  idempotencyKey:    text("idempotency_key").notNull(),
  requestFingerprint: text("request_fingerprint").notNull(),
  responseStatus:    integer("response_status"),
  responseBodyJson:  jsonb("response_body_json"),
  createdAt:         timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  expiresAt:         timestamp("expires_at",  { withTimezone: true }).notNull(),   // NOT NULL
}, (t) => [
  uniqueIndex("idempotency_keys_unique_idx").on(t.ownerKey, t.idempotencyKey),  // UNIQUE
  index("idempotency_keys_expires_idx").on(t.expiresAt),
]);

// ─── 18. audit_events ────────────────────────────────────────────────────────

export const auditEvents = pgTable("audit_events", {
  id:           uuid("id").primaryKey().defaultRandom(),
  actorType:    auditActorTypeEnum("actor_type").notNull(),
  actorId:      text("actor_id"),
  eventType:    auditEventTypeEnum("event_type").notNull(),
  subjectType:  text("subject_type"),
  subjectId:    text("subject_id"),
  metadataJson: jsonb("metadata_json").notNull().default({}),
  createdAt:    timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("audit_events_created_idx").on(t.createdAt),
  index("audit_events_actor_idx").on(t.actorId),
]);

// ─── 19. model_versions ──────────────────────────────────────────────────────

export const modelVersions = pgTable("model_versions", {
  id:            uuid("id").primaryKey().defaultRandom(),
  taskType:      modelTaskTypeEnum("task_type").notNull(),
  provider:      text("provider").notNull(),
  modelId:       text("model_id").notNull(),
  promptVersion: text("prompt_version"),
  activeFrom:    timestamp("active_from", { withTimezone: true }).notNull(),
  retiredAt:     timestamp("retired_at",  { withTimezone: true }),
});

// ─── 20. pipeline_versions ───────────────────────────────────────────────────

export const pipelineVersions = pgTable("pipeline_versions", {
  version:     text("version").primaryKey(),   // "v1.0.0" — fachlicher PK
  description: text("description").notNull(),
  createdAt:   timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

// ─── 21. social_accounts ─────────────────────────────────────────────────────

/**
 * A linked TikTok or Instagram account belonging to a creator profile.
 *
 * providerAccountId: the platform's own stable user identifier (NOT an access token).
 * disconnectedAt:    set when the user unlinks; treated as inactive.
 *
 * UNIQUE(creatorProfileId, platform): one active linked account per platform per profile.
 * (Enforced at service level; a profile can have historical disconnected rows.)
 * UNIQUE(platform, providerAccountId): a provider account can only be linked once globally.
 */
export const socialAccounts = pgTable("social_accounts", {
  id:                uuid("id").primaryKey().defaultRandom(),
  creatorProfileId:  uuid("creator_profile_id").notNull().references(() => creatorProfiles.id),
  platform:          creatorPlatformEnum("platform").notNull(),
  providerAccountId: text("provider_account_id").notNull(),
  displayName:       text("display_name"),
  username:          text("username"),
  connectedAt:       timestamp("connected_at", { withTimezone: true }).notNull().defaultNow(),
  disconnectedAt:    timestamp("disconnected_at", { withTimezone: true }),
}, (t) => [
  index("social_accounts_profile_idx").on(t.creatorProfileId),
  // Global uniqueness: a provider account can only be linked once at a time
  uniqueIndex("social_accounts_provider_unique_idx").on(t.platform, t.providerAccountId),
]);



export const schema = {
  users, anonymousSessions, userSessions, creatorProfiles,
  scans, uploadedAssets, criterionObservations, scoreSets,
  findings, actions, dailyTasks, generatedItems,
  libraryEntries, subscriptions, entitlements, usageCounters,
  idempotencyKeys, auditEvents, modelVersions, pipelineVersions,
  socialAccounts,
};
