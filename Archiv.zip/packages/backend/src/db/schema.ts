/**
 * Datenbankschema-Typdefinitionen.
 *
 * Diese Datei definiert die TypeScript-Interfaces aller Datenbanktabellen.
 * Sie ist vollständig ohne DB-Verbindung importierbar.
 *
 * Nach npm-Installation wird dieses Interface-Set in Drizzle-Schema-Definitionen
 * (schema.drizzle.ts) überführt. Die Feldnamen und -typen bleiben identisch —
 * nur die Deklarationssyntax ändert sich.
 *
 * ── ARCHITEKTURREGELN ──────────────────────────────────────────────────────
 * 1. Diese Datei importiert KEIN Drizzle, KEINE DB-Clients
 * 2. packages/shared/scoring darf NICHT von hier importiert werden
 *    (Richtung: backend → shared, niemals umgekehrt)
 * 3. Keine Datenbankverbindung beim Import dieser Datei
 */

import type {
  CreatorPlatform,
  ScanStatus,
  DbCriterionState,
  DbObservationSource,
  DbFindingSeverity,
  DbFindingStatus,
  OwnerType,
  ActionType,
  ActionStatus,
  DailyTaskStatus,
  GeneratedItemType,
  SubscriptionStatus,
  SubscriptionProvider,
  EntitlementSource,
  FeatureKey,
  AuditEventType,
  AuditActorType,
  ModelTaskType,
  UploadContentType,
} from "./enums.js";

// ─── users ────────────────────────────────────────────────────────────────────

/**
 * Ein registrierter VYRO-Nutzer.
 * appleSubject ist nullable — ein User kann erstellt worden sein,
 * bevor der Apple-Auth-Flow abgeschlossen ist (Onboarding-Edge-Cases).
 *
 * Index: appleSubject (unique, partial: WHERE appleSubject IS NOT NULL)
 */
export interface DbUser {
  id: string;                     // uuid, PK
  appleSubject: string | null;    // Apple Identity Subject — unique, nullable
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date | null;         // Soft-delete für DSGVO-Löschwarteschlange
}

// ─── anonymous_sessions ───────────────────────────────────────────────────────

/**
 * Anonyme Sitzung vor Kontoerstellung.
 *
 * deviceSecretHash: BCrypt/Argon2-Hash des Geräteschlüssels — nie im Klartext.
 * mergedIntoUserId: gesetzt wenn die Sitzung einem Konto zugeordnet wurde.
 * Invariante: mergedIntoUserId kann nur einmal gesetzt werden (DATENBANK-Constraint).
 *
 * Löschung: expiresAt überschritten + mergedIntoUserId gesetzt → löschbar nach 90 Tagen.
 *
 * Index: expiresAt (Löschläufe)
 */
export interface DbAnonymousSession {
  id: string;                      // uuid, PK
  deviceSecretHash: string;        // gehashtes Gerätegeheimnis
  createdAt: Date;
  lastSeenAt: Date;
  expiresAt: Date;
  mergedIntoUserId: string | null; // FK → users.id; nullable; nur einmal setzbar
}

// ─── user_sessions ────────────────────────────────────────────────────────────

/**
 * Authentifizierte Benutzersitzung mit rotierenden Refresh-Tokens.
 *
 * refreshTokenHash: Hash des opaken Refresh-Tokens (nie Klartext).
 * tokenFamilyId: Alle Tokens einer Login-Session teilen eine Family-ID.
 *   Wird ein abgelaufenes Token erneut verwendet → gesamte Family sperren.
 * replacedBySessionId: Zeigt auf den Nachfolger nach Token-Rotation.
 *
 * Index: userId, expiresAt
 */
export interface DbUserSession {
  id: string;                      // uuid, PK
  userId: string;                  // FK → users.id
  refreshTokenHash: string;        // Hash des Refresh-Tokens
  tokenFamilyId: string;           // uuid; für Wiederverwendungserkennung
  createdAt: Date;
  expiresAt: Date;
  revokedAt: Date | null;
  replacedBySessionId: string | null; // FK → user_sessions.id
}

// ─── creator_profiles ─────────────────────────────────────────────────────────

/**
 * Ein Creator-Profil gehört entweder einem anonymen oder registrierten Nutzer.
 *
 * Invariante: Genau einer von ownerUserId / ownerAnonymousSessionId ist nicht null.
 * ownerType = "user"      → ownerUserId gesetzt,       ownerAnonymousSessionId null
 * ownerType = "anonymous" → ownerAnonymousSessionId gesetzt, ownerUserId null
 *
 * V2: Ein User kann mehrere Profile haben (Multi-Account).
 *
 * Index: ownerUserId, ownerAnonymousSessionId
 */
export interface DbCreatorProfile {
  id: string;                               // uuid, PK
  ownerType: OwnerType;
  ownerUserId: string | null;               // FK → users.id
  ownerAnonymousSessionId: string | null;   // FK → anonymous_sessions.id
  platform: CreatorPlatform;
  createdAt: Date;
  updatedAt: Date;
}

// ─── scans ────────────────────────────────────────────────────────────────────

/**
 * Ein einzelner Profilanalyse-Lauf.
 *
 * scoringModelVersion und pipelineVersion werden beim Abschluss gesetzt.
 * totalScore ist null bis status = 'completed'.
 * displayable gibt an ob der Score angezeigt werden darf (Coverage-Regel).
 *
 * Index: creatorProfileId, createdAt (für Verlauf + Tagesabfragen)
 */
export interface DbScan {
  id: string;                       // uuid, PK
  creatorProfileId: string;         // FK → creator_profiles.id
  status: ScanStatus;
  platform: CreatorPlatform;
  scoringModelVersion: string | null; // null bis completed
  pipelineVersion: string | null;     // null bis completed
  coverage: number | null;            // 0.0–1.0; null bis completed
  displayable: boolean | null;        // null bis completed
  totalScore: number | null;          // 0–100; null bis completed oder bei displayable=false
  createdAt: Date;
  completedAt: Date | null;
  failedAt: Date | null;
  failureCode: string | null;
}

// ─── uploaded_assets ──────────────────────────────────────────────────────────

/**
 * Eine hochgeladene Datei (Screenshot).
 *
 * DATENSCHUTZ:
 *   - Nur storageKey speichern, keine öffentliche URL
 *   - expiresAt MUSS gesetzt sein — Löschpflicht nach max. 24 Stunden
 *   - deletedAt: bestätigt aktive Löschung aus dem Objektspeicher
 *
 * perceptualHash: für Duplikaterkennung, KEIN Bildinhalt
 *
 * Index: expiresAt (Löschjob), scanId
 */
export interface DbUploadedAsset {
  id: string;                   // uuid, PK
  scanId: string;               // FK → scans.id
  storageKey: string;           // Pfad im Objektspeicher (GCS key)
  contentType: UploadContentType;
  byteSize: number;
  perceptualHash: string | null; // DCT-Hash für Duplikaterkennung
  createdAt: Date;
  expiresAt: Date;              // MUSS gesetzt sein — max. 24 h nach Upload
  deletedAt: Date | null;       // Bestätigung der Objektspeicher-Löschung
}

// ─── criterion_observations ───────────────────────────────────────────────────

/**
 * Beobachtungsergebnis je Kriterium für einen Scan.
 *
 * Unique: (scanId, criterionId) — jedes Kriterium genau einmal je Scan.
 *
 * WICHTIG: Keine Punktzahl speichern. Punkte entstehen deterministisch
 * aus dem State — der Bewertungskern berechnet sie jederzeit reproduzierbar.
 *
 * criterionId muss ein gültiger Wert aus ALL_CRITERION_IDS sein.
 * Validation findet in der API-Schicht statt, nicht per FK.
 *
 * modelVersion: die Modellkennung, die diese Beobachtung erzeugt hat.
 *
 * Index: scanId (Primärzugriff)
 */
export interface DbCriterionObservation {
  id: string;                          // uuid, PK
  scanId: string;                      // FK → scans.id
  criterionId: string;                 // CriterionId aus dem Score-Modell
  state: DbCriterionState;
  source: DbObservationSource;         // A | B | C
  modelVersion: string | null;         // z. B. "gemini-2.0-flash-001"; null bei Klasse A
  createdAt: Date;
  // UNIQUE: (scanId, criterionId)
}

// ─── score_sets ───────────────────────────────────────────────────────────────

/**
 * Das vollständige ScoreSet eines abgeschlossenen Scans.
 *
 * rawPayloadJson: serialisiertes ScoreSet-Objekt aus dem Bewertungskern.
 *   Enthält alle CategoryScores. Darf KEINE KI-Rohantworten enthalten.
 *
 * scoringModelVersion: muss mit scans.scoringModelVersion übereinstimmen.
 *
 * Unique: scanId (1:1 zum Scan)
 */
export interface DbScoreSet {
  id: string;                    // uuid, PK
  scanId: string;                // FK → scans.id, UNIQUE
  scoringModelVersion: string;
  totalScore: number;            // 0–100, normalisiert
  coverage: number;              // 0.0–1.0
  displayable: boolean;
  rawPayloadJson: string;        // JSON: ScoreSet aus dem Bewertungskern
  createdAt: Date;
}

// ─── findings ─────────────────────────────────────────────────────────────────

/**
 * Ein konkreter Befund aus der Befundbildung (Pipeline-Stufe 5).
 *
 * criterionIdsJson: JSON-Array der betroffenen Kriterium-IDs.
 *   Optional aber empfohlen für Admin-Diagnose und Nachrechenbarkeit.
 *
 * Kein Erklärungstext hier — der kommt aus Pipeline-Stufe 6 (separates System).
 *
 * Index: scanId
 */
export interface DbFinding {
  id: string;                    // uuid, PK
  scanId: string;                // FK → scans.id
  templateId: string;            // FindingTemplate-ID aus dem Score-Modell
  severity: DbFindingSeverity;
  impact: number;                // Verlorene Punkte, 1-basiert
  priority: number;              // Sortierrang, 1 = höchste Priorität
  blockedByFoundation: boolean;
  status: DbFindingStatus;       // initialisiert als 'open'
  criterionIdsJson: string | null; // JSON: string[], betroffene Kriterien
  createdAt: Date;
}

// ─── actions ──────────────────────────────────────────────────────────────────

/**
 * Eine aus einem Befund abgeleitete Handlungsempfehlung.
 */
export interface DbAction {
  id: string;                   // uuid, PK
  creatorProfileId: string;     // FK → creator_profiles.id
  sourceFindingId: string | null; // FK → findings.id; null bei manuell erstellten
  type: ActionType;
  status: ActionStatus;
  createdAt: Date;
  completedAt: Date | null;
}

// ─── daily_tasks ──────────────────────────────────────────────────────────────

/**
 * Die tägliche Aufgabe auf dem Heute-Screen.
 * assignedDate: Format YYYY-MM-DD (als String für einfache Abfragen)
 *
 * Index: creatorProfileId + assignedDate
 */
export interface DbDailyTask {
  id: string;                   // uuid, PK
  creatorProfileId: string;     // FK → creator_profiles.id
  actionId: string;             // FK → actions.id
  assignedDate: string;         // "2025-01-15"
  status: DailyTaskStatus;
  createdAt: Date;
}

// ─── generated_items ──────────────────────────────────────────────────────────

/**
 * Ein KI-generierter Inhalt (Bio, Hook, Caption usw.).
 *
 * DATENSCHUTZ: content darf keine fremden personenbezogenen Daten enthalten.
 *   Die Generierung erfolgt auf Basis von Scan-Metadaten, nicht von Screenshots.
 *
 * modelVersion: die Modellkennung, die diesen Inhalt erzeugt hat.
 * promptVersion: die Prompt-Vorlage — wichtig für Qualitäts-Tracking.
 */
export interface DbGeneratedItem {
  id: string;                    // uuid, PK
  creatorProfileId: string;      // FK → creator_profiles.id
  type: GeneratedItemType;
  content: string;               // Der generierte Text
  modelVersion: string;          // z. B. "gemini-2.0-flash-001"
  promptVersion: string;         // z. B. "bio-generator-v1"
  createdAt: Date;
}

// ─── library_entries ──────────────────────────────────────────────────────────

/**
 * Vom Nutzer gespeicherter generierter Inhalt.
 * Verknüpft einen generated_item mit dem Nutzerprofil.
 */
export interface DbLibraryEntry {
  id: string;                    // uuid, PK
  creatorProfileId: string;      // FK → creator_profiles.id
  generatedItemId: string;       // FK → generated_items.id
  createdAt: Date;
}

// ─── subscriptions ────────────────────────────────────────────────────────────

/**
 * Abo-Information aus dem Store.
 *
 * WICHTIG: Dies ist NICHT die Berechtigungswahrheit — das ist entitlements.
 * subscriptions ist der Rohdatensatz aus Store-Webhooks.
 *
 * providerCustomerId: Apple-spezifische Kunden-ID.
 * providerSubscriptionId: Apple-spezifische Abo-ID (original transaction ID).
 */
export interface DbSubscription {
  id: string;                          // uuid, PK
  userId: string;                      // FK → users.id
  provider: SubscriptionProvider;
  providerCustomerId: string | null;
  providerSubscriptionId: string | null;
  status: SubscriptionStatus;
  currentPeriodEnd: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

// ─── entitlements ─────────────────────────────────────────────────────────────

/**
 * Produktwahrheit für Feature-Zugang.
 *
 * Dies ist die einzige Stelle, die der Backend-Code für Berechtigungsprüfungen
 * verwendet. RevenueCat, App Store Server API und Webhooks schreiben in diese
 * Tabelle — sie lesen nicht aus ihr.
 *
 * active = true: Nutzer hat Zugang zu featureKey
 * expiresAt: gesetzt bei zeitlich begrenztem Zugang (Testphase, Kulanzfrist)
 *
 * Index: userId (häufigster Lesezugriff)
 */
export interface DbEntitlement {
  id: string;                    // uuid, PK
  userId: string;                // FK → users.id
  featureKey: FeatureKey;
  active: boolean;
  source: EntitlementSource;
  expiresAt: Date | null;
  updatedAt: Date;
  // UNIQUE: (userId, featureKey)
}

// ─── usage_counters ───────────────────────────────────────────────────────────

/**
 * Nutzungszähler für Rate-Limiting und Free-Tier-Grenzen.
 *
 * periodKey: Format "2025-W03" (Woche) oder "2025-01" (Monat)
 * count: atomar erhöhbar — kein Read-Modify-Write
 *
 * ownerType/ownerId: kann User oder AnonymousSession sein
 *
 * Index: (ownerType, ownerId, featureKey, periodKey) — auch Unique-Constraint
 */
export interface DbUsageCounter {
  id: string;                    // uuid, PK
  ownerType: OwnerType;
  ownerId: string;               // userId oder anonymousSessionId
  featureKey: FeatureKey;
  periodKey: string;             // "2025-W03" oder "2025-01"
  count: number;
  updatedAt: Date;
  // UNIQUE: (ownerType, ownerId, featureKey, periodKey)
}

// ─── idempotency_keys ─────────────────────────────────────────────────────────

/**
 * Idempotenz-Tabelle für mutierenden Operationen.
 *
 * ownerKey: Konto- oder Session-ID des Anfragenden
 * idempotencyKey: Client-generierter UUID (aus dem Idempotency-Key-Header)
 * requestFingerprint: Hash der Anfrage-Parameter — erkennt geänderte Requests
 *
 * responseStatus und responseBodyJson: gecachte Antwort für Wiederholungen
 *
 * UNIQUE: (ownerKey, idempotencyKey)
 * Index: expiresAt (Ablauflauf)
 *
 * WICHTIG: Das Schema steht von Anfang an — Idempotenz ist kein späteres Feature.
 */
export interface DbIdempotencyKey {
  id: string;                       // uuid, PK
  ownerKey: string;                 // userId oder anonymousSessionId
  idempotencyKey: string;           // Client-UUID aus Header
  requestFingerprint: string;       // SHA256(method + path + body)
  responseStatus: number | null;    // HTTP-Status der gecachten Antwort
  responseBodyJson: string | null;  // gecachte Antwort (JSON)
  createdAt: Date;
  expiresAt: Date;                  // typischerweise 24h nach Erstellung
  // UNIQUE: (ownerKey, idempotencyKey)
}

// ─── audit_events ─────────────────────────────────────────────────────────────

/**
 * Unveränderliches Audit-Log.
 *
 * DATENSCHUTZ: metadataJson enthält KEINE:
 *   - Bios, Texte aus Screenshots
 *   - Tokens, Refresh-Token-Hashes
 *   - Modell-Prompts oder -Antworten
 *   - Screenshots oder Bildinhalte
 *
 * Erlaubt in metadataJson: Kennungen, Zustände, Versions-IDs.
 *
 * Index: createdAt (zeitliche Abfragen, Protokoll-Export)
 * Index: actorId (Support-Abfragen)
 *
 * Das Audit-Log ist APPEND-ONLY: UPDATE und DELETE sind auf dieser
 * Tabelle nicht erlaubt (Datenbankrechte + Anwendungsregel).
 */
export interface DbAuditEvent {
  id: string;                    // uuid, PK
  actorType: AuditActorType;
  actorId: string | null;        // userId oder adminId; null für System-Events
  eventType: AuditEventType;
  subjectType: string | null;    // z. B. "user", "scan", "subscription"
  subjectId: string | null;      // ID des betroffenen Objekts
  metadataJson: string;          // JSON ohne sensitive Inhalte
  createdAt: Date;
}

// ─── model_versions ───────────────────────────────────────────────────────────

/**
 * Versionstabelle für KI-Modelle und Prompts.
 *
 * Scans referenzieren die verwendete Modell-Konfiguration für Nachvollziehbarkeit.
 * activeFrom/retiredAt: ermöglicht Schattenläufe und stufenweises Ausrollen.
 */
export interface DbModelVersion {
  id: string;                    // uuid, PK
  taskType: ModelTaskType;
  provider: string;              // z. B. "google-vertex", "openai"
  modelId: string;               // z. B. "gemini-2.0-flash-001"
  promptVersion: string | null;  // Prompt-Vorlage; null für nicht-LLM-Tasks
  activeFrom: Date;
  retiredAt: Date | null;
}

// ─── pipeline_versions ────────────────────────────────────────────────────────

/**
 * Versionshistorie der Analyse-Pipeline.
 *
 * Scans speichern die Pipeline-Version zum Zeitpunkt ihrer Verarbeitung.
 * Damit sind Vergleiche zwischen Scans verschiedener Pipeline-Generationen möglich.
 */
export interface DbPipelineVersion {
  version: string;               // PK; z. B. "v1.0.0"
  createdAt: Date;
  description: string;
}
