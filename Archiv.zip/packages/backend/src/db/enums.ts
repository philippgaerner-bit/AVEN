/**
 * Datenbankschema-Enumerationen und Konstantendefinitionen.
 *
 * Diese Datei enthält die Wertemengen aller Enum-Spalten.
 * Sie ist importierbar ohne DB-Verbindung und wird von:
 *   - dem Schema selbst (schema.ts)
 *   - den Tests
 *   - der Business-Logik
 * verwendet, um Tippfehler und Inkonsistenzen zu vermeiden.
 *
 * Architekturregeln:
 *   - Kein Import von Drizzle oder DB-Clients
 *   - Nur Konstanten — keine Verbindungen, keine Queries
 */

// ─── Plattformen ──────────────────────────────────────────────────────────────

export const CREATOR_PLATFORMS = ["instagram", "tiktok"] as const;
export type CreatorPlatform = (typeof CREATOR_PLATFORMS)[number];

// ─── Scan-Status ──────────────────────────────────────────────────────────────

export const SCAN_STATUSES = [
  "accepted",
  "processing",
  "completed",
  "failed",
] as const;
export type ScanStatus = (typeof SCAN_STATUSES)[number];

// ─── Kriterium-Zustände (spiegelt scoring/types.ts) ──────────────────────────

export const DB_CRITERION_STATES = [
  "fulfilled",
  "partial",
  "missing",
  "unavailable",
] as const;
export type DbCriterionState = (typeof DB_CRITERION_STATES)[number];

// ─── Beobachtungsquellen ──────────────────────────────────────────────────────

export const DB_OBSERVATION_SOURCES = ["A", "B", "C"] as const;
export type DbObservationSource = (typeof DB_OBSERVATION_SOURCES)[number];

// ─── Finding-Schweregrad ──────────────────────────────────────────────────────

export const DB_FINDING_SEVERITIES = [
  "foundation",
  "lever",
  "polish",
] as const;
export type DbFindingSeverity = (typeof DB_FINDING_SEVERITIES)[number];

// ─── Finding-Status ───────────────────────────────────────────────────────────

export const DB_FINDING_STATUSES = ["open", "completed", "dismissed"] as const;
export type DbFindingStatus = (typeof DB_FINDING_STATUSES)[number];

// ─── Owner-Typ (Creator Profile) ─────────────────────────────────────────────

export const OWNER_TYPES = ["anonymous", "user"] as const;
export type OwnerType = (typeof OWNER_TYPES)[number];

// ─── Action-Typ ───────────────────────────────────────────────────────────────

export const ACTION_TYPES = [
  "fix_bio",
  "fix_content",
  "fix_feed",
  "fix_branding",
  "fix_profile_pic",
  "fix_username",
  "fix_engagement",
  "rescan",
] as const;
export type ActionType = (typeof ACTION_TYPES)[number];

// ─── Action-Status ────────────────────────────────────────────────────────────

export const ACTION_STATUSES = ["pending", "completed", "dismissed"] as const;
export type ActionStatus = (typeof ACTION_STATUSES)[number];

// ─── Daily Task Status ────────────────────────────────────────────────────────

export const DAILY_TASK_STATUSES = ["pending", "completed", "skipped"] as const;
export type DailyTaskStatus = (typeof DAILY_TASK_STATUSES)[number];

// ─── Generated Item Typ ───────────────────────────────────────────────────────

export const GENERATED_ITEM_TYPES = [
  "bio",
  "hook",
  "caption",
  "hashtags",
  "content_idea",
] as const;
export type GeneratedItemType = (typeof GENERATED_ITEM_TYPES)[number];

// ─── Subscription-Status ──────────────────────────────────────────────────────

export const SUBSCRIPTION_STATUSES = [
  "trialing",
  "active",
  "past_due",
  "canceled",
  "expired",
] as const;
export type SubscriptionStatus = (typeof SUBSCRIPTION_STATUSES)[number];

// ─── Subscription-Provider ────────────────────────────────────────────────────

export const SUBSCRIPTION_PROVIDERS = [
  "apple_iap",
  "google_play",   // V2
  "stripe",         // V2, Web
] as const;
export type SubscriptionProvider = (typeof SUBSCRIPTION_PROVIDERS)[number];

// ─── Entitlement-Quelle ───────────────────────────────────────────────────────

export const ENTITLEMENT_SOURCES = [
  "subscription",
  "trial",
  "manual",       // Für interne Tests / Support
] as const;
export type EntitlementSource = (typeof ENTITLEMENT_SOURCES)[number];

// ─── Entitlement-Feature-Schlüssel ───────────────────────────────────────────

/**
 * Alle Feature-Schlüssel, die in entitlements und usage_counters verwendet werden.
 * Nicht extern konfigurierbar — Wertemengen sind Teil des Datenmodells.
 */
export const FEATURE_KEYS = [
  "scans",
  "bio_generation",
  "hook_generation",
  "caption_generation",
  "hashtag_generation",
  "content_idea_generation",
  "library_entries",
  "full_insights",   // Alle 7 Befund-Erklärungen freigeschaltet
] as const;
export type FeatureKey = (typeof FEATURE_KEYS)[number];

// ─── Audit-Event-Typen ────────────────────────────────────────────────────────

export const AUDIT_EVENT_TYPES = [
  "account_created",
  "account_merged",
  "account_deleted",
  "session_created",
  "session_revoked",
  "subscription_activated",
  "subscription_changed",
  "entitlement_granted",
  "entitlement_revoked",
  "admin_viewed_user",
  "data_export_requested",
  "data_deletion_completed",
] as const;
export type AuditEventType = (typeof AUDIT_EVENT_TYPES)[number];

// ─── Audit-Actor-Typ ──────────────────────────────────────────────────────────

export const AUDIT_ACTOR_TYPES = ["user", "admin", "system"] as const;
export type AuditActorType = (typeof AUDIT_ACTOR_TYPES)[number];

// ─── Model-Task-Typen ─────────────────────────────────────────────────────────

export const MODEL_TASK_TYPES = [
  "ocr",
  "vision_observe",
  "language_observe",
  "language_generate",
  "transcription",   // V2
] as const;
export type ModelTaskType = (typeof MODEL_TASK_TYPES)[number];

// ─── Upload-Content-Typen ─────────────────────────────────────────────────────

export const UPLOAD_CONTENT_TYPES = [
  "image/jpeg",
  "image/png",
  "image/heic",
  "image/webp",
] as const;
export type UploadContentType = (typeof UPLOAD_CONTENT_TYPES)[number];
