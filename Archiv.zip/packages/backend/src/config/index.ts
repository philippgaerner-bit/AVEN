/**
 * Typsicheres Konfigurationsmodul.
 *
 * Regeln:
 *  - Kein direkter process.env-Zugriff außerhalb dieser Datei
 *  - Secrets (JWT_SECRET, DATABASE_URL) haben keine Defaults — fehlen sie, schlägt der Start fehl
 *  - loadConfig() ist testbar: nimmt ein env-Objekt, nicht process.env direkt
 *  - Die erzeugte Config ist ein unveränderliches POJO — kein singleton
 */

import { SCORING_MODEL_VERSION } from "@vyro/shared/scoring";

// ─── Typen ───────────────────────────────────────────────────────────────────

export type NodeEnv = "development" | "test" | "staging" | "production";

// ─── Provider-Auswahl ────────────────────────────────────────────────────────

export const PROVIDER_CHOICES = ["fake", "disabled"] as const;
export type ProviderChoice = string; // "fake" | "disabled" | "google-vision" | "openai" | …

export interface AppConfig {
  readonly nodeEnv: NodeEnv;
  readonly port: number;

  // Datenbankverbindung — Pflicht in allen Umgebungen
  readonly databaseUrl: string;

  // Cache — optional in development
  readonly redisUrl: string | null;

  // Authentifizierung
  readonly jwtSecret: string;
  readonly appleClientId: string;

  // Storage
  readonly gcsBucketName: string;

  // Score-Modell-Kompatibilität
  readonly scoringModelVersionExpected: string;

  // Abgeleitete Flags
  readonly isDevelopment: boolean;
  readonly isProduction: boolean;
  readonly isTest: boolean;

  // ── Provider-Konfiguration ─────────────────────────────────────────────────
  /** "fake" = StubProvider; "disabled" = safe error; future: "google-vision", "openai" etc. */
  readonly ocrProvider: ProviderChoice;
  readonly visionProvider: ProviderChoice;
  readonly recommendationAiProvider: ProviderChoice;

  /** Maximale Wartezeit je Provider-Aufruf in ms */
  readonly providerTimeoutMs: number;
  /** Maximale Retry-Versuche je Provider-Aufruf */
  readonly providerMaxRetries: number;

  // ── Billing ───────────────────────────────────────────────────────────────
  readonly billingProvider: string;
  readonly billingWebhookSecret: string | null;

  // ── TikTok OAuth ──────────────────────────────────────────────────────────
  /** TikTok Developer App Client Key (public) */
  readonly tiktokClientKey:    string | null;
  /** TikTok Developer App Client Secret — NEVER sent to client */
  readonly tiktokClientSecret: string | null;
  /** Full redirect URI registered in TikTok Developer Portal */
  readonly tiktokRedirectUri:  string;
}

// ─── Fehlerklasse für Konfigurationsfehler ───────────────────────────────────

export class ConfigError extends Error {
  override readonly name = "ConfigError";
  constructor(message: string) {
    super(`[VYRO Config] ${message}`);
  }
}

// ─── Laderfunktion ────────────────────────────────────────────────────────────

/**
 * Lädt und validiert die Konfiguration aus einem env-Objekt.
 *
 * In production: schlägt hart fehl bei fehlenden Pflichtfeldern.
 * In development: einige nicht-sicherheitskritische Felder haben Defaults.
 *
 * @throws ConfigError bei fehlenden oder ungültigen Werten
 */
export function loadConfig(
  env: Record<string, string | undefined> = process.env
): AppConfig {
  // ── NODE_ENV ──────────────────────────────────────────────────────────────
  const rawNodeEnv = env["NODE_ENV"] ?? "development";
  if (!isNodeEnv(rawNodeEnv)) {
    throw new ConfigError(
      `NODE_ENV muss development | test | staging | production sein, erhalten: "${rawNodeEnv}"`
    );
  }
  const nodeEnv: NodeEnv = rawNodeEnv;
  const isDev = nodeEnv === "development";
  const isTest = nodeEnv === "test";

  // ── PORT ──────────────────────────────────────────────────────────────────
  const rawPort = env["PORT"] ?? "3000";
  const port = parseInt(rawPort, 10);
  if (!Number.isFinite(port) || port < 1 || port > 65535) {
    throw new ConfigError(
      `PORT muss eine Ganzzahl zwischen 1 und 65535 sein, erhalten: "${rawPort}"`
    );
  }

  // ── DATABASE_URL — Pflichtfeld, kein Default ──────────────────────────────
  const databaseUrl = env["DATABASE_URL"];
  if (!databaseUrl) {
    throw new ConfigError(
      "DATABASE_URL muss gesetzt sein. " +
        "Für lokale Entwicklung: postgresql://localhost:5432/vyro_dev"
    );
  }

  // ── REDIS_URL — optional ──────────────────────────────────────────────────
  const redisUrl = env["REDIS_URL"] ?? null;

  // ── JWT_SECRET — Pflichtfeld, kein Default ────────────────────────────────
  const jwtSecret = env["JWT_SECRET"];
  if (!jwtSecret) {
    throw new ConfigError(
      "JWT_SECRET muss gesetzt sein. " +
        "Mindestlänge: 32 Zeichen. Niemals einen fixen Default verwenden."
    );
  }
  if (jwtSecret.length < 32) {
    throw new ConfigError(
      `JWT_SECRET ist zu kurz (${jwtSecret.length} Zeichen). Mindestlänge: 32`
    );
  }

  // ── APPLE_CLIENT_ID ───────────────────────────────────────────────────────
  const appleClientId =
    env["APPLE_CLIENT_ID"] ??
    (isDev || isTest ? "com.vyro.app.dev" : undefined);
  if (!appleClientId) {
    throw new ConfigError("APPLE_CLIENT_ID muss in production gesetzt sein.");
  }

  // ── GCS_BUCKET_NAME ───────────────────────────────────────────────────────
  const gcsBucketName =
    env["GCS_BUCKET_NAME"] ??
    (isDev || isTest ? "vyro-screenshots-dev" : undefined);
  if (!gcsBucketName) {
    throw new ConfigError("GCS_BUCKET_NAME muss in production gesetzt sein.");
  }

  // ── SCORING_MODEL_VERSION_EXPECTED ────────────────────────────────────────
  // Wenn nicht gesetzt, wird die aktuelle Engine-Version verwendet.
  // In production sollte sie explizit gesetzt werden, um Deployments zu validieren.
  const scoringModelVersionExpected =
    env["SCORING_MODEL_VERSION_EXPECTED"] ?? SCORING_MODEL_VERSION;

  const ocrProvider               = env["OCR_PROVIDER"]               ?? (isDev || isTest ? "fake" : "disabled");
  const visionProvider            = env["VISION_PROVIDER"]            ?? (isDev || isTest ? "fake" : "disabled");
  const recommendationAiProvider  = env["RECOMMENDATION_AI_PROVIDER"] ?? (isDev || isTest ? "fake" : "disabled");

  const rawTimeout  = parseInt(env["PROVIDER_TIMEOUT_MS"]   ?? "10000", 10);
  const rawRetries  = parseInt(env["PROVIDER_MAX_RETRIES"]  ?? "2",     10);
  const providerTimeoutMs   = Number.isFinite(rawTimeout)  && rawTimeout  > 0 ? rawTimeout  : 10000;
  const providerMaxRetries  = Number.isFinite(rawRetries)  && rawRetries  >= 0 ? rawRetries : 2;

  const billingProvider       = env["BILLING_PROVIDER"]        ?? (isDev || isTest ? "stub" : "disabled");
  const billingWebhookSecret  = env["BILLING_WEBHOOK_SECRET"]  ?? null;

  const tiktokClientKey    = env["TIKTOK_CLIENT_KEY"]    ?? null;
  const tiktokClientSecret = env["TIKTOK_CLIENT_SECRET"] ?? null;
  // Default redirect URI — override via env in production
  const tiktokRedirectUri  = env["TIKTOK_REDIRECT_URI"]  ??
    (isDev || isTest
      ? "https://avengrowth.app/auth/tiktok/callback"
      : "https://avengrowth.app/auth/tiktok/callback");

  return {
    nodeEnv,
    port,
    databaseUrl,
    redisUrl,
    jwtSecret,
    appleClientId,
    gcsBucketName,
    scoringModelVersionExpected,
    isDevelopment: isDev,
    isProduction: nodeEnv === "production",
    isTest,
    ocrProvider,
    visionProvider,
    recommendationAiProvider,
    providerTimeoutMs,
    providerMaxRetries,
    billingProvider,
    billingWebhookSecret,
    tiktokClientKey,
    tiktokClientSecret,
    tiktokRedirectUri,
  };
}

// ─── Hilfsfunktionen ─────────────────────────────────────────────────────────

function isNodeEnv(value: string): value is NodeEnv {
  return ["development", "test", "staging", "production"].includes(value);
}

// ─── Instanzen: Singleton-Muster für Laufzeit ────────────────────────────────

/**
 * Singleton-Config für den Anwendungsstart.
 * Wird in server.ts einmalig erzeugt und weitergereicht.
 * Tests sollen loadConfig() direkt aufrufen.
 */
let _cachedConfig: AppConfig | null = null;

export function getConfig(): AppConfig {
  if (_cachedConfig === null) {
    _cachedConfig = loadConfig(process.env);
  }
  return _cachedConfig;
}

/** Nur für Tests: Cache zurücksetzen */
export function resetConfigCache(): void {
  _cachedConfig = null;
}
