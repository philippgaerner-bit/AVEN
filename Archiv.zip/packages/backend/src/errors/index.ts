/**
 * Zentrales Fehlersystem.
 *
 * Prinzipien:
 *  - AppError ist die einzige öffentlich exponierte Fehlerklasse
 *  - expose: true  → Code und Message gehen an den Client
 *  - expose: false → Client bekommt nur "INTERNAL_ERROR" + generische Meldung
 *  - Kein Stacktrace, keine internen Details im Client-Response
 *  - Kein Log-Output hier — das ist Aufgabe des HTTP-Handlers
 */

// ─── Fehlercodes ─────────────────────────────────────────────────────────────

export const ERROR_CODES = {
  VALIDATION_ERROR: "VALIDATION_ERROR",
  UNAUTHORIZED:     "UNAUTHORIZED",
  FORBIDDEN:        "FORBIDDEN",
  NOT_FOUND:        "NOT_FOUND",
  CONFLICT:         "CONFLICT",
  RATE_LIMITED:     "RATE_LIMITED",
  INTERNAL_ERROR:   "INTERNAL_ERROR",
} as const;

export type ErrorCode = (typeof ERROR_CODES)[keyof typeof ERROR_CODES];

// ─── HTTP-Status-Mapping ──────────────────────────────────────────────────────

export const ERROR_HTTP_STATUS: Readonly<Record<ErrorCode, number>> = {
  VALIDATION_ERROR: 400,
  UNAUTHORIZED:     401,
  FORBIDDEN:        403,
  NOT_FOUND:        404,
  CONFLICT:         409,
  RATE_LIMITED:     429,
  INTERNAL_ERROR:   500,
};

// ─── AppError ─────────────────────────────────────────────────────────────────

export interface AppErrorOptions {
  code: ErrorCode;
  message: string;
  /**
   * Wenn true: code und message werden an den Client weitergegeben.
   * Wenn false: Client erhält nur "INTERNAL_ERROR" + generische Nachricht.
   */
  expose?: boolean;
  /** Ursprünglicher Fehler — nie an den Client weitergegeben */
  cause?: unknown;
}

export class AppError extends Error {
  override readonly name = "AppError";
  readonly code: ErrorCode;
  readonly httpStatus: number;
  readonly expose: boolean;

  constructor(options: AppErrorOptions) {
    super(options.message);
    this.code = options.code;
    this.httpStatus = ERROR_HTTP_STATUS[options.code];
    this.expose = options.expose ?? true;
    if (options.cause !== undefined) {
      this.cause = options.cause;
    }
  }

  static validationError(message: string): AppError {
    return new AppError({ code: "VALIDATION_ERROR", message, expose: true });
  }

  static unauthorized(message = "Authentifizierung erforderlich"): AppError {
    return new AppError({ code: "UNAUTHORIZED", message, expose: true });
  }

  static forbidden(message = "Zugriff verweigert"): AppError {
    return new AppError({ code: "FORBIDDEN", message, expose: true });
  }

  static notFound(resource: string): AppError {
    return new AppError({
      code: "NOT_FOUND",
      message: `${resource} nicht gefunden`,
      expose: true,
    });
  }

  static conflict(message: string): AppError {
    return new AppError({ code: "CONFLICT", message, expose: true });
  }

  static rateLimited(message = "Zu viele Anfragen"): AppError {
    return new AppError({ code: "RATE_LIMITED", message, expose: true });
  }

  static internal(message: string, cause?: unknown): AppError {
    return new AppError({
      code: "INTERNAL_ERROR",
      message,
      expose: false, // interner Fehler wird NICHT exponiert
      cause,
    });
  }
}

// ─── Fehler-Response-Format ───────────────────────────────────────────────────

export interface ErrorResponse {
  error: {
    code: string;
    message: string;
  };
}

/**
 * Wandelt einen beliebigen Fehler in das API-Antwortformat um.
 *
 * Sicherheitsregel:
 *   - AppError mit expose=true: code und message werden weitergegeben
 *   - Alles andere: generische INTERNAL_ERROR-Antwort
 *   - Stacktraces, interne Details, Datenbankfehler: NIE im Response
 */
export function formatErrorResponse(err: unknown): {
  statusCode: number;
  body: ErrorResponse;
} {
  if (err instanceof AppError && err.expose) {
    return {
      statusCode: err.httpStatus,
      body: {
        error: {
          code: err.code,
          message: err.message,
        },
      },
    };
  }

  // Alle anderen Fehler: generische 500-Antwort
  return {
    statusCode: 500,
    body: {
      error: {
        code: ERROR_CODES.INTERNAL_ERROR,
        message: "Ein unerwarteter Fehler ist aufgetreten.",
      },
    },
  };
}

/**
 * Prüft ob ein Fehler sicher geloggt werden darf (kein sensibler Inhalt).
 * Für den Einsatz in Log-Writern.
 */
export function isSafeToLog(err: unknown): boolean {
  // AppError ist immer sicher zu loggen (kein sensitiver Inhalt im message-Feld)
  if (err instanceof AppError) return true;
  // Standard-Fehler: sicher, aber vorsichtig (kein Stacktrace-Weiterleitung)
  if (err instanceof Error) return true;
  return false;
}
