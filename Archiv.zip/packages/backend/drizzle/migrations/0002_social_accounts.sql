-- VYRO V1 — Migration 0002: Social Accounts
-- Adds table for linked TikTok/Instagram accounts.
-- Run after 0001_initial.sql.

CREATE TABLE social_accounts (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_profile_id  UUID NOT NULL REFERENCES creator_profiles(id),
  platform            creator_platform NOT NULL,
  provider_account_id TEXT NOT NULL,
  display_name        TEXT,
  username            TEXT,
  connected_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  disconnected_at     TIMESTAMPTZ,

  -- A provider account can only be actively linked once globally per platform
  UNIQUE (platform, provider_account_id)
);

CREATE INDEX social_accounts_profile_idx ON social_accounts(creator_profile_id);
