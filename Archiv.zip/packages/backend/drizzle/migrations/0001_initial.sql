-- VYRO V1 — Initiale Migration
-- Erstellt: 2025-01-01
-- Tabellen: 20
-- NICHT gegen Production ausführen ohne Backup

-- ── Enums ────────────────────────────────────────────────────────────────────

CREATE TYPE creator_platform      AS ENUM ('instagram', 'tiktok');
CREATE TYPE scan_status           AS ENUM ('accepted', 'processing', 'completed', 'failed');
CREATE TYPE criterion_state       AS ENUM ('fulfilled', 'partial', 'missing', 'unavailable');
CREATE TYPE observation_source    AS ENUM ('A', 'B', 'C');
CREATE TYPE finding_severity      AS ENUM ('foundation', 'lever', 'polish');
CREATE TYPE finding_status        AS ENUM ('open', 'completed', 'dismissed');
CREATE TYPE owner_type            AS ENUM ('user', 'anonymous');
CREATE TYPE action_type           AS ENUM ('fix_bio','fix_content','fix_feed','fix_branding','fix_profile_pic','fix_username','fix_engagement','rescan');
CREATE TYPE action_status         AS ENUM ('pending', 'completed', 'dismissed');
CREATE TYPE daily_task_status     AS ENUM ('pending', 'completed', 'skipped');
CREATE TYPE generated_item_type   AS ENUM ('bio', 'hook', 'caption', 'hashtags', 'content_idea');
CREATE TYPE subscription_status   AS ENUM ('trialing', 'active', 'past_due', 'canceled', 'expired');
CREATE TYPE subscription_provider AS ENUM ('apple_iap', 'google_play', 'stripe');
CREATE TYPE entitlement_source    AS ENUM ('subscription', 'trial', 'manual');
CREATE TYPE feature_key           AS ENUM ('scans','bio_generation','hook_generation','caption_generation','hashtag_generation','content_idea_generation','library_entries','full_insights');
CREATE TYPE audit_event_type      AS ENUM ('account_created','account_merged','account_deleted','session_created','session_revoked','subscription_activated','subscription_changed','entitlement_granted','entitlement_revoked','admin_viewed_user','data_export_requested','data_deletion_completed');
CREATE TYPE audit_actor_type      AS ENUM ('user', 'admin', 'system');
CREATE TYPE model_task_type       AS ENUM ('ocr', 'vision_observe', 'language_observe', 'language_generate', 'transcription');
CREATE TYPE upload_content_type   AS ENUM ('image/jpeg', 'image/png', 'image/heic', 'image/webp');

-- ── 1. users ─────────────────────────────────────────────────────────────────

CREATE TABLE users (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  apple_subject  TEXT UNIQUE,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at     TIMESTAMPTZ
);

-- ── 2. anonymous_sessions ────────────────────────────────────────────────────

CREATE TABLE anonymous_sessions (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  device_secret_hash    TEXT NOT NULL,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  last_seen_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at            TIMESTAMPTZ NOT NULL,
  merged_into_user_id   UUID REFERENCES users(id)
);
CREATE INDEX anon_sessions_expires_idx ON anonymous_sessions(expires_at);

-- ── 3. user_sessions ─────────────────────────────────────────────────────────

CREATE TABLE user_sessions (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id               UUID NOT NULL REFERENCES users(id),
  refresh_token_hash    TEXT NOT NULL,
  token_family_id       UUID NOT NULL,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at            TIMESTAMPTZ NOT NULL,
  revoked_at            TIMESTAMPTZ,
  replaced_by_session_id UUID
);
CREATE INDEX user_sessions_user_idx    ON user_sessions(user_id);
CREATE INDEX user_sessions_expires_idx ON user_sessions(expires_at);

-- ── 4. creator_profiles ──────────────────────────────────────────────────────
-- CHECK: abhängig von owner_type muss exakt user ODER anonymous ID gesetzt sein

CREATE TABLE creator_profiles (
  id                        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_type                owner_type NOT NULL,
  owner_user_id             UUID REFERENCES users(id),
  owner_anonymous_session_id UUID REFERENCES anonymous_sessions(id),
  platform                  creator_platform NOT NULL,
  created_at                TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at                TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT creator_owner_invariant CHECK (
    (owner_type = 'user'      AND owner_user_id IS NOT NULL AND owner_anonymous_session_id IS NULL) OR
    (owner_type = 'anonymous' AND owner_anonymous_session_id IS NOT NULL AND owner_user_id IS NULL)
  )
);
CREATE INDEX creator_profiles_user_idx ON creator_profiles(owner_user_id);
CREATE INDEX creator_profiles_anon_idx ON creator_profiles(owner_anonymous_session_id);

-- ── 5. scans ─────────────────────────────────────────────────────────────────

CREATE TABLE scans (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_profile_id    UUID NOT NULL REFERENCES creator_profiles(id),
  status                scan_status NOT NULL DEFAULT 'accepted',
  platform              creator_platform NOT NULL,
  scoring_model_version TEXT,
  pipeline_version      TEXT,
  coverage              NUMERIC(4,3),
  displayable           BOOLEAN,
  total_score           INTEGER,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at          TIMESTAMPTZ,
  failed_at             TIMESTAMPTZ,
  failure_code          TEXT
);
CREATE INDEX scans_profile_created_idx ON scans(creator_profile_id, created_at);

-- ── 6. uploaded_assets ───────────────────────────────────────────────────────

CREATE TABLE uploaded_assets (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  scan_id         UUID NOT NULL REFERENCES scans(id),
  storage_key     TEXT NOT NULL,
  content_type    upload_content_type NOT NULL,
  byte_size       INTEGER NOT NULL,
  perceptual_hash TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at      TIMESTAMPTZ NOT NULL,    -- NOT NULL: 24h-Datenschutzpflicht
  deleted_at      TIMESTAMPTZ
);
CREATE INDEX uploaded_assets_expires_idx ON uploaded_assets(expires_at);
CREATE INDEX uploaded_assets_scan_idx    ON uploaded_assets(scan_id);

-- ── 7. criterion_observations ────────────────────────────────────────────────
-- KEINE Punkte-Spalte — Punkte deterministisch aus State im Bewertungskern

CREATE TABLE criterion_observations (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  scan_id        UUID NOT NULL REFERENCES scans(id),
  criterion_id   TEXT NOT NULL,
  state          criterion_state NOT NULL,
  source         observation_source NOT NULL,
  model_version  TEXT,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (scan_id, criterion_id)    -- UNIQUE(scanId, criterionId)
);

-- ── 8. score_sets ────────────────────────────────────────────────────────────

CREATE TABLE score_sets (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  scan_id               UUID NOT NULL REFERENCES scans(id) UNIQUE,  -- UNIQUE(scanId)
  scoring_model_version TEXT NOT NULL,
  total_score           INTEGER NOT NULL,
  coverage              NUMERIC(4,3) NOT NULL,
  displayable           BOOLEAN NOT NULL,
  raw_payload_json      JSONB NOT NULL,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── 9. findings ──────────────────────────────────────────────────────────────

CREATE TABLE findings (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  scan_id               UUID NOT NULL REFERENCES scans(id),
  template_id           TEXT NOT NULL,
  severity              finding_severity NOT NULL,
  impact                INTEGER NOT NULL,
  priority              INTEGER NOT NULL,
  blocked_by_foundation BOOLEAN NOT NULL DEFAULT FALSE,
  finding_status        finding_status NOT NULL DEFAULT 'open',
  criterion_ids_json    JSONB,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX findings_scan_idx ON findings(scan_id);

-- ── 10. actions ──────────────────────────────────────────────────────────────

CREATE TABLE actions (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_profile_id UUID NOT NULL REFERENCES creator_profiles(id),
  source_finding_id  UUID REFERENCES findings(id),
  type              action_type NOT NULL,
  action_status     action_status NOT NULL DEFAULT 'pending',
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at      TIMESTAMPTZ
);

-- ── 11. daily_tasks ──────────────────────────────────────────────────────────

CREATE TABLE daily_tasks (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_profile_id UUID NOT NULL REFERENCES creator_profiles(id),
  action_id         UUID NOT NULL REFERENCES actions(id),
  assigned_date     TEXT NOT NULL,
  status            daily_task_status NOT NULL DEFAULT 'pending',
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX daily_tasks_profile_date_idx ON daily_tasks(creator_profile_id, assigned_date);

-- ── 12. generated_items ──────────────────────────────────────────────────────

CREATE TABLE generated_items (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_profile_id UUID NOT NULL REFERENCES creator_profiles(id),
  type              generated_item_type NOT NULL,
  content           TEXT NOT NULL,
  model_version     TEXT NOT NULL,
  prompt_version    TEXT NOT NULL,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── 13. library_entries ──────────────────────────────────────────────────────

CREATE TABLE library_entries (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_profile_id UUID NOT NULL REFERENCES creator_profiles(id),
  generated_item_id  UUID NOT NULL REFERENCES generated_items(id),
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── 14. subscriptions ────────────────────────────────────────────────────────

CREATE TABLE subscriptions (
  id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id                  UUID NOT NULL REFERENCES users(id),
  provider                 subscription_provider NOT NULL,
  provider_customer_id     TEXT,
  provider_subscription_id TEXT,
  status                   subscription_status NOT NULL,
  current_period_end       TIMESTAMPTZ,
  created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── 15. entitlements ─────────────────────────────────────────────────────────

CREATE TABLE entitlements (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES users(id),
  feature_key feature_key NOT NULL,
  active      BOOLEAN NOT NULL DEFAULT FALSE,
  source      entitlement_source NOT NULL,
  expires_at  TIMESTAMPTZ,
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (user_id, feature_key)    -- UNIQUE(userId, featureKey)
);

-- ── 16. usage_counters ───────────────────────────────────────────────────────

CREATE TABLE usage_counters (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_type  owner_type NOT NULL,
  owner_id    TEXT NOT NULL,
  feature_key feature_key NOT NULL,
  period_key  TEXT NOT NULL,
  count       INTEGER NOT NULL DEFAULT 0,
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (owner_type, owner_id, feature_key, period_key)    -- UNIQUE
);

-- ── 17. idempotency_keys ─────────────────────────────────────────────────────

CREATE TABLE idempotency_keys (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_key           TEXT NOT NULL,
  idempotency_key     TEXT NOT NULL,
  request_fingerprint TEXT NOT NULL,
  response_status     INTEGER,
  response_body_json  JSONB,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at          TIMESTAMPTZ NOT NULL,    -- NOT NULL
  UNIQUE (owner_key, idempotency_key)    -- UNIQUE
);
CREATE INDEX idempotency_keys_expires_idx ON idempotency_keys(expires_at);

-- ── 18. audit_events ─────────────────────────────────────────────────────────

CREATE TABLE audit_events (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_type    audit_actor_type NOT NULL,
  actor_id      TEXT,
  event_type    audit_event_type NOT NULL,
  subject_type  TEXT,
  subject_id    TEXT,
  metadata_json JSONB NOT NULL DEFAULT '{}',
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX audit_events_created_idx ON audit_events(created_at);
CREATE INDEX audit_events_actor_idx   ON audit_events(actor_id);

-- ── 19. model_versions ───────────────────────────────────────────────────────

CREATE TABLE model_versions (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  task_type      model_task_type NOT NULL,
  provider       TEXT NOT NULL,
  model_id       TEXT NOT NULL,
  prompt_version TEXT,
  active_from    TIMESTAMPTZ NOT NULL,
  retired_at     TIMESTAMPTZ
);

-- ── 20. pipeline_versions ────────────────────────────────────────────────────

CREATE TABLE pipeline_versions (
  version     TEXT PRIMARY KEY,
  description TEXT NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
