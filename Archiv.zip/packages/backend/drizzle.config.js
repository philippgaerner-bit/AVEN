/** @type {import('drizzle-kit').Config} */
export default {
  schema:    "./src/db/drizzle-schema.ts",
  out:       "./drizzle/migrations",
  dialect:   "postgresql",
  dbCredentials: {
    url: process.env["DATABASE_URL"] ?? "postgresql://localhost:5432/vyro_dev",
  },
};
